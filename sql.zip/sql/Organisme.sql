INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(0,'Alliance Consulting & Co','Service commercial','Vertex Solutions','04399361482899'),
(1,'Alliance Consulting Expert','Service public','Finance Conseil','61449160181184');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(2,'Alliance Corporation Plus','Centre social','Association Solidarité','99681039770865'),
(3,'Alliance Développement Europe','Entreprise de télécommunications','Livraison Express','83749606723106');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(4,'Alliance Développement Plus','Organisme professionnel','Menuiserie Dupont','35696983511650'),
(5,'Alliance Expertise','Société coopérative','Artisanat France','64657027681310');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(6,'Alliance Expertise & Co','Agence de communication','Proxima Services','51583517557475'),
(7,'Alliance Formation & Co','Administration publique','Green Power Solutions','41153586627347');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(8,'Alliance Formation Europe','Bureau d’études','Formation Plus','49547411879760'),
(9,'Alliance Formation France','Marketplace','Eco Energie Solutions','14456675474164');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(10,'Alliance Formation Global','Marketplace','Eureka Formation','55135109961992'),
(11,'Alliance Gestion Expert','Ordre des médecins','Voyage & Découverte','94463675653457');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(12,'Alliance Gestion France','Centre médical','Smart Solutions','50903491136764'),
(13,'Alliance Gestion Plus','Organisation','Hygiène Solutions','37369492774818');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(14,'Alliance Group','Chambre de commerce','Santé Services','45492468114566'),
(15,'Alliance Group Expert','Agence','Voyage & Découverte','64395976320391');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(16,'Alliance Industries Plus','Hôtel','Dynamic Consulting','54947427460121'),
(17,'Alliance Innovations Global','Association','Vignoble Prestige','12131340525796');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(18,'Alliance International','Pharmacie','Bâtiment Conseil','24045470964623'),
(19,'Alliance Services Europe','Artisan','Cloud Services Group','97972248625762');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(20,'Alliance Solutions','Cabinet d’avocats','Entreprise Régionale Plus','46375189170439'),
(21,'Alliance Solutions & Co','Groupement d’intérêt économique','Pôle Compétitivité Tech','04192764534790');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(22,'Alliance Solutions France','Conseil municipal','System Consulting','12070770097552'),
(23,'Alliance Systèmes & Co','Organisme professionnel','Association Culturelle Plus','34155561754951');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(24,'Alliance Systèmes Global','Incubateur','Design Solutions','31755974540812'),
(25,'Alliance Technologies Expert','Organisation syndicale','Leader Consulting','87426415813850');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(26,'Alpha Conseil','Boutique','Delta Conseil','66993280797290'),
(27,'Alpha Développement','Organisme professionnel','Initiative Conseil','89871930904161');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(28,'Alpha Développement Europe','Institution culturelle','Fondation Avenir','13353058135321'),
(29,'Alpha Développement Global','Boutique','Énergie France Services','70166949409410');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(30,'Alpha Expertise','Domain viticole','Market France','05343618852979'),
(31,'Alpha Expertise & Co','Réseau professionnel','Supply Chain Group','49813822243929');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(32,'Alpha Expertise Expert','Accélérateur','Clean Services','77868772018216'),
(33,'Alpha Expertise France','Organisme social','BlueSky Consulting','88505198985503');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(34,'Alpha Formation & Co','Plateforme en ligne','Eco Services France','11249968465613'),
(35,'Alpha Formation Plus','Établissement bancaire','Audit & Conseil','03272509017675');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(36,'Alpha France Europe','Institut','Orion Conseil','49983789689029'),
(37,'Alpha France Expert','Bureau de contrôle','Restaurant du Parc','57747469825298');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(38,'Alpha Industries Europe','Chambre de commerce','Cargo Solutions','76501664744515'),
(39,'Alpha Industries France','École d’ingénieurs','Nettoyage Plus','39436973556770');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(40,'Alpha Industries Pro','Grande surface','Focus Expertise','11817269176120'),
(41,'Alpha International France','Établissement public','Dynamic Consulting','53802769473829');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(42,'Alpha Partners France','Centre technique','Agence Immo Plus','77758640755640'),
(43,'Alpha Services','Université','Logiciel Plus','27878674792420');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(44,'Alpha Services France','Société d’investissement','Brand Consulting','44416266079427'),
(45,'Alpha Services Pro','Préfecture','Agence Immo Plus','34003288118378');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(46,'Alpha Solutions Plus','Agence de communication','Pub & Marketing','40898525591078'),
(47,'Alpha Systèmes Europe','Multinationale','NetPlus Services','53164655097189');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(48,'Alpha Systèmes France','Établissement bancaire','Pub & Marketing','07636601385786'),
(49,'Alpha Systèmes Plus','Organisme de financement','Initiative Conseil','93107964729076');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(50,'Ambition Consulting Plus','Centre culturel','Rénovation Experts','33461387233745'),
(51,'Ambition Consulting Pro','Laboratoire d’analyses','Centre Recherche France','41481215394554');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(52,'Ambition Corporation','Fondation','SoftTech Consulting','48644541941466'),
(53,'Ambition Expertise Pro','Service public','Compagnie Générale Services','39882556354758');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(54,'Ambition Formation Expert','Commerce','Stratégie Plus','16256688781404'),
(55,'Ambition Formation Plus','Ordre des experts-comptables','Green Power Solutions','33331784273428');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(56,'Ambition France & Co','Institution culturelle','BTP Services France','89426130307217'),
(57,'Ambition France Pro','Mission locale','Master Conseil','66772793497874');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(58,'Ambition Gestion Pro','Centre de loisirs','Avenir Formation','73132517245938'),
(59,'Ambition Group Expert','Association culturelle','Brand Consulting','73702337499955');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(60,'Ambition Innovations','Entreprise de logistique','Tech Innov Solutions','01881288734260'),
(61,'Ambition International Expert','Établissement de santé','Premium Services','35532681481476');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(62,'Ambition Partners Europe','Entreprise individuelle','Impulse Consulting','02989503798879'),
(63,'Ambition Solutions France','Pôle de compétitivité','ONG Aide Internationale','96660041572770');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(64,'Ambition Solutions Global','Établissement financier','Fondation Espoir','51332772575456'),
(65,'Ambition Systèmes France','Conseil','Studio Créatif','04933542923867');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(66,'Ambition Technologies Global','Cabinet de conseil','Société Nouvelle Horizon','42423456449363'),
(67,'Atlas Conseil France','PME','Forward Services','15057472504818');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(68,'Atlas Consulting & Co','Plateforme en ligne','Web Innov Agency','52239108080847'),
(69,'Atlas Consulting Expert','Association environnementale','Holding Avenir','37349711245757');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(70,'Atlas Consulting Global','Cabinet de conseil','Terra Conseil','89108936240483'),
(71,'Atlas Corporation','Office','Restauration Plus','02631834868093');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(72,'Atlas Développement & Co','Cabinet médical','Clarté Consulting','61304066737783'),
(73,'Atlas Développement Expert','Office public','Gestion Finance Plus','16580191851743');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(74,'Atlas Développement Pro','Établissement scolaire','Réseau Performance','00118996279710'),
(75,'Atlas Expertise Expert','Vignoble','Expertis Consulting','63537773067099');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(76,'Atlas Expertise Pro','Entreprise','Leader Consulting','89109660249632'),
(77,'Atlas Formation','Club privé','Forward Services','79233916970452');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(78,'Atlas Formation Plus','Mairie','Hôtellerie Prestige','66097299421300'),
(79,'Atlas Formation Pro','Centre d’appel','Food Services Group','71269410188372');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(80,'Atlas France Plus','Administration','Transport Services','97987060916991'),
(81,'Atlas Group Pro','Réseau professionnel','Domaine des Vignes','70948438523478');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(82,'Atlas Industries','Société de transport','SoftTech Consulting','59448411073455'),
(83,'Atlas Industries & Co','Ministère','Urban Immo Group','31183394641169');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(84,'Atlas Industries Plus','Commerçant','BTP Services France','93315180064285'),
(85,'Atlas Innovations','Société','Bien-être Solutions','98290692536833');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(86,'Atlas Innovations Plus','Entreprise innovante','Société Centrale Conseil','61497529189508'),
(87,'Atlas International Europe','Café','Proxima Services','03888827300619');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(88,'Atlas International Pro','Autorité de régulation','Smart Solutions','90772791077080'),
(89,'Atlas Partners Plus','Artisan','Avenir Formation','07108561891730');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(90,'Atlas Services Plus','Autorité de régulation','Groupe National Services','37776283698764'),
(91,'Atlas Solutions Plus','Centre de formation','System Consulting','23141650963720');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(92,'Atlas Systèmes Expert','Centre hospitalier','Livraison Express','74152227083273'),
(93,'Atlas Systèmes Global','Centre de bien-être','Observatoire Économique','43858819247990');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(94,'Atlas Technologies','Site e-commerce','Nova Consulting','65980251702083'),
(95,'Avenir Conseil Expert','Établissement financier','Groupe Évolution','06166384849267');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(96,'Avenir Consulting','Agence de voyage','Fiscal Conseil','69491791384687'),
(97,'Avenir Corporation','Entreprise de BTP','Excellence Conseil','03202068984907');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(98,'Avenir Corporation Expert','Hôpital','Sport & Fitness','23846359579224'),
(99,'Avenir Corporation Global','Établissement','Médical Plus','05794491091924');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(100,'Avenir Développement France','Entreprise innovante','Société Centrale Conseil','52530982385282'),
(101,'Avenir Développement Plus','Centre technique','CyberTech Consulting','16893705681791');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(102,'Avenir Expertise Europe','Cabinet médical','Prime Conseil','89302469614195'),
(103,'Avenir Formation Expert','Coopérative','Proxima Services','60740479131085');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(104,'Avenir Gestion Expert','Société','Alliance Conseil','44819824444190'),
(105,'Avenir Group Expert','Agence digitale','Académie France','62794039477565');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(106,'Avenir Group Plus','Laboratoire de recherche','Logistique France','27148125844214'),
(107,'Avenir Industries & Co','Micro-entreprise','Recyclage Services','11970342972165');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(108,'Avenir Innovations','Institut','Data Solutions France','13091849942498'),
(109,'Avenir Innovations Plus','Restaurant','Innova Services','04767778352439');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(110,'Avenir Partners France','Société d’investissement','Data Solutions France','09815266641600'),
(111,'Avenir Partners Pro','Entreprise de construction','Association Solidarité','07400761874489');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(112,'Avenir Services France','Fondation reconnue d’utilité publique','Focus Expertise','83299600836192'),
(113,'Avenir Services Plus','Coopérative de production','Talent Consulting','83256242986570');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(114,'Avenir Solutions Expert','École privée','OpenMind Conseil','30406762587990'),
(115,'Avenir Systèmes France','Organisme social','Eureka Formation','54974177731292');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(116,'Avenir Systèmes Pro','Réseau associatif','Pâtisserie Gourmande','61489300054250'),
(117,'Avenir Technologies France','Cluster','Développement Durable France','19534826539155');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(118,'Concept Conseil Expert','Club privé','Zenith Consulting','68879093253812'),
(119,'Concept Conseil Global','Plateforme en ligne','Bio Solutions Group','13481978255026');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(120,'Concept Consulting Europe','Service public','Cargo Solutions','40889959274644'),
(121,'Concept Corporation & Co','Entreprise solidaire','Eco Services France','94222613091131');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(122,'Concept Corporation Expert','Cabinet médical','Livraison Express','58304118838276'),
(123,'Concept Corporation France','Commerçant','Groupe Synergie','01012309236419');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(124,'Concept Expertise','Établissement','Vignoble Prestige','04068641245294'),
(125,'Concept Expertise Global','Organisme financier','Cargo Solutions','28024447286655');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(126,'Concept Expertise Pro','Bureau de contrôle','Hôtellerie Prestige','03148996672991'),
(127,'Concept Formation Global','Café','Laboratoire Innovation','00153179956293');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(128,'Concept Formation Plus','Fondation d’entreprise','Rénovation Experts','77346357025442'),
(129,'Concept Gestion Expert','Conseil municipal','Global Services Group','74882690982102');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(130,'Concept Gestion Pro','Entreprise publique','Data Solutions France','85684001519316'),
(131,'Concept Group & Co','Hôtel','Transport Services','94161378720595');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(132,'Concept Group Europe','Caisse d’assurance','Zenith Consulting','40807999152837'),
(133,'Concept Group France','Holding','Green Power Solutions','71831661402415');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(134,'Concept Industries Expert','Conseil départemental','Consulting Partners','84974197579515'),
(135,'Concept Innovations','Pôle de compétitivité','Développement Durable France','56462568808178');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(136,'Concept Innovations France','Organisation internationale','Voyage & Découverte','12643621546831'),
(137,'Concept International Global','Ministère','Cap Excellence','25050207471864');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(138,'Concept Services France','Cabinet d’architectes','Pâtisserie Gourmande','47727079960160'),
(139,'Concept Services Global','Structure d’insertion','Smart Digital Group','01486803022718');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(140,'Concept Technologies & Co','Association sportive','Agence Immo Plus','69142467163095'),
(141,'Delta Consulting','École supérieure','Académie France','41907684953303');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(142,'Delta Corporation','Office','Techno Conseil','72621772576158'),
(143,'Delta Développement Expert','Club privé','Bâtiment Conseil','71577020945608');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(144,'Delta Expertise & Co','Chambre','Auto Plus France','28140405633832'),
(145,'Delta Expertise France','Collectivité territoriale','First Consulting','43220904942193');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(146,'Delta Formation & Co','Club privé','Tech Innov Solutions','15466058594948'),
(147,'Delta France Plus','Société anonyme','Event Solutions','22053462408242');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(148,'Delta Group Expert','Hypermarché','CodeFactory','73174539593818'),
(149,'Delta Industries & Co','Hypermarché','System Consulting','41386596393397');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(150,'Delta Industries France','Centre médical','Immobilier Conseil','86083128840599'),
(151,'Delta Industries Plus','Micro-entreprise','First Consulting','75542339943998');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(152,'Delta Innovations Expert','Ferme','Fondation Avenir','38370712391707'),
(153,'Delta Innovations France','Groupement','Société Centrale Conseil','51234437091275');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(154,'Delta International','Fondation reconnue d’utilité publique','Performance Conseil','19147412962598'),
(155,'Delta Partners Plus','Organisme privé','Leader Consulting','75299182305257');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(156,'Delta Solutions France','Entreprise sociale','Optima Gestion','08607004378609'),
(157,'Delta Solutions Pro','Établissement scolaire','Santé Services','87460743860889');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(158,'Delta Systèmes & Co','Organisme de recherche','Terra Conseil','34558486411016'),
(159,'Delta Systèmes Europe','Groupement d’intérêt économique','Pâtisserie Gourmande','56612234223008');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(160,'Delta Systèmes Expert','École de commerce','Groupe National Services','60298530819197'),
(161,'Delta Systèmes France','Établissement scolaire','Livraison Express','37552528926266');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(162,'Delta Technologies','Entreprise artisanale','SoluTech','46068154886496'),
(163,'Delta Technologies France','Cabinet comptable','Communication Plus','52082105659342');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(164,'Delta Technologies Pro','Service administratif','Clarté Consulting','16133533876138'),
(165,'Dynamic Consulting Europe','Auto-entrepreneur','Holding Avenir','26941277422612');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(166,'Dynamic Corporation Expert','Association','Fondation Espoir','87135024521662'),
(167,'Dynamic Corporation Plus','Café','Bâtiment Conseil','26095323755123');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(168,'Dynamic Expertise Plus','Centre de loisirs','Performance Conseil','64306461991608'),
(169,'Dynamic Formation Europe','Caisse de retraite','Hôtel du Centre','80042819612264');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(170,'Dynamic Formation Global','Entreprise de sécurité','Ferme du Val','80945926154249'),
(171,'Dynamic Group Pro','Administration territoriale','Nova Consulting','73769844515967');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(172,'Dynamic Industries Expert','Centre de bien-être','Future Solutions','18694862411442'),
(173,'Dynamic Industries Plus','Banque en ligne','Omni Services','26631432173881');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(174,'Dynamic Innovations','Autorité de régulation','Atelier Création','54080687710457'),
(175,'Dynamic Innovations & Co','Organisme','Association Solidarité','63770485440118');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(176,'Dynamic Innovations Pro','Entreprise publique','Événementiel Plus','90233463546827'),
(177,'Dynamic International & Co','Entreprise privée','Académie France','28760338386037');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(178,'Dynamic International Europe','Ferme','Groupe Synergie','57289393254432'),
(179,'Dynamic International Global','Chambre d’agriculture','Immo Gestion Services','14218161543295');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(180,'Dynamic International Pro','Institution publique','Excellence Conseil','30263539970757'),
(181,'Dynamic Partners','Supermarché','Expertis Consulting','48086530719852');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(182,'Dynamic Partners & Co','Club','Brand Consulting','65420078562447'),
(183,'Dynamic Partners Global','Salle de sport','Terra Conseil','87953838272165');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(184,'Dynamic Partners Plus','Autorité administrative','Dynamic Consulting','97426970309110'),
(185,'Dynamic Services & Co','Groupement','Groupe Horizon','55233143714153');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(186,'Dynamic Services Pro','Cabinet d’avocats','Hôtellerie Prestige','66101145700887'),
(187,'Dynamic Solutions France','Entreprise de logistique','Cloud Services Group','07998403454940');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(188,'Dynamic Technologies Expert','Société par actions simplifiée','Société Nouvelle Horizon','51172662571021'),
(189,'Eco Conseil Expert','Entreprise informatique','Business Solutions','02714539648145');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(190,'Eco Consulting Europe','Agence web','Studio Créatif','19357151305722'),
(191,'Eco Consulting Plus','Conseil municipal','Groupe National Services','06879811557359');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(192,'Eco Développement Plus','Coopérative','First Consulting','14965734356754'),
(193,'Eco Expertise Expert','Autorité administrative','Eureka Formation','50364560104206');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(194,'Eco Expertise France','Établissement public','Forward Services','79669860060726'),
(195,'Eco Formation Europe','Site e-commerce','Alliance Conseil','00842088509450');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(196,'Eco Formation Global','Entreprise de sécurité','Communication Plus','63226310861529'),
(197,'Eco Formation Plus','Établissement public','Talent Consulting','87531683428372');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(198,'Eco France Expert','Organisme','Tech Innov Solutions','67911166843544'),
(199,'Eco France France','Institut de formation','Bâtiment Conseil','92514660866955');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(200,'Eco France Plus','Bureau d’études','Pro Active Consulting','31075462612220'),
(201,'Eco Group & Co','Boutique','Recyclage Services','67175931110744');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(202,'Eco Innovations & Co','Agence d’intérim','Communication Plus','35941676081099'),
(203,'Eco International France','Société industrielle','Immo Gestion Services','56136975442614');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(204,'Eco International Pro','Conseil municipal','Cap Excellence','96125802314241'),
(205,'Eco Partners Europe','ONG','Café du Centre SARL','90871596711465');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(206,'Eco Partners Global','Autorité de régulation','Tourisme Services','75448113486823'),
(207,'Eco Partners Plus','Structure d’insertion','Groupe International Services','63096316539743');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(208,'Eco Services Plus','Agence immobilière','Nettoyage Plus','68757832328008'),
(209,'Eco Solutions Europe','Club','Capital Consulting','41156100500573');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(210,'Eco Solutions Pro','Autorité indépendante','Objectif Performance','22081621286772'),
(211,'Eco Systèmes','École','Pub & Marketing','30709382432796');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(212,'Eco Systèmes & Co','ONG','Sureté Conseil','28763516626342'),
(213,'Eco Systèmes France','Organisation professionnelle','SoluTech','67491822757258');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(214,'Eco Systèmes Global','Supermarché','Vignoble Prestige','96820569738597'),
(215,'Eco Technologies','Autorité administrative','Corporate Services','59610427307900');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(216,'Eureka Conseil Plus','Spa','Réseau Digital','05155543066331'),
(217,'Eureka Consulting','Coopérative agricole','Optima Gestion','00923711330753');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(218,'Eureka Corporation','Conseil régional','Sport & Fitness','42342055637983'),
(219,'Eureka Corporation Expert','Entreprise de BTP','OpenMind Conseil','74125656280773');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(220,'Eureka Corporation Global','Mission locale','Master Conseil','69082429466628'),
(221,'Eureka Développement & Co','Bureau d’études','Compagnie Générale Services','71949821280048');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(222,'Eureka Développement Plus','Réseau','Invest Group France','59317681145042'),
(223,'Eureka Expertise Global','Entreprise de rénovation','Réseau Digital','19508740624589');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(224,'Eureka Expertise Pro','Société coopérative','Cargo Solutions','50618765333953'),
(225,'Eureka Formation','Fondation reconnue d’utilité publique','Hygiène Solutions','63288896308380');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(226,'Eureka Formation Global','Entreprise de BTP','Objectif Performance','93605177374058'),
(227,'Eureka Formation Pro','Chambre','Prime Conseil','58355849470625');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(228,'Eureka France & Co','Réseau','Communication Plus','17375712988549'),
(229,'Eureka France Pro','Ordre professionnel','Groupe National Services','25196903640816');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(230,'Eureka Gestion','Institut de beauté','Artisanat France','52175459275274'),
(231,'Eureka Gestion & Co','Fondation reconnue d’utilité publique','Travaux & Co','53733573056682');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(232,'Eureka Group','Société informatique','Performance Conseil','03985212408085'),
(233,'Eureka Group Expert','Entreprise artisanale','First Consulting','10751389196609');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(234,'Eureka Group France','Société informatique','Smart Solutions','92586151047963'),
(235,'Eureka Group Pro','Caisse d’assurance','ONG Aide Internationale','60235376513846');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(236,'Eureka Industries Global','Conseil régional','Société Nouvelle Horizon','84054631721890'),
(237,'Eureka Innovations Europe','Centre de formation','SoftTech Consulting','17302322579724');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(238,'Eureka Innovations Global','Office','Artisanat France','96426070454139'),
(239,'Eureka Partners Europe','Ordre des médecins','Atlas Consulting','10469355224372');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(240,'Eureka Partners Pro','Salle de sport','Élan Conseil','75642636415619'),
(241,'Eureka Systèmes','Vignoble','Invest Group France','70810824136330');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(242,'Eureka Systèmes France','École supérieure','Pub & Marketing','23655018182408'),
(243,'Eureka Systèmes Global','Association loi 1901','Travaux & Co','02366095985104');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(244,'Eureka Technologies France','Réseau associatif','Distribution Services','50674374221929'),
(245,'Eureka Technologies Pro','Entreprise de sécurité','Accélérateur Business','48725290555770');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(246,'Excellence Conseil Expert','Société de services','Vision & Co','70262813537899'),
(247,'Excellence Conseil France','École','Forward Services','42636964278858');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(248,'Excellence Consulting Europe','Syndicat','Logiciel Plus','53466785413942'),
(249,'Excellence Consulting France','Commerce','Techno Conseil','03791451750018');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(250,'Excellence Consulting Pro','Établissement bancaire','BTP Services France','85706386257057'),
(251,'Excellence Corporation','Agence d’intérim','École Supérieure Plus','10669337115548');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(252,'Excellence Corporation Plus','Institution éducative','Ferme du Val','51935211222431'),
(253,'Excellence Développement & Co','École publique','Finance Conseil','16223683886004');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(254,'Excellence Développement Plus','Institution','Transport Services','72856176854776'),
(255,'Excellence Développement Pro','Entreprise de nettoyage','Tech Innov Solutions','75829901959158');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(256,'Excellence Expertise France','Club','Culture & Loisirs','69968305045927'),
(257,'Excellence Expertise Global','Société informatique','Café du Centre SARL','69292028535421');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(258,'Excellence Expertise Plus','Startup technologique','CyberTech Consulting','96259045705699'),
(259,'Excellence Formation','Établissement bancaire','Digital Factory','66490538741474');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(260,'Excellence Formation France','Mission locale','Hygiène Solutions','59681379192906'),
(261,'Excellence Formation Global','Caisse d’assurance','Web Innov Agency','50042931248630');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(262,'Excellence France & Co','Centre d’affaires','Immobilier Conseil','33010868986528'),
(263,'Excellence Gestion & Co','Hôtel','Design Solutions','21888130721277');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(264,'Excellence Gestion Expert','Micro-entreprise','Event Solutions','89010093769854'),
(265,'Excellence Gestion France','École de commerce','Bien-être Solutions','97643455110675');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(266,'Excellence Gestion Plus','Préfecture','Delta Conseil','54780409375281'),
(267,'Excellence Group France','Institution culturelle','Transport Services','78430858226677');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(268,'Excellence Group Global','Association caritative','Capital Consulting','95946897266270'),
(269,'Excellence Industries','Entreprise de BTP','Urban Conseil','32532372154806');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(270,'Excellence Industries Global','Organisme financier','Clinique du Parc','36325326133495'),
(271,'Excellence International Europe','Agence','Logiciel Plus','68966090312222');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(272,'Excellence International Expert','Groupement d’intérêt économique','Green Power Solutions','17777433092494'),
(273,'Excellence International Global','Auto-entrepreneur','Stratégie Plus','35428096111808');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(274,'Excellence Partners','Agence de recrutement','Gourmet Services','41210500571909'),
(275,'Excellence Partners Expert','Conseil municipal','NetPlus Services','18221212015015');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(276,'Excellence Partners Global','Agence d’intérim','Corporate Services','25107111574378'),
(277,'Excellence Solutions Europe','Établissement de santé','Boulangerie du Centre','51587134994419');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(278,'Excellence Solutions France','Bureau de contrôle','Culture & Loisirs','73747710261601'),
(279,'Excellence Systèmes France','Association sportive','Sigma Solutions','06129722967223');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(280,'Excellence Systèmes Plus','Hôtel','Restaurant du Parc','62520540599126'),
(281,'Excellence Systèmes Pro','Entreprise solidaire','Impact Solutions','84279885992108');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(282,'Excellence Technologies Europe','Société de gestion','Optimum Conseil','86162896503749'),
(283,'Excellence Technologies France','Clinique','Entreprise Moderne France','22636952830256');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(284,'Future Conseil','Centre de formation','Institut Formation Pro','92424293989430'),
(285,'Future Conseil Europe','Établissement bancaire','Global Services Group','34439155465528');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(286,'Future Conseil Pro','Fédération','Impulse Consulting','69438426638804'),
(287,'Future Corporation Europe','Agence gouvernementale','Green Power Solutions','45628424244485');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(288,'Future Corporation Pro','Fondation','Protect France','59293762708920'),
(289,'Future Développement & Co','Entreprise innovante','Tourisme Services','24437764919259');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(290,'Future Développement Expert','Université','Expertis Consulting','79030504363161'),
(291,'Future Expertise','Établissement privé','Brand Consulting','61007315032106');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(292,'Future Expertise France','Filiale','Think Tank France','82556259419753'),
(293,'Future Formation & Co','Grande surface','Digital Factory','73230881841317');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(294,'Future Formation Pro','Organisation professionnelle','Infotech Solutions','13450354766680'),
(295,'Future Gestion France','Chambre d’agriculture','Garage Auto Services','93625291688863');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(296,'Future Gestion Pro','Domain viticole','Concept Développement','52165037184679'),
(297,'Future Group France','Établissement de santé','IT Performance Group','75099657772939');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(298,'Future Industries Expert','École publique','Atelier Création','17724572131739'),
(299,'Future Innovations','Commerce','Finance Conseil','76589521170714');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(300,'Future International Expert','Agence marketing','Société Nouvelle Horizon','07225838438331'),
(301,'Future Partners & Co','Agence web','Excellence Conseil','79176456950886');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(302,'Future Partners France','Mairie','Dynamik Solutions','03945013125709'),
(303,'Future Services Expert','Bureau de contrôle','Groupe International Services','42391623805257');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(304,'Future Solutions & Co','Bureau','Brand Consulting','87265695345639'),
(305,'Future Systèmes France','Centre','Culture & Loisirs','36393128995788');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(306,'Future Systèmes Global','Centre d’affaires','Société Européenne Conseil','04858239433853'),
(307,'Future Systèmes Pro','Collectivité','Domaine des Vignes','67271733782064');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(308,'Future Technologies Plus','Organisation non gouvernementale','Gestion Finance Plus','45235659376794'),
(309,'Global Consulting France','Administration publique','Holding Avenir','18275124976087');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(310,'Global Consulting Global','PME','IT Performance Group','38365428429365'),
(311,'Global Corporation & Co','Autorité administrative','Alliance Conseil','90862679293134');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(312,'Global Corporation Europe','Confédération','Bâtiment Conseil','28079782786905'),
(313,'Global Corporation Global','Fédération','Association Solidarité','05623299936740');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(314,'Global Développement Global','Pépinière d’entreprises','Cluster Innovation','46725745934509'),
(315,'Global Développement Pro','Association humanitaire','System Consulting','70191283341225');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(316,'Global Expertise','Entreprise de rénovation','Entreprise Française Innovation','06738298796745'),
(317,'Global Expertise Plus','Cabinet d’architectes','Patrimoine Conseil','39703903829384');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(318,'Global France Europe','Entreprise individuelle','Digital Factory','21296753368627'),
(319,'Global Gestion','École publique','Société Européenne Conseil','77118397377467');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(320,'Global Gestion & Co','Pépinière d’entreprises','Fiscal Conseil','01142748713537'),
(321,'Global Gestion Expert','Organisation professionnelle','Forward Services','83783396319333');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(322,'Global Group','Centre technique','Restauration Plus','33456434051823'),
(323,'Global Industries & Co','Observatoire','Techno Conseil','77526032345373');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(324,'Global Industries France','Association loi 1901','Cap Excellence','90665654038156'),
(325,'Global International & Co','Auto-entrepreneur','SoftTech Consulting','94732443643407');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(326,'Global Partners','Fondation d’entreprise','Ferme du Val','78276249854379'),
(327,'Global Services Expert','Entreprise innovante','Business Solutions','33384004795130');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(328,'Global Solutions Expert','Institution financière','Impact Solutions','28239810875628'),
(329,'Global Solutions Pro','Café','Vision & Co','58777387511453');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(330,'Green Conseil','Vignoble','BlueSky Consulting','84127448240831'),
(331,'Green Conseil & Co','Office','Rénovation Experts','28522562461526');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(332,'Green Conseil Europe','Cluster','Urban Immo Group','37792218935902'),
(333,'Green Conseil Pro','Organisation humanitaire','System Consulting','04204482194767');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(334,'Green Consulting Expert','Agence de communication','NetPlus Services','80363309827082'),
(335,'Green Consulting Plus','Pépinière d’entreprises','Institut Formation Pro','36830142912404');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(336,'Green Corporation France','Office de tourisme','Groupe Évolution','56190038125021'),
(337,'Green Corporation Global','Observatoire','Agence Immo Plus','42153780131987');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(338,'Green Corporation Pro','Cabinet d’avocats','Ambition Services','91276705067585'),
(339,'Green Développement France','Salon de coiffure','OpenMind Conseil','21310966235610');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(340,'Green Expertise','Caisse de retraite','Tourisme Services','97582084845171'),
(341,'Green Formation','Organisme social','Expert Compta Group','14691378790983');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(342,'Green Formation & Co','Institut de recherche','Compagnie Générale Services','36746791553410'),
(343,'Green Formation Global','Institution publique','Impact Solutions','46651674346388');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(344,'Green Formation Plus','Institut de beauté','BlueSky Consulting','34180529403156'),
(345,'Green Gestion','Organisation syndicale','Corporate Services','74967557791205');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(346,'Green Gestion France','Entreprise artisanale','Insight Consulting','51589061050256'),
(347,'Green Group Plus','Entreprise de services numériques','Cluster Innovation','06994260632036');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(348,'Green Industries Europe','Organisme professionnel','Supply Chain Group','78685494216147'),
(349,'Green Industries Expert','Salon de coiffure','Vignoble Prestige','68147641245407');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(350,'Green Industries France','Agence digitale','Food Services Group','66439051956773'),
(351,'Green Innovations & Co','Auto-entrepreneur','Terra Conseil','53979592641910');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(352,'Green Partners Pro','Université','Sigma Solutions','46180761452954'),
(353,'Green Services Pro','Ordre des avocats','Vignoble Prestige','92151142733272');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(354,'Green Solutions & Co','Organisme social','Pharma Services','86099147655715'),
(355,'Green Systèmes Pro','Artisan','Association Solidarité','43707705859744');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(356,'Hexa Conseil France','Agence immobilière','Artisanat France','08843424761769'),
(357,'Hexa Consulting','Artisan','Corporate Services','93306917629249');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(358,'Hexa Consulting Expert','Artisan','Stratégie Plus','49693311093095'),
(359,'Hexa Consulting Global','Incubateur','Clinique du Parc','07736383006587');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(360,'Hexa Corporation','Agence de communication','Coopérative Agricole France','98522654039404'),
(361,'Hexa Développement','Institut de recherche','Supply Chain Group','47909535519874');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(362,'Hexa Développement Europe','Caisse','Société Européenne Conseil','64587119408168'),
(363,'Hexa Développement Expert','Clinique','RH Solutions','50608805194637');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(364,'Hexa Développement Global','Institut de beauté','Design Solutions','71242473778145'),
(365,'Hexa Formation Expert','Multinationale','Sécurité Services','88048774936325');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(366,'Hexa Formation Pro','Chambre de commerce','Club Santé Plus','86522816632314'),
(367,'Hexa France','Société par actions simplifiée','ONG Aide Internationale','66435367605774');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(368,'Hexa France Global','Institut','Solar Tech France','60469534284808'),
(369,'Hexa France Plus','Centre de formation','Société Nouvelle Horizon','07461014177609');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(370,'Hexa Gestion Pro','Région','Domaine des Vignes','15577606176961'),
(371,'Hexa Group & Co','Groupement d’intérêt économique','CodeFactory','39765421162189');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(372,'Hexa Group Expert','Service technique','Tech Innov Solutions','84431480064342'),
(373,'Hexa Group France','Entreprise familiale','Sport & Fitness','55925290374884');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(374,'Hexa Industries Global','Fondation','Urban Immo Group','85340805380748'),
(375,'Hexa Industries Plus','Plateforme en ligne','Accélérateur Business','52918579215959');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(376,'Hexa Innovations France','Autorité indépendante','First Consulting','02874861018297'),
(377,'Hexa Innovations Pro','Mission locale','Green Power Solutions','92191727351305');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(378,'Hexa International Europe','Service technique','Sureté Conseil','36359538882592'),
(379,'Hexa International Expert','Start-up','Event Solutions','87227983908966');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(380,'Hexa International Global','Agence de recrutement','Urban Immo Group','25176813885744'),
(381,'Hexa Services Europe','Ordre des médecins','Terra Conseil','83213477427961');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(382,'Hexa Solutions','Société informatique','Livraison Express','67817208511413'),
(383,'Hexa Solutions Pro','Administration','Solar Tech France','41400251704301');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(384,'Hexa Systèmes & Co','École privée','Prime Conseil','54011283442475'),
(385,'Hexa Systèmes France','Mission locale','Compagnie Générale Services','93631062113078');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(386,'Hexa Systèmes Global','Fondation d’entreprise','Excellence Conseil','21379251588647'),
(387,'Hexa Technologies France','Micro-entreprise','Vision & Co','07638546594460');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(388,'Hexa Technologies Pro','Café','Horizon Développement','05798609409900'),
(389,'Horizon Conseil Pro','Laboratoire','Élan Conseil','80242909803544');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(390,'Horizon Consulting Global','Conseil régional','Le Bistro Moderne','09617672761467'),
(391,'Horizon Corporation Expert','Ordre des avocats','Patrimoine Conseil','57211546776625');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(392,'Horizon Corporation Global','Pôle de compétitivité','CodeFactory','73031537340523'),
(393,'Horizon Corporation Plus','Entreprise énergétique','Ambition Services','48365219973794');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(394,'Horizon Expertise France','Caisse','Société Centrale Conseil','65377883336856'),
(395,'Horizon Expertise Plus','Entreprise individuelle','École Supérieure Plus','05471210249444');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(396,'Horizon France','École de commerce','Urban Immo Group','24199277028118'),
(397,'Horizon France Europe','Ordre des médecins','Insight Consulting','85176778908809');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(398,'Horizon Gestion Plus','Centre d’affaires','Réseau Performance','03582944350684'),
(399,'Horizon Industries','Supermarché','Nova Consulting','15166678792127');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(400,'Horizon Industries Pro','Société par actions simplifiée','Gourmet Services','12997525019913'),
(401,'Horizon Innovations Global','Société anonyme','CyberTech Consulting','86433004390923');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(402,'Horizon International Global','Institution éducative','Observatoire Économique','72757314756811'),
(403,'Horizon Partners','Institut de beauté','Fiscal Conseil','83206460634394');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(404,'Horizon Partners & Co','École supérieure','Livraison Express','92705685731565'),
(405,'Horizon Partners Europe','Établissement privé','Fiscal Conseil','20797088500824');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(406,'Horizon Partners Global','Société à responsabilité limitée','Nettoyage Plus','86776554860246'),
(407,'Horizon Partners Plus','Startup technologique','ONG Aide Internationale','77515684922068');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(408,'Horizon Partners Pro','Domain viticole','Protect France','19143410174606'),
(409,'Horizon Services & Co','Société de transport','Pro Active Consulting','79000059713149');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(410,'Horizon Solutions Global','Association caritative','Audit & Conseil','58312342700824'),
(411,'Horizon Solutions Pro','Établissement bancaire','Sigma Solutions','37160210075971');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(412,'Horizon Systèmes Expert','Magasin','Alliance Conseil','27694453166317'),
(413,'Horizon Technologies & Co','Hypermarché','Excellence Conseil','62637081693585');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(414,'Horizon Technologies Expert','Laboratoire d’analyses','Groupe International Services','21669538021547'),
(415,'Horizon Technologies Plus','Maison de santé','Media Group France','92441240097179');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(416,'Impact Conseil France','Office public','Association Solidarité','42548854365409'),
(417,'Impact Conseil Pro','École de commerce','Stratégie Plus','93221218796730');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(418,'Impact Consulting Expert','Organisme privé','Patrimoine Conseil','25773926328740'),
(419,'Impact Consulting Global','Coopérative agricole','Stratégie Plus','51012025449479');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(420,'Impact Corporation & Co','Commerce','Atlas Consulting','91800227638460'),
(421,'Impact Corporation Plus','Accélérateur','Incubateur StartUp France','82450005212440');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(422,'Impact Corporation Pro','Caisse de retraite','NetPlus Services','44007148387355'),
(423,'Impact Formation Europe','Entreprise de livraison','Retail Solutions','22280055621632');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(424,'Impact France France','Centre médical','Énergie France Services','43371363945776'),
(425,'Impact France Global','Service commercial','Solar Tech France','23254021775774');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(426,'Impact France Plus','Association environnementale','Terra Conseil','60736182387956'),
(427,'Impact France Pro','Centre de formation','Food Services Group','61316913750856');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(428,'Impact Gestion Pro','Organisme public','Talent Consulting','90228668823953'),
(429,'Impact Group France','Coopérative','ONG Aide Internationale','80727006589186');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(430,'Impact Industries','Société coopérative','Société Européenne Conseil','56350401186804'),
(431,'Impact Industries & Co','Boutique','Initiative Conseil','71800577202794');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(432,'Impact Innovations Europe','Établissement de santé','Fiscal Conseil','71868789351396'),
(433,'Impact Innovations Pro','Association environnementale','Entreprise Française Innovation','03973726396547');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(434,'Impact Partners Europe','Plateforme','Artisanat France','75799269200138'),
(435,'Impact Partners Pro','Administration publique','Protect France','79025913965301');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(436,'Impact Services Europe','Auto-entrepreneur','Future Solutions','64678861159872'),
(437,'Impact Solutions & Co','Groupement','Immobilier Conseil','45594332385900');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(438,'Impact Solutions Expert','Coopérative','Cap Excellence','28355042096136'),
(439,'Impact Solutions Global','Centre','Recrutement Plus','85488047256499');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(440,'Impact Systèmes Global','Service administratif','Finance Conseil','65074856331626'),
(441,'Impact Systèmes Pro','Agence nationale','Invest Group France','14000053999624');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(442,'Impact Technologies & Co','Organisme social','Bio Solutions Group','59790415335154'),
(443,'Impact Technologies France','Office de tourisme','Coopérative Agricole France','43301693140908');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(444,'Impulse Conseil Europe','Conseil municipal','Formation Plus','77745006390314'),
(445,'Impulse Conseil Global','Mutuelle','Centre Recherche France','17700185830840');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(446,'Impulse Consulting & Co','Association caritative','Dynamik Solutions','78688625609295'),
(447,'Impulse Consulting Europe','Caisse de retraite','Infotech Solutions','08144381128686');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(448,'Impulse Corporation France','Institution','Recrutement Plus','15074034340464'),
(449,'Impulse Corporation Global','Agence européenne','Domaine des Vignes','56921548336577');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(450,'Impulse Développement Plus','Établissement privé','Studio Créatif','00796252218894'),
(451,'Impulse Expertise','Agence événementielle','Finance Conseil','05327872394524');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(452,'Impulse Formation','Organisme de certification','NextGen Solutions','43779280773439'),
(453,'Impulse Formation Europe','Association','Bien-être Solutions','63949831870800');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(454,'Impulse Formation Pro','Cabinet','Eco Services France','05006673213259'),
(455,'Impulse France Global','Institution financière','Patrimoine Conseil','62161256758623');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(456,'Impulse France Plus','Commerce','Cluster Innovation','17026320695773'),
(457,'Impulse France Pro','Société industrielle','Data Solutions France','39486451745071');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(458,'Impulse Gestion & Co','Lycée','Sureté Conseil','68954472707528'),
(459,'Impulse Gestion Global','Institution publique','Cargo Solutions','39127998682547');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(460,'Impulse Group Pro','Auto-entrepreneur','Distribution Services','84736884754139'),
(461,'Impulse Innovations & Co','Coopérative de production','Sécurité Services','97865296589170');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(462,'Impulse Innovations Expert','Centre','BTP Services France','19751557637194'),
(463,'Impulse Partners','Entreprise de sécurité','Prime Conseil','67691372397493');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(464,'Impulse Partners & Co','Établissement privé','Alpha Conseil','67197104180935'),
(465,'Impulse Partners Europe','Centre de bien-être','Urban Conseil','34369998972602');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(466,'Impulse Partners France','Commerçant','Vignoble Prestige','75734139026220'),
(467,'Impulse Partners Pro','Conseil','Forward Services','70950076670035');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(468,'Impulse Services & Co','Vignoble','Vignoble Prestige','61964824252853'),
(469,'Impulse Services Europe','Ministère','Énergie France Services','24800932785986');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(470,'Impulse Solutions Global','Établissement','Market France','01995185935098'),
(471,'Impulse Systèmes Europe','Réseau associatif','CyberTech Consulting','11600300307267');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(472,'Impulse Systèmes France','Agence gouvernementale','Innova Services','81388695226025'),
(473,'Impulse Technologies Global','Autorité indépendante','Distribution Services','09790121186826');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(474,'Innova Conseil Expert','Administration publique','Coopérative Agricole France','06970947853074'),
(475,'Innova Corporation France','Organisation','Entreprise Française Innovation','07891390093884');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(476,'Innova Corporation Pro','Institut de recherche','Global Services Group','02430840433309'),
(477,'Innova Expertise Plus','École d’ingénieurs','Media Group France','35134777034174');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(478,'Innova Formation Global','Plateforme','Vignoble Prestige','79882775154338'),
(479,'Innova France France','Groupement d’intérêt économique','Café du Centre SARL','86337162410851');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(480,'Innova France Pro','Entreprise de télécommunications','Corporate Services','47303839256019'),
(481,'Innova Gestion Expert','Ordre des avocats','Immo Gestion Services','81935184190253');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(482,'Innova Gestion France','Préfecture','IT Performance Group','95156199425156'),
(483,'Innova Group France','Association environnementale','Delta Conseil','16184377280153');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(484,'Innova Group Global','Commerce','Design Solutions','16604468921834'),
(485,'Innova Industries & Co','Entreprise agricole','Insight Consulting','42503267452941');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(486,'Innova Industries Plus','Institution','Holding Avenir','52482525420700'),
(487,'Innova Innovations Plus','Société d’investissement','System Consulting','10946911065592');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(488,'Innova Innovations Pro','Université','Incubateur StartUp France','88512346838986'),
(489,'Innova International France','Ordre professionnel','Think Tank France','32962397182537');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(490,'Innova International Global','Organisation professionnelle','Audit & Conseil','79711369457424'),
(491,'Innova International Pro','Association environnementale','Numérique Conseil','21880041777936');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(492,'Innova Services & Co','Café','Nexus Conseil','83221489391144'),
(493,'Innova Services Expert','Association étudiante','Holding Avenir','32697512107258');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(494,'Innova Solutions Expert','Hypermarché','Corporate Services','93151026499433'),
(495,'Innova Systèmes','Entreprise artisanale','Green Power Solutions','91518065808465');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(496,'Innova Systèmes Global','Micro-entreprise','Art & Création','91639904407923'),
(497,'Innova Technologies','Cabinet médical','Agence Immo Plus','12129720958068');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(498,'Innova Technologies Expert','Association humanitaire','Global Services Group','48750246535978'),
(499,'Innova Technologies Global','Agence digitale','Retail Solutions','26073455141480');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(500,'Leader Conseil Plus','Agence web','Protect France','11643868085817'),
(501,'Leader Consulting Europe','Agence événementielle','Restauration Plus','14032608945207');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(502,'Leader Consulting Expert','Commerce','Food Services Group','36759051529441'),
(503,'Leader Corporation Pro','Institution financière','Avenir Formation','91179771284370');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(504,'Leader Formation & Co','Établissement privé','Optimum Conseil','56477831722094'),
(505,'Leader Formation Pro','Département','Premium Services','42366999986980');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(506,'Leader France Europe','Centre social','First Consulting','02555810067989'),
(507,'Leader France Global','Centre médical','Entreprise Générale France','17872125726815');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(508,'Leader Gestion Europe','Association environnementale','First Consulting','92160607636580'),
(509,'Leader Group','Pôle de compétitivité','Accélérateur Business','10318047090938');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(510,'Leader Group France','Association caritative','Event Solutions','56440602534804'),
(511,'Leader Group Global','Association','Alliance Conseil','58099097541864');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(512,'Leader Industries','Entreprise de nettoyage','Hygiène Solutions','83439655217478'),
(513,'Leader Innovations Pro','Organisation','Santé Services','26866834790913');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(514,'Leader International Expert','Caisse','Menuiserie Dupont','51740407549520'),
(515,'Leader Partners France','Agence marketing','Voyage & Découverte','18683930377965');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(516,'Leader Partners Pro','Café','Groupe Synergie','76598201482669'),
(517,'Leader Solutions & Co','Coopérative de production','Sport & Fitness','99459785412567');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(518,'Leader Systèmes France','Cabinet médical','Groupe Financia','78666656704868'),
(519,'Leader Systèmes Pro','PME','Avenir Formation','62453242535342');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(520,'Leader Technologies France','Autorité de régulation','Travaux & Co','82425124137144'),
(521,'Leader Technologies Global','Coopérative de production','Market France','39972581768393');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(522,'Master Conseil & Co','Magasin','Restaurant du Parc','92357259457573'),
(523,'Master Conseil Europe','Établissement','Avenir Formation','13429488416928');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(524,'Master Conseil Expert','Entreprise informatique','Le Bistro Moderne','99918821287921'),
(525,'Master Conseil France','Société','Retail Solutions','97525780965130');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(526,'Master Conseil Plus','Entreprise de nettoyage','Data Solutions France','94192732761529'),
(527,'Master Consulting & Co','Société commerciale','Proxima Services','13351664913352');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(528,'Master Consulting Europe','École','Business Solutions','22560787413186'),
(529,'Master Consulting Expert','Autorité indépendante','Data Solutions France','17456400594126');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(530,'Master Corporation & Co','Institution financière','Urban Conseil','27526370597290'),
(531,'Master Corporation Global','Cluster','Terra Conseil','18281326276865');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(532,'Master Développement Europe','Bureau de contrôle','ONG Aide Internationale','85952691389824'),
(533,'Master Expertise Europe','Artisan','Omni Services','77912830945547');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(534,'Master Expertise France','Organisme de formation','BTP Services France','93376468045975'),
(535,'Master Formation Expert','Société d’investissement','Vignoble Prestige','29916292799111');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(536,'Master France Plus','Hub','Rénovation Experts','62229652337851'),
(537,'Master Gestion Expert','Conseil municipal','Groupe Horizon','43842811588680');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(538,'Master Gestion Plus','Entreprise privée','Cloud Services Group','67355951198883'),
(539,'Master Group','Ministère','Recrutement Plus','03501404454786');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(540,'Master Industries','Ferme','Smart Solutions','40215665501066'),
(541,'Master Industries France','Fédération','Vision & Co','59622605030051');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(542,'Master Industries Plus','Laboratoire','Clean Services','96265702002944'),
(543,'Master Innovations & Co','Site e-commerce','Urban Immo Group','02464472852154');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(544,'Master Innovations Expert','Organisme','Impulse Consulting','72360098108859'),
(545,'Master Partners','Entreprise innovante','Société Nouvelle Horizon','23020668516510');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(546,'Master Partners Europe','Agence nationale','Expert Compta Group','96943498791012'),
(547,'Master Services & Co','Ordre des médecins','Think Tank France','00834641666832');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(548,'Master Services Europe','Agence immobilière','Food Services Group','04249277045802'),
(549,'Master Technologies','Agence de voyage','Entreprise Générale France','52667753678863');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(550,'NextGen Conseil Expert','Société commerciale','Hexa Consulting','19029964396952'),
(551,'NextGen Consulting','Assurance','Impulse Consulting','10934445406171');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(552,'NextGen Consulting Europe','Société de transport','Design Solutions','50136143982545'),
(553,'NextGen Consulting Plus','Agence européenne','Digital Conseil France','58236293700236');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(554,'NextGen Corporation','Fondation reconnue d’utilité publique','Agence Immo Plus','10511942928245'),
(555,'NextGen Corporation Plus','Service','Fondation Espoir','16152903369291');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(556,'NextGen Corporation Pro','Association culturelle','Clarté Consulting','07954848686430'),
(557,'NextGen Développement & Co','Collectivité','Centre Recherche France','43369172121797');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(558,'NextGen Expertise','Organisme public','SoftTech Consulting','25932229547875'),
(559,'NextGen Expertise & Co','Entreprise de BTP','Zenith Consulting','83448149301569');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(560,'NextGen Expertise Expert','Accélérateur','Core Services','00814925734797'),
(561,'NextGen Expertise Plus','Vignoble','Vertex Solutions','58620632731603');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(562,'NextGen Formation Pro','Domain viticole','Logiciel Plus','42185449243386'),
(563,'NextGen France Pro','Office public','Voyage & Découverte','32786909888777');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(564,'NextGen Gestion Plus','Think tank','Pâtisserie Gourmande','91666215518625'),
(565,'NextGen Group Global','Centre de bien-être','Environnement Conseil','54700130589923');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(566,'NextGen Innovations Pro','Entreprise de construction','Accélérateur Business','13116518097651'),
(567,'NextGen Partners & Co','Maison de santé','Bio Solutions Group','19093011022063');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(568,'NextGen Partners Europe','Association sportive','Hexa Consulting','36542070472800'),
(569,'NextGen Services','Mutuelle','Think Tank France','93296425184801');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(570,'NextGen Services Europe','Société industrielle','Techno Conseil','88137449112475'),
(571,'NextGen Services Expert','Hub','Société Centrale Conseil','56320609963798');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(572,'NextGen Services Plus','Université','Sécurité Services','83304846289639'),
(573,'NextGen Services Pro','Fédération','Bien-être Solutions','64806973855515');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(574,'NextGen Solutions','Société de gestion','Agence Immo Plus','29443659437518'),
(575,'NextGen Solutions Plus','Filiale','Immobilier Conseil','10387191983383');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(576,'NextGen Systèmes France','Boutique','Excellence Conseil','42295250341843'),
(577,'NextGen Technologies & Co','Société de services','Sport & Fitness','92376508395002');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(578,'NextGen Technologies Expert','Agence','Impact Solutions','13509960251716'),
(579,'NextGen Technologies Global','Hôtel','Immo Gestion Services','90917228995263');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(580,'Nexus Conseil & Co','Association culturelle','Auto Plus France','11134878794484'),
(581,'Nexus Conseil Europe','Grande surface','Réseau Performance','93967623839522');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(582,'Nexus Corporation France','Entreprise sociale','Solar Tech France','36287289151682'),
(583,'Nexus Expertise Global','Organisation non gouvernementale','Nettoyage Plus','53956924531684');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(584,'Nexus Formation','Salon de coiffure','Bien-être Solutions','25088103820772'),
(585,'Nexus France & Co','Site e-commerce','Web Innov Agency','63004211900388');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(586,'Nexus France Europe','Société','First Consulting','59356438720169'),
(587,'Nexus France Expert','Agence web','Réseau Digital','22618818656268');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(588,'Nexus France Plus','Groupement d’intérêt économique','IT Performance Group','58209304141497'),
(589,'Nexus Group France','Établissement public','Gestion Finance Plus','48415618906271');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(590,'Nexus Industries','Service commercial','Logiciel Plus','65592957834979'),
(591,'Nexus Industries & Co','Société industrielle','Ambition Services','70243310414951');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(592,'Nexus Industries Europe','Hypermarché','Auto Plus France','94527544733774'),
(593,'Nexus Industries Plus','École supérieure','Stratégie Plus','05380702557413');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(594,'Nexus Innovations','Cabinet de conseil','Laboratoire Innovation','84745745472829'),
(595,'Nexus Innovations Pro','Entreprise informatique','Café du Centre SARL','82589806137780');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(596,'Nexus International Europe','Entreprise publique','Vertex Solutions','52799816237270'),
(597,'Nexus International Plus','Entreprise de sécurité','Communication Plus','93026904782406');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(598,'Nexus Partners','Domain viticole','Institut National Études','72718401704749'),
(599,'Nexus Partners Pro','Cabinet d’avocats','Green Power Solutions','48446740190474');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(600,'Nexus Services Europe','Caisse','Smart Solutions','51431823407648'),
(601,'Nexus Services Plus','Chambre des métiers','Alliance Conseil','92630011302975');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(602,'Nexus Solutions Europe','Entreprise de télécommunications','Audit & Conseil','48134378022965'),
(603,'Nexus Solutions Pro','Organisme social','Audit & Conseil','58889338278943');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(604,'Nexus Systèmes France','Incubateur','Zenith Consulting','51838128216416'),
(605,'Nexus Systèmes Plus','Réseau professionnel','Eco Services France','63130709633339');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(606,'Nexus Technologies & Co','Agence de communication','Cap Excellence','28807581719686'),
(607,'Nova Conseil & Co','Établissement public','Agri Développement','99802240092180');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(608,'Nova Conseil France','Administration territoriale','Association Culturelle Plus','74909261439828'),
(609,'Nova Conseil Global','ONG','Sureté Conseil','50724752379742');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(610,'Nova Conseil Plus','Confédération','Pub & Marketing','28363293440441'),
(611,'Nova Conseil Pro','Laboratoire de recherche','System Consulting','40552565426879');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(612,'Nova Consulting Plus','Entreprise publique','Smart Solutions','27800694776653'),
(613,'Nova Corporation','Réseau associatif','Capital Consulting','41739485297994');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(614,'Nova Développement Europe','Bureau','Sécurité Services','52845993203248'),
(615,'Nova Développement France','Domain viticole','Réseau Digital','01063157848094');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(616,'Nova Expertise Plus','Bureau de contrôle','Fondation Espoir','13155912215233'),
(617,'Nova Formation Pro','Confédération','Groupe National Services','80935787568500');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(618,'Nova France & Co','Association culturelle','Cloud Services Group','00738751872437'),
(619,'Nova France Expert','Société commerciale','Invest Group France','50089895304543');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(620,'Nova France Plus','Coopérative de production','Commerce Plus','88754555393217'),
(621,'Nova France Pro','Marketplace','Fondation Espoir','45057086100459');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(622,'Nova Group','Groupement d’intérêt économique','Association Culturelle Plus','24153016412223'),
(623,'Nova Group Plus','Société de transport','Dev Solutions','86589499933466');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(624,'Nova Industries Pro','Collectivité','Protect France','26472336220819'),
(625,'Nova Innovations France','Établissement privé','Association Solidarité','80796322753935');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(626,'Nova International Pro','Mission locale','Centre Recherche France','99367058252057'),
(627,'Nova Partners','Organisme public','Commerce Plus','76498295070211');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(628,'Nova Partners Europe','Conseil départemental','Alliance Conseil','64426210684017'),
(629,'Nova Partners France','Ordre des avocats','Groupe Synergie','64258714726938');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(630,'Nova Services & Co','Entreprise informatique','ONG Aide Internationale','83533157324897'),
(631,'Nova Services Expert','Organisme privé','Sécurité Services','20349709085201');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(632,'Nova Services Plus','Micro-entreprise','Core Services','25701243183965'),
(633,'Nova Solutions & Co','Service administratif','Club Santé Plus','59761759521895');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(634,'Nova Solutions Global','Association sportive','Eureka Formation','93134464648221'),
(635,'Nova Systèmes Europe','Entreprise de rénovation','Culture & Loisirs','26456993563850');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(636,'Nova Systèmes Global','Laboratoire','Groupe Horizon','05307533755489'),
(637,'Nova Technologies','Institut de recherche','SoftTech Consulting','07302045495492');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(638,'Omni Conseil Europe','PME','Domaine des Vignes','60428258947348'),
(639,'Omni Conseil Plus','Centre culturel','Sport & Fitness','43697661320434');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(640,'Omni Consulting Global','Centre d’appel','Logistique France','19408069458535'),
(641,'Omni Consulting Plus','Préfecture','Développement Durable France','91222082111168');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(642,'Omni Consulting Pro','Coopérative agricole','RH Solutions','06766927166365'),
(643,'Omni Corporation France','Société de services','Startup Factory','80846030156540');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(644,'Omni Corporation Global','Structure d’insertion','Boulangerie du Centre','31521855621070'),
(645,'Omni Corporation Pro','Pharmacie','Réseau Digital','66772997033898');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(646,'Omni Développement','Centre de formation','Sport & Fitness','83080884243333'),
(647,'Omni Développement Expert','Hypermarché','Groupe National Services','37682852335467');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(648,'Omni Expertise & Co','Société à responsabilité limitée','Réseau Digital','85262972572628'),
(649,'Omni Expertise Global','Agence de communication','ONG Aide Internationale','20599551363029');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(650,'Omni Formation Europe','Société de services','Recrutement Plus','46768865285145'),
(651,'Omni Formation France','Entreprise sociale','IT Performance Group','90586172275593');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(652,'Omni Formation Global','Administration territoriale','Vignoble Prestige','60260535812668'),
(653,'Omni Group','Société de transport','RH Solutions','60184590742530');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(654,'Omni Group Europe','Réseau associatif','Laboratoire Innovation','01153762742328'),
(655,'Omni Industries','Entreprise de nettoyage','Auto Plus France','00574456046093');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(656,'Omni Industries Europe','Mission locale','Terra Conseil','77788393104403'),
(657,'Omni Industries Plus','Fondation','Infotech Solutions','09678614531856');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(658,'Omni Innovations Plus','Agence événementielle','Santé Services','98760506726721'),
(659,'Omni Partners France','Administration territoriale','Logistique France','03273196561641');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(660,'Omni Partners Plus','Société coopérative','Talent Consulting','92574479580739'),
(661,'Omni Partners Pro','Préfecture','Atlas Consulting','87127090304598');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(662,'Omni Services & Co','Établissement de santé','Impact Solutions','47319426498338'),
(663,'Omni Services Pro','Club sportif','Forward Services','50308606598351');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(664,'Omni Solutions Expert','Organisation syndicale','Commerce Plus','39856068768752'),
(665,'Omni Solutions Global','Centre de loisirs','Auto Plus France','76791189365238');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(666,'Omni Systèmes France','Agence web','Web Innov Agency','78520711159596'),
(667,'Omni Technologies & Co','Club','Avenir Formation','50753294655089');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(668,'OpenMind Consulting France','Entreprise informatique','Association Culturelle Plus','96490159345468'),
(669,'OpenMind Consulting Plus','Société de gestion','Centre Recherche France','16645057011816');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(670,'OpenMind Corporation France','Préfecture','Leader Consulting','07402128441215'),
(671,'OpenMind Corporation Global','Organisme','Vertex Solutions','71374302439647');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(672,'OpenMind Expertise Pro','Institut de recherche','Habitat Solutions','05731404519954'),
(673,'OpenMind Formation Europe','Institution culturelle','Expertis Consulting','12810426175629');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(674,'OpenMind Formation Global','Centre de formation','Immo Gestion Services','63502224510219'),
(675,'OpenMind Formation Pro','Agence événementielle','Groupe Financia','39965693827793');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(676,'OpenMind France Europe','Réseau associatif','Livraison Express','34218659000107'),
(677,'OpenMind Gestion Pro','Spa','Campus Formation','81880189893594');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(678,'OpenMind Group','Hôpital','Garage Auto Services','80692772753433'),
(679,'OpenMind Industries & Co','Laboratoire d’analyses','Société Centrale Conseil','77315233205730');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(680,'OpenMind Innovations France','Organisation humanitaire','Transport Services','84576993506060'),
(681,'OpenMind International France','Supermarché','Pub & Marketing','45207871547927');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(682,'OpenMind International Global','Service technique','System Consulting','03549874127188'),
(683,'OpenMind International Plus','Chambre d’agriculture','Médical Plus','22785709702962');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(684,'OpenMind Partners','Auto-entrepreneur','Recrutement Plus','33173970625669'),
(685,'OpenMind Partners & Co','Cabinet','Gestion Finance Plus','95736936784618');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(686,'OpenMind Partners Plus','Organisation professionnelle','Expert Compta Group','89143731375598'),
(687,'OpenMind Services Plus','Commerçant','Travaux & Co','52875307553803');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(688,'OpenMind Solutions Europe','Société par actions simplifiée','Domaine des Vignes','43233533775262'),
(689,'OpenMind Solutions Global','Institution publique','Livraison Express','35208444107090');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(690,'OpenMind Systèmes Global','Entreprise énergétique','Global Services Group','36144893762269'),
(691,'OpenMind Systèmes Plus','École d’ingénieurs','Orion Conseil','65556513816812');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(692,'OpenMind Technologies Pro','Centre hospitalier','Immobilier Conseil','63025631165102'),
(693,'Optima Conseil','Conseil','Communication Plus','43725662542253');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(694,'Optima Conseil Europe','Office public','Immo Gestion Services','40129346499040'),
(695,'Optima Conseil Expert','Organisme public','Media Group France','22834593849948');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(696,'Optima Consulting','Structure d’insertion','Sigma Solutions','04563468071157'),
(697,'Optima Consulting & Co','Think tank','Santé Services','43699493181514');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(698,'Optima Consulting France','Club privé','Pôle Compétitivité Tech','12929625357630'),
(699,'Optima Corporation & Co','Filiale','Supply Chain Group','40367121526079');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(700,'Optima Corporation Global','Entreprise publique','Consulting Partners','74338758826824'),
(701,'Optima Corporation Pro','Entreprise innovante','Dev Solutions','91819269813570');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(702,'Optima Expertise & Co','Fondation d’entreprise','Entreprise Régionale Plus','96652835612775'),
(703,'Optima Formation & Co','Salle de sport','Hôtel du Centre','71339597588118');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(704,'Optima France','Entreprise de BTP','Holding Avenir','73843860723377'),
(705,'Optima France France','Conseil régional','Habitat Solutions','05610074386947');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(706,'Optima Gestion France','Autorité de régulation','SoluTech','20566910483385'),
(707,'Optima Group France','Agence immobilière','Eco Services France','47534194798011');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(708,'Optima Group Plus','Entreprise de livraison','Zenith Consulting','04964698394562'),
(709,'Optima Industries & Co','Banque','Logiciel Plus','02270203831573');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(710,'Optima Industries Global','Université','Zenith Consulting','84813047384169'),
(711,'Optima Industries Plus','École supérieure','Numérique Conseil','03750388338792');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(712,'Optima Industries Pro','Cabinet médical','Studio Créatif','56899937405625'),
(713,'Optima Innovations','Agence digitale','Talent Consulting','74439609969705');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(714,'Optima Innovations France','Autorité indépendante','RH Solutions','62909588131674'),
(715,'Optima International & Co','Préfecture','Food Services Group','94030448451897');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(716,'Optima International Europe','Conseil','Gourmet Services','25267194906412'),
(717,'Optima International Pro','Entreprise privée','Logiciel Plus','51972626146490');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(718,'Optima Partners & Co','Centre culturel','Startup Factory','14986429397800'),
(719,'Optima Partners France','Commerce','Immobilier Conseil','42020866685738');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(720,'Optima Services Expert','Entreprise de construction','Association Culturelle Plus','45320934634277'),
(721,'Optima Solutions France','Réseau professionnel','Pub & Marketing','18311124944934');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(722,'Optima Systèmes Pro','Préfecture','École Supérieure Plus','17309383473193'),
(723,'Optima Technologies Europe','Société de gestion','System Consulting','71945220546501');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(724,'Optima Technologies Global','Agence de voyage','Excellence Conseil','55998880478761'),
(725,'Orion Conseil Global','Centre de bien-être','First Consulting','42239570501157');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(726,'Orion Consulting Expert','Mairie','Bio Solutions Group','67962019141924'),
(727,'Orion Consulting Plus','Entreprise individuelle','Réseau Performance','56511918996951');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(728,'Orion Corporation & Co','Organisme social','Entreprise Générale France','46655283097104'),
(729,'Orion Corporation Expert','École d’ingénieurs','Hexa Consulting','65487877549414');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(730,'Orion Développement France','École privée','Club Santé Plus','13521588689580'),
(731,'Orion Expertise & Co','Organisation','OpenMind Conseil','80682982405102');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(732,'Orion Expertise France','Chambre','System Consulting','26801598207277'),
(733,'Orion Expertise Pro','Agence gouvernementale','Agri Développement','50141369276694');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(734,'Orion Formation Expert','Organisation','Alliance Conseil','72277337730869'),
(735,'Orion Formation Pro','Réseau','Association Culturelle Plus','43085032675528');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(736,'Orion France','Commerçant','Pâtisserie Gourmande','26958843888301'),
(737,'Orion Group Expert','Bar','Compagnie Générale Services','80541928302341');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(738,'Orion Innovations France','Collectivité','Atlas Consulting','48147469063569'),
(739,'Orion Innovations Global','Banque','Vignoble Prestige','45035541681806');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(740,'Orion International & Co','Service commercial','Groupe Évolution','74657082779346'),
(741,'Orion International Expert','Réseau','Finance Conseil','19952039054215');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(742,'Orion Partners','Cabinet médical','Avenir Formation','85631511262431'),
(743,'Orion Services Global','Hôpital','Ambition Services','55079907673807');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(744,'Orion Solutions Europe','Exploitation agricole','Formation Plus','42160938888214'),
(745,'Orion Solutions Global','École','Immo Gestion Services','17915675767881');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(746,'Orion Systèmes Plus','Conseil','Startup Factory','26907295673392'),
(747,'Orion Technologies','Office','Green Consulting','69257465741449');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(748,'Orion Technologies Pro','Commerce','Focus Expertise','39530955772815'),
(749,'Performance Consulting Pro','Mutuelle','BTP Services France','16604258125977');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(750,'Performance Corporation Expert','Agence web','Retail Solutions','59526338043960'),
(751,'Performance Corporation Pro','Entreprise','Café du Centre SARL','30381421190765');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(752,'Performance Développement Europe','Société commerciale','Immobilier Conseil','78768710400650'),
(753,'Performance Expertise Global','Organisation humanitaire','Invest Group France','37171354580999');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(754,'Performance Formation Europe','Administration publique','Observatoire Économique','42547032657852'),
(755,'Performance Formation Global','Magasin','Entreprise Moderne France','03609541813319');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(756,'Performance France & Co','Centre hospitalier','Fondation Avenir','13552802350192'),
(757,'Performance France Expert','Entreprise sociale','Supply Chain Group','73481536121979');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(758,'Performance France Pro','Organisme de certification','Excellence Conseil','65968505307198'),
(759,'Performance Gestion Expert','Laboratoire d’analyses','SoluTech','19344053608227');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(760,'Performance Gestion France','Société commerciale','Horizon Développement','10500607920560'),
(761,'Performance Group','Marketplace','Ferme du Val','48983145901077');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(762,'Performance Group Global','Domain viticole','Société Nouvelle Horizon','80347090498236'),
(763,'Performance Industries','Entreprise de services numériques','Clinique du Parc','93125279152305');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(764,'Performance Industries Expert','Entreprise publique','Avenir Formation','14197531530854'),
(765,'Performance International Plus','Entreprise de nettoyage','Association Culturelle Plus','75325739894057');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(766,'Performance Partners & Co','Entreprise publique','Media Group France','19057084924337'),
(767,'Performance Services & Co','Entreprise artisanale','Coopérative Agricole France','90202831944595');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(768,'Performance Services Plus','Banque','Global Services Group','68849645277346'),
(769,'Performance Solutions Europe','Office de tourisme','Domaine des Vignes','44573966562600');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(770,'Performance Solutions Plus','Entreprise','Core Services','77163599971876'),
(771,'Performance Systèmes France','Université','Dynamic Consulting','33098868796653');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(772,'Performance Systèmes Global','Société de gestion','Ferme du Val','21126882470537'),
(773,'Performance Systèmes Plus','Magasin','Orion Conseil','15706685494739');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(774,'Performance Technologies Global','Collectivité territoriale','Club Santé Plus','92835092250531'),
(775,'Prime Conseil','Plateforme','Infotech Solutions','82040072168812');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(776,'Prime Conseil Europe','Agence de recrutement','CyberTech Consulting','34652992596857'),
(777,'Prime Conseil France','Office public','IT Performance Group','52925337902244');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(778,'Prime Conseil Global','Syndicat','Urban Immo Group','11844525468462'),
(779,'Prime Conseil Pro','Ordre des experts-comptables','Holding Avenir','27359554278478');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(780,'Prime Développement France','Artisan','Institut Formation Pro','56083391815179'),
(781,'Prime Expertise','Société d’investissement','Menuiserie Dupont','13662916543469');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(782,'Prime Expertise France','Exploitation agricole','Objectif Performance','15768866889078'),
(783,'Prime Formation Europe','Site e-commerce','Design Solutions','57786954001823');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(784,'Prime Formation Plus','Filiale','Innovation Lab','26455759343291'),
(785,'Prime France Plus','Service','Alliance Conseil','52607242508877');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(786,'Prime Gestion Europe','Association environnementale','Think Tank France','86555796321106'),
(787,'Prime Gestion Plus','Supermarché','Avantage Conseil','79272386966748');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(788,'Prime Gestion Pro','Entreprise artisanale','Formation Plus','04629629981395'),
(789,'Prime Group Expert','Laboratoire','Énergie France Services','56161086505817');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(790,'Prime Group France','Organisme de financement','Terra Conseil','94706654439664'),
(791,'Prime Group Plus','Caisse d’assurance','Delta Conseil','43825408311092');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(792,'Prime Industries & Co','Société anonyme','SoftTech Consulting','23857414585505'),
(793,'Prime Industries Europe','Établissement privé','Entreprise Française Innovation','61559175964375');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(794,'Prime Industries Global','Entreprise individuelle','Réseau Digital','06468743290052'),
(795,'Prime Innovations Plus','Conseil départemental','Bien-être Solutions','65110492609411');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(796,'Prime International France','Entreprise informatique','Avenir Formation','69048775754707'),
(797,'Prime International Pro','Agence événementielle','Premium Services','46657825216981');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(798,'Prime Services & Co','Association','Laboratoire Innovation','12012597097519'),
(799,'Prime Services Europe','Cabinet comptable','Proxima Services','28111140030240');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(800,'Prime Solutions & Co','Bureau d’études','Market France','74557074316993'),
(801,'Prime Solutions Plus','Organisme de certification','Smart Solutions','71617010748826');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(802,'Prime Systèmes','Plateforme en ligne','Optimum Conseil','74595020997370'),
(803,'Prime Systèmes Plus','Coopérative de production','Corporate Services','09703443808984');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(804,'Proxima Conseil Expert','Hub','Groupe Évolution','67852825264176'),
(805,'Proxima Consulting France','Agence de communication','Sureté Conseil','98824143812534');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(806,'Proxima Consulting Plus','Service commercial','Formation Plus','76630940717468'),
(807,'Proxima Corporation Plus','Association environnementale','Dynamic Consulting','06984939037606');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(808,'Proxima Corporation Pro','Club','Sécurité Services','11149987219426'),
(809,'Proxima Développement Europe','Association environnementale','IT Performance Group','82387167306788');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(810,'Proxima Expertise Expert','Ministère','Talent Consulting','90240860504996'),
(811,'Proxima Formation Pro','Banque en ligne','Impulse Consulting','15326933145903');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(812,'Proxima Gestion','Office public','Digital Factory','80735376252764'),
(813,'Proxima Industries Expert','Association culturelle','CodeFactory','08392526161847');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(814,'Proxima Industries France','Laboratoire d’analyses','Smart Solutions','98941705558157'),
(815,'Proxima Industries Plus','Accélérateur','Événementiel Plus','01239193538278');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(816,'Proxima Innovations & Co','Organisme de certification','Fondation Avenir','90304181102289'),
(817,'Proxima Innovations Global','Micro-entreprise','Gestion Finance Plus','23691862386955');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(818,'Proxima International','Entreprise de sécurité','NetPlus Services','63356487772816'),
(819,'Proxima Partners','Commerce','Excellence Conseil','79331413675875');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(820,'Proxima Services','Conseil municipal','Exploitation Agricole Martin','38938209260575'),
(821,'Proxima Solutions Expert','Entreprise','Solar Tech France','73957892509874');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(822,'Proxima Systèmes & Co','Autorité administrative','Impulse Consulting','75787346286383'),
(823,'Proxima Systèmes Plus','Organisme de financement','Expert Compta Group','17466981668221');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(824,'Proxima Systèmes Pro','Préfecture','Cluster Innovation','95939838838130'),
(825,'Proxima Technologies & Co','Institution publique','Entreprise Moderne France','52801297920397');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(826,'Sigma Consulting Expert','Entreprise privée','Ambition Services','81482853108567'),
(827,'Sigma Consulting France','Conseil départemental','Hygiène Solutions','85691351131688');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(828,'Sigma Consulting Plus','Laboratoire','Alpha Conseil','99713942669764'),
(829,'Sigma Corporation France','Centre technique','Entreprise Française Innovation','08839461670043');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(830,'Sigma Développement','Supermarché','Objectif Performance','78432085295806'),
(831,'Sigma Développement & Co','Association sportive','Nettoyage Plus','02398721105433');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(832,'Sigma Développement Global','Agence de recrutement','Commerce Plus','43060432780554'),
(833,'Sigma Expertise Plus','Centre d’appel','Optimum Conseil','90881268180100');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(834,'Sigma Formation France','Autorité administrative','Data Solutions France','54374112062826'),
(835,'Sigma France Plus','Plateforme en ligne','BTP Services France','74149754335370');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(836,'Sigma Group Plus','Entreprise innovante','Protect France','91347401161305'),
(837,'Sigma Industries & Co','Entreprise solidaire','Société Nouvelle Horizon','99412311634092');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(838,'Sigma Industries France','Auto-entrepreneur','Environnement Conseil','77010777165100'),
(839,'Sigma Industries Global','Organisme public','Café du Centre SARL','34551350987371');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(840,'Sigma International','Association','Événementiel Plus','01874943466240'),
(841,'Sigma International Europe','Café','Habitat Solutions','45072693968620');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(842,'Sigma Services Expert','Marketplace','Pâtisserie Gourmande','72204998918633'),
(843,'Sigma Services Plus','Grande entreprise','Innova Services','27467692458135');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(844,'Smart Conseil Expert','Entreprise de sécurité','Logistique France','38656948128309'),
(845,'Smart Consulting & Co','Institution publique','Vertex Solutions','25548170327928');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(846,'Smart Corporation Europe','Association','Compagnie Générale Services','09721073338283'),
(847,'Smart Corporation Pro','Entreprise publique','Impact Solutions','75795238647623');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(848,'Smart Développement & Co','Agence web','Consulting Partners','13676586231444'),
(849,'Smart Développement Global','Agence nationale','Art & Création','00359052364555');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(850,'Smart Développement Plus','Société de services','Le Bistro Moderne','64336013674490'),
(851,'Smart Expertise','Caisse','Innovation Lab','22398252940852');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(852,'Smart Expertise France','Entreprise privée','Nexus Conseil','86820086297706'),
(853,'Smart Expertise Global','Institution','Insight Consulting','29370956373178');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(854,'Smart Expertise Plus','Conseil','ONG Aide Internationale','97701879744073'),
(855,'Smart Expertise Pro','Confédération','Rénovation Experts','13373584533766');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(856,'Smart France France','Conseil','Sport & Fitness','27422837232353'),
(857,'Smart France Global','Société commerciale','Réseau Digital','91042081700070');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(858,'Smart France Pro','Ferme','Transport Services','02601122502087'),
(859,'Smart Gestion','Entreprise énergétique','Bâtiment Conseil','71494124444899');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(860,'Smart Gestion & Co','Site e-commerce','Design Solutions','95225300646900'),
(861,'Smart Gestion Global','Hôpital','Académie France','09160517840466');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(862,'Smart Gestion Plus','Société de services','Distribution Services','49018536369986'),
(863,'Smart Gestion Pro','Coopérative','First Consulting','78457444222463');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(864,'Smart Group Plus','Ordre des médecins','CodeFactory','91359497805835'),
(865,'Smart Industries','Cabinet d’avocats','Leader Consulting','99347900245447');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(866,'Smart Industries & Co','Fondation d’entreprise','Transport Services','13570897044372'),
(867,'Smart Industries Expert','Entreprise de livraison','Urban Conseil','18238155690129');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(868,'Smart Industries Global','Laboratoire de recherche','Accélérateur Business','26876404370780'),
(869,'Smart Industries Plus','Coopérative agricole','Finance Conseil','48983401664834');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(870,'Smart Innovations Europe','Service','NextGen Solutions','34898021809798'),
(871,'Smart Partners & Co','Caisse d’assurance','Cloud Services Group','68012247218928');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(872,'Smart Partners Plus','Association caritative','Académie France','97520928907189'),
(873,'Smart Services Europe','Club','École Supérieure Plus','02002457988449');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(874,'Smart Services Global','Établissement','Voyage & Découverte','77029821845921'),
(875,'Smart Solutions Europe','Organisme professionnel','Zenith Consulting','11472323903744');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(876,'Smart Solutions Expert','Centre culturel','Domaine des Vignes','87769345447394'),
(877,'Smart Solutions Global','Coopérative agricole','Groupe National Services','60089038992004');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(878,'Smart Systèmes Expert','Marketplace','Stratégie Plus','21323742820359'),
(879,'Smart Technologies & Co','Chambre des métiers','BlueSky Consulting','55388261171392');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(880,'Smart Technologies Expert','Conseil','Premium Services','43325566877157'),
(881,'Synergie Conseil & Co','Conseil','Protect France','22765100049474');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(882,'Synergie Conseil Global','Ordre professionnel','Entreprise Moderne France','04978968248540'),
(883,'Synergie Corporation & Co','Université','Clinique du Parc','90841515698548');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(884,'Synergie Corporation Plus','Observatoire','Clarté Consulting','07331366793929'),
(885,'Synergie Développement & Co','Établissement','Société Nouvelle Horizon','40422184770298');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(886,'Synergie Développement Expert','Centre technique','Global Services Group','52765937778353'),
(887,'Synergie Expertise & Co','Institution éducative','Excellence Conseil','89537295446754');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(888,'Synergie Formation Pro','Agence événementielle','Auto Plus France','00779231135028'),
(889,'Synergie France Pro','Préfecture','Optimum Conseil','98174059182580');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(890,'Synergie Gestion Europe','École','Logistique France','02023850893177'),
(891,'Synergie Gestion France','Autorité indépendante','Gourmet Services','23724463755149');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(892,'Synergie Gestion Plus','Réseau','Design Solutions','48350781594351'),
(893,'Synergie Group Pro','Conseil municipal','Entreprise Moderne France','02334169063120');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(894,'Synergie Industries Europe','Entreprise de télécommunications','Restaurant du Parc','44059864381490'),
(895,'Synergie Industries Plus','Ordre professionnel','Smart Solutions','26826797377974');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(896,'Synergie Innovations & Co','Site e-commerce','Clarté Consulting','23635291262001'),
(897,'Synergie Innovations Europe','École publique','Cap Excellence','50733358627451');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(898,'Synergie International Pro','Start-up','Pôle Compétitivité Tech','62112143354238'),
(899,'Synergie Partners','Bureau de contrôle','System Consulting','44077492347054');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(900,'Synergie Partners Europe','Institution éducative','Objectif Performance','36374560475866'),
(901,'Synergie Partners Plus','Agence de voyage','Pôle Compétitivité Tech','25927201689557');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(902,'Synergie Services & Co','Service technique','Auto Plus France','18275332633804'),
(903,'Synergie Solutions Pro','Entreprise individuelle','Invest Group France','98295826703555');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(904,'Synergie Systèmes Global','Agence digitale','Entreprise Française Innovation','88493964795950'),
(905,'Synergie Technologies Europe','Office de tourisme','Formation Plus','63566549364779');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(906,'Terra Consulting Europe','Association loi 1901','Dev Solutions','84283555821443'),
(907,'Terra Consulting Plus','Agence d’intérim','Supply Chain Group','35331544991851');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(908,'Terra Corporation & Co','Conseil régional','Talent Consulting','65059321274333'),
(909,'Terra Corporation Expert','Entreprise de logistique','École Supérieure Plus','14215668176686');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(910,'Terra Développement','Association','Food Services Group','62946030635593'),
(911,'Terra Développement Global','Conseil municipal','BlueSky Consulting','65025980080164');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(912,'Terra Formation & Co','Association culturelle','Accélérateur Business','99498507988916'),
(913,'Terra Formation Europe','Ferme','Studio Créatif','83745581487106');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(914,'Terra Formation Plus','Laboratoire de recherche','Sigma Solutions','77713038306245'),
(915,'Terra France Expert','Service public','Optimum Conseil','94380162185133');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(916,'Terra France Plus','Office de tourisme','Coopérative Agricole France','31066711958018'),
(917,'Terra Group','Multinationale','Optima Gestion','85470578718437');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(918,'Terra Group France','Filiale','Concept Développement','67766846737625'),
(919,'Terra Group Plus','Magasin','Core Services','95042036874061');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(920,'Terra Innovations Expert','École supérieure','Innova Services','30481032968221'),
(921,'Terra Innovations Pro','Mutuelle','Environnement Conseil','24102777596522');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(922,'Terra International Global','Association environnementale','Protect France','59659737097463'),
(923,'Terra Services Global','Grande entreprise','Solar Tech France','52365408844332');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(924,'Terra Services Pro','Entreprise artisanale','Alpha Conseil','56249363331718'),
(925,'Terra Solutions','Filiale','École Supérieure Plus','33776461241242');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(926,'Terra Solutions & Co','Conseil municipal','École Supérieure Plus','42275147290388'),
(927,'Terra Solutions Europe','Administration','Corporate Services','38947314482331');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(928,'Terra Solutions Global','Mission locale','Association Solidarité','48726894574808'),
(929,'Terra Solutions Plus','Pharmacie','NextGen Solutions','01421201243713');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(930,'Terra Systèmes & Co','Restaurant','Audit & Conseil','82151070583105'),
(931,'Terra Systèmes France','Bar','Association Solidarité','78538589014462');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(932,'Terra Technologies & Co','Entreprise sociale','Entreprise Française Innovation','26649351083079'),
(933,'Vertex Conseil Expert','Hypermarché','Vision & Co','88053913083863');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(934,'Vertex Corporation','Multinationale','Future Solutions','87239062948546'),
(935,'Vertex Corporation & Co','Artisan','Société Nouvelle Horizon','93362141690861');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(936,'Vertex Développement & Co','Société coopérative','Cargo Solutions','72304941678757'),
(937,'Vertex Expertise Expert','École d’ingénieurs','Vignoble Prestige','18374159917077');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(938,'Vertex Expertise Global','Service','Pharma Services','04293006577437'),
(939,'Vertex Formation France','Chambre','Menuiserie Dupont','60176863222473');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(940,'Vertex France Pro','Service commercial','Tourisme Services','55740942157711'),
(941,'Vertex Group & Co','Société commerciale','Avenir Formation','71767514598364');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(942,'Vertex Group Global','Laboratoire de recherche','Groupe Financia','01188729139687'),
(943,'Vertex Industries & Co','Association loi 1901','Ferme du Val','12660505513139');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(944,'Vertex Industries Europe','Centre de recherche','Agence Immo Plus','64720703707151'),
(945,'Vertex International','Agence de recrutement','Talent Consulting','58272819205940');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(946,'Vertex International Plus','Structure d’insertion','Pro Active Consulting','94319945137515'),
(947,'Vertex Partners','Association humanitaire','Recrutement Plus','42106249456568');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(948,'Vertex Partners Global','Agence de recrutement','Optimum Conseil','29394959641879'),
(949,'Vertex Systèmes','Société de transport','Atelier Création','80996630516923');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(950,'Vertex Systèmes & Co','Entreprise de rénovation','ONG Aide Internationale','25796598429179'),
(951,'Vertex Technologies','Artisan','Retail Solutions','40023997131692');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(952,'Vision Corporation Plus','Entreprise solidaire','Coopérative Agricole France','22774338202085'),
(953,'Vision Développement Plus','Association sportive','Market France','21020589793408');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(954,'Vision Expertise Europe','Agence immobilière','Groupe Horizon','54270061107347'),
(955,'Vision Expertise Expert','Association environnementale','Centre Recherche France','18634397731587');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(956,'Vision Formation Expert','Domain viticole','Dynamik Solutions','48843166072549'),
(957,'Vision France France','Centre d’affaires','System Consulting','58868091201625');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(958,'Vision France Global','Société anonyme','Développement Durable France','85647495234880'),
(959,'Vision Gestion & Co','Conseil régional','Auto Plus France','13365251556065');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(960,'Vision Gestion Europe','Organisme de formation','ONG Aide Internationale','14611134835695'),
(961,'Vision Group Expert','Institution culturelle','Campus Formation','43240249605851');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(962,'Vision Group Plus','Vignoble','Recrutement Plus','01557588929001'),
(963,'Vision Group Pro','Société industrielle','Groupe Horizon','62763942702017');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(964,'Vision Industries Europe','Établissement financier','Café du Centre SARL','24170355504810'),
(965,'Vision Industries France','École d’ingénieurs','Bio Solutions Group','18441345481641');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(966,'Vision Innovations France','Organisation','Digital Factory','44661769122214'),
(967,'Vision International','Établissement de santé','Groupe Évolution','25261950549250');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(968,'Vision International & Co','Cabinet d’avocats','Formation Plus','72504089013780'),
(969,'Vision Partners Expert','Association loi 1901','Optima Gestion','77414295911652');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(970,'Vision Partners Plus','Entreprise solidaire','Expert Compta Group','27876330353743'),
(971,'Vision Services & Co','Cabinet','Cargo Solutions','10883436907582');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(972,'Vision Services Plus','Coopérative','Distribution Services','46419142745920'),
(973,'Vision Solutions & Co','Agence gouvernementale','Clarté Consulting','76901312510745');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(974,'Vision Systèmes','Entreprise familiale','Talent Consulting','81130859967700'),
(975,'Vision Systèmes Pro','Entreprise familiale','Core Services','66379098642008');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(976,'Vision Technologies & Co','Organisation non gouvernementale','Alliance Conseil','86493202095745'),
(977,'Zenith Conseil France','Hôpital','SoluTech','71486807625483');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(978,'Zenith Conseil Global','Entreprise innovante','Expertis Consulting','10715087439461'),
(979,'Zenith Consulting','Entreprise de BTP','Exploitation Agricole Martin','34059022183492');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(980,'Zenith Consulting Europe','Club','Expertis Consulting','30243174223813'),
(981,'Zenith Corporation France','Entreprise de construction','Gourmet Services','19300646958425');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(982,'Zenith Développement & Co','Grande entreprise','Groupe International Services','24991681647176'),
(983,'Zenith Développement Global','Organisme privé','Gourmet Services','48142866004868');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(984,'Zenith Développement Plus','Fondation reconnue d’utilité publique','Événementiel Plus','33643311655418'),
(985,'Zenith Développement Pro','Agence digitale','Performance Conseil','84816093713127');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(986,'Zenith Expertise & Co','Agence de recrutement','Proxima Services','17212656914219'),
(987,'Zenith Expertise Global','Entreprise de BTP','Urban Immo Group','42013812405854');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(988,'Zenith Expertise Plus','Lycée','Dynamik Solutions','89192184661388'),
(989,'Zenith Formation','Magasin','Travaux & Co','36000281227549');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(990,'Zenith France France','Site e-commerce','Santé Services','32484628146797'),
(991,'Zenith France Plus','Société par actions simplifiée','Rénovation Experts','61656642669630');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(992,'Zenith Innovations Global','Mission locale','Distribution Services','64305103200016'),
(993,'Zenith Partners','Société de conseil','Fondation Avenir','48970291203654');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(994,'Zenith Partners France','Association caritative','Groupe Horizon','82378477413219'),
(995,'Zenith Partners Global','Conseil','Rénovation Experts','44628265691764');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(996,'Zenith Solutions Plus','Société de services','Campus Formation','93440916349061'),
(997,'Zenith Systèmes Global','Société d’investissement','Réseau Performance','57923469087983');

INSERT INTO Organisme (refOrganisme,nomOrganisme,typeOrganisme,raisonSociale,numeroSIRET) VALUES
(998,'Zenith Systèmes Plus','Réseau associatif','Transport Services','08600873814599'),
(999,'Zenith Technologies Expert','Société anonyme','Protect France','31843211877457');

