INSERT INTO Organisation (numero,adresse) VALUES
(0,'524 Carcagnol, 79360 Villiers-en-Bois'),
(1,'178 Le Courtil Jean Raimbeaux, 12270 La Fouillade');

INSERT INTO Organisation (numero,adresse) VALUES
(2,'344 Les Cazelles, 51800 Vienne-la-Ville'),
(3,'736 Quai d''Armement - L, 73470 Gerbaix');

INSERT INTO Organisation (numero,adresse) VALUES
(4,'780 Les Hauts Savornins, 61560 Courgeoût'),
(5,'929bis Saubiel, 25110 Vergranne');

INSERT INTO Organisation (numero,adresse) VALUES
(6,'415 Résidence Chappe, 24140 Saint-Martin-des-Combes'),
(7,'712 Pratmau, 80540 Guignemicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(8,'591 Mas Belenq, 06530 Peymeinade'),
(9,'292 Bourg de FAYET, 02250 Autremencourt');

INSERT INTO Organisation (numero,adresse) VALUES
(10,'909 Les Garennes, 79100 Saint-Léger-de-Montbrun'),
(11,'214bis Pisse Co, 11240 Ferran');

INSERT INTO Organisation (numero,adresse) VALUES
(12,'308 Sarradials, 20218 Castineta'),
(13,'262bis Le Saint Lieu, 15500 Auriac-l''Église');

INSERT INTO Organisation (numero,adresse) VALUES
(14,'837 Quartier la Gradine, 42110 Valeille'),
(15,'502 Valcros et Rousset, 07170 Villeneuve-de-Berg');

INSERT INTO Organisation (numero,adresse) VALUES
(16,'998bis Poteau de Sauveterre, 60940 Cinqueux'),
(17,'677 Le Petit Monceau, 25270 Crouzet-Migette');

INSERT INTO Organisation (numero,adresse) VALUES
(18,'326 Domaine de Saint Victor, 33870 Vayres'),
(19,'70bis Belinguié, 80220 Bouttencourt');

INSERT INTO Organisation (numero,adresse) VALUES
(20,'235 Petit Bourg, 44680 Chaumes-en-Retz'),
(21,'695 Les Bois Plantes, 69620 Saint-Laurent-d''Oingt');

INSERT INTO Organisation (numero,adresse) VALUES
(22,'21 Epanchoir de Foucaud, 19600 Chasteaux'),
(23,'819 Les Longues Raies, 40700 Bassercles');

INSERT INTO Organisation (numero,adresse) VALUES
(24,'968 Maisonnette Comelles, 77860 Couilly-Pont-aux-Dames'),
(25,'808 En Pras Ruit, 33550 Capian');

INSERT INTO Organisation (numero,adresse) VALUES
(26,'942 Les Lazes, 39250 Cerniébaud'),
(27,'841 La Litiere, 61600 Saint-Georges-d''Annebecq');

INSERT INTO Organisation (numero,adresse) VALUES
(28,'146bis Les Collets, 08230 Sévigny-la-Forêt'),
(29,'253 Belses, 49330 Étriché');

INSERT INTO Organisation (numero,adresse) VALUES
(30,'54bis Bérot, 74960 Cran-Gevrier'),
(31,'366 la Lausiere, 57570 Mondorff');

INSERT INTO Organisation (numero,adresse) VALUES
(32,'518 La Grange d''En Bas, 54290 Crévéchamps'),
(33,'795bis Le Château Artonges, 24290 Fanlac');

INSERT INTO Organisation (numero,adresse) VALUES
(34,'354bis Avenue du Grand Jas, 54760 Arraye-et-Han'),
(35,'470 Les Croptins, 01480 Ars-sur-Formans');

INSERT INTO Organisation (numero,adresse) VALUES
(36,'953 Tres Le Serre, 21200 Montagny-lès-Beaune'),
(37,'135 Les Chauzes, 69400 Limas');

INSERT INTO Organisation (numero,adresse) VALUES
(38,'281 Le Serret, 08150 Lépron-les-Vallées'),
(39,'560 La Kayouta, 38690 Eydoche');

INSERT INTO Organisation (numero,adresse) VALUES
(40,'919 Maison Seule, 42470 Fourneaux'),
(41,'694bis Les Griffouls, 17430 Muron');

INSERT INTO Organisation (numero,adresse) VALUES
(42,'957 Varennes, 25550 Bavans'),
(43,'78 Col de Fourniero-ouest, 65130 Laborde');

INSERT INTO Organisation (numero,adresse) VALUES
(44,'591 Voie de liaison Ruelle des Prés - Rue Rancher, 17810 Saint-Georges-des-Coteaux'),
(45,'718 Pre Bombert, 62270 Boubers-sur-Canche');

INSERT INTO Organisation (numero,adresse) VALUES
(46,'373 Résidence Panoramique, 80490 Bailleul'),
(47,'456bis Le Bon Poirier, 07120 Pradons');

INSERT INTO Organisation (numero,adresse) VALUES
(48,'468bis Noir Vaux, 25160 Remoray-Boujeons'),
(49,'899bis Champ du Pommier, 70000 Charmoille');

INSERT INTO Organisation (numero,adresse) VALUES
(50,'397 Lafarge, 60410 Villeneuve-sur-Verberie'),
(51,'121 Parc Carol de Roumanie, 50480 Brucheville');

INSERT INTO Organisation (numero,adresse) VALUES
(52,'716 "Buvette ""Crêperie du Lac""", 11290 Roullens'),
(53,'481 Allée du Cèdre vert, 57670 Bénestroff');

INSERT INTO Organisation (numero,adresse) VALUES
(54,'723bis Colognac, 76270 Sainte-Beuve-en-Rivière'),
(55,'215 Escalier de l''Ancien Chemin de l''Abadie, 13123 Arles');

INSERT INTO Organisation (numero,adresse) VALUES
(56,'252bis Pincinelli, 48500 La Tieule'),
(57,'511bis Les Vignes, 34400 Vérargues');

INSERT INTO Organisation (numero,adresse) VALUES
(58,'114bis lieu dit Bénas d''en bas, 12640 La Cresse'),
(59,'766 Bois de Madame, 14280 Authie');

INSERT INTO Organisation (numero,adresse) VALUES
(60,'81 Le Mas Des Oliviers, 04500 Saint-Laurent-du-Verdon'),
(61,'81bis La Molette, 35650 Le Rheu');

INSERT INTO Organisation (numero,adresse) VALUES
(62,'50 13ème Bis, 02340 Vincy-Reuil-et-Magny'),
(63,'708bis Stables, 59740 Bérelles');

INSERT INTO Organisation (numero,adresse) VALUES
(64,'384 Le Moulin De Roche, 66500 Villefranche-de-Conflent'),
(65,'740bis My Lou, 30490 Montfrin');

INSERT INTO Organisation (numero,adresse) VALUES
(66,'38 Le Rose, 53350 La Roë'),
(67,'286 Les Tioulieres, 62960 Erny-Saint-Julien');

INSERT INTO Organisation (numero,adresse) VALUES
(68,'390 Morand, 76940 Vatteville-la-Rue'),
(69,'46 Quartier du Bac, 21310 Noiron-sur-Bèze');

INSERT INTO Organisation (numero,adresse) VALUES
(70,'27 ZAE Lucien AUZAS NORD - Porte A, 28800 Saumeray'),
(71,'144 ld mardagne, 21610 Saint-Seine-sur-Vingeanne');

INSERT INTO Organisation (numero,adresse) VALUES
(72,'464 Coutiet d''en haut, 42220 Burdignes'),
(73,'970 Route des gîtes, 53200 Coudray');

INSERT INTO Organisation (numero,adresse) VALUES
(74,'654 Prats d''Ambach, 17320 Saint-Just-Luzac'),
(75,'896 Fracieta, 10350 Le Pavillon-Sainte-Julie');

INSERT INTO Organisation (numero,adresse) VALUES
(76,'675 Transformateur électrique, 57260 Guébling'),
(77,'847 Mas De Cocagne, 60153 Rethondes');

INSERT INTO Organisation (numero,adresse) VALUES
(78,'421bis Font du Roi, 67000 Strasbourg'),
(79,'442bis Les Grands Barons, 51130 Vert-Toulon');

INSERT INTO Organisation (numero,adresse) VALUES
(80,'651 Grande Serve, 71340 Iguerande'),
(81,'689 La Mairie de Vendresse, 45300 Courcy-aux-Loges');

INSERT INTO Organisation (numero,adresse) VALUES
(82,'709bis Allée Résistance et Déportation, 62120 Campagne-lès-Wardrecques'),
(83,'149 Les Aousserots, 19430 La Chapelle-Saint-Géraud');

INSERT INTO Organisation (numero,adresse) VALUES
(84,'222 Montée du Barry, 78500 Sartrouville'),
(85,'61 Chez Demas, 74370 Les Ollières');

INSERT INTO Organisation (numero,adresse) VALUES
(86,'721 Église Notre Dame de Romigier, 31160 Montastruc-de-Salies'),
(87,'859 Trounet, 80320 Hypercourt');

INSERT INTO Organisation (numero,adresse) VALUES
(88,'130bis Rue du Galion, 20116 Aullène'),
(89,'328 La Fillole, 66330 Cabestany');

INSERT INTO Organisation (numero,adresse) VALUES
(90,'968bis Les Grands Cleux, 12400 Les Costes-Gozon'),
(91,'308 Le Bois de Geys, 46400 Saint-Paul-de-Vern');

INSERT INTO Organisation (numero,adresse) VALUES
(92,'578 La Cote Saint-Marc, 46100 Camboulit'),
(93,'671 Les Cledies, 25430 Chazot');

INSERT INTO Organisation (numero,adresse) VALUES
(94,'975 Couronne Du Cros C, 59830 Cobrieux'),
(95,'595 Allée des Lucioles, 14340 Valsemé');

INSERT INTO Organisation (numero,adresse) VALUES
(96,'340 Chemin de Brégancon, 51400 Sept-Saulx'),
(97,'727 Port Fitou, 56230 Molac');

INSERT INTO Organisation (numero,adresse) VALUES
(98,'994 Mousset Haut, 06130 Grasse'),
(99,'742bis Tremoulet, 78790 Arnouville-lès-Mantes');

INSERT INTO Organisation (numero,adresse) VALUES
(100,'77bis Les Grands Près, 76210 Saint-Eustache-la-Forêt'),
(101,'838 Le Bois de Larat, 57170 Hampont');

INSERT INTO Organisation (numero,adresse) VALUES
(102,'486 Les Crêtes, 49520 Noyant-la-Gravoyère'),
(103,'489bis La Serre, 11240 Belvèze-du-Razès');

INSERT INTO Organisation (numero,adresse) VALUES
(104,'746 La Font Vineuse, 07200 Rochecolombe'),
(105,'63bis Prads, 50450 Ver');

INSERT INTO Organisation (numero,adresse) VALUES
(106,'601 Les Rochers du Chateau, 15700 Pleaux'),
(107,'226bis Chemin des Adrés, 63500 Perrier');

INSERT INTO Organisation (numero,adresse) VALUES
(108,'80 Florazur B, 55500 Stainville'),
(109,'593 La Sabolieme, 26210 Lens-Lestang');

INSERT INTO Organisation (numero,adresse) VALUES
(110,'583bis Blanzou, 42130 Marcilly-le-Châtel'),
(111,'22bis La Promenade, 32230 Scieurac-et-Flourès');

INSERT INTO Organisation (numero,adresse) VALUES
(112,'835 Champ du Garric, 50390 Reigneville-Bocage'),
(113,'224 Bordevieille, 46120 Saint-Bressou');

INSERT INTO Organisation (numero,adresse) VALUES
(114,'861 Les Ardelets, 80210 Valines'),
(115,'713 Hlm le Plessis Bat E2, 56530 Gestel');

INSERT INTO Organisation (numero,adresse) VALUES
(116,'970 Prix, 08380 Tarzy'),
(117,'609 Ruelle Cliquette, 69510 Thurins');

INSERT INTO Organisation (numero,adresse) VALUES
(118,'385 Rase de Jaillon, 01390 Mionnay'),
(119,'313 Les Pailles-nord, 67130 Wildersbach');

INSERT INTO Organisation (numero,adresse) VALUES
(120,'120 Le Gros Bonnet, 76790 Étretat'),
(121,'201 Petit Simandre, 71960 Bussières');

INSERT INTO Organisation (numero,adresse) VALUES
(122,'407 La Promenade, 79200 Parthenay'),
(123,'259 La Taille Charles, 58270 Saint-Jean-aux-Amognes');

INSERT INTO Organisation (numero,adresse) VALUES
(124,'387 Lieu-dit Le Magret, 45550 Saint-Denis-de-l''Hôtel'),
(125,'733bis La Pièce de la Croix, 34210 Agel');

INSERT INTO Organisation (numero,adresse) VALUES
(126,'733 Gravas, 42110 Saint-Martin-Lestra'),
(127,'891 Quarton, 62130 Guinecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(128,'673 Résidence Murat, 76780 Argueil'),
(129,'163 Rond-Point du Logis du Loup, 37120 La Tour-Saint-Gelin');

INSERT INTO Organisation (numero,adresse) VALUES
(130,'127 Vaysse, 40120 Maillères'),
(131,'863 Boulet, 31410 Saint-Hilaire');

INSERT INTO Organisation (numero,adresse) VALUES
(132,'765 Remenos, 17400 Ternant'),
(133,'686 La Coumbetta, 35210 Saint-Christophe-des-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(134,'562 Le Souvenir, 24160 Saint-Jory-las-Bloux'),
(135,'691 Ot Mediatheque et Musee les Memoires, 68510 Kœtzingue');

INSERT INTO Organisation (numero,adresse) VALUES
(136,'749 Pierrelongue, 21200 Bouze-lès-Beaune'),
(137,'917 Rond point Nova Antipolis, 28130 Soulaires');

INSERT INTO Organisation (numero,adresse) VALUES
(138,'932 Réserve de Magny, 62132 Fiennes'),
(139,'630 Puech Vernet, 52100 Sapignicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(140,'789bis La Rodelle, 15600 Saint-Étienne-de-Maurs'),
(141,'364 Les Loges Des Vallieres A/B, 62980 Noyelles-lès-Vermelles');

INSERT INTO Organisation (numero,adresse) VALUES
(142,'529 Fromagerie, 45270 Nesploy'),
(143,'522 La Hajelette, 21310 Arceau');

INSERT INTO Organisation (numero,adresse) VALUES
(144,'236 Impasse du Verger, 30110 Soustelle'),
(145,'912 Bois de Bozon, 14490 Noron-la-Poterie');

INSERT INTO Organisation (numero,adresse) VALUES
(146,'991 Cornillon, 77940 Voulx'),
(147,'607 Moulin de Bernard, 58800 Chaumot');

INSERT INTO Organisation (numero,adresse) VALUES
(148,'710 Voie liaison Chemin des Serres - Avenue Angélique Braquet, 40380 Onard'),
(149,'302 La Vieille Rue, 62144 Villers-au-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(150,'82 Route Departementale 119, 33210 Mazères'),
(151,'368 Valtan, 33670 Le Pout');

INSERT INTO Organisation (numero,adresse) VALUES
(152,'975bis Rue de la République, 63350 Crevant-Laveine'),
(153,'771 La Longe, 72150 Saint-Georges-de-la-Couée');

INSERT INTO Organisation (numero,adresse) VALUES
(154,'31 Parc Naturel Départemental des Rives du Loup, 17330 Loulay'),
(155,'947 Derriere le Colombié, 31230 Labastide-Paumès');

INSERT INTO Organisation (numero,adresse) VALUES
(156,'494 Campas, 06580 Pégomas'),
(157,'909 Les Mourlans, 04700 Lurs');

INSERT INTO Organisation (numero,adresse) VALUES
(158,'692 Les Hermes, 71640 Saint-Mard-de-Vaux'),
(159,'620 Place de la Poste, 25360 Saint-Juan');

INSERT INTO Organisation (numero,adresse) VALUES
(160,'830 Les Mourades, 72210 Chemiré-le-Gaudin'),
(161,'991 Moulin Tombé, 77750 Orly-sur-Morin');

INSERT INTO Organisation (numero,adresse) VALUES
(162,'37 Le Gatta, 32500 Fleurance'),
(163,'745 Voie d''accès CREAM, 60590 Sérifontaine');

INSERT INTO Organisation (numero,adresse) VALUES
(164,'669 Les Jardins De Cagnes, 60650 Blacourt'),
(165,'768 Le Mas Saint Jean Villas, 62710 Courrières');

INSERT INTO Organisation (numero,adresse) VALUES
(166,'856 Fenouillet, 77560 Champcenest'),
(167,'7 Montée Mengola, 19330 Saint-Germain-les-Vergnes');

INSERT INTO Organisation (numero,adresse) VALUES
(168,'992bis Fond de Graviere, 80190 Épénancourt'),
(169,'708bis La Pendarie, 14220 Les Moutiers-en-Cinglais');

INSERT INTO Organisation (numero,adresse) VALUES
(170,'17 Magrinet-Sud, 38970 Beaufin'),
(171,'434 Impasse des Amis, 27600 Le Val d''Hazey');

INSERT INTO Organisation (numero,adresse) VALUES
(172,'556 Barral, 21121 Hauteville-lès-Dijon'),
(173,'872bis Escoussas Nord, 33840 Lerm-et-Musset');

INSERT INTO Organisation (numero,adresse) VALUES
(174,'325 Hameau du triadou, 35390 Grand-Fougeray'),
(175,'736 Chemin de l''Aco de Martin, 71530 Virey-le-Grand');

INSERT INTO Organisation (numero,adresse) VALUES
(176,'606 Passage du Patrimoine, 21330 Vertault'),
(177,'233 Pavillon Baroque, 55400 Morgemoulin');

INSERT INTO Organisation (numero,adresse) VALUES
(178,'466bis L''Oiseau, 17570 Les Mathes'),
(179,'158 Ginestoux, 07610 Lemps');

INSERT INTO Organisation (numero,adresse) VALUES
(180,'427 La Tilerie, 17140 Lagord'),
(181,'84bis Jardin Mélinée et Missak Manouchian, 70230 Vy-lès-Filain');

INSERT INTO Organisation (numero,adresse) VALUES
(182,'180bis Montée de l''Abbaye de Saint-Pons, 02380 Coucy-le-Château-Auffrique'),
(183,'352 Monteillet, 40320 Urgons');

INSERT INTO Organisation (numero,adresse) VALUES
(184,'912 Chemin de Montjinou, 60400 Sempigny'),
(185,'519 Liaison Rond Point Maicon/Avenue Francis Teisseire, 09350 Montfa');

INSERT INTO Organisation (numero,adresse) VALUES
(186,'976 Lotissement le Clos du Castel LOT 5, 24360 Varaignes'),
(187,'932bis Berdou, 27910 Vascœuil');

INSERT INTO Organisation (numero,adresse) VALUES
(188,'649 Ruelle Charpentier, 14340 La Roque-Baignard'),
(189,'909bis Chemin du Pilon du Roy, 41150 Mesland');

INSERT INTO Organisation (numero,adresse) VALUES
(190,'452 Teste Rouge, 35440 Dingé'),
(191,'342 Chemin de la Mer d''Eze, 44690 Monnières');

INSERT INTO Organisation (numero,adresse) VALUES
(192,'101 Rond point du Val Claret, 39270 Sarrogna'),
(193,'389 La Guirauzelle, 42310 Sail-les-Bains');

INSERT INTO Organisation (numero,adresse) VALUES
(194,'860 Stade municipale Serge Mésonès - ERP, 26730 Eymeux'),
(195,'412bis Le Haut du Village, 66220 Saint-Paul-de-Fenouillet');

INSERT INTO Organisation (numero,adresse) VALUES
(196,'79 Chemin des Anémones, 51130 Chaltrait'),
(197,'795 Manaut, 79160 Coulonges-sur-l''Autize');

INSERT INTO Organisation (numero,adresse) VALUES
(198,'734 Coupes, 15500 Charmensac'),
(199,'299 Square Elie Levy, 77160 Rouilly');

INSERT INTO Organisation (numero,adresse) VALUES
(200,'693 Les Avertis, 31450 Montbrun-Lauragais'),
(201,'380 Chante Parne, 25390 Consolation-Maisonnettes');

INSERT INTO Organisation (numero,adresse) VALUES
(202,'222 Lapanouse de Cernon, 64640 Iholdy'),
(203,'663 La Croix Pendrie, 60150 Coudun');

INSERT INTO Organisation (numero,adresse) VALUES
(204,'364 Montmorin, 67500 Haguenau'),
(205,'293 La Rue Mérié, 39100 Champvans');

INSERT INTO Organisation (numero,adresse) VALUES
(206,'641 La Guerrière, 59740 Lez-Fontaine'),
(207,'991 Collets Sud, 13250 Cornillon-Confoux');

INSERT INTO Organisation (numero,adresse) VALUES
(208,'465 Delta, 21540 Grosbois-en-Montagne'),
(209,'595 Serre de l''Eveque, 25580 Étalans');

INSERT INTO Organisation (numero,adresse) VALUES
(210,'421 Saint-Etienne, 17130 Jussas'),
(211,'157 ZI de Vergonhac, 50310 Montebourg');

INSERT INTO Organisation (numero,adresse) VALUES
(212,'641 L''Estrop-ouest, 17520 Saint-Ciers-Champagne'),
(213,'132 Voie Communale Ferme du Bois des Huttes, 40300 Orist');

INSERT INTO Organisation (numero,adresse) VALUES
(214,'46 Lizarnie, 36210 Val-Fouzon'),
(215,'825bis Les Combes ouest, 67310 Traenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(216,'449 La Madeleine Nord Ouest, 64350 Lasserre'),
(217,'83bis La Cave Basse, 62134 Anvin');

INSERT INTO Organisation (numero,adresse) VALUES
(218,'610 Fontane, 62128 Noreuil'),
(219,'6 Bissieux, 29510 Briec');

INSERT INTO Organisation (numero,adresse) VALUES
(220,'606 Vers le Moulin Est, 64400 Précilhon'),
(221,'911 Les Sauvages, 79380 Saint-André-sur-Sèvre');

INSERT INTO Organisation (numero,adresse) VALUES
(222,'381 Bonnepause, 52100 Sapignicourt'),
(223,'617 Le Foirail, 20217 Nonza');

INSERT INTO Organisation (numero,adresse) VALUES
(224,'468 Place Chanoine César Musso, 57415 Enchenberg'),
(225,'68bis Gagliardet, 27220 La Baronnie');

INSERT INTO Organisation (numero,adresse) VALUES
(226,'964bis La Maison De Marie, 61800 Moncy'),
(227,'192 Les Planes Del Riou, 34270 Lauret');

INSERT INTO Organisation (numero,adresse) VALUES
(228,'978 Sagne Soulier, 62134 Monchy-Cayeux'),
(229,'175bis Les Riez Megrez, 26340 Rimon-et-Savel');

INSERT INTO Organisation (numero,adresse) VALUES
(230,'565bis L''Ariail, 33290 Blanquefort'),
(231,'824 Les Bastides De L''Hubac 2-3, 68600 Wolfgantzen');

INSERT INTO Organisation (numero,adresse) VALUES
(232,'371bis ZI de l''Omois, 32430 Saint-Georges'),
(233,'341 Les Basses Certelles, 02270 Monceau-le-Neuf-et-Faucouzy');

INSERT INTO Organisation (numero,adresse) VALUES
(234,'916 Pont de la Pierre, 26240 Beausemblant'),
(235,'414 La Briandiere, 47600 Francescas');

INSERT INTO Organisation (numero,adresse) VALUES
(236,'965 Breillet, 02480 Dury'),
(237,'803 Les Burlons Bas, 19200 Thalamy');

INSERT INTO Organisation (numero,adresse) VALUES
(238,'311 Boude, 72340 Loir en Vallée'),
(239,'310 Chateau des Millets, 60400 Varesnes');

INSERT INTO Organisation (numero,adresse) VALUES
(240,'29 La Bourgogne, 32430 Saint-Georges'),
(241,'174 Layat, 29600 Plourin-lès-Morlaix');

INSERT INTO Organisation (numero,adresse) VALUES
(242,'690 Chezelles, 38300 Domarin'),
(243,'934 Le Petit Boudet, 76640 Trémauville');

INSERT INTO Organisation (numero,adresse) VALUES
(244,'337 L''Espine, 45370 Mareau-aux-Prés'),
(245,'388 Refuge du Glacier Blanc, 68210 Falkwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(246,'586 Espace Jean Buffelan, 11250 Saint-Hilaire'),
(247,'578bis Quartier les Gravas, 21140 Lantilly');

INSERT INTO Organisation (numero,adresse) VALUES
(248,'571 Le Frayssinet Bas, 02000 Laon'),
(249,'944 La Massebeuve, 13103 Mas-Blanc-des-Alpilles');

INSERT INTO Organisation (numero,adresse) VALUES
(250,'533 La Boulbene, 14140 Saint-Georges-en-Auge'),
(251,'729 Courneilla, 17210 Bran');

INSERT INTO Organisation (numero,adresse) VALUES
(252,'347 Route Métropolitaine 67, 02760 Holnon'),
(253,'857bis La Salze, 64160 Sedzère');

INSERT INTO Organisation (numero,adresse) VALUES
(254,'383 Thiery Pré, 76450 Ocqueville'),
(255,'773 Le Capri, 14100 Firfol');

INSERT INTO Organisation (numero,adresse) VALUES
(256,'917 La Garde de Dieu, 44540 Saint-Sulpice-des-Landes'),
(257,'667 Le Garrigou, 57365 Flévy');

INSERT INTO Organisation (numero,adresse) VALUES
(258,'950 Caramot, 21220 Curtil-Vergy'),
(259,'646 Les Renards, 23600 Lavaufranche');

INSERT INTO Organisation (numero,adresse) VALUES
(260,'581bis Combe du Notaire, 23600 Saint-Marien'),
(261,'851 Grand Dergis - Hauteville Lompnes, 02140 Thenailles');

INSERT INTO Organisation (numero,adresse) VALUES
(262,'253 Le Grand Mont, 15700 Brageac'),
(263,'447 Le_colombier, 57450 Barst');

INSERT INTO Organisation (numero,adresse) VALUES
(264,'10bis Le Moulin du Saule, 05160 Réallon'),
(265,'302 Ferme Bouteille, 53640 Le Horps');

INSERT INTO Organisation (numero,adresse) VALUES
(266,'236 Voie de retournement RM2205, 39150 Grande-Rivière'),
(267,'709 Le Cammas Vieux, 51210 Fromentières');

INSERT INTO Organisation (numero,adresse) VALUES
(268,'111bis Canto Grillou, 65250 Gazave'),
(269,'346bis Logères, 72270 Ligron');

INSERT INTO Organisation (numero,adresse) VALUES
(270,'469bis Chaurès, 44170 Marsac-sur-Don'),
(271,'791 Le Bourdier, 35590 Clayes');

INSERT INTO Organisation (numero,adresse) VALUES
(272,'51bis Camboueich Nord, 58330 Bona'),
(273,'914bis Les_issards, 07310 Arcens');

INSERT INTO Organisation (numero,adresse) VALUES
(274,'175 Carrefous, 44460 Fégréac'),
(275,'280 La Galanderie, 77630 Barbizon');

INSERT INTO Organisation (numero,adresse) VALUES
(276,'497 Pomies, 19500 Ligneyrac'),
(277,'29 Voie Communale Cc de Froidmont à Plomion, 21270 Montmançon');

INSERT INTO Organisation (numero,adresse) VALUES
(278,'631 La Petite Locaterie, 52150 Sommerécourt'),
(279,'173 La Maisonneuve de Ladrey, 34690 Fabrègues');

INSERT INTO Organisation (numero,adresse) VALUES
(280,'31 Le Cros Saint Pierre B, 32600 Beaupuy'),
(281,'743 Coeur De Cagnes, 43300 Auvers');

INSERT INTO Organisation (numero,adresse) VALUES
(282,'649 Lafaille, 77440 Tancrou'),
(283,'428 Les Vellattes, 52230 Échenay');

INSERT INTO Organisation (numero,adresse) VALUES
(284,'394 En Cote Bordon, 70140 Montagney'),
(285,'925 Casa Bella - L''Olivette, 17800 Brives-sur-Charente');

INSERT INTO Organisation (numero,adresse) VALUES
(286,'58 Vers le Fond de Prez, 77151 Montceaux-lès-Provins'),
(287,'834 Trabesses, 05400 Rabou');

INSERT INTO Organisation (numero,adresse) VALUES
(288,'199bis Prés Ferrand, 02380 Fresnes-sous-Coucy'),
(289,'900 L''Oursin Bat A Et B, 67230 Westhouse');

INSERT INTO Organisation (numero,adresse) VALUES
(290,'720 Au Dessus de la Charbonnie, 23600 Malleret-Boussac'),
(291,'332 La Grande Metairie, 13890 Mouriès');

INSERT INTO Organisation (numero,adresse) VALUES
(292,'178 Les Monceaux, 11360 Villeneuve-les-Corbières'),
(293,'1bis Fourques d''en bas, 32420 Betcave-Aguin');

INSERT INTO Organisation (numero,adresse) VALUES
(294,'631 Magnobe, 80290 Hescamps'),
(295,'422 Rue de Belleu, 16560 Villejoubert');

INSERT INTO Organisation (numero,adresse) VALUES
(296,'362 Villa Colombe, 33124 Aillas'),
(297,'441 Le Bari, 28800 Saumeray');

INSERT INTO Organisation (numero,adresse) VALUES
(298,'780 Espinassous, 65200 Labassère'),
(299,'110bis La Couliche, 51300 Blacy');

INSERT INTO Organisation (numero,adresse) VALUES
(300,'786 Les Pennetieres, 19120 Queyssac-les-Vignes'),
(301,'98 Le Bois du Plante, 65690 Montignac');

INSERT INTO Organisation (numero,adresse) VALUES
(302,'253 Domaine de Barive, 06450 Utelle'),
(303,'224 Liaison Rue Raymond Ferraretto/Place Adrien Castillon, 01230 Chaley');

INSERT INTO Organisation (numero,adresse) VALUES
(304,'281bis La Filature, 15250 Laroquevieille'),
(305,'759 Les Hates, 61160 Brieux');

INSERT INTO Organisation (numero,adresse) VALUES
(306,'246 Route de Camon, 71960 Prissé'),
(307,'754 Le Beau Temps, 32730 Montégut-Arros');

INSERT INTO Organisation (numero,adresse) VALUES
(308,'642bis Font-Patine, 22530 Saint-Guen'),
(309,'231 Tatarau, 72160 Vouvray-sur-Huisne');

INSERT INTO Organisation (numero,adresse) VALUES
(310,'317 Lasserre Lissosse, 33570 Montagne'),
(311,'937bis Autet, 16480 Châtignac');

INSERT INTO Organisation (numero,adresse) VALUES
(312,'579 Mont de Madame Rose, 76490 Rives-en-Seine'),
(313,'190 Côte de la Poudrière, 14123 Ifs');

INSERT INTO Organisation (numero,adresse) VALUES
(314,'790 Les Contilles, 60117 Vauciennes'),
(315,'129 Place des Marchands, 32230 Pallanne');

INSERT INTO Organisation (numero,adresse) VALUES
(316,'961bis Chateau Blanc, 27300 Courbépine'),
(317,'289bis Place Larbe, 37600 Bridoré');

INSERT INTO Organisation (numero,adresse) VALUES
(318,'774 Le Monsiau, 15120 Montsalvy'),
(319,'896 Pra Ricende, 61130 Saint-Ouen-de-la-Cour');

INSERT INTO Organisation (numero,adresse) VALUES
(320,'833 Les Hermes, 20234 Ortale'),
(321,'709 Ferme des Francs Fossés, 07220 Saint-Montan');

INSERT INTO Organisation (numero,adresse) VALUES
(322,'875bis Allée Dali, 31320 Vieille-Toulouse'),
(323,'811 Chemin du Mont Saint Michel, 65170 Vielle-Aure');

INSERT INTO Organisation (numero,adresse) VALUES
(324,'752 Courneilla, 30170 Durfort-et-Saint-Martin-de-Sossenac'),
(325,'568bis Le Coulet, 57580 Baudrecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(326,'601 Cabantous, 33180 Vertheuil'),
(327,'846 La Teppe, 12640 Rivière-sur-Tarn');

INSERT INTO Organisation (numero,adresse) VALUES
(328,'411 Campeyrou, 34160 Campagne'),
(329,'165 Route de la Souleille, 38200 Luzinay');

INSERT INTO Organisation (numero,adresse) VALUES
(330,'686 Chameyer, 69350 La Mulatière'),
(331,'711 Rond Point du Gheit, 28140 Eole-en-Beauce');

INSERT INTO Organisation (numero,adresse) VALUES
(332,'742 La Sablonie, 20134 Sampolo'),
(333,'3 Les Pézeriaux, 21120 Frénois');

INSERT INTO Organisation (numero,adresse) VALUES
(334,'261 Bretelle Entrée Trachel - Mathis (Chaussée nord), 05800 Le Glaizil'),
(335,'171 Eglise Saint-Sernin, 21150 Thenissey');

INSERT INTO Organisation (numero,adresse) VALUES
(336,'472 Chemin rural de la Colle, 66210 Sauto'),
(337,'118bis Résidence l''Estello, 52500 Grenant');

INSERT INTO Organisation (numero,adresse) VALUES
(338,'270 La Troliere, 10210 Chesley'),
(339,'918 Place Masséna, 80310 Le Mesge');

INSERT INTO Organisation (numero,adresse) VALUES
(340,'756 Le Gagnage au Chat-sud, 57370 Metting'),
(341,'939 Les Pres-Ginies, 11390 Brousses-et-Villaret');

INSERT INTO Organisation (numero,adresse) VALUES
(342,'779 Les-Perissols, 02400 Brasles'),
(343,'894 Mercuer, 24370 Saint-Julien-de-Lampon');

INSERT INTO Organisation (numero,adresse) VALUES
(344,'200 Cremassorin Inférieur, 57645 Retonfey'),
(345,'463 Les Blanches Pierres, 25640 Villers-Grélot');

INSERT INTO Organisation (numero,adresse) VALUES
(346,'860 Les Carries, 76113 Sahurs'),
(347,'927bis Col Del Four, 24530 La Chapelle-Faucher');

INSERT INTO Organisation (numero,adresse) VALUES
(348,'570 Ferme L''Alpine des Colines, 33190 Les Esseintes'),
(349,'895 Fournet, 65290 Louey');

INSERT INTO Organisation (numero,adresse) VALUES
(350,'667 Résidence Maryland 2, 08090 Tournes'),
(351,'983 Résidence Petite Garrigue - Bâtiment Bouscarle, 76560 Doudeville');

INSERT INTO Organisation (numero,adresse) VALUES
(352,'269 Les Petits Beroyers, 10130 Villeneuve-au-Chemin'),
(353,'736 Place Francis Lai, 55170 Bazincourt-sur-Saulx');

INSERT INTO Organisation (numero,adresse) VALUES
(354,'783bis Les-Combes, 05110 Claret'),
(355,'875bis """ L''Oiseau """, 03130 Neuilly-en-Donjon');

INSERT INTO Organisation (numero,adresse) VALUES
(356,'287bis Le Fond de Chivres, 77610 Fontenay-Trésigny'),
(357,'728 L’Infialaire, 14330 Lison');

INSERT INTO Organisation (numero,adresse) VALUES
(358,'764 Domaine de Saint Angel, 70600 Argillières'),
(359,'744 Etang Biolet, 27100 Tournedos-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(360,'908 Maison Neuve, 11500 Ginoles'),
(361,'954 Château de la Crête, 20142 Campo');

INSERT INTO Organisation (numero,adresse) VALUES
(362,'88 Les Esmieux, 11240 Escueillens-et-Saint-Just-de-Bélengard'),
(363,'538 Le Bois d''Hartennes, 50240 Saint-Laurent-de-Terregatte');

INSERT INTO Organisation (numero,adresse) VALUES
(364,'499 Comba Versa, 69480 Anse'),
(365,'469 Moulin du Libezen, 32110 Arblade-le-Haut');

INSERT INTO Organisation (numero,adresse) VALUES
(366,'863 Puech Tournez, 02250 Montigny-sous-Marle'),
(367,'422 La Casette, 68800 Leimbach');

INSERT INTO Organisation (numero,adresse) VALUES
(368,'608 Mariet, 57920 Kédange-sur-Canner'),
(369,'701 Jean Dussert, 77310 Saint-Fargeau-Ponthierry');

INSERT INTO Organisation (numero,adresse) VALUES
(370,'614bis la Gaillardie, 56190 Billiers'),
(371,'99 Lescaragot, 47120 Saint-Jean-de-Duras');

INSERT INTO Organisation (numero,adresse) VALUES
(372,'591 Les Parizets, 40110 Villenave'),
(373,'95bis Les Mésanges, 15190 Marcenat');

INSERT INTO Organisation (numero,adresse) VALUES
(374,'851 Puech des Ayres, 01170 Crozet'),
(375,'140 Lotissement Michel Bernard, 39190 Maynal');

INSERT INTO Organisation (numero,adresse) VALUES
(376,'647 La Tour de l''Eau, 54150 Anoux'),
(377,'736bis Haut Soleil, 21410 Saint-Jean-de-Bœuf');

INSERT INTO Organisation (numero,adresse) VALUES
(378,'227 La Font des Clappiers, 11150 Villepinte'),
(379,'614 Les Longues Raies, 04250 Gigors');

INSERT INTO Organisation (numero,adresse) VALUES
(380,'203 Cap de Front Entrée 3, 11160 Caunes-Minervois'),
(381,'917bis La Saularie, 50300 Le Val-Saint-Père');

INSERT INTO Organisation (numero,adresse) VALUES
(382,'337 Croix de Recoules, 20225 Nessa'),
(383,'423bis L''Hippodrome B, 36700 Fléré-la-Rivière');

INSERT INTO Organisation (numero,adresse) VALUES
(384,'793 La Boutique, 59114 Saint-Sylvestre-Cappel'),
(385,'460bis Résidence Le Santa Cruz Bâtiment B, 66500 Catllar');

INSERT INTO Organisation (numero,adresse) VALUES
(386,'580bis Montée de Malignon, 68210 Montreux-Jeune'),
(387,'852 Rond-Point des Stades, 51420 Witry-lès-Reims');

INSERT INTO Organisation (numero,adresse) VALUES
(388,'534 Charrus, 78790 Montchauvet'),
(389,'656 Bombes, 07340 Andance');

INSERT INTO Organisation (numero,adresse) VALUES
(390,'489bis le Costal, 78440 Drocourt'),
(391,'210bis Riviere le Neuf, 39150 Château-des-Prés');

INSERT INTO Organisation (numero,adresse) VALUES
(392,'607 Ferme de la Malmaison, 48170 Saint-Jean-la-Fouillouse'),
(393,'216bis Lieu-dit le Bois, 72110 Saint-Denis-des-Coudrais');

INSERT INTO Organisation (numero,adresse) VALUES
(394,'819 Ferme de Sabeyanne, 10330 Bailly-le-Franc'),
(395,'149bis Pujau, 07400 Saint-Pierre-la-Roche');

INSERT INTO Organisation (numero,adresse) VALUES
(396,'505 Chemin de la Villa Noel, 15120 Leucamp'),
(397,'976 Mas du Serre, 47390 Layrac');

INSERT INTO Organisation (numero,adresse) VALUES
(398,'962 Les Montliaux, 39270 Présilly'),
(399,'75 Les combes, 56300 Neulliac');

INSERT INTO Organisation (numero,adresse) VALUES
(400,'209 Pre de la Pièce, 62270 Houvin-Houvigneul'),
(401,'917bis Cimetière du Forest, 02860 Chermizy-Ailles');

INSERT INTO Organisation (numero,adresse) VALUES
(402,'648 """ Les Chaulets """, 07000 Veyras'),
(403,'320 Mourviel, 64230 Arbus');

INSERT INTO Organisation (numero,adresse) VALUES
(404,'132 Les Razes, 59117 Wervicq-Sud'),
(405,'876bis Briare, 25270 Villers-sous-Chalamont');

INSERT INTO Organisation (numero,adresse) VALUES
(406,'204 Pont Bencet, 67390 Marckolsheim'),
(407,'466bis Maison Vieille, 45300 Morville-en-Beauce');

INSERT INTO Organisation (numero,adresse) VALUES
(408,'670 Le Christina A, 63980 Échandelys'),
(409,'186bis Aumont, 21330 Balot');

INSERT INTO Organisation (numero,adresse) VALUES
(410,'490bis Truquet, 63820 Laqueuille'),
(411,'750bis Les Rosières, 39700 Rans');

INSERT INTO Organisation (numero,adresse) VALUES
(412,'614 Foyer D''Urgence Ccas, 42130 Ailleux'),
(413,'533 Chemin de l''Hippodrome, 78930 Auffreville-Brasseuil');

INSERT INTO Organisation (numero,adresse) VALUES
(414,'688 Le Cambou, 09460 Mijanès'),
(415,'777 Le Raus, 80170 Rosières-en-Santerre');

INSERT INTO Organisation (numero,adresse) VALUES
(416,'623bis La Quietude, 01560 Courtes'),
(417,'288 Coste de Paou, 70300 Éhuns');

INSERT INTO Organisation (numero,adresse) VALUES
(418,'866 Le Misserou, 22800 Saint-Bihy'),
(419,'535 Curtil Bally, 21500 Asnières-en-Montagne');

INSERT INTO Organisation (numero,adresse) VALUES
(420,'479 Le Besseyrie, 33370 Sallebœuf'),
(421,'66 Chemin Departemental 116, 59620 Aulnoye-Aymeries');

INSERT INTO Organisation (numero,adresse) VALUES
(422,'910 Le Champ d''Orcy, 16500 Ansac-sur-Vienne'),
(423,'37 Le Picon, 31420 Samouillan');

INSERT INTO Organisation (numero,adresse) VALUES
(424,'259 Bâtiment A5, 59630 Cappelle-Brouck'),
(425,'127 Chemin Departemental 116, 62760 Mondicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(426,'784bis Bogue, 29600 Sainte-Sève'),
(427,'874 La Resse, 52340 Ageville');

INSERT INTO Organisation (numero,adresse) VALUES
(428,'48 Route de Vézouillac, 12230 Sainte-Eulalie-de-Cernon'),
(429,'396bis Puech le Franc, 80560 Colincamps');

INSERT INTO Organisation (numero,adresse) VALUES
(430,'389bis Le Cognet, 73330 Le Pont-de-Beauvoisin'),
(431,'152bis Les Crouzels, 33460 Cussac-Fort-Médoc');

INSERT INTO Organisation (numero,adresse) VALUES
(432,'723 Las Brugues, 07430 Colombier-le-Cardinal'),
(433,'710 Dardé, 11410 Marquein');

INSERT INTO Organisation (numero,adresse) VALUES
(434,'739 Hameaux De La Riviere, 68480 Pfetterhouse'),
(435,'911 Issanchou, 45120 Cepoy');

INSERT INTO Organisation (numero,adresse) VALUES
(436,'129bis Coume Belle, 28260 Berchères-sur-Vesgre'),
(437,'690 Terres Girard, 62158 Bavincourt');

INSERT INTO Organisation (numero,adresse) VALUES
(438,'670 Domaine de Bouilletiere, 04150 Revest-des-Brousses'),
(439,'434 le petit Laréna, 20220 Algajola');

INSERT INTO Organisation (numero,adresse) VALUES
(440,'254 Goué en Dessus, 17890 Chaillevette'),
(441,'526 Le Clos Seillard, 47350 Puymiclan');

INSERT INTO Organisation (numero,adresse) VALUES
(442,'555 Rue Principale, 39190 Vercia'),
(443,'895 Lotissement BENOIST (OAP), 27270 Mesnil-en-Ouche');

INSERT INTO Organisation (numero,adresse) VALUES
(444,'785 Place Larbe, 49112 Verrières-en-Anjou'),
(445,'453bis L''Occrochat, 25530 Courtetain-et-Salans');

INSERT INTO Organisation (numero,adresse) VALUES
(446,'552 HLM Les Roses, 21350 Villeferry'),
(447,'603 Lavillatte, 31220 Mondavezan');

INSERT INTO Organisation (numero,adresse) VALUES
(448,'277 Fort de Pierre Chatel, 07310 Lachapelle-sous-Chanéac'),
(449,'166 Mas Gauthier, 06470 Entraunes');

INSERT INTO Organisation (numero,adresse) VALUES
(450,'545 Rond-Point  Victor Vasarely, 64200 Arcangues'),
(451,'482bis Les Combalons, 61170 Coulonges-sur-Sarthe');

INSERT INTO Organisation (numero,adresse) VALUES
(452,'641 Chassin, 22660 Trévou-Tréguignec'),
(453,'365 Le Goutoulas, 28200 Saint-Denis-les-Ponts');

INSERT INTO Organisation (numero,adresse) VALUES
(454,'628 Carre Azur A-B-C-D, 02190 Neufchâtel-sur-Aisne'),
(455,'786bis Les Fans, 63720 Martres-sur-Morge');

INSERT INTO Organisation (numero,adresse) VALUES
(456,'848 Sous la Baume, 53110 Thubœuf'),
(457,'863 Le Forest, 09300 Lavelanet');

INSERT INTO Organisation (numero,adresse) VALUES
(458,'581 Le Mas de Bru, 29390 Leuhan'),
(459,'271 Les Jambions, 76590 Muchedent');

INSERT INTO Organisation (numero,adresse) VALUES
(460,'112 L''Aire, 63390 Sainte-Christine'),
(461,'977 Les Canalettes, 01130 Saint-Germain-de-Joux');

INSERT INTO Organisation (numero,adresse) VALUES
(462,'282bis Communal de Cornadouire, 70190 Beaumotte-Aubertans'),
(463,'983 Le Grevat, 68260 Kingersheim');

INSERT INTO Organisation (numero,adresse) VALUES
(464,'438 La Beillesse, 54550 Pont-Saint-Vincent'),
(465,'24bis Miquels, 39800 Neuvilley');

INSERT INTO Organisation (numero,adresse) VALUES
(466,'22 Le Bourg Neuf, 45290 Varennes-Changy'),
(467,'431 La Rue du Blocq, 40500 Audignon');

INSERT INTO Organisation (numero,adresse) VALUES
(468,'567 le Cros, 34190 Saint-Maurice-Navacelles'),
(469,'249bis Gilet le Neuf, 67700 Monswiller');

INSERT INTO Organisation (numero,adresse) VALUES
(470,'617 Roc Fendut, 14520 Port-en-Bessin-Huppain'),
(471,'603 Blache du Boisson, 26390 Hauterives');

INSERT INTO Organisation (numero,adresse) VALUES
(472,'384 Champ de Seyne, 68420 Hattstatt'),
(473,'930 Aux Preutières, 38160 Chatte');

INSERT INTO Organisation (numero,adresse) VALUES
(474,'253 Le Lieu Cheval, 57130 Ars-sur-Moselle'),
(475,'841bis Le Rivazur, 28310 Gouillons');

INSERT INTO Organisation (numero,adresse) VALUES
(476,'469 Champ Bouvard, 26770 Aleyrac'),
(477,'87 Grangeon, 64150 Sauvelade');

INSERT INTO Organisation (numero,adresse) VALUES
(478,'65bis Le Cros et Siales, 14117 Arromanches-les-Bains'),
(479,'462bis Mont de Madame Rose, 27800 Brionne');

INSERT INTO Organisation (numero,adresse) VALUES
(480,'509 Auteuil 109 Bat B Et C, 71270 Frontenard'),
(481,'269 Roque Vert, 55320 Sommedieue');

INSERT INTO Organisation (numero,adresse) VALUES
(482,'218 Pre d''Engauri, 79700 Mauléon'),
(483,'22 Pra Boucher, 69460 Blacé');

INSERT INTO Organisation (numero,adresse) VALUES
(484,'771 Les Fromentières, 48310 Saint-Laurent-de-Veyrès'),
(485,'728 Lieu Dit Jean Bernat, 18330 Vouzeron');

INSERT INTO Organisation (numero,adresse) VALUES
(486,'547bis Le Mas De Daudet, 01640 Saint-Jean-le-Vieux'),
(487,'247 Residence les Golfeurs, 40420 Brocas');

INSERT INTO Organisation (numero,adresse) VALUES
(488,'358 Les Colombines, 24560 Plaisance'),
(489,'904 Le Castéra, 13390 Auriol');

INSERT INTO Organisation (numero,adresse) VALUES
(490,'348bis L''Ubac de Berdine, 53290 Bierné'),
(491,'365bis Beauvert-est, 67370 Wiwersheim');

INSERT INTO Organisation (numero,adresse) VALUES
(492,'681 Pres des Gouilles, 12800 Castelmary'),
(493,'591 Le Mazuc, 65380 Lanne');

INSERT INTO Organisation (numero,adresse) VALUES
(494,'7bis Falguerot, 69290 Craponne'),
(495,'359bis Haut de la Perthe, 62450 Villers-au-Flos');

INSERT INTO Organisation (numero,adresse) VALUES
(496,'106 Placette de Tralatour, 38650 Saint-Martin-de-la-Cluze'),
(497,'35bis Le Tureau Minet, 31330 Le Burgaud');

INSERT INTO Organisation (numero,adresse) VALUES
(498,'99 Le Prat de l''Ort, 52230 Aingoulaincourt'),
(499,'439 Le Puech d’Espessergues, 38480 Saint-Martin-de-Vaulserre');

INSERT INTO Organisation (numero,adresse) VALUES
(500,'966 Les Gravas, 76540 Gerponville'),
(501,'498 Les Coués, 65130 Laborde');

INSERT INTO Organisation (numero,adresse) VALUES
(502,'948 Rue de la Vésubie, 57220 Helstroff'),
(503,'765 Domaine de Poupetiere, 48200 Saint-Pierre-le-Vieux');

INSERT INTO Organisation (numero,adresse) VALUES
(504,'346 Les Aires, 62860 Baralle'),
(505,'575 Ferme des Catherinettes, 18310 Nohant-en-Graçay');

INSERT INTO Organisation (numero,adresse) VALUES
(506,'488bis La Rodelle, 71570 Chaintré'),
(507,'684bis Bestes, 26150 Vachères-en-Quint');

INSERT INTO Organisation (numero,adresse) VALUES
(508,'419 La Combe Longue, 62500 Boisdinghem'),
(509,'377bis Route des Grangères, 61170 Buré');

INSERT INTO Organisation (numero,adresse) VALUES
(510,'363 Chemin de la Blanchere, 28310 Oinville-Saint-Liphard'),
(511,'378 Le Petit Bedun, 55110 Doulcon');

INSERT INTO Organisation (numero,adresse) VALUES
(512,'534 La Fortière, 39380 Santans'),
(513,'540 La Borie du Retour, 72440 Tresson');

INSERT INTO Organisation (numero,adresse) VALUES
(514,'251 Coulette, 28300 Saint-Aubin-des-Bois'),
(515,'947bis Jalabert, 31370 Beaufort');

INSERT INTO Organisation (numero,adresse) VALUES
(516,'319 Lotissement la Fontaine, 27350 Étréville'),
(517,'869bis La Roujarie, 50760 Montfarville');

INSERT INTO Organisation (numero,adresse) VALUES
(518,'268 Peyrefitte, 57430 Sarralbe'),
(519,'517bis Impasse Alfred de Vigny, 21230 Jouey');

INSERT INTO Organisation (numero,adresse) VALUES
(520,'309 Bon-pommier, 60120 Gannes'),
(521,'889bis mayrac, 15290 La Ségalassière');

INSERT INTO Organisation (numero,adresse) VALUES
(522,'683 Les Cotes de Jouas, 57970 Kuntzig'),
(523,'253 Musée Vers à Soie, 06450 Venanson');

INSERT INTO Organisation (numero,adresse) VALUES
(524,'507 Cercy, 19160 Roche-le-Peyroux'),
(525,'718bis Mas, 59740 Bérelles');

INSERT INTO Organisation (numero,adresse) VALUES
(526,'702 Le Village - Chemin des Grands Près, 32430 Cologne'),
(527,'607 Chez Bel, 74230 Le Bouchet-Mont-Charvin');

INSERT INTO Organisation (numero,adresse) VALUES
(528,'175bis Mounery, 49460 Soulaire-et-Bourg'),
(529,'919 Hameau de la Rotrate, 04530 La Condamine-Châtelard');

INSERT INTO Organisation (numero,adresse) VALUES
(530,'105bis Résidence le Manhattan, 52300 Thonnance-lès-Joinville'),
(531,'729 Fayolle, 18100 Méry-sur-Cher');

INSERT INTO Organisation (numero,adresse) VALUES
(532,'78 Claudo Quartier, 76530 La Bouille'),
(533,'75 Les Cent Jalois, 74200 La Vernaz');

INSERT INTO Organisation (numero,adresse) VALUES
(534,'265 Les Capellans, 09800 Saint-Lary'),
(535,'248 Vignard, 60620 Acy-en-Multien');

INSERT INTO Organisation (numero,adresse) VALUES
(536,'357 Cote de Roubreau, 79410 Saint-Rémy'),
(537,'638 Fontaine Saint Martin, 07110 Loubaresse');

INSERT INTO Organisation (numero,adresse) VALUES
(538,'860 Les Sottys, 57580 Vatimont'),
(539,'448 Moulin de Martre, 79110 Crézières');

INSERT INTO Organisation (numero,adresse) VALUES
(540,'385 Teyssonies, 76850 Grigneuseville'),
(541,'269 Terre Broche, 33350 Saint-Genès-de-Castillon');

INSERT INTO Organisation (numero,adresse) VALUES
(542,'46 Carbonel, 28200 Saint-Denis-les-Ponts'),
(543,'215bis Jolivet, 08090 Tournes');

INSERT INTO Organisation (numero,adresse) VALUES
(544,'103bis Les Fonroides, 68410 Ammerschwihr'),
(545,'157 Rue des Champs Longs, 09230 Fabas');

INSERT INTO Organisation (numero,adresse) VALUES
(546,'13bis Stade Jean-Pierre Rives, 31320 Vieille-Toulouse'),
(547,'817bis Boulevard du Fouery, 02340 Agnicourt-et-Séchelles');

INSERT INTO Organisation (numero,adresse) VALUES
(548,'340bis Parc des Papillons, 49220 Thorigné-d''Anjou'),
(549,'963 Bretelle Sortie Promenade des Anglais-Aéroport, 61190 Normandel');

INSERT INTO Organisation (numero,adresse) VALUES
(550,'157bis Florazur A, 43410 Lempdes-sur-Allagnon'),
(551,'620 ZAC du Moulin Mayeux, 63390 Ayat-sur-Sioule');

INSERT INTO Organisation (numero,adresse) VALUES
(552,'453 Champ Signon, 76740 Saint-Aubin-sur-Mer'),
(553,'764 La Soulayrie, 37210 Parçay-Meslay');

INSERT INTO Organisation (numero,adresse) VALUES
(554,'491bis Villa Flora, 05700 Orpierre'),
(555,'725 Frons, 32190 Roquebrune');

INSERT INTO Organisation (numero,adresse) VALUES
(556,'342 Allée Colonel Beltrame, 01150 Blyes'),
(557,'534 Domaine de Sérame, 77124 Crégy-lès-Meaux');

INSERT INTO Organisation (numero,adresse) VALUES
(558,'733 Truels, 79300 Bressuire'),
(559,'521 Les Sénières, 08150 Laval-Morency');

INSERT INTO Organisation (numero,adresse) VALUES
(560,'701bis Palazol et Gros Bois, 77620 Bransles'),
(561,'620 Chemin du Roy, 65130 Benqué-Molère');

INSERT INTO Organisation (numero,adresse) VALUES
(562,'175bis Passelaygues, 03450 Vicq'),
(563,'628 La Grangeotte, 39210 Voiteur');

INSERT INTO Organisation (numero,adresse) VALUES
(564,'120bis Callaguès, 35420 Mellé'),
(565,'461 Chemin de Bételgeuse, 37500 Ligré');

INSERT INTO Organisation (numero,adresse) VALUES
(566,'703 La Chavanne, 79100 Luzay'),
(567,'611bis La Baraque de Grilloles, 52130 Sommancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(568,'170bis Hameau le Canton de Boué, 41100 Villeromain'),
(569,'61 Villa Bastet, 27270 Chamblac');

INSERT INTO Organisation (numero,adresse) VALUES
(570,'737 Le Tibourin, 45260 La Cour-Marigny'),
(571,'693 Les Grands Morillons, 12100 La Roque-Sainte-Marguerite');

INSERT INTO Organisation (numero,adresse) VALUES
(572,'353 Taillade, 70150 Courcuire'),
(573,'169bis Impasse de la Louvière, 02500 Logny-lès-Aubenton');

INSERT INTO Organisation (numero,adresse) VALUES
(574,'250 Ribaumes, 55190 Ourches-sur-Meuse'),
(575,'229 Lilignod, 33350 Pujols');

INSERT INTO Organisation (numero,adresse) VALUES
(576,'738 Le Village Bazeilles, 02330 Celles-lès-Condé'),
(577,'294 Grotte, 40200 Saint-Paul-en-Born');

INSERT INTO Organisation (numero,adresse) VALUES
(578,'640 Rotonde du Bois de l''aune, 51330 Bussy-le-Repos'),
(579,'192 Couberchy, 52240 Buxières-lès-Clefmont');

INSERT INTO Organisation (numero,adresse) VALUES
(580,'282bis Le Riva Bella C, 25500 Les Combes'),
(581,'186 Les Roures A, 76590 Notre-Dame-du-Parc');

INSERT INTO Organisation (numero,adresse) VALUES
(582,'583bis Vintabren, 04110 Vachères'),
(583,'117bis Le Mayrac, 73200 Pallud');

INSERT INTO Organisation (numero,adresse) VALUES
(584,'5bis Saint Martin des Faux, 80132 Le Titre'),
(585,'704 Les Pesquies, 21250 Corgengoux');

INSERT INTO Organisation (numero,adresse) VALUES
(586,'373 Résidence Benjamin Nivet, 23260 Saint-Agnant-près-Crocq'),
(587,'343 Castelline, 49250 Les Bois d''Anjou');

INSERT INTO Organisation (numero,adresse) VALUES
(588,'938bis Route de Marcillac, 47500 Monsempron-Libos'),
(589,'447 Nespes, 64400 Esquiule');

INSERT INTO Organisation (numero,adresse) VALUES
(590,'702 Serre du Liquier, 14240 Les Loges'),
(591,'427 lieu-dit Baptistou, 01140 Mogneneins');

INSERT INTO Organisation (numero,adresse) VALUES
(592,'132 Les Bonnes, 57480 Haute-Kontz'),
(593,'315 Square François Suarez, 71520 Matour');

INSERT INTO Organisation (numero,adresse) VALUES
(594,'143 La Petite Villaine, 37230 Luynes'),
(595,'695 Magnet, 03170 Deneuille-les-Mines');

INSERT INTO Organisation (numero,adresse) VALUES
(596,'842 Valeron, 34210 Oupia'),
(597,'64 Les Marcillons, 55150 Chaumont-devant-Damvillers');

INSERT INTO Organisation (numero,adresse) VALUES
(598,'862 Bois du Pavillon, 64450 Lalonquette'),
(599,'416 Les Escoffiers, 76260 Le Mesnil-Réaume');

INSERT INTO Organisation (numero,adresse) VALUES
(600,'535bis Puech de la Rode, 27160 Le Lesme'),
(601,'21bis Le Gué Pierrat, 20134 Tasso');

INSERT INTO Organisation (numero,adresse) VALUES
(602,'23 Sente des Corps Morts, 77174 Villeneuve-le-Comte'),
(603,'747 Route Nationale 85, 45110 Germigny-des-Prés');

INSERT INTO Organisation (numero,adresse) VALUES
(604,'305 Chemin de la Rosa Bianca, 47250 Sainte-Gemme-Martaillac'),
(605,'23 Beaurivage, 73220 Saint-Pierre-de-Belleville');

INSERT INTO Organisation (numero,adresse) VALUES
(606,'575 Allée des Jardins de Jeanne, 64190 Lay-Lamidou'),
(607,'516 La Canelle, 31370 Montgras');

INSERT INTO Organisation (numero,adresse) VALUES
(608,'653 Centre pénitentiaire Moulins-Yzeure, 02270 Mesbrecourt-Richecourt'),
(609,'897 Puech Rousset, 28190 Villebon');

INSERT INTO Organisation (numero,adresse) VALUES
(610,'500 Louise, 45490 Corbeilles'),
(611,'401 Guedy, 70130 Motey-sur-Saône');

INSERT INTO Organisation (numero,adresse) VALUES
(612,'664 Riou et Couesse, 46120 Saint-Maurice-en-Quercy'),
(613,'713 Jeu d''''en-Bas, 38510 Saint-Sorlin-de-Morestel');

INSERT INTO Organisation (numero,adresse) VALUES
(614,'682 chemin rural dit de Cousselange ou des Romains, 64350 Anoye'),
(615,'102 Muid Pluma, 32300 Belloc-Saint-Clamens');

INSERT INTO Organisation (numero,adresse) VALUES
(616,'719 La Salette, 68190 Ungersheim'),
(617,'421 Place Alziary de Malausséna, 64350 Peyrelongue-Abos');

INSERT INTO Organisation (numero,adresse) VALUES
(618,'695bis Chemin rural dit des Sapins, 64320 Sendets'),
(619,'897 Lieu dit Les Trinquades, 31160 Moncaup');

INSERT INTO Organisation (numero,adresse) VALUES
(620,'279bis Les Sénières, 69380 Lozanne'),
(621,'169 Bladiès, 45320 Foucherolles');

INSERT INTO Organisation (numero,adresse) VALUES
(622,'743 Métairie de Serres, 33690 Grignols'),
(623,'351 La Réserve des Placiers, 38970 Sainte-Luce');

INSERT INTO Organisation (numero,adresse) VALUES
(624,'221 La Chambière, 59630 Brouckerque'),
(625,'946 La Palmerie, 50520 Chérencé-le-Roussel');

INSERT INTO Organisation (numero,adresse) VALUES
(626,'912 La Villefranche d''En Bas, 26190 Bouvante'),
(627,'724 Escaladou, 57870 Walscheid');

INSERT INTO Organisation (numero,adresse) VALUES
(628,'997 Sentier Corniche des Oliviers/Route de l''Abadie, 73200 Mercury'),
(629,'829 Pre du Tour, 63600 Grandrif');

INSERT INTO Organisation (numero,adresse) VALUES
(630,'877 Le Fortou, 10140 Beurey'),
(631,'686 Le Moussou, 40700 Monget');

INSERT INTO Organisation (numero,adresse) VALUES
(632,'437 La Conquête, 39140 Fontainebrux'),
(633,'463 Place de la Croix, 02220 Maast-et-Violaine');

INSERT INTO Organisation (numero,adresse) VALUES
(634,'550 Coudougnes, 40230 Tosse'),
(635,'402 La Couarde Ouest, 74390 Châtel');

INSERT INTO Organisation (numero,adresse) VALUES
(636,'763bis Le Bousquet de Ceor, 80240 Guyencourt-Saulcourt'),
(637,'773bis Avenue du Stade Hlm Anjou, 26220 Orcinas');

INSERT INTO Organisation (numero,adresse) VALUES
(638,'925 Lotissement Le Clos, 25470 Thiébouhans'),
(639,'636 Le Valvert, 62140 La Loge');

INSERT INTO Organisation (numero,adresse) VALUES
(640,'370 Le Villar, 69270 Fontaines-Saint-Martin'),
(641,'909 L’Hubac de Labastide, 73160 Cognin');

INSERT INTO Organisation (numero,adresse) VALUES
(642,'961 Mergabes-Bas, 58430 Fâchin'),
(643,'466 Bervic, 50800 La Bloutière');

INSERT INTO Organisation (numero,adresse) VALUES
(644,'472 Mireou, 26150 Die'),
(645,'490 Pitrals, 47200 Marcellus');

INSERT INTO Organisation (numero,adresse) VALUES
(646,'823 Acy le haut, 24560 Faux'),
(647,'832bis Hameau les Chevreaux, 77730 Citry');

INSERT INTO Organisation (numero,adresse) VALUES
(648,'114 Bastonenq, 47250 Labastide-Castel-Amouroux'),
(649,'323 Les Valettes Sud, 34600 Le Poujol-sur-Orb');

INSERT INTO Organisation (numero,adresse) VALUES
(650,'595 Sapins Priest, 17780 Moëze'),
(651,'485 Les Raisins Verts, 48320 Ispagnac');

INSERT INTO Organisation (numero,adresse) VALUES
(652,'349 Criswald, 76690 Saint-Georges-sur-Fontaine'),
(653,'108 Les Cent Clouds, 33210 Saint-Pierre-de-Mons');

INSERT INTO Organisation (numero,adresse) VALUES
(654,'994bis Saint-Jean-Bichard, 24310 Biras'),
(655,'387 Villa Les Lauriers, 20232 Vallecalle');

INSERT INTO Organisation (numero,adresse) VALUES
(656,'254 La Grotte, 09100 Saint-Martin-d''Oydes'),
(657,'922 Les Fayettes, 11300 Lauraguel');

INSERT INTO Organisation (numero,adresse) VALUES
(658,'849 ZAE du Fongeri, 14220 Grimbosq'),
(659,'274 Louage Gautier, 14700 Saint-Martin-de-Mieux');

INSERT INTO Organisation (numero,adresse) VALUES
(660,'105 Serre du Sault, 76730 Auzouville-sur-Saâne'),
(661,'162 GFA La Théoloise, 13123 Arles');

INSERT INTO Organisation (numero,adresse) VALUES
(662,'350 Sénégas, 32400 Fustérouau'),
(663,'285bis Granget, 02490 Maissemy');

INSERT INTO Organisation (numero,adresse) VALUES
(664,'629 La Parro Recoules P, 77830 Pamfou'),
(665,'561 Place du Jeu de Paume, 01510 La Burbanche');

INSERT INTO Organisation (numero,adresse) VALUES
(666,'454bis Carlas, 53970 L''Huisserie'),
(667,'986 Saint Hilaire, 09800 Saint-Lary');

INSERT INTO Organisation (numero,adresse) VALUES
(668,'709 Le Lastic, 21110 Collonges-lès-Premières'),
(669,'597 Champ Baron, 39130 Hautecour');

INSERT INTO Organisation (numero,adresse) VALUES
(670,'900 La Cense Brulée, 55600 Vigneul-sous-Montmédy'),
(671,'613 Négrals, 27640 Villiers-en-Désœuvre');

INSERT INTO Organisation (numero,adresse) VALUES
(672,'872bis La Fosse Poncette, 46500 Bio'),
(673,'737bis Combeyroudesques, 40500 Dumes');

INSERT INTO Organisation (numero,adresse) VALUES
(674,'391 Hameau de Valon, 51530 Saint-Martin-d''Ablois'),
(675,'948 Ancien Chemin Cal de Spagnol, 43100 Chaniat');

INSERT INTO Organisation (numero,adresse) VALUES
(676,'225 Montagne de Chooz, 52190 Choilley-Dardenay'),
(677,'692bis Tayrac, 39360 Molinges');

INSERT INTO Organisation (numero,adresse) VALUES
(678,'372 Boulouis, 80400 Grécourt'),
(679,'404bis Allée François Aragon, 34600 Le Pradal');

INSERT INTO Organisation (numero,adresse) VALUES
(680,'174 Charessas, 09600 Pradettes'),
(681,'354 Etang Ratier, 29530 Collorec');

INSERT INTO Organisation (numero,adresse) VALUES
(682,'671bis Les Renauds, 77370 Vieux-Champagne'),
(683,'897 Chemin du Moulin du Vallon de Magnan, 72370 Soulitré');

INSERT INTO Organisation (numero,adresse) VALUES
(684,'668bis Villa Bastet, 66460 Maury'),
(685,'976bis Gieussac, 57340 Morhange');

INSERT INTO Organisation (numero,adresse) VALUES
(686,'285 Champ de Versaillat, 23200 Aubusson'),
(687,'97 Roumier, 03130 Loddes');

INSERT INTO Organisation (numero,adresse) VALUES
(688,'680 Champ Renard, 67130 Wisches'),
(689,'955 Bretelle Entrée Malraux - Tunnel André Liautaud, 64160 Lussagnet-Lusson');

INSERT INTO Organisation (numero,adresse) VALUES
(690,'556 Aubusson, 41120 Chitenay'),
(691,'672 Alpoulils, 21220 Bévy');

INSERT INTO Organisation (numero,adresse) VALUES
(692,'614 Le Vert, 45340 Barville-en-Gâtinais'),
(693,'544bis Bérot, 77580 Pierre-Levée');

INSERT INTO Organisation (numero,adresse) VALUES
(694,'184 Escales, 16310 Mouzon'),
(695,'469 Route des Grangères, 28290 Commune nouvelle d''Arrou');

INSERT INTO Organisation (numero,adresse) VALUES
(696,'93 Le Mas du Compte, 66500 Nohèdes'),
(697,'261bis Rond point Saint Honorat, 38090 Bonnefamille');

INSERT INTO Organisation (numero,adresse) VALUES
(698,'871 Le Bois du Dentiste, 71390 Marcilly-lès-Buxy'),
(699,'291 Voie liaison chemin des Carrières - chemin de Calvi, 65310 Laloubère');

INSERT INTO Organisation (numero,adresse) VALUES
(700,'897bis Le Pasteur B, 23100 Saint-Merd-la-Breuille'),
(701,'669bis Chemin de la Jonction, 57290 Fameck');

INSERT INTO Organisation (numero,adresse) VALUES
(702,'868bis Le Tournadou, 33330 Saint-Laurent-des-Combes'),
(703,'775bis Moulin de la Barriere, 67450 Mundolsheim');

INSERT INTO Organisation (numero,adresse) VALUES
(704,'678 Villa Krochka, 08430 Champigneul-sur-Vence'),
(705,'327bis Calvaire du Tilleul, 27550 Nassandres sur Risle');

INSERT INTO Organisation (numero,adresse) VALUES
(706,'927 Voie liaison Boulevard de Montréal - Ancien Chemin de la Lanterne, 62217 Wailly'),
(707,'943 Gournié, 34420 Cers');

INSERT INTO Organisation (numero,adresse) VALUES
(708,'138 Les Grands Pres, 39150 Fort-du-Plasne'),
(709,'31 Bâtiment A4, 43230 Couteuges');

INSERT INTO Organisation (numero,adresse) VALUES
(710,'698 Terre Batie, 40120 Pouydesseaux'),
(711,'608bis Le Moulin à Papier, 43130 Solignac-sous-Roche');

INSERT INTO Organisation (numero,adresse) VALUES
(712,'883 Blancaria, 45170 Chilleurs-aux-Bois'),
(713,'690 Janirou, 68460 Lutterbach');

INSERT INTO Organisation (numero,adresse) VALUES
(714,'60 Saint Henri, 52300 Vecqueville'),
(715,'926 Hlm les Durantats Bat C1, 16460 Valence');

INSERT INTO Organisation (numero,adresse) VALUES
(716,'220bis Le Couvent, 44110 Soudan'),
(717,'181 Le Grand Cossange, 53250 Villepail');

INSERT INTO Organisation (numero,adresse) VALUES
(718,'522 Les Rois, 71200 Saint-Sernin-du-Bois'),
(719,'503 Grand Ronjon, 58460 Corvol-l''Orgueilleux');

INSERT INTO Organisation (numero,adresse) VALUES
(720,'19 Belair, 76570 Cideville'),
(721,'221 Cap de la Goute, 69430 Avenas');

INSERT INTO Organisation (numero,adresse) VALUES
(722,'936 Le Grand Bord, 68380 Breitenbach-Haut-Rhin'),
(723,'944bis Chemin du Cimetière Allemand, 56920 Saint-Gonnery');

INSERT INTO Organisation (numero,adresse) VALUES
(724,'813 Lou Roucas, 57410 Rahling'),
(725,'615 La Croix des Barres, 45290 Pressigny-les-Pins');

INSERT INTO Organisation (numero,adresse) VALUES
(726,'979 Domaine du Colombier, 79220 Saint-Christophe-sur-Roc'),
(727,'334 Pas Del Theil, 14710 Saint-Laurent-sur-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(728,'118 Nabrion, 06850 Briançonnet'),
(729,'969 Les Cotes de Jouas, 51290 Chapelaine');

INSERT INTO Organisation (numero,adresse) VALUES
(730,'400 Cap Long, 64420 Saubole'),
(731,'876 Les Coustons, 67310 Dahlenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(732,'77 Les Petits Debrits, 10210 Les Granges'),
(733,'935 Saint-Martin, 16420 Brigueuil');

INSERT INTO Organisation (numero,adresse) VALUES
(734,'965 Scierie de la Besbre, 02600 Retheuil'),
(735,'450 L Ibac du Col de l Olivier, 07200 Vesseaux');

INSERT INTO Organisation (numero,adresse) VALUES
(736,'238 Le Clastre, 44400 Rezé'),
(737,'621 Jardin Joseph Kessel, 58110 Tamnay-en-Bazois');

INSERT INTO Organisation (numero,adresse) VALUES
(738,'167 Route de Baillès, 59132 Eppe-Sauvage'),
(739,'475 Eglise du Forest, 07160 Le Cheylard');

INSERT INTO Organisation (numero,adresse) VALUES
(740,'733bis Liaucous, 71740 Tancon'),
(741,'146bis Le Gagnage au Chat Nord, 73630 Jarsy');

INSERT INTO Organisation (numero,adresse) VALUES
(742,'938 La Coste et le Goutail, 21380 Épagny'),
(743,'773 Alas, 01150 Blyes');

INSERT INTO Organisation (numero,adresse) VALUES
(744,'993bis Sainte Eulalie, 67170 Rottelsheim'),
(745,'275 Chemin du Vallon, 18270 Saint-Maur');

INSERT INTO Organisation (numero,adresse) VALUES
(746,'899bis Chemin du Louage Thibault, 56740 Locmariaquer'),
(747,'901 Le Bas Misseau, 13114 Puyloubier');

INSERT INTO Organisation (numero,adresse) VALUES
(748,'757bis Pres de la Breche, 02360 Raillimont'),
(749,'435 La Meridienne, 42510 Sainte-Agathe-en-Donzy');

INSERT INTO Organisation (numero,adresse) VALUES
(750,'71 Paresous-Est, 57170 Sotzeling'),
(751,'935 Saint Loup, 76540 Theuville-aux-Maillots');

INSERT INTO Organisation (numero,adresse) VALUES
(752,'255 Domaine de Rivage haut, 37420 Savigny-en-Véron'),
(753,'664 Cité l''Aiguille les Chenes, 51170 Chambrecy');

INSERT INTO Organisation (numero,adresse) VALUES
(754,'820bis Naflous, 61200 Aunou-le-Faucon'),
(755,'185 Roumiere, 21170 Laperrière-sur-Saône');

INSERT INTO Organisation (numero,adresse) VALUES
(756,'916 Le Tréluzenq, 33210 Saint-Pierre-de-Mons'),
(757,'88 Quartier Hameau de Venascle, 09230 Barjac');

INSERT INTO Organisation (numero,adresse) VALUES
(758,'103bis Tertre aux oies, 27230 Saint-Mards-de-Fresne'),
(759,'671 Bois Brule, 24240 Flaugeac');

INSERT INTO Organisation (numero,adresse) VALUES
(760,'153bis Domaine de Sannes, 59157 Beauvois-en-Cambrésis'),
(761,'398bis Bois du Bassin, 59530 Jolimetz');

INSERT INTO Organisation (numero,adresse) VALUES
(762,'179bis Manoir Lou Soleou, 70240 Mollans'),
(763,'303 Lieu-dit La Serrote, 74560 La Muraz');

INSERT INTO Organisation (numero,adresse) VALUES
(764,'235 La Vallée aux Grillons, 63740 Gelles'),
(765,'569bis Saint - Esteve, 23150 Lépinas');

INSERT INTO Organisation (numero,adresse) VALUES
(766,'559bis La Marianne, 08350 Villers-sur-Bar'),
(767,'662 Chambod Nord, 63190 Saint-Jean-d''Heurs');

INSERT INTO Organisation (numero,adresse) VALUES
(768,'838 Chanets, 68130 Aspach'),
(769,'797bis Les Treilloux, 67470 Seltz');

INSERT INTO Organisation (numero,adresse) VALUES
(770,'480 Hameau des Patins, 74150 Lornay'),
(771,'873bis étang D, 21340 Molinot');

INSERT INTO Organisation (numero,adresse) VALUES
(772,'993 Les_cotes_de_berge, 73390 Chamoux-sur-Gelon'),
(773,'751 Etang-Fouche, 77730 Citry');

INSERT INTO Organisation (numero,adresse) VALUES
(774,'690 La Grande Fontaine, 63350 Vinzelles'),
(775,'924bis Camp Français, 57365 Chailly-lès-Ennery');

INSERT INTO Organisation (numero,adresse) VALUES
(776,'23bis La Bernardie, 03140 Voussac'),
(777,'284 Coeur De Cagnes, 56120 Lanouée');

INSERT INTO Organisation (numero,adresse) VALUES
(778,'18 La Remise de Beaurepaire, 54480 Parux'),
(779,'612bis Grimes, 47480 Bajamont');

INSERT INTO Organisation (numero,adresse) VALUES
(780,'31 Caboussac, 32300 Labéjan'),
(781,'146bis Forêt Royale Darmaca, 51390 Gueux');

INSERT INTO Organisation (numero,adresse) VALUES
(782,'534 Square d''Alicante, 11130 Sigean'),
(783,'952 Sainte-Margueritte, 47500 Saint-Vite');

INSERT INTO Organisation (numero,adresse) VALUES
(784,'140bis Gour de Bade, 30130 Saint-Paulet-de-Caisson'),
(785,'692 Estoueou d''en Bas, 21390 Dompierre-en-Morvan');

INSERT INTO Organisation (numero,adresse) VALUES
(786,'114 La Chiandre, 57580 Vatimont'),
(787,'187 Les Grands Navoirs Ouest, 57970 Oudrenne');

INSERT INTO Organisation (numero,adresse) VALUES
(788,'444bis La Borie de Gras, 59670 Winnezeele'),
(789,'369 """ Les Mouillets """, 76280 Criquetot-l''Esneval');

INSERT INTO Organisation (numero,adresse) VALUES
(790,'691 Cour et Jardins, 59198 Haspres'),
(791,'42 melac, 36120 Bommiers');

INSERT INTO Organisation (numero,adresse) VALUES
(792,'716 Les Ratilles, 61170 Le Plantis'),
(793,'725bis Les Traverses, 07220 Viviers');

INSERT INTO Organisation (numero,adresse) VALUES
(794,'575 Les Clos Chalots, 54120 Lachapelle'),
(795,'899 La Ferme Neuve, 68610 Lautenbachzell');

INSERT INTO Organisation (numero,adresse) VALUES
(796,'353 Salesse, 27390 Saint-Agnan-de-Cernières'),
(797,'517 Cluot de Calliera, 16310 Roussines');

INSERT INTO Organisation (numero,adresse) VALUES
(798,'250bis Lacoux - Hauteville-Lompnes, 06540 Fontan'),
(799,'739 ancienne école - Salau, 60500 Vineuil-Saint-Firmin');

INSERT INTO Organisation (numero,adresse) VALUES
(800,'464bis Le Belleriq et le Calvaire, 08300 Rethel'),
(801,'798 Valcros et Rousset, 04310 Ganagobie');

INSERT INTO Organisation (numero,adresse) VALUES
(802,'770 Le Peyrié, 76810 Luneray'),
(803,'927bis Hameau de Lapeyrère, 57580 Beux');

INSERT INTO Organisation (numero,adresse) VALUES
(804,'670 Bajoc, 46200 Saint-Sozy'),
(805,'21 Rue du Lavoir, 73240 Avressieux');

INSERT INTO Organisation (numero,adresse) VALUES
(806,'323bis Les Gleizes, 54630 Flavigny-sur-Moselle'),
(807,'155bis Volada, 24350 Grand-Brassac');

INSERT INTO Organisation (numero,adresse) VALUES
(808,'191bis Les Cités, 16120 Bassac'),
(809,'663 Gours, 40460 Sanguinet');

INSERT INTO Organisation (numero,adresse) VALUES
(810,'323bis Beaurivage, 02800 Anguilcourt-le-Sart'),
(811,'389 La Fontaine, 17160 Louzignac');

INSERT INTO Organisation (numero,adresse) VALUES
(812,'26bis Le Plan Saint Leger, 51470 Saint-Memmie'),
(813,'490 Les Grands Bergers, 14610 Anisy');

INSERT INTO Organisation (numero,adresse) VALUES
(814,'813bis Lilignod, 62117 Brebières'),
(815,'345 domaine d''Arnauteille, 25320 Torpes');

INSERT INTO Organisation (numero,adresse) VALUES
(816,'426bis Mandailles, 57580 Vatimont'),
(817,'249 Fosse-clinchamp, 08090 Cliron');

INSERT INTO Organisation (numero,adresse) VALUES
(818,'417 Bruyeres des Clous, 16390 Montignac-le-Coq'),
(819,'509 Bois de la Chassagne, 64460 Casteide-Doat');

INSERT INTO Organisation (numero,adresse) VALUES
(820,'381 Bois des Roses, 54930 Fraisnes-en-Saintois'),
(821,'171 Domaine de Bouilletiere, 27110 Vitot');

INSERT INTO Organisation (numero,adresse) VALUES
(822,'113 Le Chateau de Lincou, 55290 Montiers-sur-Saulx'),
(823,'6 Caumels, 34300 Agde');

INSERT INTO Organisation (numero,adresse) VALUES
(824,'793 Les Rivieres Anglaises, 19190 Le Chastang'),
(825,'124 Le Village Haut, 76440 Saint-Michel-d''Halescourt');

INSERT INTO Organisation (numero,adresse) VALUES
(826,'188 Le Bellet, 49450 Sèvremoine'),
(827,'688bis Villa Aqui Sien Ben, 32200 Maurens');

INSERT INTO Organisation (numero,adresse) VALUES
(828,'953 Les Jardins Des Colettes, 59980 Honnechy'),
(829,'721bis Riou et Couesse, 18120 Quincy');

INSERT INTO Organisation (numero,adresse) VALUES
(830,'942bis La Quieta, 40380 Onard'),
(831,'241bis La Baresquie, 58380 Lucenay-lès-Aix');

INSERT INTO Organisation (numero,adresse) VALUES
(832,'98 Bandaire, 22590 Pordic'),
(833,'31 La Rengo, 51270 La Chapelle-sous-Orbais');

INSERT INTO Organisation (numero,adresse) VALUES
(834,'869 Pont de la Mule, 25870 Palise'),
(835,'966 le Cambon, 15170 Coltines');

INSERT INTO Organisation (numero,adresse) VALUES
(836,'747 Chapelle Saint-Antoine, 62860 Écourt-Saint-Quentin'),
(837,'900bis Village Cantot, 02430 Gauchy');

INSERT INTO Organisation (numero,adresse) VALUES
(838,'741bis les Pelus, 27120 Aigleville'),
(839,'259bis Baraque d’Isidore, 50460 Tonneville');

INSERT INTO Organisation (numero,adresse) VALUES
(840,'248 Vialet Vielh, 21190 Mavilly-Mandelot'),
(841,'819 Espace Fernande Bataille, 77370 Nangis');

INSERT INTO Organisation (numero,adresse) VALUES
(842,'180 Terres du Bosc, 32490 Monferran-Savès'),
(843,'22bis Bel Gazou, 64300 Saint-Girons-en-Béarn');

INSERT INTO Organisation (numero,adresse) VALUES
(844,'726 Route Métropolitaine 6202bis, 57635 Bickenholtz'),
(845,'947 Les Ris, 38280 Villette-d''Anthon');

INSERT INTO Organisation (numero,adresse) VALUES
(846,'742bis Le Quier, 08310 Ménil-Lépinois'),
(847,'212 Autoroute A8, 73450 Valloire');

INSERT INTO Organisation (numero,adresse) VALUES
(848,'865bis Vigne Neuve, 37220 Panzoult'),
(849,'512 Amaroux, 31540 Falga');

INSERT INTO Organisation (numero,adresse) VALUES
(850,'96 Les Petits Chapoux, 62130 Conteville-en-Ternois'),
(851,'713bis Impasse Eugène Arnaud, 29890 Kerlouan');

INSERT INTO Organisation (numero,adresse) VALUES
(852,'480bis Pechcarbou, 17770 Nantillé'),
(853,'670 Esplanade de Magnan, 40700 Hagetmau');

INSERT INTO Organisation (numero,adresse) VALUES
(854,'736bis Les Ravels, 57660 Freybouse'),
(855,'123bis Saint Apoly, 79220 Les Groseillers');

INSERT INTO Organisation (numero,adresse) VALUES
(856,'134 Les Hortes, 10400 Saint-Aubin'),
(857,'540 Les Aires, 50630 Videcosville');

INSERT INTO Organisation (numero,adresse) VALUES
(858,'922 Les Basses Coutures, 19330 Chanteix'),
(859,'998 Square Marcel Kirchner, 24570 Condat-sur-Vézère');

INSERT INTO Organisation (numero,adresse) VALUES
(860,'785 Esquères, 80170 Warvillers'),
(861,'823 Le Château de Blomac, 51130 Clamanges');

INSERT INTO Organisation (numero,adresse) VALUES
(862,'468 Hlm les Chartreux Bat B1, 70000 Cerre-lès-Noroy'),
(863,'960 Lieu-dit La Blachille, 35850 Gévezé');

INSERT INTO Organisation (numero,adresse) VALUES
(864,'494 Puech d''Orlhaguet, 31270 Frouzins'),
(865,'442bis Avenue des Iles, 59970 Vicq');

INSERT INTO Organisation (numero,adresse) VALUES
(866,'681bis Le Champ d''Astier, 40240 Saint-Justin'),
(867,'782 L''Haut Brenot, 38570 Le Cheylas');

INSERT INTO Organisation (numero,adresse) VALUES
(868,'978 Chemin du Pré de France, 55190 Bovée-sur-Barboure'),
(869,'563 Route de Saint Jean, 51170 Faverolles-et-Coëmy');

INSERT INTO Organisation (numero,adresse) VALUES
(870,'777bis Courtalesque, 27500 Triqueville'),
(871,'29 Saint Montan, 29520 Châteauneuf-du-Faou');

INSERT INTO Organisation (numero,adresse) VALUES
(872,'178 Le Rajalas, 21340 Val-Mont'),
(873,'464 Les Béarnais, 28260 Boncourt');

INSERT INTO Organisation (numero,adresse) VALUES
(874,'190bis Les Ourliacs, 19290 Sornac'),
(875,'841 Les Durances, 15300 Laveissière');

INSERT INTO Organisation (numero,adresse) VALUES
(876,'419 En Charmont, 55250 Brizeaux'),
(877,'389 Barthés, 61700 Dompierre');

INSERT INTO Organisation (numero,adresse) VALUES
(878,'223bis Au Dessus de Presles, 54800 Puxe'),
(879,'575bis hameau MONCLIN, 19130 Voutezac');

INSERT INTO Organisation (numero,adresse) VALUES
(880,'673 Résidence Le Crêt de Paste, 55800 Noyers-Auzécourt'),
(881,'191 Le Séguéla, 33190 Bourdelles');

INSERT INTO Organisation (numero,adresse) VALUES
(882,'57 Villa Tarpan, 74340 Samoëns'),
(883,'590 Lieu-dit Bardol, 08300 Biermes');

INSERT INTO Organisation (numero,adresse) VALUES
(884,'723 Lou Cayla, 32380 Gaudonville'),
(885,'275bis Le Tremblay Haut, 60650 Savignies');

INSERT INTO Organisation (numero,adresse) VALUES
(886,'160bis L''Hoste, 26340 Pradelle'),
(887,'953bis Quartier Sambuc, 71510 Saint-Léger-sur-Dheune');

INSERT INTO Organisation (numero,adresse) VALUES
(888,'492 la Colle Michel, 39300 Supt'),
(889,'150 Villa Le Gite, 23150 Lavaveix-les-Mines');

INSERT INTO Organisation (numero,adresse) VALUES
(890,'377 Le Chan Baudoin, 07790 Saint-Alban-d''Ay'),
(891,'389 Combe Haute, 26470 La Motte-Chalancon');

INSERT INTO Organisation (numero,adresse) VALUES
(892,'66 Rue de la Palisse, 14800 Saint-Arnoult'),
(893,'301bis Bois Brunet, 52200 Ormancey');

INSERT INTO Organisation (numero,adresse) VALUES
(894,'730 Loustal, 60170 Ribécourt-Dreslincourt'),
(895,'224 Le Pont du Bost, 59470 Wormhout');

INSERT INTO Organisation (numero,adresse) VALUES
(896,'171 Le Girbon, 36600 La Vernelle'),
(897,'742 Ripoz, 58700 Prémery');

INSERT INTO Organisation (numero,adresse) VALUES
(898,'807bis Gilet le Vieux, 02120 Hauteville'),
(899,'935 Nervy Ouest, 27800 Saint-Victor-d''Épine');

INSERT INTO Organisation (numero,adresse) VALUES
(900,'114bis Saint Etienne, 15600 Rouziers'),
(901,'420 Sardiges, 67370 Willgottheim');

INSERT INTO Organisation (numero,adresse) VALUES
(902,'333 La Longeagne, 17460 Rioux'),
(903,'791 Chemin Borne des 3 Abbés, 29790 Pont-Croix');

INSERT INTO Organisation (numero,adresse) VALUES
(904,'269bis Le Petit Bedun, 19150 Laguenne'),
(905,'774 Mieugy, 70800 Cuve');

INSERT INTO Organisation (numero,adresse) VALUES
(906,'490bis La Fumade, 01190 Chavannes-sur-Reyssouze'),
(907,'636 """ Les Landes """, 03400 Yzeure');

INSERT INTO Organisation (numero,adresse) VALUES
(908,'553 Le Four a Chaux, 44810 La Chevallerais'),
(909,'296 Bois Tréteau, 27170 Romilly-la-Puthenaye');

INSERT INTO Organisation (numero,adresse) VALUES
(910,'858 Rond point Nova Antipolis, 74270 Droisy'),
(911,'996 Les Petites Chaumes, 73360 Les Échelles');

INSERT INTO Organisation (numero,adresse) VALUES
(912,'370 Résidence les hermes Bâtiment F, 28410 Goussainville'),
(913,'695 Le Bois Fistère, 33430 Lignan-de-Bazas');

INSERT INTO Organisation (numero,adresse) VALUES
(914,'130 Derriere le Calvaire, 19120 Altillac'),
(915,'235 Puech Meja, 63200 Ménétrol');

INSERT INTO Organisation (numero,adresse) VALUES
(916,'631bis Bonne Terre, 21440 Saint-Martin-du-Mont'),
(917,'696 Voie liaison Avenue Buenos Ayres Avenue René Maurice, 27150 Hébécourt');

INSERT INTO Organisation (numero,adresse) VALUES
(918,'56bis Cité des Basaltes, 02880 Juvigny'),
(919,'55 Les Petites Forges, 74420 Villard');

INSERT INTO Organisation (numero,adresse) VALUES
(920,'852 Le Casse, 26410 Boulc'),
(921,'128 Chemin Departemental 24, 21500 Athie');

INSERT INTO Organisation (numero,adresse) VALUES
(922,'921bis Col de la Faucille, 57810 Languimberg'),
(923,'653 Camp de Boup, 21340 Cormot-Vauchignon');

INSERT INTO Organisation (numero,adresse) VALUES
(924,'317 Rond point de Provence, 21460 Toutry'),
(925,'565 Valatte, 45340 Juranville');

INSERT INTO Organisation (numero,adresse) VALUES
(926,'97bis Curnier, 49490 Lasse'),
(927,'593 L''Oursin Bat A Et B, 25620 Charbonnières-les-Sapins');

INSERT INTO Organisation (numero,adresse) VALUES
(928,'344bis Hotel Rio Minho, 40300 Sorde-l''Abbaye'),
(929,'570 Au Pavillon, 64190 Castetbon');

INSERT INTO Organisation (numero,adresse) VALUES
(930,'613 Le coulet-Sud, 35120 Saint-Marcan'),
(931,'753 Le Mirador, 46160 Gréalou');

INSERT INTO Organisation (numero,adresse) VALUES
(932,'138 Résidence Les Pêcheurs, 30250 Aubais'),
(933,'950 Les Izoules, 05300 Salérans');

INSERT INTO Organisation (numero,adresse) VALUES
(934,'10 Pierrefiche, 35240 Marcillé-Robert'),
(935,'106bis Place de l''Eglise à Monti, 29840 Landunvez');

INSERT INTO Organisation (numero,adresse) VALUES
(936,'737 La Besse-basse, 14480 Le Fresne-Camilly'),
(937,'925 Le Puech de Cayssac, 70000 Colombier');

INSERT INTO Organisation (numero,adresse) VALUES
(938,'446bis Volle, 26110 Curnier'),
(939,'200 Peberac, 19600 Nespouls');

INSERT INTO Organisation (numero,adresse) VALUES
(940,'648 le Bérot, 27190 Glisolles'),
(941,'844bis Cardouet et Bastiros, 34120 Cazouls-d''Hérault');

INSERT INTO Organisation (numero,adresse) VALUES
(942,'781 Mazelourgues, 38460 Vernas'),
(943,'801 Landes Rouges, 65330 Recurt');

INSERT INTO Organisation (numero,adresse) VALUES
(944,'708 Les Chez, 42420 Lorette'),
(945,'968bis La Sylvelene, 56430 Saint-Brieuc-de-Mauron');

INSERT INTO Organisation (numero,adresse) VALUES
(946,'453 La Sauge-Est, 10240 Magnicourt'),
(947,'906bis Crau du Sapt, 18110 Pigny');

INSERT INTO Organisation (numero,adresse) VALUES
(948,'420 Les cayres, 62250 Offrethun'),
(949,'878 ZAE Les Persèdes, 41000 Villebarou');

INSERT INTO Organisation (numero,adresse) VALUES
(950,'490 Les Arrendies, 33540 Landerrouet-sur-Ségur'),
(951,'223 Bois de l''Etang, 67320 Hirschland');

INSERT INTO Organisation (numero,adresse) VALUES
(952,'732bis Tourdets, 54200 Bouvron'),
(953,'420 Mouis, 64120 Lohitzun-Oyhercq');

INSERT INTO Organisation (numero,adresse) VALUES
(954,'458 Le Combre, 47110 Le Temple-sur-Lot'),
(955,'886 Villa Europa, 66360 Canaveilles');

INSERT INTO Organisation (numero,adresse) VALUES
(956,'520 En Roujou, 22140 Saint-Laurent'),
(957,'557bis Le Grand Fossé, 53150 Brée');

INSERT INTO Organisation (numero,adresse) VALUES
(958,'169 Petits Jours, 73190 Saint-Jeoire-Prieuré'),
(959,'860 La Foux, 77130 Montereau-Fault-Yonne');

INSERT INTO Organisation (numero,adresse) VALUES
(960,'767 Montigny aux Bois, 44770 Préfailles'),
(961,'640 Francon, 25110 Autechaux');

INSERT INTO Organisation (numero,adresse) VALUES
(962,'236bis Montee Marius, 19160 Sérandon'),
(963,'261 Herbousset, 68440 Schlierbach');

INSERT INTO Organisation (numero,adresse) VALUES
(964,'572 Saletta, 20229 Nocario'),
(965,'561 Les Abourioux, 43230 Frugières-le-Pin');

INSERT INTO Organisation (numero,adresse) VALUES
(966,'176 Saint Apoly, 46800 Fargues'),
(967,'534 Au Bois des Croix, 10510 Maizières-la-Grande-Paroisse');

INSERT INTO Organisation (numero,adresse) VALUES
(968,'565 Les Cytises 2, 09400 Bédeilhac-et-Aynat'),
(969,'93bis Saint Léopardin, 47800 Saint-Pardoux-Isaac');

INSERT INTO Organisation (numero,adresse) VALUES
(970,'196 Les Jacourets, 52130 Wassy'),
(971,'398 Les Clodons, 35190 Cardroc');

INSERT INTO Organisation (numero,adresse) VALUES
(972,'456 Volpilliaire, 02860 Presles-et-Thierny'),
(973,'209 Mas Robinson, 26310 Jonchères');

INSERT INTO Organisation (numero,adresse) VALUES
(974,'362 Res Lafayette B, 62120 Rely'),
(975,'552bis Font Divina, 57430 Hazembourg');

INSERT INTO Organisation (numero,adresse) VALUES
(976,'672 La Borie de Cazes, 15590 Velzic'),
(977,'186 L’Infialaire, 37120 Marigny-Marmande');

INSERT INTO Organisation (numero,adresse) VALUES
(978,'161bis Lamaron, 14400 Magny-en-Bessin'),
(979,'466bis Libac, 09500 Mirepoix');

INSERT INTO Organisation (numero,adresse) VALUES
(980,'842bis Coumel Salbat, 78930 Auffreville-Brasseuil'),
(981,'461bis Grays, 45510 Vannes-sur-Cosson');

INSERT INTO Organisation (numero,adresse) VALUES
(982,'365bis Le Breil, 72400 Saint-Martin-des-Monts'),
(983,'784 L’Entoygne, 33230 Les Peintures');

INSERT INTO Organisation (numero,adresse) VALUES
(984,'349 L''Uvernal, 38140 La Murette'),
(985,'968 Rue du Treillard, 16560 Villejoubert');

INSERT INTO Organisation (numero,adresse) VALUES
(986,'820 Fontaine Jean Manfaut, 16200 Fleurac'),
(987,'344 La Côte du Moulinet, 68210 Bellemagny');

INSERT INTO Organisation (numero,adresse) VALUES
(988,'429 Le Ruissol, 18130 Chalivoy-Milon'),
(989,'455 La Bérarde Superieure, 12390 Auzits');

INSERT INTO Organisation (numero,adresse) VALUES
(990,'850 L’Escarassous, 25190 Rosières-sur-Barbèche'),
(991,'583 Rez du Porteau, 38160 Chevrières');

INSERT INTO Organisation (numero,adresse) VALUES
(992,'190 La Baldonie, 50000 Saint-Lô'),
(993,'126 Maltraüt, 34700 Le Puech');

INSERT INTO Organisation (numero,adresse) VALUES
(994,'44 Nabouly d''en Bas, 71290 Jouvençon'),
(995,'553 Closures mauvaises, 02650 Mézy-Moulins');

INSERT INTO Organisation (numero,adresse) VALUES
(996,'631bis La Rue du Blocq, 63300 Thiers'),
(997,'428 Avenue Jules Constant, 38650 Saint-Martin-de-la-Cluze');

INSERT INTO Organisation (numero,adresse) VALUES
(998,'968 Lotissement les Cigalines, 05700 Orpierre'),
(999,'636 Co d''Albert, 33760 Ladaux');

INSERT INTO Organisation (numero,adresse) VALUES
(1000,'275 Les Jardinats, 04240 Méailles'),
(1001,'989bis Les Petits Rigaudets, 19210 Montgibaud');

INSERT INTO Organisation (numero,adresse) VALUES
(1002,'338bis Les Armengauds, 36290 Villiers'),
(1003,'484bis Impasse du L.e.p., 37600 Beaulieu-lès-Loches');

INSERT INTO Organisation (numero,adresse) VALUES
(1004,'960 Voie du Puits, 59990 Rombies-et-Marchipont'),
(1005,'567 Ferme du Bouvreau, 23400 Montboucher');

INSERT INTO Organisation (numero,adresse) VALUES
(1006,'967 Fontlebeau et Costebelle, 27700 Bernières-sur-Seine'),
(1007,'271 Le Mas de Serret, 22390 Gurunhuel');

INSERT INTO Organisation (numero,adresse) VALUES
(1008,'244bis Place Jean Baptiste Malausséna, 29570 Camaret-sur-Mer'),
(1009,'293 Chemin de l''Auberge, 80500 Laboissière-en-Santerre');

INSERT INTO Organisation (numero,adresse) VALUES
(1010,'853 Anninacs, 68510 Kœtzingue'),
(1011,'938bis La Gaîté, 23160 Saint-Sébastien');

INSERT INTO Organisation (numero,adresse) VALUES
(1012,'418bis Place de Long, 71360 Sully'),
(1013,'158 Basse Vaucluse, 59226 Rumegies');

INSERT INTO Organisation (numero,adresse) VALUES
(1014,'49 Moulin de Gaillac, 07160 Saint-Michel-d''Aurance'),
(1015,'298 La Vignola, 31310 Saint-Christaud');

INSERT INTO Organisation (numero,adresse) VALUES
(1016,'224 Hameau du Plantier, 63720 Chavaroux'),
(1017,'181 Domaine du Petit Fidèle, 57230 Sturzelbronn');

INSERT INTO Organisation (numero,adresse) VALUES
(1018,'143bis Parking Pôle Culturel Auguste Escoffier, 08300 Acy-Romance'),
(1019,'123 La Brousse, 06460 Caussols');

INSERT INTO Organisation (numero,adresse) VALUES
(1020,'26bis Les Neufs Pres, 10110 Chacenay'),
(1021,'433bis Pépianne, 29790 Mahalon');

INSERT INTO Organisation (numero,adresse) VALUES
(1022,'972 Chemin de Rieux, 17520 Saint-Martial-sur-Né'),
(1023,'91bis Bâtiment Le genévrier, 47360 Cours');

INSERT INTO Organisation (numero,adresse) VALUES
(1024,'367 L''Age Goyard, 54470 Dommartin-la-Chaussée'),
(1025,'206 La Coutarie-Haute, 39300 Le Vaudioux');

INSERT INTO Organisation (numero,adresse) VALUES
(1026,'173bis Champ Delher, 80110 Sauvillers-Mongival'),
(1027,'654 Le Champ Fagots, 69380 Châtillon');

INSERT INTO Organisation (numero,adresse) VALUES
(1028,'835 Bonmort, 04330 Barrême'),
(1029,'497bis Moulin Colon, 16140 Villejésus');

INSERT INTO Organisation (numero,adresse) VALUES
(1030,'520bis Chamery, 41360 Épuisay'),
(1031,'434 Résidence les Allées du Bourg, 80300 Montauban-de-Picardie');

INSERT INTO Organisation (numero,adresse) VALUES
(1032,'618 Le Val de la Cave du Bouc, 02480 Artemps'),
(1033,'23 Barges, 09160 Montgauch');

INSERT INTO Organisation (numero,adresse) VALUES
(1034,'241bis Minitroux, 26800 Étoile-sur-Rhône'),
(1035,'788 Le Sorbier, 03380 Saint-Martinien');

INSERT INTO Organisation (numero,adresse) VALUES
(1036,'914bis Pré Carré, 30460 Lasalle'),
(1037,'94bis Le Cazal, 47360 Saint-Salvy');

INSERT INTO Organisation (numero,adresse) VALUES
(1038,'966bis Piale Loup, 58700 Champlin'),
(1039,'56 Badens, 27210 Fatouville-Grestain');

INSERT INTO Organisation (numero,adresse) VALUES
(1040,'945 Escalier reliant les n°54 et 72 de l''Avenue Milon de Veraillon, 04310 Peyruis'),
(1041,'465 Combrieres, 52800 Sarcey');

INSERT INTO Organisation (numero,adresse) VALUES
(1042,'667 Champ du Bosc, 60310 Canny-sur-Matz'),
(1043,'884 Mouciera Inferieure, 36400 La Châtre');

INSERT INTO Organisation (numero,adresse) VALUES
(1044,'130bis Les Theilles, 45230 Sainte-Geneviève-des-Bois'),
(1045,'911bis Briges, 24290 Les Farges');

INSERT INTO Organisation (numero,adresse) VALUES
(1046,'910bis Le Garay des Ruches, 33670 Madirac'),
(1047,'557 Sainte Eugène, 43800 Chamalières-sur-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(1048,'571bis Boulevard Gordon Bennett, 56920 Kerfourn'),
(1049,'772 Ferme de Fauroux, 44670 La Chapelle-Glain');

INSERT INTO Organisation (numero,adresse) VALUES
(1050,'794 Rond Point Saint Roch, 64300 Sallespisse'),
(1051,'783bis Mancou, 21530 Saint-Andeux');

INSERT INTO Organisation (numero,adresse) VALUES
(1052,'833bis La Domerguie, 79370 Mougon-Thorigné'),
(1053,'205 Champ Sainte Marie, 45210 La Chapelle-Saint-Sépulcre');

INSERT INTO Organisation (numero,adresse) VALUES
(1054,'439 Farinet, 14350 Souleuvre en Bocage'),
(1055,'408 Le Rivet du Pied, 02120 Grand-Verly');

INSERT INTO Organisation (numero,adresse) VALUES
(1056,'281bis Coste Plane, 61100 Cerisy-Belle-Étoile'),
(1057,'823bis Quart d''Avard, 59530 Jolimetz');

INSERT INTO Organisation (numero,adresse) VALUES
(1058,'455 Chazeaux le Bas, 01380 Saint-Cyr-sur-Menthon'),
(1059,'660 Hameau de Cautirac, 08290 La Férée');

INSERT INTO Organisation (numero,adresse) VALUES
(1060,'167 Le Bouffayou Est, 04380 Thoard'),
(1061,'711 Piste de l''Ubac, 72610 Oisseau-le-Petit');

INSERT INTO Organisation (numero,adresse) VALUES
(1062,'665 Les Lignes, 31140 Fonbeauzard'),
(1063,'793bis Chemin de la Gane, 55160 Maizeray');

INSERT INTO Organisation (numero,adresse) VALUES
(1064,'810 Charrière du bois, 04600 Château-Arnoux-Saint-Auban'),
(1065,'138bis College Jules Verne, 40180 Tercis-les-Bains');

INSERT INTO Organisation (numero,adresse) VALUES
(1066,'42bis Le Dernier Muid, 61250 Cuissai'),
(1067,'868 Sous le Rocher - Cormaranche-en-Bugey, 80250 Grivesnes');

INSERT INTO Organisation (numero,adresse) VALUES
(1068,'69 La Soucarliere, 79220 Les Groseillers'),
(1069,'270 13ème Bis, 36110 Bretagne');

INSERT INTO Organisation (numero,adresse) VALUES
(1070,'726 Ferme du Rhuez, 31500 Toulouse'),
(1071,'466 Coste Raste, 54370 Hénaménil');

INSERT INTO Organisation (numero,adresse) VALUES
(1072,'759 Le Biol, 26600 Chantemerle-les-Blés'),
(1073,'878bis Le Mondou, 47120 Baleyssagues');

INSERT INTO Organisation (numero,adresse) VALUES
(1074,'970bis Fort des Reys, 25190 Les Terres-de-Chaux'),
(1075,'631bis Palachin Est, 33420 Jugazan');

INSERT INTO Organisation (numero,adresse) VALUES
(1076,'963 le Var, 71530 Fragnes-La Loyère'),
(1077,'129 Le Caussanel Bas, 42114 Saint-Cyr-de-Valorges');

INSERT INTO Organisation (numero,adresse) VALUES
(1078,'315 Veseou, 35720 Tressé'),
(1079,'120 Ferme Fays Bas, 52240 Maisoncelles');

INSERT INTO Organisation (numero,adresse) VALUES
(1080,'679 Galas, 08380 Auge'),
(1081,'147bis Chemin de la Tour, 01260 Champagne-en-Valromey');

INSERT INTO Organisation (numero,adresse) VALUES
(1082,'143 Terres de la Croix, 66820 Fuilla'),
(1083,'116 Champ-Blas, 14230 Canchy');

INSERT INTO Organisation (numero,adresse) VALUES
(1084,'64bis Jardin Boulevard de la Madeleine, 68420 Vœgtlinshoffen'),
(1085,'177bis Résidence Le Ségovent 6, 74930 Reignier-Ésery');

INSERT INTO Organisation (numero,adresse) VALUES
(1086,'851 Le Cheret des moutons, 57590 Viviers'),
(1087,'630 Rivière Vieille, 53800 Saint-Martin-du-Limet');

INSERT INTO Organisation (numero,adresse) VALUES
(1088,'915 Cadravals Haut, 71510 Dennevy'),
(1089,'152bis Les Grandes Demaines, 33220 Saint-André-et-Appelles');

INSERT INTO Organisation (numero,adresse) VALUES
(1090,'794 Chemin de Cadieyres, 40200 Aureilhan'),
(1091,'595bis Le Chateau et la Grand Bastide, 39700 Évans');

INSERT INTO Organisation (numero,adresse) VALUES
(1092,'381 Les Petits Clous, 64290 Aubertin'),
(1093,'478 Escalier du Castel, 76590 Sainte-Foy');

INSERT INTO Organisation (numero,adresse) VALUES
(1094,'540 Cantefau, 16300 Angeduc'),
(1095,'970 Champ-chauvin, 11320 Montferrand');

INSERT INTO Organisation (numero,adresse) VALUES
(1096,'371bis Berline Est, 12550 La Bastide-Solages'),
(1097,'510bis Le Petit Bosquet entrée D (27 à 37), 54470 Rembercourt-sur-Mad');

INSERT INTO Organisation (numero,adresse) VALUES
(1098,'107 Place  Mathilde de Monleon, 22270 Jugon-les-Lacs Commune nouvelle'),
(1099,'518 La sigua, 03420 La Petite-Marche');

INSERT INTO Organisation (numero,adresse) VALUES
(1100,'641 Haut du Faubourg, 51530 Brugny-Vaudancourt'),
(1101,'967 La Peyrède, 16260 Les Pins');

INSERT INTO Organisation (numero,adresse) VALUES
(1102,'382 Champ Coudray, 70400 Saulnot'),
(1103,'524 Le Plo Ouest, 77700 Chessy');

INSERT INTO Organisation (numero,adresse) VALUES
(1104,'438bis Gages le Bas, 11350 Paziols'),
(1105,'244 Route de Séverac, 04200 Saint-Geniez');

INSERT INTO Organisation (numero,adresse) VALUES
(1106,'361 Basse Roche, 03260 Magnet'),
(1107,'970bis Baychère, 73300 Hermillon');

INSERT INTO Organisation (numero,adresse) VALUES
(1108,'669 Madrunette, 01990 Saint-Trivier-sur-Moignans'),
(1109,'756 Les Lauriers Roses A-B-C, 55600 Han-lès-Juvigny');

INSERT INTO Organisation (numero,adresse) VALUES
(1110,'634bis Val de Thors, 56380 Monteneuf'),
(1111,'317bis Saint Cloud, 34000 Montpellier');

INSERT INTO Organisation (numero,adresse) VALUES
(1112,'765bis Chemin de la Tour de Bellet à Magnan, 07660 Lavillatte'),
(1113,'251 Place Saint Jean, 32600 Pujaudran');

INSERT INTO Organisation (numero,adresse) VALUES
(1114,'325 Pre de Marsillon Supran, 58290 Maux'),
(1115,'682bis La Jalade, 47140 Massels');

INSERT INTO Organisation (numero,adresse) VALUES
(1116,'241 Bâtiment A6, 60290 Rantigny'),
(1117,'295 Lotissement Fontvieille, 66360 Oreilla');

INSERT INTO Organisation (numero,adresse) VALUES
(1118,'576 Champ Beau, 25390 Fournets-Luisans'),
(1119,'549bis Villa Sainte Luce, 11600 Fournes-Cabardès');

INSERT INTO Organisation (numero,adresse) VALUES
(1120,'559 Silo, 11290 Roullens'),
(1121,'139 Les Brots, 64190 Sus');

INSERT INTO Organisation (numero,adresse) VALUES
(1122,'791 Sendac, 73200 Monthion'),
(1123,'788 Lagriffoul, 64490 Osse-en-Aspe');

INSERT INTO Organisation (numero,adresse) VALUES
(1124,'460 En Cabanel, 26150 Montmaur-en-Diois'),
(1125,'509 Villa Iole, 46230 Montdoumerc');

INSERT INTO Organisation (numero,adresse) VALUES
(1126,'279bis La Pagasse, 38200 Luzinay'),
(1127,'59 Les Traverses, 17500 Saint-Hilaire-du-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(1128,'285 Saint Rame, 25330 Flagey'),
(1129,'83bis Le Champ de Fer Perles, 65240 Grézian');

INSERT INTO Organisation (numero,adresse) VALUES
(1130,'806bis Les Chambets, 29470 Loperhet'),
(1131,'832 cabane des chasseurs acca citou, 79200 Gourgé');

INSERT INTO Organisation (numero,adresse) VALUES
(1132,'918 Sauvayre, 21230 Antigny-la-Ville'),
(1133,'665 Chemin de Falicon à Tourrette-levens, 03160 Couzon');

INSERT INTO Organisation (numero,adresse) VALUES
(1134,'304 Pont de Mirabel, 60350 Saint-Pierre-lès-Bitry'),
(1135,'560 La Couronne, 08190 Le Thour');

INSERT INTO Organisation (numero,adresse) VALUES
(1136,'966 Le Milieu, 43580 Esplantas-Vazeilles'),
(1137,'204 La Barthie, 33890 Gensac');

INSERT INTO Organisation (numero,adresse) VALUES
(1138,'746 Crestoules, 45250 Escrignelles'),
(1139,'463bis Place Henri Barbusse, 61390 Tellières-le-Plessis');

INSERT INTO Organisation (numero,adresse) VALUES
(1140,'0bis Abietta de Salomon, 72230 Guécélard'),
(1141,'969 Faubourg d''En Bas, 80510 Longpré-les-Corps-Saints');

INSERT INTO Organisation (numero,adresse) VALUES
(1142,'2 Fontaine Jean Manfaut, 52310 Vraincourt'),
(1143,'939bis La Milie, 57960 Soucht');

INSERT INTO Organisation (numero,adresse) VALUES
(1144,'579 Lotissement Les coteaux de St Trouvé, 55160 Ville-en-Woëvre'),
(1145,'29 Saint Xist, 76440 Longmesnil');

INSERT INTO Organisation (numero,adresse) VALUES
(1146,'708 Carrefour des Aiglons, 72120 Saint-Calais'),
(1147,'41bis Les Jardins De L''Hubac, 18240 Léré');

INSERT INTO Organisation (numero,adresse) VALUES
(1148,'114 Le Pigne, 53230 Courbeveille'),
(1149,'501bis La Grosse Pierre, 40240 Labastide-d''Armagnac');

INSERT INTO Organisation (numero,adresse) VALUES
(1150,'518 ZI de Fontvergnes, 42220 Bourg-Argental'),
(1151,'725bis Hameau du Vivier, 25680 Trouvans');

INSERT INTO Organisation (numero,adresse) VALUES
(1152,'427 Sauvagnac, 36140 Montchevrier'),
(1153,'959 Res La Roseraie, 16300 Saint-Bonnet');

INSERT INTO Organisation (numero,adresse) VALUES
(1154,'580 Champ Daujat, 65560 Ferrières'),
(1155,'797 Route de la Cavalerie, 67160 Wissembourg');

INSERT INTO Organisation (numero,adresse) VALUES
(1156,'155 Le Bois Bertrand, 50490 Saint-Michel-de-la-Pierre'),
(1157,'214 La Pourquière, 77240 Vert-Saint-Denis');

INSERT INTO Organisation (numero,adresse) VALUES
(1158,'483 Ancienne Abbaye du Paraclet, 59241 Masnières'),
(1159,'853 Nauviale, 53160 Izé');

INSERT INTO Organisation (numero,adresse) VALUES
(1160,'71 Famenoise, 45390 Desmonts'),
(1161,'33 Place  Lucien Sauze, 25530 Orsans');

INSERT INTO Organisation (numero,adresse) VALUES
(1162,'273bis Pelissières, 47230 Thouars-sur-Garonne'),
(1163,'835bis Montsales, 47370 Masquières');

INSERT INTO Organisation (numero,adresse) VALUES
(1164,'116 Ranc du Prieur les Repanti, 71320 Saint-Eugène'),
(1165,'540 Pres du Bourg, 26270 Loriol-sur-Drôme');

INSERT INTO Organisation (numero,adresse) VALUES
(1166,'90 Le Tremblay, 35630 Vignoc'),
(1167,'132bis Budant aux Remparts, 61410 Tessé-Froulay');

INSERT INTO Organisation (numero,adresse) VALUES
(1168,'95 Chemin de la Ferme de Vaux, 42130 Trelins'),
(1169,'236 Retif, 70300 Ormoiche');

INSERT INTO Organisation (numero,adresse) VALUES
(1170,'724 Le Caralie, 21460 Toutry'),
(1171,'669 Les Clauses Basses, 56350 Saint-Vincent-sur-Oust');

INSERT INTO Organisation (numero,adresse) VALUES
(1172,'709 Le Chateau de Villard, 50330 Clitourps'),
(1173,'478 Petit Coudoux, 65100 Gez-ez-Angles');

INSERT INTO Organisation (numero,adresse) VALUES
(1174,'787 Bois de Madame, 64210 Arbonne'),
(1175,'546 Pata, 18390 Saint-Germain-du-Puy');

INSERT INTO Organisation (numero,adresse) VALUES
(1176,'106 Chemin de Nesles, 65190 Lespouey'),
(1177,'655 Le Moulin Berly, 73250 Saint-Jean-de-la-Porte');

INSERT INTO Organisation (numero,adresse) VALUES
(1178,'660bis Puech de Crezes-Bas, 78640 Villiers-Saint-Frédéric'),
(1179,'521bis Roubuols, 70300 Ailloncourt');

INSERT INTO Organisation (numero,adresse) VALUES
(1180,'901 Villa Christine, 47260 Brugnac'),
(1181,'205 Costo Caudo, 15190 Lugarde');

INSERT INTO Organisation (numero,adresse) VALUES
(1182,'509 Les Martelly, 66360 Souanyas'),
(1183,'718bis Les Villards, 72110 Nogent-le-Bernard');

INSERT INTO Organisation (numero,adresse) VALUES
(1184,'505bis Guzet Neige, 67650 Blienschwiller'),
(1185,'787 Au Dessus la Fosse à Taver, 64320 Sendets');

INSERT INTO Organisation (numero,adresse) VALUES
(1186,'530bis Lieu dit Barrié, 60190 Sacy-le-Petit'),
(1187,'415 Les Rocs de la Serre, 27520 Thénouville');

INSERT INTO Organisation (numero,adresse) VALUES
(1188,'988bis Clot de Leve, 55100 Douaumont'),
(1189,'304bis Rue de L''Église, 39150 La Chaumusse');

INSERT INTO Organisation (numero,adresse) VALUES
(1190,'288 Sanhes, 38250 Saint-Nizier-du-Moucherotte'),
(1191,'913 Le Moulinel, 15240 Sauvat');

INSERT INTO Organisation (numero,adresse) VALUES
(1192,'179 Abri Bus, 70200 Lantenot'),
(1193,'304bis Monplo, 28230 Épernon');

INSERT INTO Organisation (numero,adresse) VALUES
(1194,'109bis Lieu Dit Rochefort, 31350 Montmaurin'),
(1195,'88bis Hameaux De La Riviere, 45300 Estouy');

INSERT INTO Organisation (numero,adresse) VALUES
(1196,'755 Platerieu, 51300 Outrepont'),
(1197,'0bis Entraigues, 20243 San-Gavino-di-Fiumorbo');

INSERT INTO Organisation (numero,adresse) VALUES
(1198,'646bis La Couletta, 42600 Magneux-Haute-Rive'),
(1199,'802 Avenue du Vallon des Fleurs, 60400 Babœuf');

INSERT INTO Organisation (numero,adresse) VALUES
(1200,'577 La Vigneroux, 09000 Prayols'),
(1201,'749 Rond-Point  Georges Zornada, 60310 Amy');

INSERT INTO Organisation (numero,adresse) VALUES
(1202,'430 Le Vayssat, 59244 Grand-Fayt'),
(1203,'915bis Impasse des Lavandières, 35130 Drouges');

INSERT INTO Organisation (numero,adresse) VALUES
(1204,'10 La Hajelette, 02810 Montigny-l''Allier'),
(1205,'924bis La Fenerie, 28500 Allainville');

INSERT INTO Organisation (numero,adresse) VALUES
(1206,'588 Moulin de Saint Juvin, 60650 Espaubourg'),
(1207,'698 Rameau, 60310 Fresnières');

INSERT INTO Organisation (numero,adresse) VALUES
(1208,'635 Le Pont de Grandfuel, 51290 Châtillon-sur-Broué'),
(1209,'307 Gabaudo, 51140 Romain');

INSERT INTO Organisation (numero,adresse) VALUES
(1210,'781 La Malle Sud, 35210 Saint-Christophe-des-Bois'),
(1211,'145 Le Puech de Lestrade, 29450 Le Tréhou');

INSERT INTO Organisation (numero,adresse) VALUES
(1212,'120 La Cloche, 45300 Vrigny'),
(1213,'349bis Centre d''animation sociale Claudette Huot-Bir, 12490 La Bastide-Pradines');

INSERT INTO Organisation (numero,adresse) VALUES
(1214,'453 Le Patriarche, 63340 Dauzat-sur-Vodable'),
(1215,'88 Garage 4, 59170 Croix');

INSERT INTO Organisation (numero,adresse) VALUES
(1216,'312 Les Rudelles, 31430 Fustignac'),
(1217,'569 Lapanouse de Cernon, 76280 Hermeville');

INSERT INTO Organisation (numero,adresse) VALUES
(1218,'9 Les Hivernals, 11800 Trèbes'),
(1219,'970 Les Plots, 03310 Durdat-Larequille');

INSERT INTO Organisation (numero,adresse) VALUES
(1220,'174bis Les Clayolles, 43360 Lorlanges'),
(1221,'187 Karukera, 28210 Coulombs');

INSERT INTO Organisation (numero,adresse) VALUES
(1222,'63bis L''Abreuvage, 19270 Saint-Pardoux-l''Ortigier'),
(1223,'797 Tajan, 52110 Charmes-la-Grande');

INSERT INTO Organisation (numero,adresse) VALUES
(1224,'896 Felicita, 28500 Vert-en-Drouais'),
(1225,'72 Vignals, 18340 Soye-en-Septaine');

INSERT INTO Organisation (numero,adresse) VALUES
(1226,'683 La Batterie Basse, 27800 Boisney'),
(1227,'917bis Le Terrage Colbin, 57560 Lafrimbolle');

INSERT INTO Organisation (numero,adresse) VALUES
(1228,'51 Combe de Chalde, 30330 Cavillargues'),
(1229,'757 Les Boynes, 06250 Mougins');

INSERT INTO Organisation (numero,adresse) VALUES
(1230,'802 La Fosse Poncette, 39250 La Latette'),
(1231,'128 Louleyre, 63630 Saint-Bonnet-le-Bourg');

INSERT INTO Organisation (numero,adresse) VALUES
(1232,'396 Chardine, 26570 Barret-de-Lioure'),
(1233,'919 Le Bas Pranles, 20151 Cannelle');

INSERT INTO Organisation (numero,adresse) VALUES
(1234,'466 La Nuirie, 36160 Urciers'),
(1235,'227 Soun du Plan, 64190 Montfort');

INSERT INTO Organisation (numero,adresse) VALUES
(1236,'192 Le Croup, 27300 Carsix'),
(1237,'787 Cagnes Provencal C, 69210 Éveux');

INSERT INTO Organisation (numero,adresse) VALUES
(1238,'543 Bordegrande, 76440 Forges-les-Eaux'),
(1239,'722 La Buffa, 02130 Beuvardes');

INSERT INTO Organisation (numero,adresse) VALUES
(1240,'612 La Gare de Vieu, 80300 Ovillers-la-Boisselle'),
(1241,'159bis Chazeaux le Haut, 20160 Vico');

INSERT INTO Organisation (numero,adresse) VALUES
(1242,'975 Chemin du Moulin du Seigneur, 62490 Sailly-en-Ostrevent'),
(1243,'243 Impasse Eden Park, 31330 Le Burgaud');

INSERT INTO Organisation (numero,adresse) VALUES
(1244,'757bis Mazelourgues, 50450 Le Mesnil-Garnier'),
(1245,'879 Prat Del Ranc, 56540 Saint-Caradec-Trégomel');

INSERT INTO Organisation (numero,adresse) VALUES
(1246,'950bis La Tour Du Chateau, 71170 Mussy-sous-Dun'),
(1247,'627bis Point Eau Incendie n°1003 (borne d''incendie), 38970 Pellafol');

INSERT INTO Organisation (numero,adresse) VALUES
(1248,'599 Champ Mathé, 02340 Vincy-Reuil-et-Magny'),
(1249,'247bis Derriere Saint Roch, 68200 Mulhouse');

INSERT INTO Organisation (numero,adresse) VALUES
(1250,'385 Terre de la Vigne, 49122 Bégrolles-en-Mauges'),
(1251,'254bis Les Fagoux, 62310 Torcy');

INSERT INTO Organisation (numero,adresse) VALUES
(1252,'465 Rue des Pivoines, 19150 Saint-Bonnet-Avalouze'),
(1253,'806bis Soleil D''Azur, 65690 Montignac');

INSERT INTO Organisation (numero,adresse) VALUES
(1254,'174 "Terrain des Landes (football, pétanque)", 41100 Crucheray'),
(1255,'66 Les Meilleureux, 58600 Garchizy');

INSERT INTO Organisation (numero,adresse) VALUES
(1256,'206 Haute Cleffay, 76450 Saint-Vaast-Dieppedalle'),
(1257,'512 La Robine, 15110 Deux-Verges');

INSERT INTO Organisation (numero,adresse) VALUES
(1258,'897bis Eglise Saint André, 76390 Conteville'),
(1259,'116 Largelé, 62270 Vacquerie-le-Boucq');

INSERT INTO Organisation (numero,adresse) VALUES
(1260,'524 Res Primavera A, 17590 Saint-Clément-des-Baleines'),
(1261,'987 hameau de Raissac, 09000 Le Bosc');

INSERT INTO Organisation (numero,adresse) VALUES
(1262,'464bis L''Oliu, 67360 Gunstett'),
(1263,'904bis Cros Viel, 58700 Authiou');

INSERT INTO Organisation (numero,adresse) VALUES
(1264,'72bis Église Notre Dame de Romigier, 15170 Neussargues en Pinatelle'),
(1265,'690 Les Grands Bois, 53100 Saint-Georges-Buttavent');

INSERT INTO Organisation (numero,adresse) VALUES
(1266,'967bis Les Myrtilles, 76570 Cideville'),
(1267,'932bis Les Genets Villa 2, 47350 Peyrière');

INSERT INTO Organisation (numero,adresse) VALUES
(1268,'471 Les Conquettes, 35420 La Bazouge-du-Désert'),
(1269,'708 Quai Napoléon 1er, 54450 Ogéviller');

INSERT INTO Organisation (numero,adresse) VALUES
(1270,'787 La Combe de l''Orme, 74470 Bellevaux'),
(1271,'644 Fond Bichot, 68380 Mittlach');

INSERT INTO Organisation (numero,adresse) VALUES
(1272,'558bis Ephad Mariposa, 03260 Magnet'),
(1273,'924 Petit Montjuif, 07260 Vernon');

INSERT INTO Organisation (numero,adresse) VALUES
(1274,'842 Rieusset, 44880 Sautron'),
(1275,'142 Romantica, 59540 Caudry');

INSERT INTO Organisation (numero,adresse) VALUES
(1276,'562 La Pierreuse sur le Banel, 59280 Armentières'),
(1277,'969bis Saint Jean le Froid, 01350 Cressin-Rochefort');

INSERT INTO Organisation (numero,adresse) VALUES
(1278,'368 Résidence Voltaire, 55230 Gouraincourt'),
(1279,'663 La Sauge-Nord, 77160 Saint-Hilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(1280,'584 Bouffevent, 67270 Kienheim'),
(1281,'999 Bernadat, 64370 Boumourt');

INSERT INTO Organisation (numero,adresse) VALUES
(1282,'794 Bregnier Village, 45300 Mareau-aux-Bois'),
(1283,'827 Les Claris, 21700 Saint-Nicolas-lès-Cîteaux');

INSERT INTO Organisation (numero,adresse) VALUES
(1284,'844 Maison du peintre, 60650 Espaubourg'),
(1285,'339 Le Yasmina B, 18220 Morogues');

INSERT INTO Organisation (numero,adresse) VALUES
(1286,'758 Cité Nestlé, 65170 Tramezaïgues'),
(1287,'280 Les Trois Sapins, 19210 Saint-Julien-le-Vendômois');

INSERT INTO Organisation (numero,adresse) VALUES
(1288,'861 La Genestelle, 58270 Fertrève'),
(1289,'570 Boucheron, 40110 Morcenx');

INSERT INTO Organisation (numero,adresse) VALUES
(1290,'585bis Le Clos de Montron, 59870 Rieulay'),
(1291,'11 La Fabrique, 48150 Le Rozier');

INSERT INTO Organisation (numero,adresse) VALUES
(1292,'158 Couaste Chabot, 11230 Sonnac-sur-l''Hers'),
(1293,'866bis Avenue Louis Giovanelli, 50470 Tollevast');

INSERT INTO Organisation (numero,adresse) VALUES
(1294,'998 Puech Ventoux, 11700 Roquecourbe-Minervois'),
(1295,'456 La Mayrinie, 20112 Olmiccia');

INSERT INTO Organisation (numero,adresse) VALUES
(1296,'821 Ferme du Bas Quesnoy, 57430 Le Val-de-Guéblange'),
(1297,'6bis Bouche à incendie, 17490 Saint-Ouen-la-Thène');

INSERT INTO Organisation (numero,adresse) VALUES
(1298,'300 Ribaumes, 62000 Dainville'),
(1299,'589 Rougnac, 38110 La Chapelle-de-la-Tour');

INSERT INTO Organisation (numero,adresse) VALUES
(1300,'600 Les Pauves, 32100 Larressingle'),
(1301,'165 Les Vergers Villa 6, 74570 Aviernoz');

INSERT INTO Organisation (numero,adresse) VALUES
(1302,'152 Le Menuisier, 20100 Bilia'),
(1303,'791bis Pas a Bres, 80110 Berteaucourt-lès-Thennes');

INSERT INTO Organisation (numero,adresse) VALUES
(1304,'458 Champs de Clauzelles, 62127 Ternas'),
(1305,'11 Magalassou, 34800 Liausson');

INSERT INTO Organisation (numero,adresse) VALUES
(1306,'518 Cerieys Gros, 18570 La Chapelle-Saint-Ursin'),
(1307,'98 La Vezingues, 13500 Martigues');

INSERT INTO Organisation (numero,adresse) VALUES
(1308,'288 À 26 Aire de St Brice, 76270 Flamets-Frétils'),
(1309,'797 Ancien Chemin de l''Archet, 37540 Saint-Cyr-sur-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(1310,'843 La Jonquiere, 51270 Courjeonnet'),
(1311,'756 Les Bredats, 76480 Sainte-Marguerite-sur-Duclair');

INSERT INTO Organisation (numero,adresse) VALUES
(1312,'553 Pre Henquau, 64450 Thèze'),
(1313,'232 Résidence les Églantines, 06420 Ilonse');

INSERT INTO Organisation (numero,adresse) VALUES
(1314,'836 Lezinou, 47420 Pompogne'),
(1315,'18 Place du Mitan, 22480 Magoar');

INSERT INTO Organisation (numero,adresse) VALUES
(1316,'601 Sautés le Bas, 10700 Trouans'),
(1317,'497 Le Terme la Forêt, 60420 Coivrel');

INSERT INTO Organisation (numero,adresse) VALUES
(1318,'416 Lauriol Est, 58270 Saint-Jean-aux-Amognes'),
(1319,'0 Chavigny, 72300 Juigné-sur-Sarthe');

INSERT INTO Organisation (numero,adresse) VALUES
(1320,'845bis La Rodelle, 52300 Chatonrupt-Sommermont'),
(1321,'189 Residence St Maurice Bat E, 35210 Châtillon-en-Vendelais');

INSERT INTO Organisation (numero,adresse) VALUES
(1322,'649bis Les Hérards, 16340 L''Isle-d''Espagnac'),
(1323,'396 La Cote Voyant, 65200 Gerde');

INSERT INTO Organisation (numero,adresse) VALUES
(1324,'473 Camp-Grand, 14420 Bons-Tassilly'),
(1325,'570 Parking 2, 63210 Saint-Pierre-Roche');

INSERT INTO Organisation (numero,adresse) VALUES
(1326,'6 Loupis, 68470 Husseren-Wesserling'),
(1327,'346bis Menerol-nord, 10240 Magnicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(1328,'163 Résidence du Luxembourg, 68680 Kembs'),
(1329,'43 Roques, 19160 Saint-Hilaire-Luc');

INSERT INTO Organisation (numero,adresse) VALUES
(1330,'835 Talipiat, 31360 Boussens'),
(1331,'760bis Chemin des Fanges, 22940 Saint-Julien');

INSERT INTO Organisation (numero,adresse) VALUES
(1332,'329 Le Son Bo, 17570 Les Mathes'),
(1333,'799 Mont Redon, 01300 Massignieu-de-Rives');

INSERT INTO Organisation (numero,adresse) VALUES
(1334,'310bis Chamarouan, 27160 Bémécourt'),
(1335,'955 Carrei Sobran, 17380 Chantemerle-sur-la-Soie');

INSERT INTO Organisation (numero,adresse) VALUES
(1336,'830 Le Pré de la Roque, 12540 Cornus'),
(1337,'130 Issac, 45170 Saint-Lyé-la-Forêt');

INSERT INTO Organisation (numero,adresse) VALUES
(1338,'603 La Petite Passe, 27550 Nassandres sur Risle'),
(1339,'975 Montoulon Ouest, 35120 Roz-Landrieux');

INSERT INTO Organisation (numero,adresse) VALUES
(1340,'920 Chemin plan du bois, 24530 Condat-sur-Trincou'),
(1341,'73bis Mas de Blaches, 21330 Marcenay');

INSERT INTO Organisation (numero,adresse) VALUES
(1342,'743 Sainte-Anne, 21120 Chaignay'),
(1343,'698 Mazieres, 17310 Saint-Pierre-d''Oléron');

INSERT INTO Organisation (numero,adresse) VALUES
(1344,'956 Les Blaches, 76940 Vatteville-la-Rue'),
(1345,'657 Camping Le Green Park, 71800 Saint-Germain-en-Brionnais');

INSERT INTO Organisation (numero,adresse) VALUES
(1346,'648 Le Pré Sanel, 14140 Lessard-et-le-Chêne'),
(1347,'849bis Bastides De L'' Hubac 6-7, 48110 Sainte-Croix-Vallée-Française');

INSERT INTO Organisation (numero,adresse) VALUES
(1348,'183 Maison Saint-Odilon, 31160 Portet-d''Aspet'),
(1349,'920bis Chavigny, 57580 Lemud');

INSERT INTO Organisation (numero,adresse) VALUES
(1350,'514 La Cavalerie, 55100 Béthelainville'),
(1351,'784 Au Got, 48140 Le Malzieu-Ville');

INSERT INTO Organisation (numero,adresse) VALUES
(1352,'909 Pré Paret, 59470 Esquelbecq'),
(1353,'777 Cavaillel, 22800 Saint-Gildas');

INSERT INTO Organisation (numero,adresse) VALUES
(1354,'922 La Tapie Haute, 67270 Wingersheim les Quatre Bans'),
(1355,'829 l''Adrech, 26470 Rottier');

INSERT INTO Organisation (numero,adresse) VALUES
(1356,'685bis Les Pins Chênes, 26600 Serves-sur-Rhône'),
(1357,'811 Le Pre de la Font, 78170 La Celle-Saint-Cloud');

INSERT INTO Organisation (numero,adresse) VALUES
(1358,'622 Vers Bezent, 45240 Ligny-le-Ribault'),
(1359,'365bis Chemin du Collet des Etoiles, 14210 Vacognes-Neuilly');

INSERT INTO Organisation (numero,adresse) VALUES
(1360,'83bis Pre des Chevres, 60220 Bouvresse'),
(1361,'977bis Petit Forme, 74520 Jonzier-Épagny');

INSERT INTO Organisation (numero,adresse) VALUES
(1362,'707 Chemin de la Vigie, 27220 L''Habit'),
(1363,'236 Jeu, 61190 Irai');

INSERT INTO Organisation (numero,adresse) VALUES
(1364,'411 Fond de la Cense, 70500 Buffignécourt'),
(1365,'322 Riverelens, 14110 Saint-Denis-de-Méré');

INSERT INTO Organisation (numero,adresse) VALUES
(1366,'92 Barthe, 61250 Ménil-Erreux'),
(1367,'232 Le Cros Saint Pierre A, 21110 Soirans');

INSERT INTO Organisation (numero,adresse) VALUES
(1368,'659 Le Rank, 19260 Veix'),
(1369,'922 Seive Ouest, 55300 Apremont-la-Forêt');

INSERT INTO Organisation (numero,adresse) VALUES
(1370,'0 Beraud, 33490 Saint-Germain-de-Grave'),
(1371,'797 La Portalerie, 27320 Saint-Germain-sur-Avre');

INSERT INTO Organisation (numero,adresse) VALUES
(1372,'440 Lesdali, 61600 Saint-Patrice-du-Désert'),
(1373,'439 Ma Logette, 54970 Landres');

INSERT INTO Organisation (numero,adresse) VALUES
(1374,'668 Liaison Avenue Emile Henriot - Rue Louis de Coppet, 07110 Prunet'),
(1375,'49 Le Florea C4, 38540 Valencin');

INSERT INTO Organisation (numero,adresse) VALUES
(1376,'311 Les Auchers Nord, 25470 Goumois'),
(1377,'452 Le Mas de Clary, 50370 Notre-Dame-de-Livoye');

INSERT INTO Organisation (numero,adresse) VALUES
(1378,'596 Le Clos St Pierre, 66110 Montbolo'),
(1379,'417 Champ Bacon, 73190 Apremont');

INSERT INTO Organisation (numero,adresse) VALUES
(1380,'877 Les Gouillettes, 41300 Theillay'),
(1381,'319 Voie du CADAM, 27120 Le Cormier');

INSERT INTO Organisation (numero,adresse) VALUES
(1382,'189 Les Martrous, 16700 Tuzie'),
(1383,'425 Parking du Riou, 73870 Saint-Julien-Mont-Denis');

INSERT INTO Organisation (numero,adresse) VALUES
(1384,'39bis Eglise Saint Quintin, 01250 Saint-Just'),
(1385,'278 Alpy, 21610 Saint-Maurice-sur-Vingeanne');

INSERT INTO Organisation (numero,adresse) VALUES
(1386,'77 Chemin rural dit de la Colle de Vallauris, 19460 Naves'),
(1387,'871bis Lieu-Dit La Grange Neuve, 64360 Abos');

INSERT INTO Organisation (numero,adresse) VALUES
(1388,'546 Le Pre la Bretagne, 51800 Voilemont'),
(1389,'997 Carnejac de GRAND-VABRE, 33890 Juillac');

INSERT INTO Organisation (numero,adresse) VALUES
(1390,'216 Terra Verde, 57220 Brouck'),
(1391,'72 Domaine de Mesle, 09100 Arvigna');

INSERT INTO Organisation (numero,adresse) VALUES
(1392,'331 Rond point des Semboules, 25410 Osselle-Routelle'),
(1393,'985bis Square Dédé Truqui, 53410 Bourgon');

INSERT INTO Organisation (numero,adresse) VALUES
(1394,'515 Local Technique, 10190 Dierrey-Saint-Pierre'),
(1395,'344bis Hameaux de Bille, 57220 Obervisse');

INSERT INTO Organisation (numero,adresse) VALUES
(1396,'830 Le Petit Soulice, 38660 Saint-Vincent-de-Mercuze'),
(1397,'143bis """ La Gagnerie """, 51320 Bréban');

INSERT INTO Organisation (numero,adresse) VALUES
(1398,'868 La Franchise, 02120 Le Hérie-la-Viéville'),
(1399,'645 Les Méans, 69460 Odenas');

INSERT INTO Organisation (numero,adresse) VALUES
(1400,'930 """ Le Fontinoux """, 80130 Tully'),
(1401,'868bis En Ratelet, 06910 Aiglun');

INSERT INTO Organisation (numero,adresse) VALUES
(1402,'543 Caraboussaou, 77114 Villiers-sur-Seine'),
(1403,'892 Bois Guiral, 51700 Vandières');

INSERT INTO Organisation (numero,adresse) VALUES
(1404,'138bis Les Martins, 31290 Villefranche-de-Lauragais'),
(1405,'605bis l''Albarea, 76150 Maromme');

INSERT INTO Organisation (numero,adresse) VALUES
(1406,'522 Domaine de la Bessay, 54580 Auboué'),
(1407,'137 """ Saussière """, 44520 Moisdon-la-Rivière');

INSERT INTO Organisation (numero,adresse) VALUES
(1408,'372 Hameau du Petit Gubian, 67600 Baldenheim'),
(1409,'559bis Hameau le Jard, 30190 La Calmette');

INSERT INTO Organisation (numero,adresse) VALUES
(1410,'49 Brénaz - Hameau de Méraléaz, 10130 Auxon'),
(1411,'514 Mont Joli, 09300 Péreille');

INSERT INTO Organisation (numero,adresse) VALUES
(1412,'901 Tunnel Leon Deloy, 45260 Noyers'),
(1413,'872 Iméras Inferieur, 71540 Igornay');

INSERT INTO Organisation (numero,adresse) VALUES
(1414,'809 Esplanade Jean Moulin, 65690 Angos'),
(1415,'252 Traverse des Coquelicots, 62550 Fontaine-lès-Hermans');

INSERT INTO Organisation (numero,adresse) VALUES
(1416,'754bis La Dricherie, 44410 La Chapelle-des-Marais'),
(1417,'636bis Jardin de la Paix, 55400 Moranville');

INSERT INTO Organisation (numero,adresse) VALUES
(1418,'176bis Rue de la Scierie, 65240 Estarvielle'),
(1419,'83 Claron, 05600 Mont-Dauphin');

INSERT INTO Organisation (numero,adresse) VALUES
(1420,'808 Salavieille Est, 03360 Saint-Bonnet-Tronçais'),
(1421,'72 Ossèse, 31270 Cugnaux');

INSERT INTO Organisation (numero,adresse) VALUES
(1422,'922 L’Abriq, 63710 Saint-Nectaire'),
(1423,'797 Route de Saint-etienne, 59630 Drincham');

INSERT INTO Organisation (numero,adresse) VALUES
(1424,'892 Baobab, 50510 Le Loreur'),
(1425,'777bis Marcholles, 47600 Calignac');

INSERT INTO Organisation (numero,adresse) VALUES
(1426,'397bis Forest la Cour Ouest, 22630 Évran'),
(1427,'878 Courtials, 64330 Mont-Disse');

INSERT INTO Organisation (numero,adresse) VALUES
(1428,'338 La Raffanelle, 76680 Rosay'),
(1429,'972 Séguret, 54260 Charency-Vezin');

INSERT INTO Organisation (numero,adresse) VALUES
(1430,'541 Bonhoure, 55600 Vigneul-sous-Montmédy'),
(1431,'756 Ferrabouc, 69620 Theizé');

INSERT INTO Organisation (numero,adresse) VALUES
(1432,'393 Rue  Antoine Lavoisier, 40320 Pimbo'),
(1433,'374bis Les Ribes, 02600 Dampleux');

INSERT INTO Organisation (numero,adresse) VALUES
(1434,'135 Hameau de La Voirie, 41100 Villeromain'),
(1435,'52 Vincent, 02340 Noircourt');

INSERT INTO Organisation (numero,adresse) VALUES
(1436,'228bis Roc du DEVEZ, 14170 Vaudeloges'),
(1437,'517 Chante-Loube, 31430 Marignac-Lasclares');

INSERT INTO Organisation (numero,adresse) VALUES
(1438,'905 Agence Postale Communale de Sclos, 37310 Sublaines'),
(1439,'754 Lardeyrolles, 13450 Grans');

INSERT INTO Organisation (numero,adresse) VALUES
(1440,'890 Chalaye, 53300 Saint-Mars-sur-Colmont'),
(1441,'156 Bonvent, 42260 Luré');

INSERT INTO Organisation (numero,adresse) VALUES
(1442,'375 Les Moulieres, 42140 La Gimond'),
(1443,'700 Lamarque, 70150 Chambornay-lès-Pin');

INSERT INTO Organisation (numero,adresse) VALUES
(1444,'6 Les Thuriers, 39270 Orgelet'),
(1445,'522 Place Jean Flory, 59111 Wavrechain-sous-Faulx');

INSERT INTO Organisation (numero,adresse) VALUES
(1446,'743bis Le Chp de la Porte, 08220 Montmeillant'),
(1447,'55 Le Val Des Anges A, 69930 Saint-Clément-les-Places');

INSERT INTO Organisation (numero,adresse) VALUES
(1448,'38 Res Primavera B, 23250 Saint-Hilaire-le-Château'),
(1449,'259 Rue du Square, 61570 Mortrée');

INSERT INTO Organisation (numero,adresse) VALUES
(1450,'893 Pont long, 15300 Virargues'),
(1451,'23 Le Moulin de la Cammazie, 68480 Winkel');

INSERT INTO Organisation (numero,adresse) VALUES
(1452,'455bis Bois Marboz, 56500 Moréac'),
(1453,'212bis Alpy, 10190 Chennegy');

INSERT INTO Organisation (numero,adresse) VALUES
(1454,'342 Ecluse_des_roussets, 34120 Castelnau-de-Guers'),
(1455,'330 Voie d''accès nord Quai la Perouse, 62760 Gaudiempré');

INSERT INTO Organisation (numero,adresse) VALUES
(1456,'518 Pierre Froide, 51460 Poix'),
(1457,'530 Impasse de la Poterne, 80120 Regnière-Écluse');

INSERT INTO Organisation (numero,adresse) VALUES
(1458,'952bis Le Mas de Salvayre, 24560 Montaut'),
(1459,'165bis La Liaubette, 72360 Sarcé');

INSERT INTO Organisation (numero,adresse) VALUES
(1460,'920 lieu dit, 30340 Saint-Julien-les-Rosiers'),
(1461,'218 Les Cotes du Moulin, 43170 Venteuges');

INSERT INTO Organisation (numero,adresse) VALUES
(1462,'711bis Les Perrons, 15600 Saint-Julien-de-Toursac'),
(1463,'892bis La Peade, 80300 Morlancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(1464,'801bis Résidence Harmony, 60210 Sarcus'),
(1465,'617 Les Moussets, 66300 Caixas');

INSERT INTO Organisation (numero,adresse) VALUES
(1466,'376bis """ Bouquetterie """, 45640 Sandillon'),
(1467,'605bis Plateau des Forges, 31480 Cabanac-Séguenville');

INSERT INTO Organisation (numero,adresse) VALUES
(1468,'464 La Manhobe, 09460 Rouze'),
(1469,'813bis Dessous Courtigy, 21140 Semur-en-Auxois');

INSERT INTO Organisation (numero,adresse) VALUES
(1470,'953bis Longue Peyssolle, 01160 Pont-d''Ain'),
(1471,'460bis Bretelle Sortie Corniglion-Molinier - Aéroport, 08200 Glaire');

INSERT INTO Organisation (numero,adresse) VALUES
(1472,'80 Champs Thevenins, 54620 Doncourt-lès-Longuyon'),
(1473,'650bis """ Brossiere """, 25290 Chassagne-Saint-Denis');

INSERT INTO Organisation (numero,adresse) VALUES
(1474,'710 Rond-Point du Corps expéditionnaire francais en Extrême Orient, 45390 Grangermont'),
(1475,'536 Sur les Tras, 80470 Ferrières');

INSERT INTO Organisation (numero,adresse) VALUES
(1476,'944 Fouent de Barraou, 29770 Plogoff'),
(1477,'677 Barjon Ouest, 79170 Brieuil-sur-Chizé');

INSERT INTO Organisation (numero,adresse) VALUES
(1478,'125bis Aire du Plan d''Eau du Radal, 39570 Saint-Didier'),
(1479,'163 La Champelle, 79120 Chenay');

INSERT INTO Organisation (numero,adresse) VALUES
(1480,'875 Les Bessias, 22110 Plounévez-Quintin'),
(1481,'627 Salle EDF, 64230 Sauvagnon');

INSERT INTO Organisation (numero,adresse) VALUES
(1482,'826 En Leurperon, 63130 Royat'),
(1483,'253 Kiosque, 76480 Duclair');

INSERT INTO Organisation (numero,adresse) VALUES
(1484,'7bis Route de Meaulne, 38690 Le Grand-Lemps'),
(1485,'361 Imbarriere, 71460 Champagny-sous-Uxelles');

INSERT INTO Organisation (numero,adresse) VALUES
(1486,'842 Bât. G2, 03190 Verneix'),
(1487,'233 La Vizeratte, 02700 Mennessis');

INSERT INTO Organisation (numero,adresse) VALUES
(1488,'961 Le Grand Roustain, 31230 Anan'),
(1489,'652bis Chazalis, 17400 Saint-Julien-de-l''Escap');

INSERT INTO Organisation (numero,adresse) VALUES
(1490,'83 Courette Louis Anfosso, 58330 Saint-Benin-des-Bois'),
(1491,'229 Villa Maguy, 62118 Plouvain');

INSERT INTO Organisation (numero,adresse) VALUES
(1492,'326 les Bletonnets, 59217 Bévillers'),
(1493,'593bis Le Chemin Vert, 42720 Pouilly-sous-Charlieu');

INSERT INTO Organisation (numero,adresse) VALUES
(1494,'513 L''Olivier, 07340 Champagne'),
(1495,'613 Le Moulin des Crouttes, 02260 Sommeron');

INSERT INTO Organisation (numero,adresse) VALUES
(1496,'139bis Chemin de la Sablière, 59530 Villers-Pol'),
(1497,'310 Laval, 59152 Anstaing');

INSERT INTO Organisation (numero,adresse) VALUES
(1498,'634bis Les Boirons Ouest, 51310 Esternay'),
(1499,'343 Les Grandes Haies, 33320 Le Taillan-Médoc');

INSERT INTO Organisation (numero,adresse) VALUES
(1500,'828 Les Collanges, 22110 Plounévez-Quintin'),
(1501,'975 Saint-Michel, 62240 Wirwignes');

INSERT INTO Organisation (numero,adresse) VALUES
(1502,'266 Le Moulin à Ciment, 67360 Dieffenbach-lès-Wœrth'),
(1503,'583 Impasse des Tillets, 10390 Clérey');

INSERT INTO Organisation (numero,adresse) VALUES
(1504,'464 Le petit Gibony, 72600 Aillières-Beauvoir'),
(1505,'520 Chassignolles, 78740 Évecquemont');

INSERT INTO Organisation (numero,adresse) VALUES
(1506,'654bis Valfroide, 59310 Nomain'),
(1507,'812bis Musée / Halte Jacquaire, 22440 Ploufragan');

INSERT INTO Organisation (numero,adresse) VALUES
(1508,'466 Tournemire, 16140 Aigre'),
(1509,'48 Le Moulin Bonin, 01230 Conand');

INSERT INTO Organisation (numero,adresse) VALUES
(1510,'556 Croix des Hens, 44670 Saint-Julien-de-Vouvantes'),
(1511,'369 Tredos, 70000 Pusy-et-Épenoux');

INSERT INTO Organisation (numero,adresse) VALUES
(1512,'785 Bâtiment Le basilic Entrée 8, 41170 Couëtron-au-Perche'),
(1513,'379 Le Barrail, 06390 Bendejun');

INSERT INTO Organisation (numero,adresse) VALUES
(1514,'344 Casot, 15400 Cheylade'),
(1515,'331 Lieu Dit Binsou, 08600 Landrichamps');

INSERT INTO Organisation (numero,adresse) VALUES
(1516,'448bis Le Bancarel, 38620 Merlas'),
(1517,'695 Route Nationale 43, 80260 Flesselles');

INSERT INTO Organisation (numero,adresse) VALUES
(1518,'560 Lieu-dit Fontabello, 19200 Saint-Victour'),
(1519,'64 Domaine de Portecluse, 24380 Breuilh');

INSERT INTO Organisation (numero,adresse) VALUES
(1520,'973bis Gymnase Colette Besson, 71620 Montcoy'),
(1521,'855bis Le Mas Regord, 35360 La Chapelle du Lou du Lac');

INSERT INTO Organisation (numero,adresse) VALUES
(1522,'392 Domaine royal parc, 01430 Vieu-d''Izenave'),
(1523,'933 Pres la Fontaine des Loups, 09500 Camon');

INSERT INTO Organisation (numero,adresse) VALUES
(1524,'77 Le Petit Douaire, 80560 Auchonvillers'),
(1525,'506 Bastides De L''Hubac 4-5, 71150 Rully');

INSERT INTO Organisation (numero,adresse) VALUES
(1526,'549 Le Séminaire, 71240 Sennecey-le-Grand'),
(1527,'943 Ma Tanniere, 60130 Avrechy');

INSERT INTO Organisation (numero,adresse) VALUES
(1528,'925 Le Mas de Frayssinhes, 39190 Rotalier'),
(1529,'859 Pre Devant, 74270 Desingy');

INSERT INTO Organisation (numero,adresse) VALUES
(1530,'813 Bât A les Deux Moulins, 17430 Moragne'),
(1531,'826 Saint Théophrède, 70000 Vaivre-et-Montoille');

INSERT INTO Organisation (numero,adresse) VALUES
(1532,'842 Nauriol Bas, 51800 Cernay-en-Dormois'),
(1533,'177bis Les Brochiers, 21800 Neuilly-lès-Dijon');

INSERT INTO Organisation (numero,adresse) VALUES
(1534,'980bis Les Plans, 38690 Burcin'),
(1535,'148 Les_brandes, 80270 Tailly');

INSERT INTO Organisation (numero,adresse) VALUES
(1536,'24 Zone de pique-nique, 38420 Saint-Jean-le-Vieux'),
(1537,'408 Marina I Et Ii, 66500 Conat');

INSERT INTO Organisation (numero,adresse) VALUES
(1538,'112bis Guirole, 47310 Laplume'),
(1539,'857 Jardin Escoffier, 32420 Sarcos');

INSERT INTO Organisation (numero,adresse) VALUES
(1540,'790bis Athena, 77139 Marcilly'),
(1541,'45bis Chemin du Vallon du Petit Paradis, 03420 Terjat');

INSERT INTO Organisation (numero,adresse) VALUES
(1542,'404 côte des Speggi, 60590 Talmontiers'),
(1543,'231 Parvis Église Saint Maurice, 26190 Rochechinard');

INSERT INTO Organisation (numero,adresse) VALUES
(1544,'751 La Piouzello, 01560 Vescours'),
(1545,'461bis Bretelle Sortie Avenue des Sapeurs Pompiers de Nice - Pont René Coty, 65190 Luc');

INSERT INTO Organisation (numero,adresse) VALUES
(1546,'816bis Montes, 68220 Buschwiller'),
(1547,'51 Saint-Brès, 07200 Lachapelle-sous-Aubenas');

INSERT INTO Organisation (numero,adresse) VALUES
(1548,'530 Ferme du Petit Caumont, 57415 Enchenberg'),
(1549,'158bis Bercan, 57455 Seingbouse');

INSERT INTO Organisation (numero,adresse) VALUES
(1550,'630 Quartier Hameau de Venascle, 34320 Roquessels'),
(1551,'385bis Sarreros, 22100 Taden');

INSERT INTO Organisation (numero,adresse) VALUES
(1552,'538 La Fosse a Ciry, 19340 Couffy-sur-Sarsonne'),
(1553,'315 La Trivale, 77570 Aufferville');

INSERT INTO Organisation (numero,adresse) VALUES
(1554,'245 Le Brusc, 62128 Wancourt'),
(1555,'535 Ruelle de Creuse Ville, 60120 Sérévillers');

INSERT INTO Organisation (numero,adresse) VALUES
(1556,'389 Les Hautes Breguieres, 24380 Chalagnac'),
(1557,'899bis Bains Nauches, 72430 Fercé-sur-Sarthe');

INSERT INTO Organisation (numero,adresse) VALUES
(1558,'186 Le Petit Pont, 11340 Belvis'),
(1559,'977bis Point Eau Incendie n°1005 (borne d''incendie), 67330 Issenhausen');

INSERT INTO Organisation (numero,adresse) VALUES
(1560,'376bis Salsogne, 01300 Brens'),
(1561,'210 Parking de la gare, 62310 Torcy');

INSERT INTO Organisation (numero,adresse) VALUES
(1562,'745 Hameau la Cabirole, 67250 Preuschdorf'),
(1563,'614 Les Vauges, 47270 Puymirol');

INSERT INTO Organisation (numero,adresse) VALUES
(1564,'720 Les Bastides Du Soleil, 16440 Roullet-Saint-Estèphe'),
(1565,'829 Les Lagiers, 76450 Saint-Martin-aux-Buneaux');

INSERT INTO Organisation (numero,adresse) VALUES
(1566,'463 Lotissement Le Gourg, 32220 Montpézat'),
(1567,'481 Combe de Barbe, 41700 Fresnes');

INSERT INTO Organisation (numero,adresse) VALUES
(1568,'282 Ancien Chemin de l''Abadie à l''Ariane, 25320 Thoraise'),
(1569,'793 Etang de la Roussière, 10700 Lhuître');

INSERT INTO Organisation (numero,adresse) VALUES
(1570,'914 La Pezade, 50210 Cerisy-la-Salle'),
(1571,'231 Saint Victor du Fau, 16700 Barro');

INSERT INTO Organisation (numero,adresse) VALUES
(1572,'203 Clot de la Mule, 59830 Bachy'),
(1573,'379 Res Les Collines De Cagnes, 31360 Proupiary');

INSERT INTO Organisation (numero,adresse) VALUES
(1574,'574 Puech du Causse, 54115 Tramont-Lassus'),
(1575,'310 La Tauleigne, 03390 Saint-Bonnet-de-Four');

INSERT INTO Organisation (numero,adresse) VALUES
(1576,'759 Cabrit, 66620 Brouilla'),
(1577,'816 Le Barralet, 27120 Rouvray');

INSERT INTO Organisation (numero,adresse) VALUES
(1578,'376 En Buisson, 28410 Abondant'),
(1579,'739bis Ripoz, 55110 Sivry-sur-Meuse');

INSERT INTO Organisation (numero,adresse) VALUES
(1580,'237bis Voiles Blanches Bât E, 11200 Canet'),
(1581,'926 Le Branle, 18270 Reigny');

INSERT INTO Organisation (numero,adresse) VALUES
(1582,'886bis les Carles, 17130 Salignac-de-Mirambeau'),
(1583,'754 Le Planque-Haute, 60190 Baugy');

INSERT INTO Organisation (numero,adresse) VALUES
(1584,'408 Dessus l''Église, 27270 Chamblac'),
(1585,'208 Contard-haut, 06530 Cabris');

INSERT INTO Organisation (numero,adresse) VALUES
(1586,'780 Le St Saens A, 36140 Lourdoueix-Saint-Michel'),
(1587,'130 La Font de Bise, 31430 Saint-Araille');

INSERT INTO Organisation (numero,adresse) VALUES
(1588,'14 Les Resid De L''Hubac Lot 2, 45360 Châtillon-sur-Loire'),
(1589,'949 Marc, 67470 Eberbach-Seltz');

INSERT INTO Organisation (numero,adresse) VALUES
(1590,'328bis Bandaire, 26110 Arpavon'),
(1591,'509 Pruns Bas, 14380 Le Mesnil-Caussois');

INSERT INTO Organisation (numero,adresse) VALUES
(1592,'13 Fretière, 29880 Guissény'),
(1593,'305 En Pendant Ouest, 40460 Sanguinet');

INSERT INTO Organisation (numero,adresse) VALUES
(1594,'566 Esplanade des Ruthènes, 03360 Saint-Bonnet-Tronçais'),
(1595,'267bis Les Petits Bonnets, 19120 Sioniac');

INSERT INTO Organisation (numero,adresse) VALUES
(1596,'752 Lassagne, 80270 Allery'),
(1597,'873bis Route Nationale N 82, 10400 Saint-Aubin');

INSERT INTO Organisation (numero,adresse) VALUES
(1598,'851bis Etang Motadet, 11400 Fonters-du-Razès'),
(1599,'911 Route du Gd Wez, 32290 Bouzon-Gellenave');

INSERT INTO Organisation (numero,adresse) VALUES
(1600,'453 hameau Tabanette, 35300 Fougères'),
(1601,'314 Le Beau Rosier, 09400 Rabat-les-Trois-Seigneurs');

INSERT INTO Organisation (numero,adresse) VALUES
(1602,'197bis La Triplotte, 25210 Bonnétage'),
(1603,'494 Chemin des Cistes, 32390 Mirepoix');

INSERT INTO Organisation (numero,adresse) VALUES
(1604,'688 Res Vidalou, 39210 Domblans'),
(1605,'458 La Scie de Tardieu, 21320 Châteauneuf');

INSERT INTO Organisation (numero,adresse) VALUES
(1606,'896 Les Rouzelets, 59660 Haverskerque'),
(1607,'935 Les Andres d''En Bas, 70130 Motey-sur-Saône');

INSERT INTO Organisation (numero,adresse) VALUES
(1608,'328 Champ Plavin, 76760 Vibeuf'),
(1609,'852 Las Carreroles, 66300 Tordères');

INSERT INTO Organisation (numero,adresse) VALUES
(1610,'626 Chaudebry, 14380 Le Mesnil-Robert'),
(1611,'188bis Le Vernugeat, 50480 Brucheville');

INSERT INTO Organisation (numero,adresse) VALUES
(1612,'321 Trunel, 65120 Sers'),
(1613,'175 Canteserp, 67260 Burbach');

INSERT INTO Organisation (numero,adresse) VALUES
(1614,'462 Quai du Corps Expéditionnaire Français en Italie, 02240 Ribemont'),
(1615,'733 Causse du Gascon, 38940 Saint-Clair-sur-Galaure');

INSERT INTO Organisation (numero,adresse) VALUES
(1616,'567bis domaine d''Arnauteille, 21370 Velars-sur-Ouche'),
(1617,'710 Les Estribes, 80370 Conteville');

INSERT INTO Organisation (numero,adresse) VALUES
(1618,'364 Vissac, 49490 Dénezé-sous-le-Lude'),
(1619,'741 Place  Maurice Brisset, 66350 Toulouges');

INSERT INTO Organisation (numero,adresse) VALUES
(1620,'705 La Pradelle, 63450 Chanonat'),
(1621,'368 Drulhe, 77120 Mouroux');

INSERT INTO Organisation (numero,adresse) VALUES
(1622,'575 Allee de la Saladine, 75018 Paris 18'),
(1623,'98 Salelles, 35290 Le Crouais');

INSERT INTO Organisation (numero,adresse) VALUES
(1624,'818 La Tremoliere, 42520 Lupé'),
(1625,'553bis Les Miniotes, 30580 Vallérargues');

INSERT INTO Organisation (numero,adresse) VALUES
(1626,'412 Balec, 28800 Villiers-Saint-Orien'),
(1627,'113 La Sapinette, 52130 Montreuil-sur-Blaise');

INSERT INTO Organisation (numero,adresse) VALUES
(1628,'384bis Vallée au Vin, 06620 Courmes'),
(1629,'254 Les Gouttes Larges, 02290 Épagny');

INSERT INTO Organisation (numero,adresse) VALUES
(1630,'976 Avenue des Roches d''Or, 18260 Assigny'),
(1631,'462 Prabus, 35230 Bourgbarré');

INSERT INTO Organisation (numero,adresse) VALUES
(1632,'288 Villa Viosna, 70500 Bourbévelle'),
(1633,'917 Grandchamp, 03390 Saint-Marcel-en-Murat');

INSERT INTO Organisation (numero,adresse) VALUES
(1634,'97 Saint-sernin-sur-rance, 19430 Bassignac-le-Bas'),
(1635,'670 Les Guilleminots, 63260 Montpensier');

INSERT INTO Organisation (numero,adresse) VALUES
(1636,'463bis Clos Maillard, 21230 Saint-Pierre-en-Vaux'),
(1637,'993 Saint Grégoire, 72430 Tassé');

INSERT INTO Organisation (numero,adresse) VALUES
(1638,'507 Parking rue des Arbousiers, 43410 Léotoing'),
(1639,'128bis Canteserp, 46120 Le Bourg');

INSERT INTO Organisation (numero,adresse) VALUES
(1640,'442 Combe de Bouge, 33115 La Teste-de-Buch'),
(1641,'49 Villa Foxy, 53340 Bannes');

INSERT INTO Organisation (numero,adresse) VALUES
(1642,'700 La Lebouse, 64460 Ponson-Debat-Pouts'),
(1643,'727 Domaine de la Martellière Rouge, 54470 Seicheprey');

INSERT INTO Organisation (numero,adresse) VALUES
(1644,'534bis Aigret, 62300 Éleu-dit-Leauwette'),
(1645,'849 Vieu, 68150 Ostheim');

INSERT INTO Organisation (numero,adresse) VALUES
(1646,'496bis lieu dit Cagnouté, 38690 Longechenal'),
(1647,'881 Route Métropolitaine 72, 21410 Saint-Jean-de-Bœuf');

INSERT INTO Organisation (numero,adresse) VALUES
(1648,'767 Terre des Manceaux, 79370 Thorigné'),
(1649,'533 Les Mourres de Tines, 02340 Berlise');

INSERT INTO Organisation (numero,adresse) VALUES
(1650,'596 À la Doux Nord, 56910 Saint-Nicolas-du-Tertre'),
(1651,'698 Paput, 68160 Sainte-Croix-aux-Mines');

INSERT INTO Organisation (numero,adresse) VALUES
(1652,'212 Pers, 05100 Puy-Saint-Pierre'),
(1653,'797 Le Gravas, 42600 Savigneux');

INSERT INTO Organisation (numero,adresse) VALUES
(1654,'526 Quartier les Lavandieres, 45480 Bazoches-les-Gallerandes'),
(1655,'304 Tromparent, 35134 Coësmes');

INSERT INTO Organisation (numero,adresse) VALUES
(1656,'544bis Sentier Paul Viazzi, 41130 Gièvres'),
(1657,'899 La Baldonie, 55100 Charny-sur-Meuse');

INSERT INTO Organisation (numero,adresse) VALUES
(1658,'883 Granges de Rivet, 21290 Terrefondrée'),
(1659,'176 Le Bertrand, 43230 Sainte-Eugénie-de-Villeneuve');

INSERT INTO Organisation (numero,adresse) VALUES
(1660,'906 Le Causse Grand, 33730 Préchac'),
(1661,'149bis Salle des Fêtes André Comte, 77100 Mareuil-lès-Meaux');

INSERT INTO Organisation (numero,adresse) VALUES
(1662,'510bis Place du 8 Mai, 11340 Belvis'),
(1663,'694 La Pilande Basse, 31800 Latoue');

INSERT INTO Organisation (numero,adresse) VALUES
(1664,'541 Col de Bedos, 57340 Bréhain'),
(1665,'312 Le Vernhassou, 21150 Alise-Sainte-Reine');

INSERT INTO Organisation (numero,adresse) VALUES
(1666,'214 Pre Cuminal, 69610 Montromant'),
(1667,'624bis Lenne, 11300 Malviès');

INSERT INTO Organisation (numero,adresse) VALUES
(1668,'815 Terres des maires, 02000 Chivy-lès-Étouvelles'),
(1669,'626 Lancelot Sud, 56140 Saint-Abraham');

INSERT INTO Organisation (numero,adresse) VALUES
(1670,'544bis Le Fief des Tournelles, 47120 Savignac-de-Duras'),
(1671,'986 Le Meridional, 64530 Barzun');

INSERT INTO Organisation (numero,adresse) VALUES
(1672,'853 Centre social, 16320 Combiers'),
(1673,'47 Vigneresc, 77410 Précy-sur-Marne');

INSERT INTO Organisation (numero,adresse) VALUES
(1674,'735bis Bergerie de Cazecouverte, 65190 Tournay'),
(1675,'914 Les Boudards, 50800 Saint-Martin-le-Bouillant');

INSERT INTO Organisation (numero,adresse) VALUES
(1676,'860 La Piece de la Bête, 80300 Carnoy'),
(1677,'892 Marchillat, 42210 Bellegarde-en-Forez');

INSERT INTO Organisation (numero,adresse) VALUES
(1678,'355 Puech de Medaille, 80500 Warsy'),
(1679,'989 Moulin Breland, 65190 Luc');

INSERT INTO Organisation (numero,adresse) VALUES
(1680,'528 Quart d''Avard, 50270 Sénoville'),
(1681,'86 Chemin de la Garenne, 35190 Cardroc');

INSERT INTO Organisation (numero,adresse) VALUES
(1682,'382 2 Col de la Croix route de Rouffiac des Corbières, 22170 Plerneuf'),
(1683,'328 Les Briats, 18310 Genouilly');

INSERT INTO Organisation (numero,adresse) VALUES
(1684,'520 Le Jas de la Bri, 31110 Gouaux-de-Luchon'),
(1685,'946 Chabre, 62490 Quiéry-la-Motte');

INSERT INTO Organisation (numero,adresse) VALUES
(1686,'855 Les Grandes Aisances, 53220 La Pellerine'),
(1687,'687 Les Trois Fons, 72600 Blèves');

INSERT INTO Organisation (numero,adresse) VALUES
(1688,'176 Autopont Cassin - Mathis (Chaussée sud), 27520 Les Monts du Roumois'),
(1689,'285 Le Petit Gué d''Hossus, 52150 Nijon');

INSERT INTO Organisation (numero,adresse) VALUES
(1690,'114 Chemin de Halage, 21390 Braux'),
(1691,'783 La Gariette, 58310 Saint-Amand-en-Puisaye');

INSERT INTO Organisation (numero,adresse) VALUES
(1692,'300 Les Arnauds, 02470 Sommelans'),
(1693,'732 Eylie d''en Bas, 14350 Valdallière');

INSERT INTO Organisation (numero,adresse) VALUES
(1694,'517bis Route Nationale 202, 34230 Aumelas'),
(1695,'703 Tournie, 01560 Curciat-Dongalon');

INSERT INTO Organisation (numero,adresse) VALUES
(1696,'962 Bel-Air, 65130 Lomné'),
(1697,'141bis Les Silos, 72120 Écorpain');

INSERT INTO Organisation (numero,adresse) VALUES
(1698,'916bis Saint-Lizier, 62144 Villers-au-Bois'),
(1699,'610bis Chemin de Chicalon, 16460 Moutonneau');

INSERT INTO Organisation (numero,adresse) VALUES
(1700,'960 Saut de Millo, 67510 Obersteinbach'),
(1701,'836bis Le Camp de Garlassac, 61450 Le Châtellier');

INSERT INTO Organisation (numero,adresse) VALUES
(1702,'373 Domaine de Lunes, 27250 Chéronvilliers'),
(1703,'533 Terres Longues, 38260 Faramans');

INSERT INTO Organisation (numero,adresse) VALUES
(1704,'777 Bourel, 27150 Gamaches-en-Vexin'),
(1705,'558 Hameau Les Combes, 10380 Viâpres-le-Petit');

INSERT INTO Organisation (numero,adresse) VALUES
(1706,'564 Lei Foulatoun, 58330 Crux-la-Ville'),
(1707,'775 Jardin des Moulins, 17330 Villeneuve-la-Comtesse');

INSERT INTO Organisation (numero,adresse) VALUES
(1708,'283 Saussière, 44690 Château-Thébaud'),
(1709,'712bis Lascazes, 05700 Villebois-les-Pins');

INSERT INTO Organisation (numero,adresse) VALUES
(1710,'638 Domaine des Chênes Lièges, 15430 Paulhac'),
(1711,'387bis Cimetiere 1, 77100 Nanteuil-lès-Meaux');

INSERT INTO Organisation (numero,adresse) VALUES
(1712,'299 Les Parizets, 02000 Urcel'),
(1713,'79 Rue de l''Etang, 37370 Chemillé-sur-Dême');

INSERT INTO Organisation (numero,adresse) VALUES
(1714,'553 La Bastizou-Basse, 67130 Wildersbach'),
(1715,'654 Rive De Cagnes A Et C, 55300 Dompcevrin');

INSERT INTO Organisation (numero,adresse) VALUES
(1716,'381bis Saint Alby, 59670 Bavinchove'),
(1717,'992bis Chongnes, 01090 Lurcy');

INSERT INTO Organisation (numero,adresse) VALUES
(1718,'393 Pont d''Ongran, 59282 Douchy-les-Mines'),
(1719,'807bis La Mariere, 55400 Mogeville');

INSERT INTO Organisation (numero,adresse) VALUES
(1720,'232 Résidence Le Gai Logis Bâtiment C5, 02120 Hauteville'),
(1721,'656bis Rosieres, 43300 Cronce');

INSERT INTO Organisation (numero,adresse) VALUES
(1722,'707bis Le Bas du Champ Magnet, 70120 Gourgeon'),
(1723,'496 Villa Marie, 73130 Saint-Avre');

INSERT INTO Organisation (numero,adresse) VALUES
(1724,'784 Bois Saint-Peyre, 77560 Les Marêts'),
(1725,'717bis Saint Rame, 71360 Collonge-la-Madeleine');

INSERT INTO Organisation (numero,adresse) VALUES
(1726,'669 Moulin D''Ayres, 50760 Valcanville'),
(1727,'745 La Terre Blanche, 09310 Larcat');

INSERT INTO Organisation (numero,adresse) VALUES
(1728,'305 Chemin des Escarrères, 27250 Rugles'),
(1729,'115 Peiro, 28270 Saint-Lubin-de-Cravant');

INSERT INTO Organisation (numero,adresse) VALUES
(1730,'107 Aire Camping Car, 33910 Bonzac'),
(1731,'725 La Ciavarlina, 59970 Vicq');

INSERT INTO Organisation (numero,adresse) VALUES
(1732,'649 Cassignoles, 60250 Mouy'),
(1733,'31 Proche le Bac, 37420 Beaumont-en-Véron');

INSERT INTO Organisation (numero,adresse) VALUES
(1734,'827 Le Vérier, 29890 Plounéour-Brignogan-plages'),
(1735,'98 Fayt Haut, 21350 Saint-Thibault');

INSERT INTO Organisation (numero,adresse) VALUES
(1736,'502bis Ferme de Franclieu, 65370 Cazarilh'),
(1737,'989 Résidence Blaise Matudi, 28700 Mondonville-Saint-Jean');

INSERT INTO Organisation (numero,adresse) VALUES
(1738,'89 HLM Bergeron Vebret Bat A, 77320 Leudon-en-Brie'),
(1739,'404 La Falière, 20127 Serra-di-Scopamène');

INSERT INTO Organisation (numero,adresse) VALUES
(1740,'91 Villa Azur A, 30450 Génolhac'),
(1741,'253 Cestrieres, 64190 Ogenne-Camptort');

INSERT INTO Organisation (numero,adresse) VALUES
(1742,'483 Le Clavet, 39240 Valfin-sur-Valouse'),
(1743,'865bis Voie s''amorçant à la petite avenue Félicité Savona, 35133 Lécousse');

INSERT INTO Organisation (numero,adresse) VALUES
(1744,'366 Domaine de Pech Redon, 28330 Coudray-au-Perche'),
(1745,'153 Moulin de Vavres, 30660 Gallargues-le-Montueux');

INSERT INTO Organisation (numero,adresse) VALUES
(1746,'780 Le Coumel, 76110 Goderville'),
(1747,'238 Salmiech, 77850 Héricy');

INSERT INTO Organisation (numero,adresse) VALUES
(1748,'780 Lotissement Les Migraniers, 11700 Douzens'),
(1749,'879 Château la Vernède, 39800 Abergement-le-Petit');

INSERT INTO Organisation (numero,adresse) VALUES
(1750,'508 chemin rural de Bergères à Bar-sur-Aube, 27120 Ménilles'),
(1751,'455 Gîtes, 34700 Le Puech');

INSERT INTO Organisation (numero,adresse) VALUES
(1752,'697 La Rue du Blocq, 51270 Orbais-l''Abbaye'),
(1753,'653 Garage 1, 54330 Forcelles-Saint-Gorgon');

INSERT INTO Organisation (numero,adresse) VALUES
(1754,'565bis Voie desserte de l''Hôpital Pasteur, 55160 Pintheville'),
(1755,'106bis Serre de la Trinité, 76390 Richemont');

INSERT INTO Organisation (numero,adresse) VALUES
(1756,'644 Boireau Bas, 19260 Peyrissac'),
(1757,'742 Aubusson, 36270 Baraize');

INSERT INTO Organisation (numero,adresse) VALUES
(1758,'566 La Farigoule, 14240 Caumont-sur-Aure'),
(1759,'684 Petite Avenue du Mont Boron, 33185 Le Haillan');

INSERT INTO Organisation (numero,adresse) VALUES
(1760,'785 City Stade, 19130 Vignols'),
(1761,'177 Rue de la Vallière, 64230 Aussevielle');

INSERT INTO Organisation (numero,adresse) VALUES
(1762,'388 Résidence Petite Garrigue - Bâtiment Alouette 1, 28220 Le Mée'),
(1763,'761 Berdot, 42114 Machézal');

INSERT INTO Organisation (numero,adresse) VALUES
(1764,'636 Champ des Croix, 57530 Maizeroy'),
(1765,'386bis Riou de Bez, 01550 Farges');

INSERT INTO Organisation (numero,adresse) VALUES
(1766,'578bis Clos Simonard, 14680 Cintheaux'),
(1767,'239bis Chemin Rural Dit du Maltara, 74270 Contamine-Sarzin');

INSERT INTO Organisation (numero,adresse) VALUES
(1768,'11 Voie liaison Chemin du Fort Thaon - voie du lotissement Mont Boron - Park, 59540 Caudry'),
(1769,'54 Rue du Chateau d''Eau, 73130 Saint-Colomban-des-Villards');

INSERT INTO Organisation (numero,adresse) VALUES
(1770,'912 Les Clastres, 11410 Montauriol'),
(1771,'595bis Le-petit-chantraine, 35550 Pipriac');

INSERT INTO Organisation (numero,adresse) VALUES
(1772,'500 Saint Jean de Gary, 44130 Blain'),
(1773,'459 La Vivère, 78125 Orphin');

INSERT INTO Organisation (numero,adresse) VALUES
(1774,'24 Mourex, 35460 Tremblay'),
(1775,'753 Le Pont de Pierre, 80135 Saint-Riquier');

INSERT INTO Organisation (numero,adresse) VALUES
(1776,'714bis Saint Santin, 47230 Thouars-sur-Garonne'),
(1777,'788 Bâtiment Le lierre, 36160 Pouligny-Notre-Dame');

INSERT INTO Organisation (numero,adresse) VALUES
(1778,'129 Les Oliviers, 05310 Freissinières'),
(1779,'175 Calviac, 72600 Saint-Calez-en-Saosnois');

INSERT INTO Organisation (numero,adresse) VALUES
(1780,'235 Les Contemines, 53470 Châlons-du-Maine'),
(1781,'15 Forêt de Belval, 38600 Fontaine');

INSERT INTO Organisation (numero,adresse) VALUES
(1782,'103 Contrée des Cailloux, 76850 Fresnay-le-Long'),
(1783,'961 Ribo Del Prat, 78470 Saint-Lambert');

INSERT INTO Organisation (numero,adresse) VALUES
(1784,'556 Serre de la Mole, 04510 Mirabeau'),
(1785,'754 Rue de la Place d''Armes, 20251 Pietraserena');

INSERT INTO Organisation (numero,adresse) VALUES
(1786,'288 La Ferratie, 08240 Tailly'),
(1787,'941bis Le Prat, 45770 Saran');

INSERT INTO Organisation (numero,adresse) VALUES
(1788,'97bis Lotissement la Gde Terre, 63500 Le Broc'),
(1789,'289bis Polletins, 04170 Saint-Julien-du-Verdon');

INSERT INTO Organisation (numero,adresse) VALUES
(1790,'576 Bellerica, 54122 Fontenoy-la-Joûte'),
(1791,'544bis Voie liaison Avenue Buenos Ayres Avenue René Maurice, 57320 Tromborn');

INSERT INTO Organisation (numero,adresse) VALUES
(1792,'921 Route Nationale N 82, 41000 Blois'),
(1793,'737bis Route de Villers les Guise, 47410 Lauzun');

INSERT INTO Organisation (numero,adresse) VALUES
(1794,'357 La Sente, 03370 Courçais'),
(1795,'278 Lieu-dit La Combe, 25530 Villers-Chief');

INSERT INTO Organisation (numero,adresse) VALUES
(1796,'672 Le Restugaud, 59840 Lompret'),
(1797,'615 Cambazelle, 60190 Épineuse');

INSERT INTO Organisation (numero,adresse) VALUES
(1798,'227 Les Tuiliers, 22800 Le Leslay'),
(1799,'517 L''Allagnier Est, 25120 Cernay-l''Église');

INSERT INTO Organisation (numero,adresse) VALUES
(1800,'290 Square du Relevant, 01090 Francheleins'),
(1801,'160 Résidence Anglade Bat Cagire E - Salau, 09100 Saint-Victor-Rouzaud');

INSERT INTO Organisation (numero,adresse) VALUES
(1802,'167bis Chemin de La Croix Saint-Joseph, 59530 Frasnoy'),
(1803,'906 Pre de Bord, 51420 Cernay-lès-Reims');

INSERT INTO Organisation (numero,adresse) VALUES
(1804,'262bis Les Villas du Verger, 02100 Fayet'),
(1805,'506bis Pré des Dix Sept Pichets, 67820 Wittisheim');

INSERT INTO Organisation (numero,adresse) VALUES
(1806,'95 La Saulneraie, 48140 Paulhac-en-Margeride'),
(1807,'841 Verchère des Pinoux, 34290 Montblanc');

INSERT INTO Organisation (numero,adresse) VALUES
(1808,'327 Le Bastidon, 56430 Saint-Léry'),
(1809,'624 Ciapagne Sovran, 76190 Hautot-le-Vatois');

INSERT INTO Organisation (numero,adresse) VALUES
(1810,'271 Résidence La Baie des Oliviers III, 60850 Lalandelle'),
(1811,'488bis Bacha, 22200 Plouisy');

INSERT INTO Organisation (numero,adresse) VALUES
(1812,'963 Chemin du Cayre, 19320 Lafage-sur-Sombre'),
(1813,'113 Calcomier, 19340 Couffy-sur-Sarsonne');

INSERT INTO Organisation (numero,adresse) VALUES
(1814,'12 Le Tonneau, 13009 Marseille 09'),
(1815,'884 Gazéou, 07600 Saint-Andéol-de-Vals');

INSERT INTO Organisation (numero,adresse) VALUES
(1816,'559 Au Cimetière, 35730 Pleurtuit'),
(1817,'601bis Linder, 48400 Les Bondons');

INSERT INTO Organisation (numero,adresse) VALUES
(1818,'476 La Molle, 58800 Germenay'),
(1819,'561bis Deveze, 39120 Balaiseaux');

INSERT INTO Organisation (numero,adresse) VALUES
(1820,'664bis Rivière Basse, 59620 Saint-Remy-Chaussée'),
(1821,'764 Les_pinees_de_saint_clement, 01170 Crozet');

INSERT INTO Organisation (numero,adresse) VALUES
(1822,'67 Les Ramelets, 45400 Semoy'),
(1823,'885bis Bartassol, 58200 Pougny');

INSERT INTO Organisation (numero,adresse) VALUES
(1824,'467 La Puech de la Penterie, 17350 Taillant'),
(1825,'970 Bois Redon, 69480 Morancé');

INSERT INTO Organisation (numero,adresse) VALUES
(1826,'919bis Allée Léon Roux, 06550 La Roquette-sur-Siagne'),
(1827,'837 Résidence les Goelands, 70000 Vallerois-Lorioz');

INSERT INTO Organisation (numero,adresse) VALUES
(1828,'740bis Les Constants, 68740 Rumersheim-le-Haut'),
(1829,'125 Domaine de Nuja, 67150 Daubensand');

INSERT INTO Organisation (numero,adresse) VALUES
(1830,'140 Hautes Combes, 14930 Vieux'),
(1831,'725 Vierisnarde, 07530 Lachamp-Raphaël');

INSERT INTO Organisation (numero,adresse) VALUES
(1832,'90 Les Anglats, 59680 Cerfontaine'),
(1833,'251 Chemin de Halage, 14240 Torteval-Quesnay');

INSERT INTO Organisation (numero,adresse) VALUES
(1834,'223 Résidence Ulysse, 21200 Combertault'),
(1835,'899 Esplanade  Dei Bladeiras, 40240 Vielle-Soubiran');

INSERT INTO Organisation (numero,adresse) VALUES
(1836,'129 Le Pré Toulon, 70190 Rioz'),
(1837,'570 Peyralbe, 58300 Saint-Léger-des-Vignes');

INSERT INTO Organisation (numero,adresse) VALUES
(1838,'598 Quarante, 31260 Saleich'),
(1839,'459 lieu-dit Rioupetit, 39190 Beaufort');

INSERT INTO Organisation (numero,adresse) VALUES
(1840,'725 École Saint Lazare, 58800 Sardy-lès-Épiry'),
(1841,'141 Square Alphonse Daudet, 11300 Pomy');

INSERT INTO Organisation (numero,adresse) VALUES
(1842,'37 En Bourgogne, 39350 Pagney'),
(1843,'739 Les Fonds, 61400 Le Pin-la-Garenne');

INSERT INTO Organisation (numero,adresse) VALUES
(1844,'252bis Rond-Point Messugues, 72400 Cherreau'),
(1845,'347 Praneuf, 80300 Hénencourt');

INSERT INTO Organisation (numero,adresse) VALUES
(1846,'138 Carrefour de la Legion D''Honneur, 32400 Corneillan'),
(1847,'16 Baisse de Rougier, 42190 Saint-Pierre-la-Noaille');

INSERT INTO Organisation (numero,adresse) VALUES
(1848,'459 Chateau D''Origny, 60420 Tricot'),
(1849,'672 L''Oliu, 71740 Tancon');

INSERT INTO Organisation (numero,adresse) VALUES
(1850,'801 Bâtiment Le cyclamen, 80370 Bernâtre'),
(1851,'758 Res Les Salines A, 41800 Fontaine-les-Coteaux');

INSERT INTO Organisation (numero,adresse) VALUES
(1852,'327 Le Pouzol, 80540 Guignemicourt'),
(1853,'345bis La Cazotie, 49350 Gennes-Val-de-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(1854,'175 Parc Paysager du Dauphiné, 31700 Cornebarrieu'),
(1855,'267 Escalier au n°548 Promenade du Lac du Boréon, 20225 Feliceto');

INSERT INTO Organisation (numero,adresse) VALUES
(1856,'405 Les Cent Jalois, 27170 Bray'),
(1857,'587 Camp Ras, 80300 Irles');

INSERT INTO Organisation (numero,adresse) VALUES
(1858,'442 Brugeassou, 72230 Arnage'),
(1859,'996 Lotissement les Coteaux de Venelles II, 79400 Saint-Maixent-l''École');

INSERT INTO Organisation (numero,adresse) VALUES
(1860,'594bis Pirochon, 10800 Cormost'),
(1861,'859bis Auron, 52370 Rennepont');

INSERT INTO Organisation (numero,adresse) VALUES
(1862,'686 Ferme-de-bauval, 32330 Mouchan'),
(1863,'421 ruelle Mélin, 07230 Saint-André-Lachamp');

INSERT INTO Organisation (numero,adresse) VALUES
(1864,'163 """ Le Pinson """, 68700 Aspach-le-Bas'),
(1865,'271 Bouque de Biau Ouest, 29190 Gouézec');

INSERT INTO Organisation (numero,adresse) VALUES
(1866,'449 Rue du Général Keller, 18130 Contres'),
(1867,'132 Derriere la Reserve, 68600 Weckolsheim');

INSERT INTO Organisation (numero,adresse) VALUES
(1868,'84 Les Alels, 10100 Ossey-les-Trois-Maisons'),
(1869,'595 Bousieyas, 62810 Warluzel');

INSERT INTO Organisation (numero,adresse) VALUES
(1870,'903 En Aille, 31860 Labarthe-sur-Lèze'),
(1871,'629 Fontcoussergues, 73220 Montsapey');

INSERT INTO Organisation (numero,adresse) VALUES
(1872,'892bis Le Ventaillou, 57220 Niedervisse'),
(1873,'979 La Chapelle, 24210 La Bachellerie');

INSERT INTO Organisation (numero,adresse) VALUES
(1874,'333bis Grillères, 63880 Olliergues'),
(1875,'255 Foret du Lagast, 16170 Montigné');

INSERT INTO Organisation (numero,adresse) VALUES
(1876,'550 Fontaine Noire, 60490 La Neuville-sur-Ressons'),
(1877,'894 Le Village, 08290 La Férée');

INSERT INTO Organisation (numero,adresse) VALUES
(1878,'81 Les Bas Astiers, 20229 Valle-d''Orezza'),
(1879,'685 Adelisa, 01300 Brens');

INSERT INTO Organisation (numero,adresse) VALUES
(1880,'9 Croix de Magrin, 78120 Clairefontaine-en-Yvelines'),
(1881,'376 Celleron, 43300 Saint-Julien-des-Chazes');

INSERT INTO Organisation (numero,adresse) VALUES
(1882,'95 Le Tut, 43100 Saint-Laurent-Chabreuges'),
(1883,'92 Escalier reliant les n°33 et 57 du Boulevard de Las Planas, 33350 Civrac-sur-Dordogne');

INSERT INTO Organisation (numero,adresse) VALUES
(1884,'72 Goutayrenc, 57412 Schmittviller'),
(1885,'974 Champ Buisson, 80132 Port-le-Grand');

INSERT INTO Organisation (numero,adresse) VALUES
(1886,'268 Collomb, 57830 Foulcrey'),
(1887,'250bis Place des Héros, 02210 Saint-Rémy-Blanzy');

INSERT INTO Organisation (numero,adresse) VALUES
(1888,'721 Les Decharty, 71120 Baron'),
(1889,'766bis Rue du Chemin Vert, 20230 Taglio-Isolaccio');

INSERT INTO Organisation (numero,adresse) VALUES
(1890,'526 Voie d''Evitement de Bram, 07610 Vion'),
(1891,'548 Les Ourtals, 33760 Escoussans');

INSERT INTO Organisation (numero,adresse) VALUES
(1892,'985 En Souille, 42660 Planfoy'),
(1893,'763 Le Bernet, 27700 Bouafles');

INSERT INTO Organisation (numero,adresse) VALUES
(1894,'1 Toutes Aoures, 38250 Villard-de-Lans'),
(1895,'934bis Ancienne D117, 02470 Monnes');

INSERT INTO Organisation (numero,adresse) VALUES
(1896,'493bis Villa Hacienda, 37420 Savigny-en-Véron'),
(1897,'396 Rue des Régiments Niçois, 76540 Thérouldeville');

INSERT INTO Organisation (numero,adresse) VALUES
(1898,'979 Le Petit Paradis, 11700 Comigne'),
(1899,'398 Le Guide, 39400 Morbier');

INSERT INTO Organisation (numero,adresse) VALUES
(1900,'881 La Vergne, 60120 Fléchy'),
(1901,'525 Le Château de Nesles, 30500 Saint-Ambroix');

INSERT INTO Organisation (numero,adresse) VALUES
(1902,'376 Laure, 10220 Piney'),
(1903,'449 Petit Charrière, 44360 Le Temple-de-Bretagne');

INSERT INTO Organisation (numero,adresse) VALUES
(1904,'812 Le Mont Grisot, 51260 Courcemain'),
(1905,'850 Route de Carcassonne, 54610 Rouves');

INSERT INTO Organisation (numero,adresse) VALUES
(1906,'758 Route Métropolitaine 26, 18310 Nohant-en-Graçay'),
(1907,'827 La Croix des Bois, 25300 Pontarlier');

INSERT INTO Organisation (numero,adresse) VALUES
(1908,'146 Fond du Village, 58800 Chitry-les-Mines'),
(1909,'930bis Le Yasmina B, 61210 Ri');

INSERT INTO Organisation (numero,adresse) VALUES
(1910,'976 Villa Maire, 14210 Trois-Monts'),
(1911,'682 Moulins de la Garde, 31290 Villefranche-de-Lauragais');

INSERT INTO Organisation (numero,adresse) VALUES
(1912,'191 Bâtiment A6, 15130 Ytrac'),
(1913,'890 Le Coteau des Fourches, 57130 Jussy');

INSERT INTO Organisation (numero,adresse) VALUES
(1914,'494 Hameau Bieugne, 61200 Urou-et-Crennes'),
(1915,'891bis Petit Gottex, 76190 Autretot');

INSERT INTO Organisation (numero,adresse) VALUES
(1916,'417 Nuces, 61110 Saint-Germain-des-Grois'),
(1917,'597bis Chemin du Puech Del Tronc, 47180 Lagupie');

INSERT INTO Organisation (numero,adresse) VALUES
(1918,'946 L''Échappée Mer, 77720 Aubepierre-Ozouer-le-Repos'),
(1919,'162 Le Baquié, 70130 Fresne-Saint-Mamès');

INSERT INTO Organisation (numero,adresse) VALUES
(1920,'933 Residence St Maurice Bat E, 73170 Meyrieux-Trouet'),
(1921,'681 Le Putet Nord, 64270 Labastide-Villefranche');

INSERT INTO Organisation (numero,adresse) VALUES
(1922,'307 La Foulerie de Daigny, 09800 Illartein'),
(1923,'589bis Chemin de la Costa Thérèse, 72360 Sarcé');

INSERT INTO Organisation (numero,adresse) VALUES
(1924,'897 Les Comtamines, 03400 Toulon-sur-Allier'),
(1925,'244 Les Costes, 21500 Courcelles-lès-Montbard');

INSERT INTO Organisation (numero,adresse) VALUES
(1926,'454 Le Blanc Savart, 70110 Georfans'),
(1927,'57 Au Dessus des Plantes, 60420 Domfront');

INSERT INTO Organisation (numero,adresse) VALUES
(1928,'832bis Villa Ouf, 41800 Saint-Jacques-des-Guérets'),
(1929,'802 Vernou, 20115 Piana');

INSERT INTO Organisation (numero,adresse) VALUES
(1930,'647 Campourci, 46310 Concorès'),
(1931,'794 La Manhobe, 10500 Maizières-lès-Brienne');

INSERT INTO Organisation (numero,adresse) VALUES
(1932,'271bis Franchironnette, 60840 Catenoy'),
(1933,'0 Sainte Agathe, 59360 Le Cateau-Cambrésis');

INSERT INTO Organisation (numero,adresse) VALUES
(1934,'619 Puech du Roube, 07150 Orgnac-l''Aven'),
(1935,'710bis Rue des Jardins, 03390 Montmarault');

INSERT INTO Organisation (numero,adresse) VALUES
(1936,'237bis Puech de Frontin, 40110 Arjuzanx'),
(1937,'163 Impasse Pablo Neruda, 41120 Valaire');

INSERT INTO Organisation (numero,adresse) VALUES
(1938,'679bis Paresous-Est, 20228 Luri'),
(1939,'17bis Les Pres du Mareau, 69420 Condrieu');

INSERT INTO Organisation (numero,adresse) VALUES
(1940,'254 L''autan, 65320 Séron'),
(1941,'168 Les Bodières, 21250 Villy-le-Moutier');

INSERT INTO Organisation (numero,adresse) VALUES
(1942,'193 Collets de Marroc St Hilaire, 57810 Lagarde'),
(1943,'337 La Badoune, 28700 Francourville');

INSERT INTO Organisation (numero,adresse) VALUES
(1944,'758bis La Grange Du Bois, 27930 Le Boulay-Morin'),
(1945,'156 Chabre, 53410 Port-Brillet');

INSERT INTO Organisation (numero,adresse) VALUES
(1946,'598 La Benoite, 19510 Masseret'),
(1947,'947 Voie Communale la Malaise, 69700 Chassagny');

INSERT INTO Organisation (numero,adresse) VALUES
(1948,'348 Le Potier, 20126 Cristinacce'),
(1949,'388 Place Henri Barbusse, 42380 Merle-Leignec');

INSERT INTO Organisation (numero,adresse) VALUES
(1950,'113 Les Sauces, 60790 Ressons-l''Abbaye'),
(1951,'795bis Granouillac, 45120 Girolles');

INSERT INTO Organisation (numero,adresse) VALUES
(1952,'259 Pont de Selve, 34630 Saint-Thibéry'),
(1953,'278 La Peyruque, 80310 Hangest-sur-Somme');

INSERT INTO Organisation (numero,adresse) VALUES
(1954,'922 Le Minerve, 41210 La Marolle-en-Sologne'),
(1955,'143bis Auffet, 21910 Barges');

INSERT INTO Organisation (numero,adresse) VALUES
(1956,'81 Bois de l''Etang, 62130 Framecourt'),
(1957,'14 Le Panneau, 53500 Saint-Pierre-des-Landes');

INSERT INTO Organisation (numero,adresse) VALUES
(1958,'643 Casa D''Ev, 14490 La Bazoque'),
(1959,'116 Lieu-dit Lacam, 74150 Versonnex');

INSERT INTO Organisation (numero,adresse) VALUES
(1960,'931bis Le Durantin, 02350 Vesles-et-Caumont'),
(1961,'665 Bellissendy, 35130 Arbrissel');

INSERT INTO Organisation (numero,adresse) VALUES
(1962,'355 Chavot, 76710 Eslettes'),
(1963,'342bis Les Clauzels, 45520 Huêtre');

INSERT INTO Organisation (numero,adresse) VALUES
(1964,'238 Cantefau, 16230 Nanclars'),
(1965,'500bis Les Camps de la Viole, 08430 Touligny');

INSERT INTO Organisation (numero,adresse) VALUES
(1966,'534bis Pré de la Marbuire, 63130 Royat'),
(1967,'971 Le Champ de Courses, 24160 Génis');

INSERT INTO Organisation (numero,adresse) VALUES
(1968,'919bis Bâtiment Le thym Entrée 43, 30250 Aubais'),
(1969,'628bis Le Cuzoul, 09460 Quérigut');

INSERT INTO Organisation (numero,adresse) VALUES
(1970,'234bis La Ringade, 31160 Couret'),
(1971,'384 La Raufière, 56120 Les Forges');

INSERT INTO Organisation (numero,adresse) VALUES
(1972,'627 Res Emiliana B, 10400 Courceroy'),
(1973,'246 Résidence Carré Verdé Bâtiment C, 65380 Bénac');

INSERT INTO Organisation (numero,adresse) VALUES
(1974,'331 Le Clot de Peyre, 29700 Plomelin'),
(1975,'673 La_vigne, 58500 Chevroches');

INSERT INTO Organisation (numero,adresse) VALUES
(1976,'695 Résidence Les Portes de la Plage, 40180 Bénesse-lès-Dax'),
(1977,'119 Le Gory, 55160 Moulotte');

INSERT INTO Organisation (numero,adresse) VALUES
(1978,'311bis La Source Saint Jean, 36260 Paudy'),
(1979,'820 Hameau des Oliviers, 77470 Villemareuil');

INSERT INTO Organisation (numero,adresse) VALUES
(1980,'615 Villa Azur A, 11140 Marsa'),
(1981,'525bis Lieu-dit Montfaucon, 11570 Villefloure');

INSERT INTO Organisation (numero,adresse) VALUES
(1982,'369 La Boule d''Or et le Moulin, 43260 Saint-Julien-Chapteuil'),
(1983,'941 Menes, 61560 La Mesnière');

INSERT INTO Organisation (numero,adresse) VALUES
(1984,'986 Fouissagou, 34310 Cruzy'),
(1985,'732 Le Nadir, 08200 La Chapelle');

INSERT INTO Organisation (numero,adresse) VALUES
(1986,'201 Mas de Galtier, 62410 Wingles'),
(1987,'538 Les Juvisses, 17490 Massac');

INSERT INTO Organisation (numero,adresse) VALUES
(1988,'523 Le Plech, 54930 They-sous-Vaudemont'),
(1989,'480 Le Moncelet, 60650 Hodenc-en-Bray');

INSERT INTO Organisation (numero,adresse) VALUES
(1990,'705 Alibert Nord Ouest, 66300 Trouillas'),
(1991,'136 Jeanodrey, 31870 Beaumont-sur-Lèze');

INSERT INTO Organisation (numero,adresse) VALUES
(1992,'776 Chemin de Las Arenas, 05130 Sigoyer'),
(1993,'696bis Negrefeuille, 67130 Belmont');

INSERT INTO Organisation (numero,adresse) VALUES
(1994,'472 Village du Blanchon, 70000 Auxon'),
(1995,'604bis Saint Dalmazy, 41600 Chaon');

INSERT INTO Organisation (numero,adresse) VALUES
(1996,'534 Quarante, 03220 Varennes-sur-Tèche'),
(1997,'201 Les Claux, 62630 Hubersent');

INSERT INTO Organisation (numero,adresse) VALUES
(1998,'723 Riou Laval, 62111 Pommier'),
(1999,'794 Les Morins, 76470 Le Tréport');

INSERT INTO Organisation (numero,adresse) VALUES
(2000,'610 """ Les Veilles Ventes """, 21121 Fontaine-lès-Dijon'),
(2001,'422 La Pio, 60360 Rotangy');

INSERT INTO Organisation (numero,adresse) VALUES
(2002,'22 Mas du Serre, 14220 Boulon'),
(2003,'255 Villa Colombe, 37220 Parçay-sur-Vienne');

INSERT INTO Organisation (numero,adresse) VALUES
(2004,'785 Les Bourdies, 51330 Bettancourt-la-Longue'),
(2005,'645bis Les Fanges, 62750 Loos-en-Gohelle');

INSERT INTO Organisation (numero,adresse) VALUES
(2006,'294 Moundot, 55500 Dagonville'),
(2007,'786bis Traverse  Vincent Marsily, 18110 Vasselay');

INSERT INTO Organisation (numero,adresse) VALUES
(2008,'520bis Tunnel Leon Deloy, 54700 Blénod-lès-Pont-à-Mousson'),
(2009,'956 Lascaut, 01240 Saint-André-le-Bouchoux');

INSERT INTO Organisation (numero,adresse) VALUES
(2010,'0bis Le Troubadour, 74800 Saint-Sixt'),
(2011,'70 Faveyrole et Batail, 80135 Yaucourt-Bussus');

INSERT INTO Organisation (numero,adresse) VALUES
(2012,'204bis La Mitaine, 38700 La Tronche'),
(2013,'182 Autopont Cassin - Mathis (Chaussée sud), 57660 Lelling');

INSERT INTO Organisation (numero,adresse) VALUES
(2014,'82bis La Nogarede, 65100 Julos'),
(2015,'696 Ruelle de la Fontaine Cristelle, 27140 Bazincourt-sur-Epte');

INSERT INTO Organisation (numero,adresse) VALUES
(2016,'329 lieu-dit Le Crabè, 73340 Lescheraines'),
(2017,'218 Le Collet de Matroou, 27290 Appeville-Annebault');

INSERT INTO Organisation (numero,adresse) VALUES
(2018,'49bis La Grande Loge, 37120 Richelieu'),
(2019,'567 Le Touron, 42590 Saint-Paul-de-Vézelin');

INSERT INTO Organisation (numero,adresse) VALUES
(2020,'742 La Roziere, 60240 Hardivillers-en-Vexin'),
(2021,'588 Le Bois de Plomion(est), 67600 Bindernheim');

INSERT INTO Organisation (numero,adresse) VALUES
(2022,'777 Broyon-Nord, 33220 Saint-Avit-Saint-Nazaire'),
(2023,'214bis Les Jardins de Fosset, 69840 Chénas');

INSERT INTO Organisation (numero,adresse) VALUES
(2024,'118 Les Olieux Romanis, 51370 Saint-Brice-Courcelles'),
(2025,'305bis Les calens, 59400 Séranvillers-Forenville');

INSERT INTO Organisation (numero,adresse) VALUES
(2026,'367 Bosquet du Maréchal, 65170 Aragnouet'),
(2027,'674 La Nove, 62860 Écourt-Saint-Quentin');

INSERT INTO Organisation (numero,adresse) VALUES
(2028,'911 Avenue Saint Exupery, 31260 Montsaunès'),
(2029,'511 Lauzic, 01600 Misérieux');

INSERT INTO Organisation (numero,adresse) VALUES
(2030,'320 Brunas, 42260 Grézolles'),
(2031,'969 Chez Demas, 67250 Memmelshoffen');

INSERT INTO Organisation (numero,adresse) VALUES
(2032,'294 Le Minerve, 10400 Soligny-les-Étangs'),
(2033,'721 Petite Combe, 54740 Vaudigny');

INSERT INTO Organisation (numero,adresse) VALUES
(2034,'946 Ginestoux, 08300 Lucquy'),
(2035,'656 Le Noyer, 79230 Brûlain');

INSERT INTO Organisation (numero,adresse) VALUES
(2036,'944 Domaine la Bouriette, 24660 Coulounieix-Chamiers'),
(2037,'773 Ecole de Charlemagne, 30340 Rousson');

INSERT INTO Organisation (numero,adresse) VALUES
(2038,'682bis Traverse des Coquelicots, 11190 Luc-sur-Aude'),
(2039,'700bis Lescalé, 52250 Flagey');

INSERT INTO Organisation (numero,adresse) VALUES
(2040,'450 La Motte des Leups, 65130 Escots'),
(2041,'841bis Le Jonquet, 78180 Montigny-le-Bretonneux');

INSERT INTO Organisation (numero,adresse) VALUES
(2042,'499 Garigol, 19200 Aix'),
(2043,'257 Les Habits, 59400 Doignies');

INSERT INTO Organisation (numero,adresse) VALUES
(2044,'865 Escalier de la Gare de Saint-Isidore, 23430 Saint-Martin-Sainte-Catherine'),
(2045,'73bis Ripasson, 36100 Issoudun');

INSERT INTO Organisation (numero,adresse) VALUES
(2046,'388 La Grange de Dufourne, 14130 Blangy-le-Château'),
(2047,'84 Chemin de Tourné, 79220 Champdeniers-Saint-Denis');

INSERT INTO Organisation (numero,adresse) VALUES
(2048,'42 Les Miniers, 76480 Le Mesnil-sous-Jumièges'),
(2049,'682 Murassos, 78440 Guitrancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2050,'66 Bâtiment Le thym Entrée 43, 02240 Parpeville'),
(2051,'556 Caprifolium, 77370 Maison-Rouge');

INSERT INTO Organisation (numero,adresse) VALUES
(2052,'721 Frugoni, 02000 Monampteuil'),
(2053,'281bis Les Arenes, 20166 Grosseto-Prugna');

INSERT INTO Organisation (numero,adresse) VALUES
(2054,'457 Notre Dame et les Lauves E, 32190 Saint-Jean-Poutge'),
(2055,'140 Les Coteaux de Venelles I, 14220 Le Hom');

INSERT INTO Organisation (numero,adresse) VALUES
(2056,'477bis Chemin de l''Amourie, 56270 Ploemeur'),
(2057,'203 Salle municipale Hubertine Auclert - ERP, 27370 Saint-Pierre-du-Bosguérard');

INSERT INTO Organisation (numero,adresse) VALUES
(2058,'406 Le Touc, 26150 Saint-Andéol'),
(2059,'810bis Lombart, 12300 Boisse-Penchot');

INSERT INTO Organisation (numero,adresse) VALUES
(2060,'353 Mas Vendran Sud, 14400 Maisons'),
(2061,'142bis La Sellerie, 08390 Les Grandes-Armoises');

INSERT INTO Organisation (numero,adresse) VALUES
(2062,'927 Le Pasteur B, 47270 Saint-Maurin'),
(2063,'826 Hameau d’Angrieres, 60000 Fouquenies');

INSERT INTO Organisation (numero,adresse) VALUES
(2064,'724 Puech Baguet, 02300 Sinceny'),
(2065,'469 Blâches-Gombert, 09420 Rimont');

INSERT INTO Organisation (numero,adresse) VALUES
(2066,'608 Le thoron, 59128 Flers-en-Escrebieux'),
(2067,'682bis Les Rousseaux, 02800 Beautor');

INSERT INTO Organisation (numero,adresse) VALUES
(2068,'857 Les Vieux Moines, 17260 Jazennes'),
(2069,'575bis Terre du Marre, 67220 Breitenau');

INSERT INTO Organisation (numero,adresse) VALUES
(2070,'630 Le Moulin de Réallon, 22720 Saint-Péver'),
(2071,'510 Marengo, 59163 Saint-Aybert');

INSERT INTO Organisation (numero,adresse) VALUES
(2072,'6 le Piboul, 02110 Molain'),
(2073,'951 Font de la Vergne, 64220 Ispoure');

INSERT INTO Organisation (numero,adresse) VALUES
(2074,'479 Quai Bir Hakeim, 63440 Marcillat'),
(2075,'941 Domaine du Pont, 71390 Saint-Désert');

INSERT INTO Organisation (numero,adresse) VALUES
(2076,'584 Victorine, 46240 Caniac-du-Causse'),
(2077,'372 Ville Vieille, 55120 Lavoye');

INSERT INTO Organisation (numero,adresse) VALUES
(2078,'655 Gervazy, 02330 Montlevon'),
(2079,'433 La Baraque de Mignonac, 43700 Brives-Charensac');

INSERT INTO Organisation (numero,adresse) VALUES
(2080,'107 Les Begauds d''En Bas, 42350 La Talaudière'),
(2081,'298bis La Femme Morte, 26420 Vassieux-en-Vercors');

INSERT INTO Organisation (numero,adresse) VALUES
(2082,'388 Haut de Neyva, 02880 Chavigny'),
(2083,'298 Val-d’Or, 27180 Bernienville');

INSERT INTO Organisation (numero,adresse) VALUES
(2084,'214 Mandos, 46240 Lunegarde'),
(2085,'735 Pieces Longues, 11160 Lespinassière');

INSERT INTO Organisation (numero,adresse) VALUES
(2086,'114bis Fraget, 26130 Montségur-sur-Lauzon'),
(2087,'707 Allée Casal, 80150 Neuilly-le-Dien');

INSERT INTO Organisation (numero,adresse) VALUES
(2088,'301 Rioufol, 23800 Dun-le-Palestel'),
(2089,'30bis Veyries de Haut, 76116 Saint-Aignan-sur-Ry');

INSERT INTO Organisation (numero,adresse) VALUES
(2090,'959 Les Rougons, 68210 Buethwiller'),
(2091,'106 Impasse du Concierge, 28190 Pontgouin');

INSERT INTO Organisation (numero,adresse) VALUES
(2092,'380 Champ Monclat, 35120 Baguer-Morvan'),
(2093,'270 Pature des Boeufs, 22980 Saint-Michel-de-Plélan');

INSERT INTO Organisation (numero,adresse) VALUES
(2094,'678 Marche Central, 33570 Francs'),
(2095,'923bis Les Grandes Fayettes, 29870 Lannilis');

INSERT INTO Organisation (numero,adresse) VALUES
(2096,'882 Les Craux, 80190 Falvy'),
(2097,'74bis Gardiniere, 31580 Balesta');

INSERT INTO Organisation (numero,adresse) VALUES
(2098,'375 La Bastisse de Menay, 41310 Saint-Amand-Longpré'),
(2099,'356 Auberge des Tureaux, 32160 Tasque');

INSERT INTO Organisation (numero,adresse) VALUES
(2100,'274 Lieu-dit Moulin à Vent, 27700 Le Thuit'),
(2101,'225 Les Jardins Des Colettes, 39300 Pillemoine');

INSERT INTO Organisation (numero,adresse) VALUES
(2102,'740 Mas de Boust, 50800 Champrepus'),
(2103,'10 Lubilhac, 21330 Nesle-et-Massoult');

INSERT INTO Organisation (numero,adresse) VALUES
(2104,'938 La Champignonnière, 24410 Ponteyraud'),
(2105,'999bis Les Gourands Neufs, 62140 Guisy');

INSERT INTO Organisation (numero,adresse) VALUES
(2106,'772 Raylehende, 16480 Sauvignac'),
(2107,'682 Point Eau Incendie n°1006 (Borne d''incendie), 26160 Félines-sur-Rimandoule');

INSERT INTO Organisation (numero,adresse) VALUES
(2108,'647 Combe-Gaillanne, 26190 Saint-Thomas-en-Royans'),
(2109,'489bis Le Patio Renoir C, 51130 Clamanges');

INSERT INTO Organisation (numero,adresse) VALUES
(2110,'483 Sarrat de Dessus, 79600 Maisontiers'),
(2111,'536bis La Bourguère, 58120 Dommartin');

INSERT INTO Organisation (numero,adresse) VALUES
(2112,'814 Bordeblanque, 53250 Couptrain'),
(2113,'12bis Rond point de la Source Romaine, 51290 Giffaumont-Champaubert');

INSERT INTO Organisation (numero,adresse) VALUES
(2114,'383bis Dessus l''Église, 80450 Camon'),
(2115,'121 Rue de la Citadelle, 28330 Béthonvilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(2116,'436 Le Champ Dayant, 26190 Le Chaffal'),
(2117,'125 Domaine de Béragne, 65150 Mazères-de-Neste');

INSERT INTO Organisation (numero,adresse) VALUES
(2118,'652bis Les Gances, 57130 Vaux'),
(2119,'11 Carriero Dou Pounènt, 14680 Fresney-le-Puceux');

INSERT INTO Organisation (numero,adresse) VALUES
(2120,'878 Moulin Bataille, 35430 Saint-Suliac'),
(2121,'266bis La Grande Fargeonnière, 64520 Bidache');

INSERT INTO Organisation (numero,adresse) VALUES
(2122,'160 Hameau de Tercier, 78125 Vieille-Église-en-Yvelines'),
(2123,'355 Place des Anciens combattants en AFN 1952 - 62, 14110 Pontécoulant');

INSERT INTO Organisation (numero,adresse) VALUES
(2124,'208 Le Pré Bertrand Henin, 17240 Sainte-Ramée'),
(2125,'71 Rue de Bouvret, 63460 Montcel');

INSERT INTO Organisation (numero,adresse) VALUES
(2126,'943 Hlm les Chartreux Bat C1, 51150 Aulnay-sur-Marne'),
(2127,'822bis Lou Ventoulet, 42155 Lentigny');

INSERT INTO Organisation (numero,adresse) VALUES
(2128,'289 Rue Grande Rue, 01500 Bettant'),
(2129,'248 Champelovier Sud, 60660 Saint-Vaast-lès-Mello');

INSERT INTO Organisation (numero,adresse) VALUES
(2130,'614 La Grange Chalamel, 80300 Fricourt'),
(2131,'8 Les Sablières, 62890 Nordausques');

INSERT INTO Organisation (numero,adresse) VALUES
(2132,'948bis Escalier Rue du Plateau Carlon/Rue du Counigou, 60120 Chepoix'),
(2133,'900 La Lauzette, 46320 Sonac');

INSERT INTO Organisation (numero,adresse) VALUES
(2134,'147 Percy, 52600 Le Pailly'),
(2135,'991 Font du Rocher, 79170 Périgné');

INSERT INTO Organisation (numero,adresse) VALUES
(2136,'463 Le Tibourin, 51480 Cumières'),
(2137,'391 Les Caumettes, 10700 Champfleury');

INSERT INTO Organisation (numero,adresse) VALUES
(2138,'514 Caroueil, 72300 Souvigné-sur-Sarthe'),
(2139,'271 Saint-Benezeth, 59222 Bousies');

INSERT INTO Organisation (numero,adresse) VALUES
(2140,'504 les Bouteux, 50300 Ponts'),
(2141,'134 Masseau-Est, 44190 Saint-Lumine-de-Clisson');

INSERT INTO Organisation (numero,adresse) VALUES
(2142,'777bis Robinson, 44710 Saint-Léger-les-Vignes'),
(2143,'719 Le Grand Arcieux, 23200 Blessac');

INSERT INTO Organisation (numero,adresse) VALUES
(2144,'610 Hameau de Font Communal, 26230 Chantemerle-lès-Grignan'),
(2145,'767 Mont Rosard, 08400 Voncq');

INSERT INTO Organisation (numero,adresse) VALUES
(2146,'419 Les Bailles, 35133 Lécousse'),
(2147,'49bis L''Hermitage, 64160 Carrère');

INSERT INTO Organisation (numero,adresse) VALUES
(2148,'675 """ Saussière """, 27560 Saint-Georges-du-Mesnil'),
(2149,'397 La Grange Fondue, 49750 Val-du-Layon');

INSERT INTO Organisation (numero,adresse) VALUES
(2150,'904 Grand Braus, 80210 Feuquières-en-Vimeu'),
(2151,'77 Gametis, 34600 Le Pradal');

INSERT INTO Organisation (numero,adresse) VALUES
(2152,'423 Petit Terrus, 15130 Saint-Étienne-de-Carlat'),
(2153,'319bis Le Clapier, 19700 Saint-Clément');

INSERT INTO Organisation (numero,adresse) VALUES
(2154,'610 Impasse Flambert, 16480 Berneuil'),
(2155,'886bis La Roche Feneaux, 27860 Heudicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2156,'589 Mont Percinette, 38850 Villages du Lac de Paladru'),
(2157,'721 Champs de l''Eglise, 76460 Néville');

INSERT INTO Organisation (numero,adresse) VALUES
(2158,'88 Fanchironette Sud-Ouest, 52250 Verseilles-le-Haut'),
(2159,'314 Piece de la Croix, 76270 Callengeville');

INSERT INTO Organisation (numero,adresse) VALUES
(2160,'929 Fargues, 10500 Saint-Christophe-Dodinicourt'),
(2161,'167 Hameau de Baubichon, 37120 Razines');

INSERT INTO Organisation (numero,adresse) VALUES
(2162,'463bis Rue de Lunelle, 59990 Estreux'),
(2163,'429 Plassetta Julien Ottonelli, 80140 Bermesnil');

INSERT INTO Organisation (numero,adresse) VALUES
(2164,'631 Résidence les Jardins de Provence, 31520 Ramonville-Saint-Agne'),
(2165,'544 Le Fond du Bois, 26110 Châteauneuf-de-Bordette');

INSERT INTO Organisation (numero,adresse) VALUES
(2166,'219bis La Fajolle, 69840 Cenves'),
(2167,'781 Ferme des Fontenelles, 59122 Rexpoëde');

INSERT INTO Organisation (numero,adresse) VALUES
(2168,'102bis couleurs du temps - appt 8, 80400 Hombleux'),
(2169,'73 Gourra, 12430 Villefranche-de-Panat');

INSERT INTO Organisation (numero,adresse) VALUES
(2170,'841 La Pierreuse sur le Banel, 39700 Sermange'),
(2171,'38 La Planque-Basse, 69580 Sathonay-Camp');

INSERT INTO Organisation (numero,adresse) VALUES
(2172,'673bis Rte de Saint Marcel, 30760 Salazac'),
(2173,'717bis Cros de Jamillon, 59530 Jolimetz');

INSERT INTO Organisation (numero,adresse) VALUES
(2174,'135 Blajoux, 14800 Canapville'),
(2175,'775 Figier, 80310 Riencourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2176,'14 Impasse des Vignes, 50320 La Lucerne-d''Outremer'),
(2177,'202 Les Villardières, 07000 Pourchères');

INSERT INTO Organisation (numero,adresse) VALUES
(2178,'865bis La Lebratiere, 65360 Bernac-Dessus'),
(2179,'179 Coumo Tiéhouert, 38210 Poliénas');

INSERT INTO Organisation (numero,adresse) VALUES
(2180,'914bis Rue Vantaure, 53410 Saint-Ouën-des-Toits'),
(2181,'726 La-Domerguerie, 55160 Pintheville');

INSERT INTO Organisation (numero,adresse) VALUES
(2182,'4 Gloige, 64230 Siros'),
(2183,'231 La Ribiera, 46140 Luzech');

INSERT INTO Organisation (numero,adresse) VALUES
(2184,'458 La Salze, 40380 Louer'),
(2185,'365 Grande Brande de la Corre, 34320 Montesquieu');

INSERT INTO Organisation (numero,adresse) VALUES
(2186,'446 Dolce Vila, 80260 La Vicogne'),
(2187,'721 Maxtonn, 55500 Chanteraine');

INSERT INTO Organisation (numero,adresse) VALUES
(2188,'43 """ La Varenne """, 24170 Larzac'),
(2189,'164 Les Seulx, 80135 Millencourt-en-Ponthieu');

INSERT INTO Organisation (numero,adresse) VALUES
(2190,'251 La Micheline, 80160 Fleury'),
(2191,'958 Le Taillis de Risemont, 34610 Castanet-le-Haut');

INSERT INTO Organisation (numero,adresse) VALUES
(2192,'786bis Pres des Gouilles, 26390 Tersanne'),
(2193,'8 Le Champ du Roi, 62140 Vacqueriette-Erquières');

INSERT INTO Organisation (numero,adresse) VALUES
(2194,'289 Le Plo de la Besse, 16120 Birac'),
(2195,'715bis L''Aiguillette, 63260 Aigueperse');

INSERT INTO Organisation (numero,adresse) VALUES
(2196,'539bis Bois du Moulin, 27190 La Bonneville-sur-Iton'),
(2197,'102 Lapeyre, 02000 Chambry');

INSERT INTO Organisation (numero,adresse) VALUES
(2198,'323 Le Saint-Germain, 68510 Kappelen'),
(2199,'940 La Symphonie, 14540 Soliers');

INSERT INTO Organisation (numero,adresse) VALUES
(2200,'837 Rieuclas, 42111 Saint-Thurin'),
(2201,'987 Fond de la Rivière, 08250 Sommerance');

INSERT INTO Organisation (numero,adresse) VALUES
(2202,'353 Camping-Cars Park, 34370 Maraussan'),
(2203,'542 Les Travers du Pont, 47210 Saint-Martin-de-Villeréal');

INSERT INTO Organisation (numero,adresse) VALUES
(2204,'139bis Rond point des Eucalyptus, 57905 Sarreinsming'),
(2205,'948 Juncail, 35480 Saint-Malo-de-Phily');

INSERT INTO Organisation (numero,adresse) VALUES
(2206,'926 Le Masoe des Chatards, 34210 Siran'),
(2207,'32 La Rigaudi, 57220 Varize-Vaudoncourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2208,'12 chemin rural dit de Groupillon, 37230 Pernay'),
(2209,'799 La Charmeraie, 63850 Espinchal');

INSERT INTO Organisation (numero,adresse) VALUES
(2210,'87 Chemin Calade de la Carral, 59350 Saint-André-lez-Lille'),
(2211,'301 Le Bois de la Forge, 07270 Empurany');

INSERT INTO Organisation (numero,adresse) VALUES
(2212,'371 La Grande Croix, 19210 Saint-Éloy-les-Tuileries'),
(2213,'288bis Lamargie, 27270 Saint-Quentin-des-Isles');

INSERT INTO Organisation (numero,adresse) VALUES
(2214,'321 Le Lavour, 51430 Bezannes'),
(2215,'34 Garampy, 24520 Cours-de-Pile');

INSERT INTO Organisation (numero,adresse) VALUES
(2216,'966 La Grabe, 34360 Babeau-Bouldoux'),
(2217,'116bis Riou de Bez, 57580 Han-sur-Nied');

INSERT INTO Organisation (numero,adresse) VALUES
(2218,'34 Le Virginia Entree B, 76110 Saint-Maclou-la-Brière'),
(2219,'958 L’Afrique, 71220 Mornay');

INSERT INTO Organisation (numero,adresse) VALUES
(2220,'786 Tuilerie de Malleret, 53120 Levaré'),
(2221,'344bis Lauberio, 17510 Néré');

INSERT INTO Organisation (numero,adresse) VALUES
(2222,'30 Le Puy Clermont, 21540 Aubigny-lès-Sombernon'),
(2223,'84 Les Pincels, 59980 Reumont');

INSERT INTO Organisation (numero,adresse) VALUES
(2224,'612bis Petites Gorges, 52190 Le Montsaugeonnais'),
(2225,'713 De Ruelle Lambercy, 77114 Villiers-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(2226,'459 Fosse Noe, 70170 Villers-sur-Port'),
(2227,'121 Le Fringalon, 74150 Crempigny-Bonneguête');

INSERT INTO Organisation (numero,adresse) VALUES
(2228,'193 Chateau des Gouttes, 47470 Dondas'),
(2229,'748bis Le Puech de Caumels, 77320 La Ferté-Gaucher');

INSERT INTO Organisation (numero,adresse) VALUES
(2230,'829 Le Viala de Sauganne, 09000 Saint-Pierre-de-Rivière'),
(2231,'259 Chemin des Seules, 11250 Preixan');

INSERT INTO Organisation (numero,adresse) VALUES
(2232,'421 Terre des Vavres, 10320 Machy'),
(2233,'542 Clos des Trois Noyers, 21190 Mavilly-Mandelot');

INSERT INTO Organisation (numero,adresse) VALUES
(2234,'418 Lotissement Sur Le Rocher, 21220 Saint-Philibert'),
(2235,'575bis Le Mouli Nau Buzeins, 44320 Chauvé');

INSERT INTO Organisation (numero,adresse) VALUES
(2236,'423 Ciari, 49310 Montilliers'),
(2237,'5bis Bât C les Deux Moulins, 76270 Neufchâtel-en-Bray');

INSERT INTO Organisation (numero,adresse) VALUES
(2238,'286 Le Warcan, 64170 Artix'),
(2239,'282 Bruinicendre, 02490 Pontruet');

INSERT INTO Organisation (numero,adresse) VALUES
(2240,'122 En Poucet, 74500 Féternes'),
(2241,'965 La Rose Jane, 45210 Mérinville');

INSERT INTO Organisation (numero,adresse) VALUES
(2242,'990 La Rape, 52130 Sommancourt'),
(2243,'976bis En Moleton, 35270 Bonnemain');

INSERT INTO Organisation (numero,adresse) VALUES
(2244,'333 Brienne, 09350 Thouars-sur-Arize'),
(2245,'794 La Bastinde, 67850 Offendorf');

INSERT INTO Organisation (numero,adresse) VALUES
(2246,'992 Le Petit Lent, 72300 Pincé'),
(2247,'279 Les Hauts De Breguieres C-D-F, 33740 Arès');

INSERT INTO Organisation (numero,adresse) VALUES
(2248,'699bis Lotissement Michel Bernard, 77560 Villiers-Saint-Georges'),
(2249,'979 Champ Bernard, 24220 Vézac');

INSERT INTO Organisation (numero,adresse) VALUES
(2250,'744 "La Paulette, route de St Laurent", 42370 Les Noës'),
(2251,'619 Caraou, 63800 Cournon-d''Auvergne');

INSERT INTO Organisation (numero,adresse) VALUES
(2252,'338bis Poulentines, 45130 Charsonville'),
(2253,'437 Les Vignières, 65350 Dours');

INSERT INTO Organisation (numero,adresse) VALUES
(2254,'563 Le Pendut, 71130 La Chapelle-au-Mans'),
(2255,'482 Le-grand-courty, 51320 Vatry');

INSERT INTO Organisation (numero,adresse) VALUES
(2256,'927 Rancillac, 02350 Chivres-en-Laonnois'),
(2257,'459 Les Aulnaies Bontemps, 25440 Abbans-Dessus');

INSERT INTO Organisation (numero,adresse) VALUES
(2258,'343 Marmont, 28800 Moriers'),
(2259,'745 Les Quartiers, 16320 Magnac-Lavalette-Villars');

INSERT INTO Organisation (numero,adresse) VALUES
(2260,'575bis Chanilières, 09800 Audressein'),
(2261,'659 Le Gand, 32390 Gavarret-sur-Aulouste');

INSERT INTO Organisation (numero,adresse) VALUES
(2262,'872bis Gourdol, 09400 Miglos'),
(2263,'68bis La Busserie, 30450 Ponteils-et-Brésis');

INSERT INTO Organisation (numero,adresse) VALUES
(2264,'607 vers les Bois, 68220 Ranspach-le-Haut'),
(2265,'451bis Coumerados, 67160 Rott');

INSERT INTO Organisation (numero,adresse) VALUES
(2266,'172 La Tolosane, 37110 Saunay'),
(2267,'465 Le Grand Couzai, 47210 Villeréal');

INSERT INTO Organisation (numero,adresse) VALUES
(2268,'739 Le Caucart, 01110 Thézillieu'),
(2269,'294 La Borie de Cabessieres, 41800 Saint-Jacques-des-Guérets');

INSERT INTO Organisation (numero,adresse) VALUES
(2270,'583 Château de Ristz, 66200 Théza'),
(2271,'853 La Vergne Haute, 69780 Toussieu');

INSERT INTO Organisation (numero,adresse) VALUES
(2272,'562 Esplanade Gilles Morosi, 03170 Doyet'),
(2273,'643bis Le Regain, 46140 Caillac');

INSERT INTO Organisation (numero,adresse) VALUES
(2274,'406 Tabariere, 02210 Brécy'),
(2275,'764 Cimetière de VILETTE, 24340 Mareuil en Périgord');

INSERT INTO Organisation (numero,adresse) VALUES
(2276,'783bis Perbencous-Bas, 27110 Villettes'),
(2277,'654bis Jardin des Fusillés de Saint-Julien du Verdon, 41310 Authon');

INSERT INTO Organisation (numero,adresse) VALUES
(2278,'383 Résidence Les Dauphins, 21430 Blanot'),
(2279,'524 Nightingale, 58290 Maux');

INSERT INTO Organisation (numero,adresse) VALUES
(2280,'641 La Motte Varenne, 14210 Le Locheur'),
(2281,'900 La Burgayrette, 38290 La Verpillière');

INSERT INTO Organisation (numero,adresse) VALUES
(2282,'710 Coutiet d''en haut, 21160 Couchey'),
(2283,'802 Barba Louis, 12300 Saint-Parthem');

INSERT INTO Organisation (numero,adresse) VALUES
(2284,'683bis La Besse, 01190 Chavannes-sur-Reyssouze'),
(2285,'618 Salganset, 12380 Balaguier-sur-Rance');

INSERT INTO Organisation (numero,adresse) VALUES
(2286,'217 Hameau la Petite Feuillée, 35610 Saint-Georges-de-Gréhaigne'),
(2287,'714 Puy de Volf, 65350 Collongues');

INSERT INTO Organisation (numero,adresse) VALUES
(2288,'947 Place Abbé Egide Martelli, 51320 Humbauville'),
(2289,'422 Le Petit Claux, 02860 Pancy-Courtecon');

INSERT INTO Organisation (numero,adresse) VALUES
(2290,'75 Jugnac, 08440 Vivier-au-Court'),
(2291,'146 Couaste Chabot, 26750 Saint-Paul-lès-Romans');

INSERT INTO Organisation (numero,adresse) VALUES
(2292,'438bis Chemin de Cognet, 79240 Largeasse'),
(2293,'11 Rond-Point  Fontaine du commandant Jean Dubouy, 50390 Sainte-Colombe');

INSERT INTO Organisation (numero,adresse) VALUES
(2294,'820bis Vianès, 32390 Roquefort'),
(2295,'158 Cardonnac, 54370 Parroy');

INSERT INTO Organisation (numero,adresse) VALUES
(2296,'377 Pain Blanc Ouest, 60490 Marest-sur-Matz'),
(2297,'120 Lavinol, 15130 Giou-de-Mamou');

INSERT INTO Organisation (numero,adresse) VALUES
(2298,'983 Calquieras, 48700 Saint-Gal'),
(2299,'4 Raissac le neuf, 33141 Saillans');

INSERT INTO Organisation (numero,adresse) VALUES
(2300,'609 Puech de la Prade, 02350 Goudelancourt-lès-Pierrepont'),
(2301,'529bis Esplanade des Victoires, 32190 Vic-Fezensac');

INSERT INTO Organisation (numero,adresse) VALUES
(2302,'185bis Plaine Selve, 01590 Chancia'),
(2303,'769 Route Dite de la Verrerie, 74270 Minzier');

INSERT INTO Organisation (numero,adresse) VALUES
(2304,'851 Rue Hélène Durand, 64780 Ossès'),
(2305,'779 Les Frênes, 08390 Sy');

INSERT INTO Organisation (numero,adresse) VALUES
(2306,'703 Lou Mazet, 40180 Saint-Pandelon'),
(2307,'457 Champ Millet, 32190 Saint-Paul-de-Baïse');

INSERT INTO Organisation (numero,adresse) VALUES
(2308,'707 Le Buisson du Grand Champ, 69380 Lissieu'),
(2309,'811 Tunnel Saluzzo, 45760 Boigny-sur-Bionne');

INSERT INTO Organisation (numero,adresse) VALUES
(2310,'95bis Le Turon - Hauteville Lompnes, 10500 Lesmont'),
(2311,'98 Imbarriere, 71550 Cussy-en-Morvan');

INSERT INTO Organisation (numero,adresse) VALUES
(2312,'544 Jacquart, 79260 La Crèche'),
(2313,'54 Villestang, 41290 Villeneuve-Frouville');

INSERT INTO Organisation (numero,adresse) VALUES
(2314,'533 Le Bouysset, 53340 Val-du-Maine'),
(2315,'529 Les Petits Clous, 57580 Aube');

INSERT INTO Organisation (numero,adresse) VALUES
(2316,'573 La Grande Chaume, 08130 Coulommes-et-Marqueny'),
(2317,'833bis La Charpene, 33560 Sainte-Eulalie');

INSERT INTO Organisation (numero,adresse) VALUES
(2318,'591 La Croix des Ormes, 33185 Le Haillan'),
(2319,'338bis Sabeyroux, 14420 Soumont-Saint-Quentin');

INSERT INTO Organisation (numero,adresse) VALUES
(2320,'424 Le Terne de la Gigotte, 27130 Bâlines'),
(2321,'314bis Chemin de Monie, 39100 Parcey');

INSERT INTO Organisation (numero,adresse) VALUES
(2322,'257bis Puech Rousset, 54640 Bettainvillers'),
(2323,'115 lavanche, 08370 Malandry');

INSERT INTO Organisation (numero,adresse) VALUES
(2324,'534bis Brunhac, 18600 Givardon'),
(2325,'749 Aire de péage Est, 63230 Saint-Ours');

INSERT INTO Organisation (numero,adresse) VALUES
(2326,'273bis Chez Moutte, 39570 Courlaoux'),
(2327,'857 Domaine de Souillard, 59360 Catillon-sur-Sambre');

INSERT INTO Organisation (numero,adresse) VALUES
(2328,'484 Champelovier Sud, 62650 Saint-Michel-sous-Bois'),
(2329,'494 Lieu-dit Lauriol, 40250 Nerbis');

INSERT INTO Organisation (numero,adresse) VALUES
(2330,'218bis Bois de Logis, 10110 Bourguignons'),
(2331,'752 Écluse des Bessays, 66600 Salses-le-Château');

INSERT INTO Organisation (numero,adresse) VALUES
(2332,'247 Les Petites Brosses, 55600 Chauvency-Saint-Hubert'),
(2333,'652 Puech Montard, 68600 Volgelsheim');

INSERT INTO Organisation (numero,adresse) VALUES
(2334,'460 Mas Rolland, 71110 Baugy'),
(2335,'126 Enguiales Haut, 79130 Pougne-Hérisson');

INSERT INTO Organisation (numero,adresse) VALUES
(2336,'972 Le Grand Vaure, 21330 Bissey-la-Pierre'),
(2337,'779 L''Occrochat, 38142 Clavans-en-Haut-Oisans');

INSERT INTO Organisation (numero,adresse) VALUES
(2338,'785bis Les Taillayes, 41270 Bouffry'),
(2339,'151 La Plaine de Presles, 44500 La Baule-Escoublac');

INSERT INTO Organisation (numero,adresse) VALUES
(2340,'856 Lavancia, 62210 Avion'),
(2341,'441 En Bosset, 21000 Dijon');

INSERT INTO Organisation (numero,adresse) VALUES
(2342,'264 Les Têtes, 03170 Saint-Angel'),
(2343,'794 La Providence Vieille, 63500 Saint-Yvoine');

INSERT INTO Organisation (numero,adresse) VALUES
(2344,'159 L''Essentiel Bat A-B, 40180 Candresse'),
(2345,'385 La Nicoulerie, 56480 Cléguérec');

INSERT INTO Organisation (numero,adresse) VALUES
(2346,'582 Voie de Moulin, 18100 Thénioux'),
(2347,'129bis Foyer rural, 17540 Vérines');

INSERT INTO Organisation (numero,adresse) VALUES
(2348,'992bis Longcol, 62156 Vis-en-Artois'),
(2349,'257 Allée des Ferrants, 71460 Malay');

INSERT INTO Organisation (numero,adresse) VALUES
(2350,'591bis L''Hermet-sud, 25560 Boujailles'),
(2351,'684 Les Ecalits, 31260 Montespan');

INSERT INTO Organisation (numero,adresse) VALUES
(2352,'878 Res Aqua Marine, 18320 Torteron'),
(2353,'775 Les Carterons Bas, 66500 Urbanya');

INSERT INTO Organisation (numero,adresse) VALUES
(2354,'24bis Plage du Centre Nautique, 41270 Ruan-sur-Egvonne'),
(2355,'214 Résidence Les Noisetiers, 24480 Alles-sur-Dordogne');

INSERT INTO Organisation (numero,adresse) VALUES
(2356,'616 Bois Royal de Redoun, 63500 Varennes-sur-Usson'),
(2357,'583 Chemin de la Garde supérieur, 24350 Bussac');

INSERT INTO Organisation (numero,adresse) VALUES
(2358,'366 La Croix Goth, 70360 Chassey-lès-Scey'),
(2359,'957bis Ruquet, 30200 Saint-Gervais');

INSERT INTO Organisation (numero,adresse) VALUES
(2360,'681bis La Pujolle, 80134 Hangest-en-Santerre'),
(2361,'518 Granouleou, 05700 Trescléoux');

INSERT INTO Organisation (numero,adresse) VALUES
(2362,'247 Les Bruyères de Chavy, 51220 Berméricourt'),
(2363,'269 Montée de la Frairie, 52700 Darmannes');

INSERT INTO Organisation (numero,adresse) VALUES
(2364,'943 Saunhac, 71440 Thurey'),
(2365,'305bis Le Bourguet, 16480 Berneuil');

INSERT INTO Organisation (numero,adresse) VALUES
(2366,'776bis Impasse du Château d''eau, 76590 Longueville-sur-Scie'),
(2367,'948 Les Grands Jardins, 63800 Saint-Georges-sur-Allier');

INSERT INTO Organisation (numero,adresse) VALUES
(2368,'679 Chemin du Cruit, 28500 La Chapelle-Forainvilliers'),
(2369,'589 La Pomme, 71110 Chambilly');

INSERT INTO Organisation (numero,adresse) VALUES
(2370,'252 La_grenadiere, 50500 Auvers'),
(2371,'871 Hameau du Guillet, 38230 Chavanoz');

INSERT INTO Organisation (numero,adresse) VALUES
(2372,'214 Couffet, 02350 Missy-lès-Pierrepont'),
(2373,'487bis Coste de Paou, 67230 Kogenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(2374,'259 Champ Layssard, 47210 Saint-Martin-de-Villeréal'),
(2375,'938bis Vernas Ouest, 11700 Saint-Couat-d''Aude');

INSERT INTO Organisation (numero,adresse) VALUES
(2376,'240 Le Grand Hubac, 57130 Ars-sur-Moselle'),
(2377,'837 Felicity Bat C, 20217 Olcani');

INSERT INTO Organisation (numero,adresse) VALUES
(2378,'759 Escalier Boulevard Bischoffsheim-Avenue du Caroubier, 39230 Recanoz'),
(2379,'163 Le Moulin du Liort, 37160 Marcé-sur-Esves');

INSERT INTO Organisation (numero,adresse) VALUES
(2380,'692bis Communal de Puot, 05260 Champoléon'),
(2381,'66 Le Pleich, 70110 Fallon');

INSERT INTO Organisation (numero,adresse) VALUES
(2382,'583 Bac d''Al Devez, 55150 Peuvillers'),
(2383,'774 Trabiet de Dejous, 20239 Murato');

INSERT INTO Organisation (numero,adresse) VALUES
(2384,'525 Noussols, 24460 Eyvirat'),
(2385,'285bis Chapons, 33340 Civrac-en-Médoc');

INSERT INTO Organisation (numero,adresse) VALUES
(2386,'975bis L''Oranger, 16700 Saint-Martin-du-Clocher'),
(2387,'2 Creve Coeur, 54930 Gugney');

INSERT INTO Organisation (numero,adresse) VALUES
(2388,'898bis Regard, 61340 Perche en Nocé'),
(2389,'386 Place Henri Faure, 27260 Fresne-Cauverville');

INSERT INTO Organisation (numero,adresse) VALUES
(2390,'237bis Roc de BELVIS, 10330 Joncreuil'),
(2391,'17 La Borie de Gras, 28170 Tremblay-les-Villages');

INSERT INTO Organisation (numero,adresse) VALUES
(2392,'950bis Rue des Pavés, 32700 Pergain-Taillac'),
(2393,'366 Lieu-dit Toussine, 15140 Besse');

INSERT INTO Organisation (numero,adresse) VALUES
(2394,'205 Lieu-dit le Grand Balzac, 45420 Batilly-en-Puisaye'),
(2395,'883bis Abbaye Saint-Félix des Salenques, 44130 Fay-de-Bretagne');

INSERT INTO Organisation (numero,adresse) VALUES
(2396,'911bis Vallée de St Martin, 62179 Audinghen'),
(2397,'198 La Palisse, 53480 Saint-Léger');

INSERT INTO Organisation (numero,adresse) VALUES
(2398,'501 Aux Rebutins, 59740 Clairfayts'),
(2399,'331 Valléra de l''Avocat, 12130 Saint-Martin-de-Lenne');

INSERT INTO Organisation (numero,adresse) VALUES
(2400,'954bis Falgous-Haut, 13111 Coudoux'),
(2401,'384 Le Mas d’Hurtes, 55800 Noyers-Auzécourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2402,'241 Passage des Oudaias, 21700 Nuits-Saint-Georges'),
(2403,'175bis Eychenat, 76480 Saint-Pierre-de-Varengeville');

INSERT INTO Organisation (numero,adresse) VALUES
(2404,'300 Grange Chaland, 57790 Aspach'),
(2405,'127 Fauchier, 54300 Vitrimont');

INSERT INTO Organisation (numero,adresse) VALUES
(2406,'214bis Col de Py, 12600 Lacroix-Barrez'),
(2407,'555 Chemin de San Peire, 58000 Challuy');

INSERT INTO Organisation (numero,adresse) VALUES
(2408,'770 Rotière, 47210 Mazières-Naresse'),
(2409,'818 Bocar d’Orle, 35620 Ercé-en-Lamée');

INSERT INTO Organisation (numero,adresse) VALUES
(2410,'898 Pature de Larang et Bulard, 77370 Châteaubleau'),
(2411,'421 Les Cotes de Bretous, 17460 Préguillac');

INSERT INTO Organisation (numero,adresse) VALUES
(2412,'425bis Le Bois-Clairet, 80320 Omiécourt'),
(2413,'972 Le Musigny, 51350 Cormontreuil');

INSERT INTO Organisation (numero,adresse) VALUES
(2414,'169 Les Dachez, 77600 Chanteloup-en-Brie'),
(2415,'938 Propriete Tafani, 40310 Gabarret');

INSERT INTO Organisation (numero,adresse) VALUES
(2416,'117 Les Douzes, 48000 Lanuéjols'),
(2417,'252bis Centre Aquatique, 37150 Luzillé');

INSERT INTO Organisation (numero,adresse) VALUES
(2418,'16 Le Pasquet, 19340 Merlines'),
(2419,'38 Balsière, 76690 Le Bocasse');

INSERT INTO Organisation (numero,adresse) VALUES
(2420,'901bis Route Métropolitaine 473, 09210 Saint-Ybars'),
(2421,'406bis Le Truquet, 16490 Alloue');

INSERT INTO Organisation (numero,adresse) VALUES
(2422,'485 Les Fagoux, 58140 Lormes'),
(2423,'599 le Village, 34190 Ganges');

INSERT INTO Organisation (numero,adresse) VALUES
(2424,'44 Pailles Rousses, 80540 Saint-Aubin-Montenoy'),
(2425,'216bis """ Le Désert """, 04150 La Rochegiron');

INSERT INTO Organisation (numero,adresse) VALUES
(2426,'692bis Le Moulin du Saule, 37380 Nouzilly'),
(2427,'386 Le Clos Beaujean, 26230 Valaurie');

INSERT INTO Organisation (numero,adresse) VALUES
(2428,'905 Cantaussel, 24360 Varaignes'),
(2429,'277bis Les Collanges, 38114 Villard-Reculas');

INSERT INTO Organisation (numero,adresse) VALUES
(2430,'539bis Jolibert, 59380 Crochte'),
(2431,'299bis Res Les Cristaux, 62164 Audresselles');

INSERT INTO Organisation (numero,adresse) VALUES
(2432,'551 Le Pre Long, 55170 Ancerville'),
(2433,'875bis Le Moulinal, 02470 Dammard');

INSERT INTO Organisation (numero,adresse) VALUES
(2434,'350 Casa Maria Antoinette, 01560 Mantenay-Montlin'),
(2435,'392 Aire de loisirs, 62130 Hernicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2436,'100 Rame, 60680 Jonquières'),
(2437,'304 Plage du Centre Nautique, 70200 Lure');

INSERT INTO Organisation (numero,adresse) VALUES
(2438,'730 Route de la Souleille, 28120 Cernay'),
(2439,'742bis Riou de Mayres, 21160 Marsannay-la-Côte');

INSERT INTO Organisation (numero,adresse) VALUES
(2440,'733 Hameau de Giffécourt, 13680 Lançon-Provence'),
(2441,'272bis la Boule, 49370 Erdre-en-Anjou');

INSERT INTO Organisation (numero,adresse) VALUES
(2442,'133 Place des Combattants, 16390 Pillac'),
(2443,'233bis Perrier Rond, 19000 Tulle');

INSERT INTO Organisation (numero,adresse) VALUES
(2444,'175 Pirié, 51240 La Chaussée-sur-Marne'),
(2445,'383 La Conquete, 28410 Broué');

INSERT INTO Organisation (numero,adresse) VALUES
(2446,'483bis L''Alize, 62250 Leubringhen'),
(2447,'735 Kim Plai, 74200 Margencel');

INSERT INTO Organisation (numero,adresse) VALUES
(2448,'407bis Villa De Cocagne, 03360 Braize'),
(2449,'852bis Serre de Guignon, 20229 Valle-d''Orezza');

INSERT INTO Organisation (numero,adresse) VALUES
(2450,'978 École Élémentaire du Logis, 09310 Vèbre'),
(2451,'652 Res Le Castelet, 77440 Isles-les-Meldeuses');

INSERT INTO Organisation (numero,adresse) VALUES
(2452,'377 Hameau de Chantigneux, 68490 Bantzenheim'),
(2453,'284 Combe Monteil, 11390 Caudebronde');

INSERT INTO Organisation (numero,adresse) VALUES
(2454,'478bis Sergueille, 11500 Belvianes-et-Cavirac'),
(2455,'262bis Rue des Ecoles, 30350 Savignargues');

INSERT INTO Organisation (numero,adresse) VALUES
(2456,'948bis La Rouvière Plane, 67260 Rimsdorf'),
(2457,'10bis Le Haut de la Vacherie, 80270 Allery');

INSERT INTO Organisation (numero,adresse) VALUES
(2458,'844 La Carronnière Est, 68130 Wahlbach'),
(2459,'570bis Les Melays, 61100 Landisacq');

INSERT INTO Organisation (numero,adresse) VALUES
(2460,'675 Les Grands Bernaux, 37800 Noyant-de-Touraine'),
(2461,'948 La Traverse, 74300 Magland');

INSERT INTO Organisation (numero,adresse) VALUES
(2462,'722bis Lotissement le Clos du Castel LOT 5, 37270 Saint-Martin-le-Beau'),
(2463,'180 Montéfanty, 37520 La Riche');

INSERT INTO Organisation (numero,adresse) VALUES
(2464,'220 Hameau de Cambié, 70500 Venisey'),
(2465,'472 Les Violets, 25110 Montivernage');

INSERT INTO Organisation (numero,adresse) VALUES
(2466,'716 Majorac, 33420 Camiac-et-Saint-Denis'),
(2467,'82 Rue de Sauvy, 56230 Le Cours');

INSERT INTO Organisation (numero,adresse) VALUES
(2468,'365bis Lou Pantai, 18320 Torteron'),
(2469,'426 La Tieule, 67270 Kienheim');

INSERT INTO Organisation (numero,adresse) VALUES
(2470,'175 Le Dos de l''Elephant, 55000 Robert-Espagne'),
(2471,'289 Domaine de Saint Victor, 44119 Treillières');

INSERT INTO Organisation (numero,adresse) VALUES
(2472,'649bis Les Verchères, 39120 Chaussin'),
(2473,'374 Ecole élémentaire Jules Verne, 70700 Vaux-le-Moncelot');

INSERT INTO Organisation (numero,adresse) VALUES
(2474,'601 Le Clausach d''Araux, 55100 Brabant-sur-Meuse'),
(2475,'389 Imp. des Noisetiers, 22300 Caouënnec-Lanvézéac');

INSERT INTO Organisation (numero,adresse) VALUES
(2476,'462bis Maugarat, 68230 Niedermorschwihr'),
(2477,'475bis Parking cimetière, 31210 Clarac');

INSERT INTO Organisation (numero,adresse) VALUES
(2478,'127 Le Camas d''Amont, 49260 Antoigné'),
(2479,'724bis Flaugiere, 26110 Sainte-Jalle');

INSERT INTO Organisation (numero,adresse) VALUES
(2480,'145bis Sintineddi, 62840 Neuve-Chapelle'),
(2481,'798 Allée des Orchidées, 80500 Villers-Tournelle');

INSERT INTO Organisation (numero,adresse) VALUES
(2482,'764 La Route, 31110 Cathervielle'),
(2483,'867 Le Saloum, 37530 Montreuil-en-Touraine');

INSERT INTO Organisation (numero,adresse) VALUES
(2484,'542 La Parfonde, 02400 Belleau'),
(2485,'962 Les Homenels, 34650 Lunas');

INSERT INTO Organisation (numero,adresse) VALUES
(2486,'351 La Fort Terre, 76490 Anquetierville'),
(2487,'566 Escalier Avenue du Caroubier-Chemin du Cal du Mt Gros, 76150 La Vaupalière');

INSERT INTO Organisation (numero,adresse) VALUES
(2488,'180 Rue de la Carayrade, 72300 Juigné-sur-Sarthe'),
(2489,'925 Chemin de Gratte lapin, 23000 Savennes');

INSERT INTO Organisation (numero,adresse) VALUES
(2490,'29 Le Vergnol, 22480 Magoar'),
(2491,'531 lieu-dit Gouazè, 51170 Lagery');

INSERT INTO Organisation (numero,adresse) VALUES
(2492,'975bis Lieu-dit Peyrenaud, 25660 Montfaucon'),
(2493,'157bis Le Riouffrey, 27220 L''Habit');

INSERT INTO Organisation (numero,adresse) VALUES
(2494,'186 Le Bez, 36110 Baudres'),
(2495,'534 Bagnères, 77165 Cuisy');

INSERT INTO Organisation (numero,adresse) VALUES
(2496,'715 Les Terres Blanches, 68730 Michelbach-le-Bas'),
(2497,'350bis Lou Clot, 57170 Château-Salins');

INSERT INTO Organisation (numero,adresse) VALUES
(2498,'707 Pont Bencet, 73630 Le Châtelard'),
(2499,'37bis Villa Solange, 34620 Puisserguier');

INSERT INTO Organisation (numero,adresse) VALUES
(2500,'78bis Chemin Rural du Russol, 09300 Roquefixade'),
(2501,'204 Moulin Maillet, 63200 Gimeaux');

INSERT INTO Organisation (numero,adresse) VALUES
(2502,'454 Parking du Vieux Pont, 51220 Villers-Franqueux'),
(2503,'989bis Au Chemin de Curade, 27370 Le Bec-Thomas');

INSERT INTO Organisation (numero,adresse) VALUES
(2504,'502 Guibertie, 46090 Francoulès'),
(2505,'70 Bacou, 55500 Cousances-lès-Triconville');

INSERT INTO Organisation (numero,adresse) VALUES
(2506,'903 Village du Verger, 70100 Rigny'),
(2507,'451 La Tramontane, 09100 Unzent');

INSERT INTO Organisation (numero,adresse) VALUES
(2508,'502 Penchenat, 64130 Ainharp'),
(2509,'960 Escalier au n°548 Promenade du Lac du Boréon, 76390 Richemont');

INSERT INTO Organisation (numero,adresse) VALUES
(2510,'3 La Condomine-ouest, 70140 La Grande-Résie'),
(2511,'699 La Pierreuse sur le Banel, 32190 Belmont');

INSERT INTO Organisation (numero,adresse) VALUES
(2512,'84 Campoustral, 62116 Ayette'),
(2513,'496 le hangar, 04270 Beynes');

INSERT INTO Organisation (numero,adresse) VALUES
(2514,'744 Lieu dit ''Les Garousses'', 43430 Chaudeyrolles'),
(2515,'10 Bourgogne Haut, 16140 Les Gours');

INSERT INTO Organisation (numero,adresse) VALUES
(2516,'685 Le Riage, 55250 Beausite'),
(2517,'385bis Les Longes Raies, 27730 Neuilly');

INSERT INTO Organisation (numero,adresse) VALUES
(2518,'474bis Moulin du Marques, 55200 Euville'),
(2519,'71 Les Pernits, 72230 Ruaudin');

INSERT INTO Organisation (numero,adresse) VALUES
(2520,'725 Les Pervenches, 21150 Bussy-le-Grand'),
(2521,'906 La_roussille, 10160 Aix-Villemaur-Pâlis');

INSERT INTO Organisation (numero,adresse) VALUES
(2522,'615 Daneyrolle, 16430 Champniers'),
(2523,'293bis Avenue Jules Constant, 53110 Lassay-les-Châteaux');

INSERT INTO Organisation (numero,adresse) VALUES
(2524,'19 Chemin Noir, 67350 Ettendorf'),
(2525,'78 Cité de la Neuville, 71260 La Salle');

INSERT INTO Organisation (numero,adresse) VALUES
(2526,'299 Les Vignettes, 17600 Saujon'),
(2527,'921bis Square Albert Blanchi, 04170 Saint-Julien-du-Verdon');

INSERT INTO Organisation (numero,adresse) VALUES
(2528,'19bis Le Bochet Saint Agnan, 51170 Unchair'),
(2529,'220 Prés Marie, 38220 Laffrey');

INSERT INTO Organisation (numero,adresse) VALUES
(2530,'691 Voie de liaison Avenue Chateaubriand Avenue Henry Dunant, 08300 Lucquy'),
(2531,'818 L''Houm, 64290 Estialescq');

INSERT INTO Organisation (numero,adresse) VALUES
(2532,'993 Riviera, 37150 Chisseaux'),
(2533,'816 L''Etang des Boudeaux, 78200 Ménerville');

INSERT INTO Organisation (numero,adresse) VALUES
(2534,'397 Le Bochet Saint Agnan, 57870 Hommert'),
(2535,'938 Ruelle de l''Eglise, 33500 Pomerol');

INSERT INTO Organisation (numero,adresse) VALUES
(2536,'43bis Pierre Chargeat, 31160 Arbas'),
(2537,'303 Maltraüt, 14130 Le Theil-en-Auge');

INSERT INTO Organisation (numero,adresse) VALUES
(2538,'173 Les Gondoux, 31430 Gratens'),
(2539,'745 La Lazerte, 42110 Salt-en-Donzy');

INSERT INTO Organisation (numero,adresse) VALUES
(2540,'815 Lieudit Roubichou, 36400 Lourouer-Saint-Laurent'),
(2541,'14 La Compagnie, 27570 Tillières-sur-Avre');

INSERT INTO Organisation (numero,adresse) VALUES
(2542,'713 Pôle Médical, 19410 Vigeois'),
(2543,'986bis La Nouare, 76280 Pierrefiques');

INSERT INTO Organisation (numero,adresse) VALUES
(2544,'440 Les Alligiers, 80200 Buire-Courcelles'),
(2545,'891bis Peyresalbes, 54830 Franconville');

INSERT INTO Organisation (numero,adresse) VALUES
(2546,'517 Carrols, 07340 Charnas'),
(2547,'875 Le Péage, 71800 Oyé');

INSERT INTO Organisation (numero,adresse) VALUES
(2548,'252bis You And Me, 60190 Montmartin'),
(2549,'729 Résidence Antoine Blondin - Bâtiment A, 10800 Saint-Julien-les-Villas');

INSERT INTO Organisation (numero,adresse) VALUES
(2550,'982 Pujaou, 62250 Bazinghen'),
(2551,'336 La Marquaterie, 02800 Achery');

INSERT INTO Organisation (numero,adresse) VALUES
(2552,'568bis Villa Aliette, 65310 Odos'),
(2553,'359 Chemin de l''Abbaye, 64400 Poey-d''Oloron');

INSERT INTO Organisation (numero,adresse) VALUES
(2554,'970 Hameau la Cense Boulette, 13100 Le Tholonet'),
(2555,'184bis Fourty, 51240 Togny-aux-Bœufs');

INSERT INTO Organisation (numero,adresse) VALUES
(2556,'329bis La Grange de Couston, 08400 Liry'),
(2557,'425bis Rond-Point  Marius Hippolyte Philogène Poutet, 72350 Viré-en-Champagne');

INSERT INTO Organisation (numero,adresse) VALUES
(2558,'197 Le Serre Est, 21460 Corrombles'),
(2559,'365bis Pre Colet, 42370 Saint-André-d''Apchon');

INSERT INTO Organisation (numero,adresse) VALUES
(2560,'115 Impasse du Prieur, 08440 Gernelle'),
(2561,'260 Chaudier, 72220 Saint-Ouen-en-Belin');

INSERT INTO Organisation (numero,adresse) VALUES
(2562,'804 Carriero de l''Uba, 34480 Puissalicon'),
(2563,'983 Carrei Sobran, 49750 Bellevigne-en-Layon');

INSERT INTO Organisation (numero,adresse) VALUES
(2564,'861 Les Cadolles, 21690 Boux-sous-Salmaise'),
(2565,'437bis Le Clos Des Cigognes, 57390 Audun-le-Tiche');

INSERT INTO Organisation (numero,adresse) VALUES
(2566,'141bis impasse des vignes, 37800 Nouâtre'),
(2567,'161bis La Baraque de Cussan, 45450 Ingrannes');

INSERT INTO Organisation (numero,adresse) VALUES
(2568,'26bis Thevenin, 78000 Versailles'),
(2569,'249bis Cardonnac, 53170 Le Buret');

INSERT INTO Organisation (numero,adresse) VALUES
(2570,'781 Le Vignou, 57220 Valmunster'),
(2571,'64 Les Homs, 21310 Beire-le-Châtel');

INSERT INTO Organisation (numero,adresse) VALUES
(2572,'385 Le Moana, 64220 Gamarthe'),
(2573,'813bis Auzies, 63890 Saint-Éloy-la-Glacière');

INSERT INTO Organisation (numero,adresse) VALUES
(2574,'623 Le Blettonnet, 09160 Prat-Bonrepaux'),
(2575,'147 Pumptrack, 60310 Évricourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2576,'733 Le Moulin des Etangs, 43260 Lantriac'),
(2577,'159 Chemin des lilas, 02240 Châtillon-sur-Oise');

INSERT INTO Organisation (numero,adresse) VALUES
(2578,'218 Le Fromental, 48150 Hures-la-Parade'),
(2579,'557 Chemin de la Place, 33240 Saint-Laurent-d''Arce');

INSERT INTO Organisation (numero,adresse) VALUES
(2580,'532 Les Jacinthes, 23320 Saint-Vaury'),
(2581,'171bis Bois de Suzanne, 03430 Vieure');

INSERT INTO Organisation (numero,adresse) VALUES
(2582,'707 Les Crozes Hauts, 64350 Peyrelongue-Abos'),
(2583,'155 La Fosse a Ciry, 09500 Vals');

INSERT INTO Organisation (numero,adresse) VALUES
(2584,'227 Le Bas de Courlanges, 58260 Trois-Vèvres'),
(2585,'997 Chemin de la Vigne jeune, 53220 Pontmain');

INSERT INTO Organisation (numero,adresse) VALUES
(2586,'230bis La corre, 55210 Saint-Maurice-sous-les-Côtes'),
(2587,'996 Résidence Arago, 24400 Saint-Laurent-des-Hommes');

INSERT INTO Organisation (numero,adresse) VALUES
(2588,'655bis Lot Le Grand Chêne, 05800 Saint-Maurice-en-Valgodemard'),
(2589,'836 Montigues, 54700 Norroy-lès-Pont-à-Mousson');

INSERT INTO Organisation (numero,adresse) VALUES
(2590,'480 La Troliere, 08430 Hagnicourt'),
(2591,'730bis Les Acacias, 07320 Rochepaule');

INSERT INTO Organisation (numero,adresse) VALUES
(2592,'293 Lotissement les coulemelles LOT 3, 32160 Préchac-sur-Adour'),
(2593,'876 Carnajac, 25330 Saraz');

INSERT INTO Organisation (numero,adresse) VALUES
(2594,'879 Giffon, 35410 Châteaugiron'),
(2595,'861bis Lou Roucas, 40380 Saint-Jean-de-Lier');

INSERT INTO Organisation (numero,adresse) VALUES
(2596,'666 La Sarrazine, 45230 Montbouy'),
(2597,'11 Bât C les Deux Moulins, 14430 Branville');

INSERT INTO Organisation (numero,adresse) VALUES
(2598,'823 Gerlande, 32450 Saint-Élix-d''Astarac'),
(2599,'984bis Le Mazert, 39210 Le Pin');

INSERT INTO Organisation (numero,adresse) VALUES
(2600,'666 Chemin du Baou des Blancs, 31220 Marignac-Laspeyres'),
(2601,'316 L''Almanza, 28500 Garancières-en-Drouais');

INSERT INTO Organisation (numero,adresse) VALUES
(2602,'93 Champ Cornu, 24310 Bourdeilles'),
(2603,'969 Las Tujagues, 05480 Villar-d''Arêne');

INSERT INTO Organisation (numero,adresse) VALUES
(2604,'964 Les petites Gardes, 71250 La Vineuse sur Fregande'),
(2605,'533 Gennetines, 52100 Villiers-en-Lieu');

INSERT INTO Organisation (numero,adresse) VALUES
(2606,'871 Les Coudenies, 02840 Festieux'),
(2607,'204 Roumenty-Haut, 44140 Remouillé');

INSERT INTO Organisation (numero,adresse) VALUES
(2608,'947 Segures, 27800 Saint-Victor-d''Épine'),
(2609,'244 Les Fontettes, 39570 Courlans');

INSERT INTO Organisation (numero,adresse) VALUES
(2610,'985 Lieu-dit La Roue, 39270 Sarrogna'),
(2611,'79 Le Plan de la Barangere, 35750 Saint-Maugan');

INSERT INTO Organisation (numero,adresse) VALUES
(2612,'509 Terres des Guillots, 25310 Pierrefontaine-lès-Blamont'),
(2613,'653 Babouet Soutran, 33160 Saint-Aubin-de-Médoc');

INSERT INTO Organisation (numero,adresse) VALUES
(2614,'785 Bouviala le Haut, 24590 Borrèze'),
(2615,'623bis Les Lebres, 68770 Ammerschwihr');

INSERT INTO Organisation (numero,adresse) VALUES
(2616,'687 La Coulète, 69730 Genay'),
(2617,'997 Chemin de l''Hippodrome, 65220 Fontrailles');

INSERT INTO Organisation (numero,adresse) VALUES
(2618,'995 Le Clos des Oliviers, 21110 Échigey'),
(2619,'56 Le Terme, 36350 La Pérouille');

INSERT INTO Organisation (numero,adresse) VALUES
(2620,'982 La_gare, 62810 Manin'),
(2621,'793bis Lieu-dit Les Baraques, 29470 Plougastel-Daoulas');

INSERT INTO Organisation (numero,adresse) VALUES
(2622,'284 La Prolle, 23130 Puy-Malsignat'),
(2623,'40 lieu dit les Fontanelles, 45320 Courtenay');

INSERT INTO Organisation (numero,adresse) VALUES
(2624,'999 Chemin du Molard, 39500 Molay'),
(2625,'782 La Croix Montenier, 70160 Senoncourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2626,'586 Le Mas, 54380 Autreville-sur-Moselle'),
(2627,'476 Maison Neuve, 27600 Fontaine-Bellenger');

INSERT INTO Organisation (numero,adresse) VALUES
(2628,'159 La_gare, 26110 Venterol'),
(2629,'713 Lieu-dit La Rochelle, 57600 Œting');

INSERT INTO Organisation (numero,adresse) VALUES
(2630,'41 Néôva, 02360 Mont-Saint-Jean'),
(2631,'200bis Zone Artisanale La Cornella - Hauteville-Lompnes, 79420 Vausseroux');

INSERT INTO Organisation (numero,adresse) VALUES
(2632,'251 Voie les Résidences de la Costière, 50200 Gratot'),
(2633,'216 Lotissement les oronges LOT 6, 50480 Sainte-Mère-Église');

INSERT INTO Organisation (numero,adresse) VALUES
(2634,'710 Les Parayes, 59152 Gruson'),
(2635,'18 Retenue des Vieille Forges, 61500 Chailloué');

INSERT INTO Organisation (numero,adresse) VALUES
(2636,'536 La Borie de Saint-Meen, 60300 Chamant'),
(2637,'118 Villa Titi, 02220 Chéry-Chartreuve');

INSERT INTO Organisation (numero,adresse) VALUES
(2638,'823bis Cabrespines, 49170 Saint-Georges-sur-Loire'),
(2639,'255 Le Cheverny B, 07610 Vion');

INSERT INTO Organisation (numero,adresse) VALUES
(2640,'834 L''Imprevue, 38390 Parmilieu'),
(2641,'90 Puech de l’Hom, 23190 Champagnat');

INSERT INTO Organisation (numero,adresse) VALUES
(2642,'649 Coustal, 29252 Plouezoc''h'),
(2643,'3 Le Village - Rue du Portail des Mourres, 62340 Campagne-lès-Guines');

INSERT INTO Organisation (numero,adresse) VALUES
(2644,'399 Blache de Roche, 65200 Visker'),
(2645,'120 La Soulairie, 34480 Puissalicon');

INSERT INTO Organisation (numero,adresse) VALUES
(2646,'119 Le Port de Loyes, 59550 Robersart'),
(2647,'996 Le sareou, 07210 Chomérac');

INSERT INTO Organisation (numero,adresse) VALUES
(2648,'701 La Pérouse, 30210 Collias'),
(2649,'533bis Caumels, 56230 Molac');

INSERT INTO Organisation (numero,adresse) VALUES
(2650,'400 l''Enclos, 32220 Espaon'),
(2651,'926 Bourg d''Avard, 67420 Saulxures');

INSERT INTO Organisation (numero,adresse) VALUES
(2652,'63 La Coste Saint-geniez-d''Ol, 21500 Arrans'),
(2653,'934 Grand Brens, 25680 Cubrial');

INSERT INTO Organisation (numero,adresse) VALUES
(2654,'209 Embonnes, 23200 Moutier-Rozeille'),
(2655,'856bis Vallée du Cruou, 54480 Bertrambois');

INSERT INTO Organisation (numero,adresse) VALUES
(2656,'755bis Le Montat-Haut, 32420 Meilhan'),
(2657,'153 Bassens, 73800 Francin');

INSERT INTO Organisation (numero,adresse) VALUES
(2658,'758bis Petit Buclat, 47230 Vianne'),
(2659,'924 Le-champ-lasseau, 68140 Eschbach-au-Val');

INSERT INTO Organisation (numero,adresse) VALUES
(2660,'94 Les Vignes du Theil, 50810 Saint-Jean-d''Elle'),
(2661,'721 Route d''Entraygues sur Truyere, 43440 Chassignolles');

INSERT INTO Organisation (numero,adresse) VALUES
(2662,'932 La Chaume à Roses, 71130 La Chapelle-au-Mans'),
(2663,'138 Les Pruniers, 67370 Dingsheim');

INSERT INTO Organisation (numero,adresse) VALUES
(2664,'997 Ferme du Gros Caumont, 51380 Vaudemange'),
(2665,'125 Ferme de Bruyères, 51330 Charmont');

INSERT INTO Organisation (numero,adresse) VALUES
(2666,'305 Sanciat, 39140 Nance'),
(2667,'773 quartier Celestrera, 05500 Buissard');

INSERT INTO Organisation (numero,adresse) VALUES
(2668,'621 Rue du Saint-Esprit, 27540 Ivry-la-Bataille'),
(2669,'512 Fonbonne, 27440 Houville-en-Vexin');

INSERT INTO Organisation (numero,adresse) VALUES
(2670,'81 Cap de la Vède, 16170 Saint-Amant-de-Nouère'),
(2671,'858 Croix rouge, 16130 Gensac-la-Pallue');

INSERT INTO Organisation (numero,adresse) VALUES
(2672,'146 Les Bertrands, 72500 Luceau'),
(2673,'105 Le Lac Noir, 54760 Lanfroicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2674,'113 Bastide De L''Olivier, 57690 Haute-Vigneulles'),
(2675,'656 Chemin de la Fontaine du Prieur, 15300 Lavigerie');

INSERT INTO Organisation (numero,adresse) VALUES
(2676,'491 Le Pas du Ranc, 68950 Reiningue'),
(2677,'980 Le Fond des Boyaux, 32150 Cazaubon');

INSERT INTO Organisation (numero,adresse) VALUES
(2678,'543 Champ Famin, 52700 Chantraines'),
(2679,'370 Rappy, 43210 Valprivas');

INSERT INTO Organisation (numero,adresse) VALUES
(2680,'251 Talespues, 16210 Chalais'),
(2681,'550 Champ de l''Aire, 34440 Colombiers');

INSERT INTO Organisation (numero,adresse) VALUES
(2682,'815bis Chemin Departemental 272 de Bohain à Avesnes, 54800 Affléville'),
(2683,'397 Saint-Victor, 22510 Moncontour');

INSERT INTO Organisation (numero,adresse) VALUES
(2684,'880 Sur Roizet, 39600 Champagne-sur-Loue'),
(2685,'973bis Les Maisons de la Jetée, 62150 Caucourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2686,'159 Les Roquelles, 52310 Viéville'),
(2687,'736 Chavade, 14540 Soliers');

INSERT INTO Organisation (numero,adresse) VALUES
(2688,'312 Font de Luc, 13080 Aix-en-Provence'),
(2689,'164 Montmayoux Haut, 59132 Eppe-Sauvage');

INSERT INTO Organisation (numero,adresse) VALUES
(2690,'531bis La Roche Amère, 58160 Imphy'),
(2691,'229 Blancaria, 65350 Oléac-Debat');

INSERT INTO Organisation (numero,adresse) VALUES
(2692,'222 Cagnes Provencal B, 32400 Sarragachies'),
(2693,'978 Monplaisir, 74350 Villy-le-Pelloux');

INSERT INTO Organisation (numero,adresse) VALUES
(2694,'864 Les Champs Lards, 39120 Tassenières'),
(2695,'588bis Coufétery, 64430 Saint-Étienne-de-Baïgorry');

INSERT INTO Organisation (numero,adresse) VALUES
(2696,'656 La Pichenette, 38730 Blandin'),
(2697,'987 Place Brombachtal, 56170 Île-d''Houat');

INSERT INTO Organisation (numero,adresse) VALUES
(2698,'708 Les Termes, 08400 Mont-Saint-Martin'),
(2699,'792 Arlendas, 62300 Lens');

INSERT INTO Organisation (numero,adresse) VALUES
(2700,'435bis Lartigue Vieille, 59200 Tourcoing'),
(2701,'123 Valléra Da Geija, 62224 Équihen-Plage');

INSERT INTO Organisation (numero,adresse) VALUES
(2702,'547 Le Perie, 32430 Thoux'),
(2703,'39 le Plan du bois, 49330 Étriché');

INSERT INTO Organisation (numero,adresse) VALUES
(2704,'635bis Lotissement les Carillons - Avrissieu le Bas, 59261 Wahagnies'),
(2705,'233 Blermont, 70500 Barges');

INSERT INTO Organisation (numero,adresse) VALUES
(2706,'979 La Petaude, 01150 Blyes'),
(2707,'829 Roudes, 33370 Fargues-Saint-Hilaire');

INSERT INTO Organisation (numero,adresse) VALUES
(2708,'767 Chemin Rural de la Trappe au Loups, 36100 Neuvy-Pailloux'),
(2709,'946 Avenue Gambart, 48140 Paulhac-en-Margeride');

INSERT INTO Organisation (numero,adresse) VALUES
(2710,'192 La Grange Du Bois, 42330 Aveizieux'),
(2711,'305bis Le Castel Des Pins, 76490 Louvetot');

INSERT INTO Organisation (numero,adresse) VALUES
(2712,'322 Impasse des Cigales, 28400 Marolles-les-Buis'),
(2713,'225 Qua Souta Riba, 30190 La Calmette');

INSERT INTO Organisation (numero,adresse) VALUES
(2714,'607 lieu dit la pique rouge, 42670 Belleroche'),
(2715,'29 Castanier Haut, 37110 Villedômer');

INSERT INTO Organisation (numero,adresse) VALUES
(2716,'955 Le Champ Rond, 42140 Chazelles-sur-Lyon'),
(2717,'852 Lotissement LOUVIGNES (OAP), 80240 Sorel');

INSERT INTO Organisation (numero,adresse) VALUES
(2718,'734 La Picharelle, 66320 Marquixanes'),
(2719,'241 Le Gros Chêne, 69290 Grézieu-la-Varenne');

INSERT INTO Organisation (numero,adresse) VALUES
(2720,'653 Parking Françoise Dolto, 60850 Lalandelle'),
(2721,'761bis Monteillas, 39240 Arinthod');

INSERT INTO Organisation (numero,adresse) VALUES
(2722,'41 Impasse privée des Chauvets, 50310 Éroudeville'),
(2723,'488 La Fosse Marie, 01130 Giron');

INSERT INTO Organisation (numero,adresse) VALUES
(2724,'758 Les Planasses, 60800 Duvy'),
(2725,'428bis Libertonne, 16360 Chantillac');

INSERT INTO Organisation (numero,adresse) VALUES
(2726,'438bis Camping Le Fort, 25380 Longevelle-lès-Russey'),
(2727,'879bis L’Etang du Lion, 55000 Resson');

INSERT INTO Organisation (numero,adresse) VALUES
(2728,'979 le Plan du bois, 16730 Trois-Palis'),
(2729,'209 La Grange Chalamel, 02430 Gauchy');

INSERT INTO Organisation (numero,adresse) VALUES
(2730,'289 Cercy, 08220 Renneville'),
(2731,'869 Combalières, 54115 Beuvezin');

INSERT INTO Organisation (numero,adresse) VALUES
(2732,'497 Serre Del Mas, 70190 Buthiers'),
(2733,'663bis Carriero Marcel Richier, 52290 Humbécourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2734,'823bis Cucurlis Nord, 60520 Thiers-sur-Thève'),
(2735,'893 Moulin Bataille, 02120 Crupilly');

INSERT INTO Organisation (numero,adresse) VALUES
(2736,'517bis Aux Essarts, 69280 Sainte-Consorce'),
(2737,'651 Le Moulin Dailly, 22290 Saint-Gilles-les-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(2738,'150 Imp. des Ormes, 66560 Ortaffa'),
(2739,'852 Croix de Recoules, 21230 Foissy');

INSERT INTO Organisation (numero,adresse) VALUES
(2740,'212 Les Pres Neufs, 48110 Le Pompidou'),
(2741,'424bis Lieu-dit Calvet, 18320 Saint-Hilaire-de-Gondilly');

INSERT INTO Organisation (numero,adresse) VALUES
(2742,'666bis Chemin de Briquenay, 71440 Vérissey'),
(2743,'592 Le Pont de Larce, 11600 Aragon');

INSERT INTO Organisation (numero,adresse) VALUES
(2744,'203 La Plaine de Presles, 69870 Poule-les-Écharmeaux'),
(2745,'500bis Serpoulet Bas, 60620 Villers-Saint-Genest');

INSERT INTO Organisation (numero,adresse) VALUES
(2746,'144 Croix Jobert, 42440 Saint-Jean-la-Vêtre'),
(2747,'150 Thumet Devant, 15190 Saint-Bonnet-de-Condat');

INSERT INTO Organisation (numero,adresse) VALUES
(2748,'502 l''Enclos, 27520 Boissey-le-Châtel'),
(2749,'213bis Les Camps, 24220 Castels et Bézenac');

INSERT INTO Organisation (numero,adresse) VALUES
(2750,'302 Saint Nizier, 35140 Mézières-sur-Couesnon'),
(2751,'699bis vialgues, 43170 Venteuges');

INSERT INTO Organisation (numero,adresse) VALUES
(2752,'764 Les Encluzes, 18310 Dampierre-en-Graçay'),
(2753,'118 La Biche, 42380 Luriecq');

INSERT INTO Organisation (numero,adresse) VALUES
(2754,'120bis La Merguie, 59660 Haverskerque'),
(2755,'723 Quartier du Port, 16190 Saint-Eutrope');

INSERT INTO Organisation (numero,adresse) VALUES
(2756,'992 Allée des Tilleuls, 54720 Chenières'),
(2757,'478 Domaine de Sérame, 46120 Saint-Maurice-en-Quercy');

INSERT INTO Organisation (numero,adresse) VALUES
(2758,'556bis Le Bois du Puy, 70200 Les Aynans'),
(2759,'804bis La Limousine, 11190 Peyrolles');

INSERT INTO Organisation (numero,adresse) VALUES
(2760,'720 Flangié, 62580 Vimy'),
(2761,'505 Allée Nolis, 80120 Vron');

INSERT INTO Organisation (numero,adresse) VALUES
(2762,'182 La Molette, 77540 Lumigny-Nesles-Ormeaux'),
(2763,'98 Le Vernet, 33670 Saint-Léon');

INSERT INTO Organisation (numero,adresse) VALUES
(2764,'793 Jacquette, 68580 Hindlingen'),
(2765,'540 Gratta Loup, 12140 Entraygues-sur-Truyère');

INSERT INTO Organisation (numero,adresse) VALUES
(2766,'43 Allée des Lauriers roses, 59560 Comines'),
(2767,'211 Beau Vallon, 26340 Saint-Benoit-en-Diois');

INSERT INTO Organisation (numero,adresse) VALUES
(2768,'312 Bâtiment Gagarine, 32340 Peyrecave'),
(2769,'301 Les Bourdies, 01500 Ambronay');

INSERT INTO Organisation (numero,adresse) VALUES
(2770,'457bis Le Champ Part, 57190 Florange'),
(2771,'748 Cote de Ponsac, 35310 Cintré');

INSERT INTO Organisation (numero,adresse) VALUES
(2772,'578 Saint Jouanès, 21430 Ménessaire'),
(2773,'591 Vieu Four, 51190 Avize');

INSERT INTO Organisation (numero,adresse) VALUES
(2774,'636 Résidence Murat, 26130 Montségur-sur-Lauzon'),
(2775,'793 Les Grands Bois de Montcle, 67240 Oberhoffen-sur-Moder');

INSERT INTO Organisation (numero,adresse) VALUES
(2776,'108 La Petite Pouge, 62630 Étaples'),
(2777,'553 Fontleau, 66210 Planès');

INSERT INTO Organisation (numero,adresse) VALUES
(2778,'562 Lordeil, 14190 Rouvres'),
(2779,'552 Plagueben, 17780 Saint-Nazaire-sur-Charente');

INSERT INTO Organisation (numero,adresse) VALUES
(2780,'43bis Locaterie de Fimorin, 77720 Champeaux'),
(2781,'534 Rogalle, 68290 Masevaux-Niederbruck');

INSERT INTO Organisation (numero,adresse) VALUES
(2782,'999bis Pérails, 73230 Saint-Jean-d''Arvey'),
(2783,'134 Lou Fraysse, 70200 Dambenoît-lès-Colombe');

INSERT INTO Organisation (numero,adresse) VALUES
(2784,'931bis La Brauge, 47220 Fals'),
(2785,'181 Carmensac Ouest, 06360 Èze');

INSERT INTO Organisation (numero,adresse) VALUES
(2786,'440 Cabane Jas La Croix, 54210 Lupcourt'),
(2787,'495 Mas St Bernard, 08270 Puiseux');

INSERT INTO Organisation (numero,adresse) VALUES
(2788,'371 Place des Écoliers, 10320 Longeville-sur-Mogne'),
(2789,'842bis Moulin de Bernard, 24130 Fraisse');

INSERT INTO Organisation (numero,adresse) VALUES
(2790,'819 Bart, 60650 Saint-Paul'),
(2791,'921 La Grange Coeuret, 80360 Flers');

INSERT INTO Organisation (numero,adresse) VALUES
(2792,'94 Manhols, 21700 Saint-Nicolas-lès-Cîteaux'),
(2793,'50 chemin rural dit de Prougillion, 63310 Saint-Clément-de-Régnat');

INSERT INTO Organisation (numero,adresse) VALUES
(2794,'524 Voie du Square Floréan, 21600 Longvic'),
(2795,'504 Les Clos Chalots, 70200 Saint-Germain');

INSERT INTO Organisation (numero,adresse) VALUES
(2796,'74 Place des Ecoles, 56300 Neulliac'),
(2797,'698 Blagne, 51220 Pouillon');

INSERT INTO Organisation (numero,adresse) VALUES
(2798,'809 Naucelle Gare, 67860 Friesenheim'),
(2799,'787 Cormaranche-en-Bugey, 17380 Puyrolland');

INSERT INTO Organisation (numero,adresse) VALUES
(2800,'5 Hameau de Parry, 26310 Val-Maravel'),
(2801,'128 Lieu-dit Pachevan, 36310 Bonneuil');

INSERT INTO Organisation (numero,adresse) VALUES
(2802,'38 Gros Bois, 02500 Ohis'),
(2803,'612 Fude, 61500 La Chapelle-près-Sées');

INSERT INTO Organisation (numero,adresse) VALUES
(2804,'618 La Crouzette, 42370 Les Noës'),
(2805,'927 Vallee De Cocagne, 79170 Luché-sur-Brioux');

INSERT INTO Organisation (numero,adresse) VALUES
(2806,'168 Fond de la Vignette, 21500 Athie'),
(2807,'467 Les Gazanes, 66820 Fuilla');

INSERT INTO Organisation (numero,adresse) VALUES
(2808,'790 Quai des Grands Yachts - M, 07160 Jaunac'),
(2809,'558 Le Pélut, 71380 Châtenoy-en-Bresse');

INSERT INTO Organisation (numero,adresse) VALUES
(2810,'461 Lieu Mathe, 76690 Clères'),
(2811,'795 Le vers, 25550 Dung');

INSERT INTO Organisation (numero,adresse) VALUES
(2812,'560 Les Treisses, 36800 Saint-Gaultier'),
(2813,'457bis Naucoules, 80500 Pierrepont-sur-Avre');

INSERT INTO Organisation (numero,adresse) VALUES
(2814,'425 Res Rialto A-B-C, 65360 Bernac-Dessus'),
(2815,'874 La Vesvre, 60117 Gondreville');

INSERT INTO Organisation (numero,adresse) VALUES
(2816,'604 Tauleac, 63700 Montaigut'),
(2817,'125bis Belcamp, 34390 Prémian');

INSERT INTO Organisation (numero,adresse) VALUES
(2818,'834 Barlatière et Mas Blanc, 67100 Strasbourg'),
(2819,'132bis La Sienda Saint Jo, 43170 Esplantas-Vazeilles');

INSERT INTO Organisation (numero,adresse) VALUES
(2820,'183bis La Girviere, 16120 Bellevigne'),
(2821,'927 Le Crêt, 54470 Mandres-aux-Quatre-Tours');

INSERT INTO Organisation (numero,adresse) VALUES
(2822,'363 La Montee Perdrix, 32240 Estang'),
(2823,'559bis Zone Les Calsades, 03450 Veauce');

INSERT INTO Organisation (numero,adresse) VALUES
(2824,'389 Lai Barrai, 53410 Port-Brillet'),
(2825,'252 Le Cheverny B, 57930 Romelfing');

INSERT INTO Organisation (numero,adresse) VALUES
(2826,'148 Pre Misdre, 37330 Couesmes'),
(2827,'648bis Le Combeynier, 64250 Itxassou');

INSERT INTO Organisation (numero,adresse) VALUES
(2828,'324 Auribel, 26340 Chastel-Arnaud'),
(2829,'81bis École primaire Charles Chevallier, 22350 Plumaudan');

INSERT INTO Organisation (numero,adresse) VALUES
(2830,'255bis L’Hospitalet, 55220 Saint-André-en-Barrois'),
(2831,'715 Le Cros Esc 3, 36120 Ambrault');

INSERT INTO Organisation (numero,adresse) VALUES
(2832,'114 Laumiere, 54210 Manoncourt-en-Vermois'),
(2833,'540 La Couture des Aises, 63390 Sainte-Christine');

INSERT INTO Organisation (numero,adresse) VALUES
(2834,'260bis Ferme de l''Arborel, 38210 Morette'),
(2835,'238 Serre Nouveau, 77870 Vulaines-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(2836,'82 Viala-Goudou, 31110 Mayrègne'),
(2837,'73 La Pezade, 54840 Sexey-les-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(2838,'165 Hlm le Plessis Bat E2, 21220 Collonges-lès-Bévy'),
(2839,'942 Trayrac, 70300 Citers');

INSERT INTO Organisation (numero,adresse) VALUES
(2840,'2bis Bretelle Sortie Avenue des Sapeurs Pompiers de Nice - Pont de la Première Division Française Libre, 62960 Beaumetz-lès-Aire'),
(2841,'692bis Bagnol, 18240 Savigny-en-Sancerre');

INSERT INTO Organisation (numero,adresse) VALUES
(2842,'977bis "Bar Restaurant ""Le Café Rousse""", 35190 Saint-Domineuc'),
(2843,'439 les Ardilliéres, 21250 Corgengoux');

INSERT INTO Organisation (numero,adresse) VALUES
(2844,'807 Champ de Maison, 62180 Airon-Saint-Vaast'),
(2845,'460 La Quillerie, 80210 Ochancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2846,'484 Les Gemeaux, 55260 Lavallée'),
(2847,'479 L''Ota, 64420 Lucgarier');

INSERT INTO Organisation (numero,adresse) VALUES
(2848,'302 Jarjat, 76640 Cliponville'),
(2849,'125 La Gineste, 66300 Saint-Jean-Lasseille');

INSERT INTO Organisation (numero,adresse) VALUES
(2850,'668 Chemin de la Tour de Bellet à Magnan, 67300 Schiltigheim'),
(2851,'194bis Le Puy Golefre, 20100 Bilia');

INSERT INTO Organisation (numero,adresse) VALUES
(2852,'411 Le Bouty, 67130 Barembach'),
(2853,'677 L''Effet Mer, 72310 La Chapelle-Huon');

INSERT INTO Organisation (numero,adresse) VALUES
(2854,'789 Trébans, 28700 Voise'),
(2855,'743bis Cimetière Saint Blaise, 02580 Autreppes');

INSERT INTO Organisation (numero,adresse) VALUES
(2856,'821 Les Nesmes, 73190 La Thuile'),
(2857,'823 La Bernadasse, 77650 Savins');

INSERT INTO Organisation (numero,adresse) VALUES
(2858,'956 Résidence de Montgauzy, 07500 Guilherand-Granges'),
(2859,'856bis Le Dobrian A, 76450 Butot-Vénesville');

INSERT INTO Organisation (numero,adresse) VALUES
(2860,'63 Château de Vesset, 64640 Hélette'),
(2861,'865 Le Buissonet, 32230 Ladevèze-Ville');

INSERT INTO Organisation (numero,adresse) VALUES
(2862,'983 Maison de Grel, 54720 Laix'),
(2863,'21 "Terrain des Landes (football, pétanque)", 64410 Lonçon');

INSERT INTO Organisation (numero,adresse) VALUES
(2864,'856 Labarthe, 31380 Montastruc-la-Conseillère'),
(2865,'481 Res Santa Lucia, 27450 Saint-Christophe-sur-Condé');

INSERT INTO Organisation (numero,adresse) VALUES
(2866,'258bis L’Ort, 35530 Servon-sur-Vilaine'),
(2867,'185 Hlm le Plessis Bat P, 67720 Hœrdt');

INSERT INTO Organisation (numero,adresse) VALUES
(2868,'187 Le Roux-Est, 67110 Dambach'),
(2869,'971 Villa Georges, 67320 Ottwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(2870,'995bis Hameau du Pont Moinet, 63330 Vergheas'),
(2871,'242 Rue du Treillard, 61300 Crulai');

INSERT INTO Organisation (numero,adresse) VALUES
(2872,'726bis La borie, 72500 La Bruère-sur-Loir'),
(2873,'436 L''Armandiere, 01550 Farges');

INSERT INTO Organisation (numero,adresse) VALUES
(2874,'246 Lieu-dit Roc Saint Martin, 08450 Chémery-Chéhéry'),
(2875,'44bis Rappy, 62550 Marest');

INSERT INTO Organisation (numero,adresse) VALUES
(2876,'766bis La Grande Gineste, 76690 Cailly'),
(2877,'185bis Le Falgayrenq, 08260 Marby');

INSERT INTO Organisation (numero,adresse) VALUES
(2878,'8 Impasse des Coquelicots, 74350 Cernex'),
(2879,'509bis Église Saint-Sauveur, 72130 Coulombiers');

INSERT INTO Organisation (numero,adresse) VALUES
(2880,'776 Saint Augustin, 02320 Anizy-le-Château'),
(2881,'127 Villeplane, 49123 Saint-Sigismond');

INSERT INTO Organisation (numero,adresse) VALUES
(2882,'847 Bâtiment le rhone, 15200 Arches'),
(2883,'474 Centre Equestre, 77370 Fontains');

INSERT INTO Organisation (numero,adresse) VALUES
(2884,'41 Fourcadelle, 10320 Saint-Jean-de-Bonneval'),
(2885,'35bis Chez Vachot, 29560 Landévennec');

INSERT INTO Organisation (numero,adresse) VALUES
(2886,'231 Font Chabaude, 11220 Tournissan'),
(2887,'567 Rue du Bourg, 60240 Montjavoult');

INSERT INTO Organisation (numero,adresse) VALUES
(2888,'910bis Shangrila, 13114 Puyloubier'),
(2889,'939 Coume Duran, 70800 Briaucourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2890,'318bis Au Creux Guillien, 56140 Ruffiac'),
(2891,'690bis Plateau de la Baoma, 06580 Pégomas');

INSERT INTO Organisation (numero,adresse) VALUES
(2892,'507 Les Terrasses Du Chateau B, 17000 La Rochelle'),
(2893,'226 Le Château de Nesles, 22450 Mantallot');

INSERT INTO Organisation (numero,adresse) VALUES
(2894,'895 La Graviere, 27800 Bosrobert'),
(2895,'31 La Beaumette, 07000 Coux');

INSERT INTO Organisation (numero,adresse) VALUES
(2896,'751 Casot, 47340 Sauvagnas'),
(2897,'895 Laspouilles, 27260 Bailleul-la-Vallée');

INSERT INTO Organisation (numero,adresse) VALUES
(2898,'402 Jardin Henri Lentulo, 40270 Le Vignau'),
(2899,'245bis Le Domaine des Fontaines, 14280 Authie');

INSERT INTO Organisation (numero,adresse) VALUES
(2900,'221 Le Cluzeau, 74270 Vanzy'),
(2901,'334 Les Vignots, 67320 Ottwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(2902,'26 Place de la Ville, 34380 Viols-le-Fort'),
(2903,'694bis Coconay, 17800 Saint-Quantin-de-Rançanne');

INSERT INTO Organisation (numero,adresse) VALUES
(2904,'715bis Lot Le Palmier, 40110 Arengosse'),
(2905,'660 Hameau de Feissal, 52000 Chamarandes-Choignes');

INSERT INTO Organisation (numero,adresse) VALUES
(2906,'100 Jean le Vert, 39120 Neublans-Abergement'),
(2907,'402 Le Thabor, 57470 Guenviller');

INSERT INTO Organisation (numero,adresse) VALUES
(2908,'959 Haras d''Ecuiry, 01410 Chézery-Forens'),
(2909,'342 Crau de Chauvin, 47180 Saint-Martin-Petit');

INSERT INTO Organisation (numero,adresse) VALUES
(2910,'901bis College Andre Malraux, 14700 Noron-l''Abbaye'),
(2911,'524 Le Temps Retrouve, 62770 Wail');

INSERT INTO Organisation (numero,adresse) VALUES
(2912,'12bis Aubesson, 05100 Cervières'),
(2913,'306bis Le Clair Soleil A1 A2 A3, 70600 Argillières');

INSERT INTO Organisation (numero,adresse) VALUES
(2914,'971 Les Boulets, 27800 Brétigny'),
(2915,'298 Les Basses Blaches, 43330 Saint-Ferréol-d''Auroure');

INSERT INTO Organisation (numero,adresse) VALUES
(2916,'824bis Les Mounges, 02200 Pernant'),
(2917,'179 Bas de Villeneuve, 20244 Carticasi');

INSERT INTO Organisation (numero,adresse) VALUES
(2918,'58 Bedettes, 21350 Gissey-le-Vieil'),
(2919,'56 Jardin Rue Auguste Pégurier, 70310 Corravillers');

INSERT INTO Organisation (numero,adresse) VALUES
(2920,'872 Fillols, 27110 Venon'),
(2921,'776 Las Touasses, 59277 Rieux-en-Cambrésis');

INSERT INTO Organisation (numero,adresse) VALUES
(2922,'832 Robinson, 59227 Montrécourt'),
(2923,'172 Les Rives, 76530 Yville-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(2924,'176 Louche, 37250 Montbazon'),
(2925,'340 Les Escabrins Bas, 11300 Festes-et-Saint-André');

INSERT INTO Organisation (numero,adresse) VALUES
(2926,'361 La Cagna, 21310 Blagny-sur-Vingeanne'),
(2927,'539bis Dom de la Tour de Laboutre, 80160 Saint-Sauflieu');

INSERT INTO Organisation (numero,adresse) VALUES
(2928,'15 St Jean du Cammas Viel, 16600 Touvre'),
(2929,'958 Liaison Avenue René Millo/Rue Massena, 02450 La Neuville-lès-Dorengt');

INSERT INTO Organisation (numero,adresse) VALUES
(2930,'290 Vaumasque, 12330 Valady'),
(2931,'513 Le Bois Brûlé, 55140 Sepvigny');

INSERT INTO Organisation (numero,adresse) VALUES
(2932,'632 Arguilla, 56310 Bubry'),
(2933,'802bis Ancien Chemin de l''Abadie à l''Ariane, 72320 Melleray');

INSERT INTO Organisation (numero,adresse) VALUES
(2934,'625 Le Lauza, 55110 Regnéville-sur-Meuse'),
(2935,'628bis Serre Chaud, 80270 Tailly');

INSERT INTO Organisation (numero,adresse) VALUES
(2936,'722 Rue de la Piscine, 42800 Dargoire'),
(2937,'845 Les Baillards, 21170 Charrey-sur-Saône');

INSERT INTO Organisation (numero,adresse) VALUES
(2938,'675bis Pied Tarrus, 05700 Montclus'),
(2939,'609 Petit Patard, 59670 Ochtezeele');

INSERT INTO Organisation (numero,adresse) VALUES
(2940,'600bis Chemin Departemental 53, 78610 Les Bréviaires'),
(2941,'109bis La Grande Bastide, 54840 Sexey-les-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(2942,'763 Route Métropolitaine 30, 69870 Chambost-Allières'),
(2943,'316 Le Barral, 17330 Saint-Pierre-de-l''Isle');

INSERT INTO Organisation (numero,adresse) VALUES
(2944,'760bis La Théoule, 03220 Varennes-sur-Tèche'),
(2945,'605 Les Plaintiers, 05140 La Faurie');

INSERT INTO Organisation (numero,adresse) VALUES
(2946,'408 La Cote du Sourderon, 67420 Saulxures'),
(2947,'691 Les Usines du Crouzet, 55000 Tannois');

INSERT INTO Organisation (numero,adresse) VALUES
(2948,'511 Claps, 51130 Vélye'),
(2949,'284 Loire, 64250 Cambo-les-Bains');

INSERT INTO Organisation (numero,adresse) VALUES
(2950,'407bis Enguiales Haut, 19120 Liourdres'),
(2951,'538 Lesquille, 24130 Le Fleix');

INSERT INTO Organisation (numero,adresse) VALUES
(2952,'226 Maugard, 38090 Bonnefamille'),
(2953,'278 Parc Robert Piat, 59173 Sercus');

INSERT INTO Organisation (numero,adresse) VALUES
(2954,'403 Aubuc, 60420 Welles-Pérennes'),
(2955,'400 Champ Gauthier, 28220 Langey');

INSERT INTO Organisation (numero,adresse) VALUES
(2956,'54 Les Dahlias, 52170 Narcy'),
(2957,'919 Salle EDF, 23140 Parsac-Rimondeix');

INSERT INTO Organisation (numero,adresse) VALUES
(2958,'212 Boue, 70140 Bresilley'),
(2959,'639 La Combe Haut, 28300 Champhol');

INSERT INTO Organisation (numero,adresse) VALUES
(2960,'168bis Les Hems, 24560 Faux'),
(2961,'846 Château de Castelbon, 61100 Flers');

INSERT INTO Organisation (numero,adresse) VALUES
(2962,'60 Carcenac Gare, 71370 Ouroux-sur-Saône'),
(2963,'15 Les Grands Navoirs Ouest, 09350 Daumazan-sur-Arize');

INSERT INTO Organisation (numero,adresse) VALUES
(2964,'709 L''Araignee et la Reynarde, 04140 Selonnet'),
(2965,'320 La Bourine, 26400 Omblèze');

INSERT INTO Organisation (numero,adresse) VALUES
(2966,'162 Pierr''Line, 79380 Saint-Jouin-de-Milly'),
(2967,'67 La Noue du Mée, 72610 Thoiré-sous-Contensor');

INSERT INTO Organisation (numero,adresse) VALUES
(2968,'729 Pomayrol, 01210 Ornex'),
(2969,'400 Les Villas des Capitelles, 14690 Le Bô');

INSERT INTO Organisation (numero,adresse) VALUES
(2970,'106 Fonvayse, 33220 Les Lèves-et-Thoumeyragues'),
(2971,'689 Chemin Rural Dit du Chateau d''Eau, 55260 Gimécourt');

INSERT INTO Organisation (numero,adresse) VALUES
(2972,'211bis Sous la Cote Nord, 67630 Scheibenhard'),
(2973,'428 Lieu-Dit Croumpadis, 54490 Piennes');

INSERT INTO Organisation (numero,adresse) VALUES
(2974,'962 Villa Theresina, 49420 Armaillé'),
(2975,'445 Resquens, 72400 Souvigné-sur-Même');

INSERT INTO Organisation (numero,adresse) VALUES
(2976,'774 Lieu-dit Las Gouttes, 01250 Journans'),
(2977,'202 Les Molinieres, 30340 Mons');

INSERT INTO Organisation (numero,adresse) VALUES
(2978,'294bis Terrain de Tennis, 20244 Carticasi'),
(2979,'749 L’Isarnie, 10330 Saint-Léger-sous-Margerie');

INSERT INTO Organisation (numero,adresse) VALUES
(2980,'856 Patrimoine Haut, 65140 Rabastens-de-Bigorre'),
(2981,'526 Raïssac, 28600 Luisant');

INSERT INTO Organisation (numero,adresse) VALUES
(2982,'108 Rue des Louvrets, 46700 Floressas'),
(2983,'574bis Albinhac - La Prunhe, 55270 Montblainville');

INSERT INTO Organisation (numero,adresse) VALUES
(2984,'958 Le Gres, 49400 Distré'),
(2985,'388 Les Pessonnets, 12270 Najac');

INSERT INTO Organisation (numero,adresse) VALUES
(2986,'864 Chante Duc, 22370 Pléneuf-Val-André'),
(2987,'932 Le Petit Deffends, 01250 Ceyzériat');

INSERT INTO Organisation (numero,adresse) VALUES
(2988,'893 Salle Pierre BRASSEUR, 58170 Millay'),
(2989,'139bis Chareyrade, 74500 Bernex');

INSERT INTO Organisation (numero,adresse) VALUES
(2990,'119 Le Pendu, 62140 La Loge'),
(2991,'589 Pech Lagastou, 70160 Faverney');

INSERT INTO Organisation (numero,adresse) VALUES
(2992,'962bis Les Bouilles, 69360 Sérézin-du-Rhône'),
(2993,'503bis Les Magabies Bas, 58490 Saint-Parize-le-Châtel');

INSERT INTO Organisation (numero,adresse) VALUES
(2994,'79 Les Corches, 24370 Peyrillac-et-Millac'),
(2995,'78 Grand Cap, 24390 Temple-Laguyon');

INSERT INTO Organisation (numero,adresse) VALUES
(2996,'434bis Le Concorde Bat 2, 11140 Montfort-sur-Boulzane'),
(2997,'598 Cap Long, 26400 Aouste-sur-Sye');

INSERT INTO Organisation (numero,adresse) VALUES
(2998,'772bis La contie basse, 76740 Fontaine-le-Dun'),
(2999,'571 Roussy Bas, 59320 Haubourdin');

INSERT INTO Organisation (numero,adresse) VALUES
(3000,'257 La Carral, 80230 Lanchères'),
(3001,'35 Cayrac le Haut, 56120 Pleugriffet');

INSERT INTO Organisation (numero,adresse) VALUES
(3002,'763 En Payan, 79600 Marnes'),
(3003,'970 Les Cours Bas, 22400 Landéhen');

INSERT INTO Organisation (numero,adresse) VALUES
(3004,'542 La Loge Tristan, 55000 Silmont'),
(3005,'709bis Le Soleil Couchant, 64130 Roquiague');

INSERT INTO Organisation (numero,adresse) VALUES
(3006,'402 Sentier du Jardin Christine, 62370 Zutkerque'),
(3007,'239 Lieu-dit Le Croz, 59171 Hélesmes');

INSERT INTO Organisation (numero,adresse) VALUES
(3008,'36bis Les Vesces Fournies, 77515 Hautefeuille'),
(3009,'271 Rouquisse, 02800 Travecy');

INSERT INTO Organisation (numero,adresse) VALUES
(3010,'997 Le Cros Esc 2, 80110 Le Plessier-Rozainvillers'),
(3011,'264 Villa Mounira, 57920 Aboncourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3012,'74 Le Py, 60127 Fresnoy-la-Rivière'),
(3013,'616 Lieu-dit La Roche, 10500 Molins-sur-Aube');

INSERT INTO Organisation (numero,adresse) VALUES
(3014,'834 Cureboursot, 62310 Torcy'),
(3015,'954 Les Charmettes, 64330 Mascaraàs-Haron');

INSERT INTO Organisation (numero,adresse) VALUES
(3016,'819 Square  Henri Bianchi, 57415 Montbronn'),
(3017,'516bis Complexe sportif Pierre Richon, 24130 La Force');

INSERT INTO Organisation (numero,adresse) VALUES
(3018,'349bis Appt 201, 63420 Ardes'),
(3019,'793 Impasse du Château d''eau, 60400 Cuts');

INSERT INTO Organisation (numero,adresse) VALUES
(3020,'445bis Route de Blissy, 59270 Flêtre'),
(3021,'408 Mélières, 33113 Saint-Symphorien');

INSERT INTO Organisation (numero,adresse) VALUES
(3022,'916bis Tragine, 33670 Saint-Léon'),
(3023,'484 Vallée de Capus, 31160 Portet-d''Aspet');

INSERT INTO Organisation (numero,adresse) VALUES
(3024,'381 Mas Des Romarins 2 Villa 27, 76450 Saint-Martin-aux-Buneaux'),
(3025,'874 Stade Jean-Pierre Rives, 16130 Segonzac');

INSERT INTO Organisation (numero,adresse) VALUES
(3026,'482 Ramillassé, 64220 Anhaux'),
(3027,'493bis En Beigne, 76440 Grumesnil');

INSERT INTO Organisation (numero,adresse) VALUES
(3028,'792 Barrat, 70110 Villafans'),
(3029,'45bis Lavisat, 16120 Saint-Simon');

INSERT INTO Organisation (numero,adresse) VALUES
(3030,'55 Bonhoure, 04510 Mallemoisson'),
(3031,'236 Salsac, 14340 Formentin');

INSERT INTO Organisation (numero,adresse) VALUES
(3032,'523 Chirollet, 40150 Angresse'),
(3033,'392 Hameau de Vorages d’En Bas, 80200 Bouchavesnes-Bergen');

INSERT INTO Organisation (numero,adresse) VALUES
(3034,'13 Allée Jean Sablon, 29100 Kerlaz'),
(3035,'244 La Claie, 25150 Villars-sous-Écot');

INSERT INTO Organisation (numero,adresse) VALUES
(3036,'810 Village de Laval d''Aurelle, 32170 Aux-Aussat'),
(3037,'894 Puech Pigues, 32230 Laveraët');

INSERT INTO Organisation (numero,adresse) VALUES
(3038,'915 La Campristinie, 80170 Maucourt'),
(3039,'258 Bas Ruissol Sud, 28150 Boncé');

INSERT INTO Organisation (numero,adresse) VALUES
(3040,'300bis Pont des Chevres, 74150 Thusy'),
(3041,'526 Villa Ketty, 31460 Albiac');

INSERT INTO Organisation (numero,adresse) VALUES
(3042,'118 Laysac, 55160 Marchéville-en-Woëvre'),
(3043,'796 Bâtiment Le basilic Entrée 1, 12230 Lapanouse-de-Cernon');

INSERT INTO Organisation (numero,adresse) VALUES
(3044,'453 Gounelle, 27400 Crasville'),
(3045,'964 Quartier Castelet, 32230 Juillac');

INSERT INTO Organisation (numero,adresse) VALUES
(3046,'417bis Hotel Vanille, 32330 Mouchan'),
(3047,'7 Puy Chauvier, 39800 Buvilly');

INSERT INTO Organisation (numero,adresse) VALUES
(3048,'561bis La Fontaine et Saint-Pansier, 64130 Ordiarp'),
(3049,'605 Le Roudilhou, 31310 Bax');

INSERT INTO Organisation (numero,adresse) VALUES
(3050,'996 Villa Les Pitchounets, 67700 Saverne'),
(3051,'312bis Le Cassagnol, 23260 Saint-Oradoux-près-Crocq');

INSERT INTO Organisation (numero,adresse) VALUES
(3052,'694 Allée du Petit Fabron, 57400 Haut-Clocher'),
(3053,'438 Défibrillateur, 74270 Chêne-en-Semine');

INSERT INTO Organisation (numero,adresse) VALUES
(3054,'505bis Les Raisins Verts, 28210 Saint-Laurent-la-Gâtine'),
(3055,'115 La Coste des Brus, 50440 Jobourg');

INSERT INTO Organisation (numero,adresse) VALUES
(3056,'177 Les Pres de Plasion, 46100 Viazac'),
(3057,'365 Sainte Catherine Est, 35680 Louvigné-de-Bais');

INSERT INTO Organisation (numero,adresse) VALUES
(3058,'871bis Les Granges St Julien, 78940 La Queue-les-Yvelines'),
(3059,'590bis Voie Communale Riviéra Palace, 69005 Lyon 05');

INSERT INTO Organisation (numero,adresse) VALUES
(3060,'535 lieu dit Salbatche, 27680 Vieux-Port'),
(3061,'605 Epanchoir de Foucaud, 15170 Coltines');

INSERT INTO Organisation (numero,adresse) VALUES
(3062,'914 """ Salles """, 65690 Angos'),
(3063,'85 La Solitude, 01190 Saint-Étienne-sur-Reyssouze');

INSERT INTO Organisation (numero,adresse) VALUES
(3064,'277bis 2 Chemin du poulit, 40440 Ondres'),
(3065,'949bis Les Escouleyres, 35390 Grand-Fougeray');

INSERT INTO Organisation (numero,adresse) VALUES
(3066,'456 Le Bas Pranles, 79500 Mazières-sur-Béronne'),
(3067,'838 Le Bois Gaillard, 43130 Retournac');

INSERT INTO Organisation (numero,adresse) VALUES
(3068,'768 Le Moulin Infernal, 08130 Guincourt'),
(3069,'929bis Chez Chertand, 57340 Lidrezing');

INSERT INTO Organisation (numero,adresse) VALUES
(3070,'637 Graves de Ravouest, 62118 Biache-Saint-Vaast'),
(3071,'526 Lou Fraysse, 49660 Sèvremoine');

INSERT INTO Organisation (numero,adresse) VALUES
(3072,'549bis Les Lévêques, 72260 Moncé-en-Saosnois'),
(3073,'374 Malakoff, 54122 Chenevières');

INSERT INTO Organisation (numero,adresse) VALUES
(3074,'559 Le Champ Leblanc, 60210 Le Mesnil-Conteville'),
(3075,'906bis L''Héritier, 20117 Ocana');

INSERT INTO Organisation (numero,adresse) VALUES
(3076,'440 Le Nid de Rat, 54580 Saint-Ail'),
(3077,'281bis Champ du Four, 34570 Montarnaud');

INSERT INTO Organisation (numero,adresse) VALUES
(3078,'226 Montée Senancour, 74370 Argonay'),
(3079,'294 Les Tomelles, 38300 Saint-Savin');

INSERT INTO Organisation (numero,adresse) VALUES
(3080,'400 Bagatelle, 76460 Pleine-Sève'),
(3081,'831 Boyon, 59212 Wignehies');

INSERT INTO Organisation (numero,adresse) VALUES
(3082,'171 La Croix de la Fee, 76730 Hermanville'),
(3083,'47 Chemin de las Coumes, 31450 Deyme');

INSERT INTO Organisation (numero,adresse) VALUES
(3084,'624 Le Peyssel, 52150 Bourg-Sainte-Marie'),
(3085,'405bis Hubac d''Angouire, 63340 Ternant-les-Eaux');

INSERT INTO Organisation (numero,adresse) VALUES
(3086,'720 Puechbiou, 04530 Saint-Paul-sur-Ubaye'),
(3087,'812 Croix de la Rode, 24380 Breuilh');

INSERT INTO Organisation (numero,adresse) VALUES
(3088,'334 Le Peiron, 56230 Questembert'),
(3089,'921 Les Baquins, 61160 Saint-Lambert-sur-Dive');

INSERT INTO Organisation (numero,adresse) VALUES
(3090,'613 La Vallée à l''Eau, 27660 Bézu-Saint-Éloi'),
(3091,'160 Libertonne, 64190 Bastanès');

INSERT INTO Organisation (numero,adresse) VALUES
(3092,'415 La Petite Carmejane, 42270 Saint-Priest-en-Jarez'),
(3093,'455bis L''Adoux, 48100 Grèzes');

INSERT INTO Organisation (numero,adresse) VALUES
(3094,'183 Hameau de Giffécourt, 62200 Boulogne-sur-Mer'),
(3095,'680 Samiac, 02860 Bruyères-et-Montbérault');

INSERT INTO Organisation (numero,adresse) VALUES
(3096,'40 Masméjean, 02300 Manicamp'),
(3097,'347 Peyrelade Sud, 21170 Charrey-sur-Saône');

INSERT INTO Organisation (numero,adresse) VALUES
(3098,'996bis Le Castagnet, 35380 Saint-Péran'),
(3099,'546bis Saint Mayeul, 59125 Trith-Saint-Léger');

INSERT INTO Organisation (numero,adresse) VALUES
(3100,'934 résidence les tilleuls, 61800 Tinchebray-Bocage'),
(3101,'988 Menes, 73660 Les Chavannes-en-Maurienne');

INSERT INTO Organisation (numero,adresse) VALUES
(3102,'704 Moulin de Saint Juvin, 49490 Linières-Bouton'),
(3103,'139 La Plisserie, 16120 Graves-Saint-Amant');

INSERT INTO Organisation (numero,adresse) VALUES
(3104,'534 Rue du Puech, 74320 Leschaux'),
(3105,'758bis Parking Louis Donat, 05260 Saint-Jean-Saint-Nicolas');

INSERT INTO Organisation (numero,adresse) VALUES
(3106,'153 Picotis, 60350 Trosly-Breuil'),
(3107,'152bis Chiloup, 59145 Berlaimont');

INSERT INTO Organisation (numero,adresse) VALUES
(3108,'325bis Place Leon Carrie, 57570 Boust'),
(3109,'975 Le Villeneuve B, 39800 Oussières');

INSERT INTO Organisation (numero,adresse) VALUES
(3110,'163 Monta de Colette, 71500 Montcony'),
(3111,'605 Le Champ de Fer Perles, 40420 Labrit');

INSERT INTO Organisation (numero,adresse) VALUES
(3112,'624bis Ferme de la Nouette, 12100 Creissels'),
(3113,'906bis Chemin du Domaine de la Bauma, 46150 Thédirac');

INSERT INTO Organisation (numero,adresse) VALUES
(3114,'475 Les Lucayas A-B-C-D, 52250 Flagey'),
(3115,'560 Le Village - Impasse du Centre, 66530 Claira');

INSERT INTO Organisation (numero,adresse) VALUES
(3116,'523bis Le Moulin à vent, 44190 Saint-Hilaire-de-Clisson'),
(3117,'485 Escalier au n°548 Promenade du Lac du Boréon, 21400 Coulmier-le-Sec');

INSERT INTO Organisation (numero,adresse) VALUES
(3118,'463bis Camcilla-nord, 08400 Mont-Saint-Martin'),
(3119,'365 Gevray, 21110 Bretenière');

INSERT INTO Organisation (numero,adresse) VALUES
(3120,'604 Le Goury, 27930 Le Mesnil-Fuguet'),
(3121,'486bis Domaine du Moulin, 31260 Figarol');

INSERT INTO Organisation (numero,adresse) VALUES
(3122,'611 Bajoc, 31160 Portet-d''Aspet'),
(3123,'530bis Les Payssels, 44320 Chauvé');

INSERT INTO Organisation (numero,adresse) VALUES
(3124,'185bis les palies, 34260 Saint-Étienne-Estréchoux'),
(3125,'537 Res Campanette A Et B, 52130 Voillecomte');

INSERT INTO Organisation (numero,adresse) VALUES
(3126,'997 Bureau de Poste des Bataillots - ERP, 32420 Sabaillan'),
(3127,'348 Courbieres, 02000 Chivy-lès-Étouvelles');

INSERT INTO Organisation (numero,adresse) VALUES
(3128,'29 Mas de la Gleize, 11200 Ferrals-les-Corbières'),
(3129,'299bis L’Homaly, 56450 Surzur');

INSERT INTO Organisation (numero,adresse) VALUES
(3130,'233 Escalier Avenue Stephen Liegeard - Rue Victorien Sardou - Rue Charles Calais, 17240 Clion'),
(3131,'695 Derriere le Moutier, 52360 Lecey');

INSERT INTO Organisation (numero,adresse) VALUES
(3132,'294 Lotissement Bertille Tortel, 34080 Montpellier'),
(3133,'17bis Hameau de Liffart, 33210 Saint-Pierre-de-Mons');

INSERT INTO Organisation (numero,adresse) VALUES
(3134,'716bis Pont de Châteauneuf, 76660 Bures-en-Bray'),
(3135,'889 Grange Servon, 72500 Flée');

INSERT INTO Organisation (numero,adresse) VALUES
(3136,'777bis Monilou, 80340 Chuignes'),
(3137,'856bis La Charriere, 76540 Ypreville-Biville');

INSERT INTO Organisation (numero,adresse) VALUES
(3138,'804 Le Viable, 16310 Saint-Adjutory'),
(3139,'95bis Bois de la Riviere, 30150 Saint-Geniès-de-Comolas');

INSERT INTO Organisation (numero,adresse) VALUES
(3140,'91bis Château Campagne, 38780 Eyzin-Pinet'),
(3141,'221 La Barthe, 67260 Keskastel');

INSERT INTO Organisation (numero,adresse) VALUES
(3142,'829 Peyralade, 65140 Escondeaux'),
(3143,'501 Lotissement les Colverts, 29800 La Forest-Landerneau');

INSERT INTO Organisation (numero,adresse) VALUES
(3144,'216 La Coste et le Goutail, 31480 Laréole'),
(3145,'238bis Village de Terron les Vendresse, 12500 Lassouts');

INSERT INTO Organisation (numero,adresse) VALUES
(3146,'45bis Les Pres Saint Remy, 29300 Guilligomarc''h'),
(3147,'409 Lieu-dit Pavillon des Eaux, 32800 Noulens');

INSERT INTO Organisation (numero,adresse) VALUES
(3148,'839bis Le Carrau, 35500 Montreuil-sous-Pérouse'),
(3149,'854 Le Clos Christina, 47800 Allemans-du-Dropt');

INSERT INTO Organisation (numero,adresse) VALUES
(3150,'336 Le Champ du Portail, 76730 Rainfreville'),
(3151,'568 Vielmont, 17610 Chérac');

INSERT INTO Organisation (numero,adresse) VALUES
(3152,'971 Route du Bois sacré, 49170 Saint-Germain-des-Prés'),
(3153,'468 Roussey, 50330 Varouville');

INSERT INTO Organisation (numero,adresse) VALUES
(3154,'699 Guiraldse, 52120 Lanty-sur-Aube'),
(3155,'494bis Champ Simonet, 64130 Aussurucq');

INSERT INTO Organisation (numero,adresse) VALUES
(3156,'827 Garnier, 07410 Bozas'),
(3157,'260 Lacour, 50800 Beslon');

INSERT INTO Organisation (numero,adresse) VALUES
(3158,'724 Lieu Dit Estien, 20259 Vallica'),
(3159,'881bis Impasse des Condamines, 59222 Croix-Caluyau');

INSERT INTO Organisation (numero,adresse) VALUES
(3160,'762 Talias, 62770 Saint-Georges'),
(3161,'747 Avenue des Glaieuls, 80220 Bouttencourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3162,'303 Les Terrasses du Levant - Le Crêt de la Neige, 62860 Buissy'),
(3163,'77bis Les Drevaux, 02110 Montbrehain');

INSERT INTO Organisation (numero,adresse) VALUES
(3164,'598bis Les Roquelles, 07370 Sarras'),
(3165,'422 Ribet, 31260 Ausseing');

INSERT INTO Organisation (numero,adresse) VALUES
(3166,'809 Les Bois du Chaillot, 34140 Loupian'),
(3167,'336 Centre commercial les Pouzeux, 47270 Saint-Urcisse');

INSERT INTO Organisation (numero,adresse) VALUES
(3168,'492bis Place de la RN 84, 13620 Carry-le-Rouet'),
(3169,'843 Au Gothaly, 46300 Rouffilhac');

INSERT INTO Organisation (numero,adresse) VALUES
(3170,'880 La Contamine, 51150 Jâlons'),
(3171,'527 Ourdénac, 76440 Forges-les-Eaux');

INSERT INTO Organisation (numero,adresse) VALUES
(3172,'489 Sours, 01120 Niévroz'),
(3173,'733 Le Poticaire, 62120 Quernes');

INSERT INTO Organisation (numero,adresse) VALUES
(3174,'360 Chemin des Autins, 17490 Bresdon'),
(3175,'311 Pessengue-Haut, 64350 Maspie-Lalonquère-Juillacq');

INSERT INTO Organisation (numero,adresse) VALUES
(3176,'394 la Picardie, 58330 Saxi-Bourdon'),
(3177,'3bis Route Métropolitaine 71, 62320 Drocourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3178,'247 Les Petits Aigriers, 57260 Guéblange-lès-Dieuze'),
(3179,'156 Saint-Amans-de-Lizertet, 67170 Krautwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(3180,'860bis Alpi, 30120 Avèze'),
(3181,'224 La Prade Haute, 80250 Folleville');

INSERT INTO Organisation (numero,adresse) VALUES
(3182,'473 Sabatie, 14250 Audrieu'),
(3183,'515 Cadour, 76590 Muchedent');

INSERT INTO Organisation (numero,adresse) VALUES
(3184,'724bis Seneclauze et Bois Long, 31320 Mervilla'),
(3185,'579 Résidence Cap Surf, 54180 Heillecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3186,'780 Parc Laussedat, 49360 Les Cerqueux'),
(3187,'611bis Ves Hauts, 32230 Peyrusse-Vieille');

INSERT INTO Organisation (numero,adresse) VALUES
(3188,'326 Hameau de Seuillac, 42350 La Talaudière'),
(3189,'336 Lieu-dit Sarrat de L''agnel, 62123 Berles-au-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(3190,'500 La Dîme, 62920 Oblinghem'),
(3191,'839bis Molieres, 69640 Montmelas-Saint-Sorlin');

INSERT INTO Organisation (numero,adresse) VALUES
(3192,'225 Clot de Lamait, 01300 Conzieu'),
(3193,'332 Basse Abietta, 40380 Poyanne');

INSERT INTO Organisation (numero,adresse) VALUES
(3194,'806 Les Bouteillettes, 59630 Saint-Pierre-Brouck'),
(3195,'252bis Fin de Mesgrigny, 57730 Altviller');

INSERT INTO Organisation (numero,adresse) VALUES
(3196,'64 Cattevayre, 62158 Saulty'),
(3197,'917bis Les Huit Setiers, 09130 Sainte-Suzanne');

INSERT INTO Organisation (numero,adresse) VALUES
(3198,'583bis La Fenêtre, 39350 Gendrey'),
(3199,'40bis Pleneroque, 68510 Rantzwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(3200,'433bis La Plaine de Bialot, 31320 Vieille-Toulouse'),
(3201,'430 Laleuf, 11140 Counozouls');

INSERT INTO Organisation (numero,adresse) VALUES
(3202,'981 Roumévey, 39270 Plaisia'),
(3203,'776 Rouades, 21120 Courtivron');

INSERT INTO Organisation (numero,adresse) VALUES
(3204,'737 Lieu-dit Carcanague, 27400 Quatremare'),
(3205,'686 La Baraque de Flavin, 41170 Sargé-sur-Braye');

INSERT INTO Organisation (numero,adresse) VALUES
(3206,'357bis Marlavagne la Fournelade, 47250 Sainte-Gemme-Martaillac'),
(3207,'825 Voie liaison Avenue des Mandariniers - Avenue de la Lanterne, 52370 Rennepont');

INSERT INTO Organisation (numero,adresse) VALUES
(3208,'445bis La Tombe de Saussaye, 09500 Camon'),
(3209,'912 Rue Mons Jovis, 58240 Azy-le-Vif');

INSERT INTO Organisation (numero,adresse) VALUES
(3210,'219 Montgros, 09310 Verdun'),
(3211,'591 Lieu-dit La Scie, 73200 Albertville');

INSERT INTO Organisation (numero,adresse) VALUES
(3212,'802 Foncoussergues, 26150 Sainte-Croix'),
(3213,'771 La Compagnie, 66360 Canaveilles');

INSERT INTO Organisation (numero,adresse) VALUES
(3214,'244bis Chateau de Lugan, 19150 Chanac-les-Mines'),
(3215,'0bis abri bus, 21700 Nuits-Saint-Georges');

INSERT INTO Organisation (numero,adresse) VALUES
(3216,'309 Iles Nouvelles, 62450 Rocquigny'),
(3217,'995 Bâtiment Le laurier rose, 64120 Beyrie-sur-Joyeuse');

INSERT INTO Organisation (numero,adresse) VALUES
(3218,'453bis Toilettes Publiques, 62130 Ramecourt'),
(3219,'440 Les Caves, 05100 Val-des-Prés');

INSERT INTO Organisation (numero,adresse) VALUES
(3220,'202 Moulin du Libezen, 59630 Brouckerque'),
(3221,'941 Derrière Saint-Jean Est, 32130 Seysses-Savès');

INSERT INTO Organisation (numero,adresse) VALUES
(3222,'692 les iscles anciennes, 49700 Forges'),
(3223,'781 Saint Rome de Cernon, 24120 La Cassagne');

INSERT INTO Organisation (numero,adresse) VALUES
(3224,'400 Les paulons, 67440 Hengwiller'),
(3225,'535 Saint - Paul, 33990 Naujac-sur-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(3226,'878 Résidence d''Amtzell, 43370 Bains'),
(3227,'780 Clamouse, 31420 Esparron');

INSERT INTO Organisation (numero,adresse) VALUES
(3228,'978 La corre, 39800 Biefmorin'),
(3229,'908 Les Plans d''Hotonnes, 68210 Balschwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(3230,'174bis Pre Moiroux, 55500 Dammarie-sur-Saulx'),
(3231,'562bis Jeancourt, 51270 Baye');

INSERT INTO Organisation (numero,adresse) VALUES
(3232,'119 Les Alaris, 58700 Chazeuil'),
(3233,'27 Square de la Négresse, 76400 Toussaint');

INSERT INTO Organisation (numero,adresse) VALUES
(3234,'244 Le Coté, 30110 Soustelle'),
(3235,'403 "Lotissement ""LES JULIENS""", 79110 Couture-d''Argenson');

INSERT INTO Organisation (numero,adresse) VALUES
(3236,'354 Gazou, 35520 La Chapelle-des-Fougeretz'),
(3237,'487bis Gratteloup, 27580 Chaise-Dieu-du-Theil');

INSERT INTO Organisation (numero,adresse) VALUES
(3238,'954 La Bouiche, 33330 Saint-Émilion'),
(3239,'604 La Carrière Medard, 47180 Couthures-sur-Garonne');

INSERT INTO Organisation (numero,adresse) VALUES
(3240,'585 Les Peigneux, 52330 Sexfontaines'),
(3241,'375bis Liaison Place de la Fontaine/Rue du Four, 16410 Garat');

INSERT INTO Organisation (numero,adresse) VALUES
(3242,'559 Fournet, 14260 Brémoy'),
(3243,'43bis Chamaras, 33420 Naujan-et-Postiac');

INSERT INTO Organisation (numero,adresse) VALUES
(3244,'417bis Lotissement le Clos des Anges, 25570 Grand''Combe-Châteleu'),
(3245,'903bis Voie s''amorçant à la rue Antoine Virello, 27230 Saint-Aubin-de-Scellon');

INSERT INTO Organisation (numero,adresse) VALUES
(3246,'15 La Pointe de Marolles, 54540 Veney'),
(3247,'813 La Cavalerie, 69380 Marcilly-d''Azergues');

INSERT INTO Organisation (numero,adresse) VALUES
(3248,'247 Bel Soleil, 62910 Houlle'),
(3249,'892 Saint-Raymond, 28300 Saint-Aubin-des-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(3250,'88bis Chemin de Terre d''Eze 4, 59132 Wallers-en-Fagne'),
(3251,'311bis Route Nationale du Baus Roux, 50570 Hauteville-la-Guichard');

INSERT INTO Organisation (numero,adresse) VALUES
(3252,'208bis Merly, 60162 Antheuil-Portes'),
(3253,'20bis Ile de Varambon, 60620 Bargny');

INSERT INTO Organisation (numero,adresse) VALUES
(3254,'670 Les Gaillardins, 10210 Lagesse'),
(3255,'37 La Rubia, 57400 Sarraltroff');

INSERT INTO Organisation (numero,adresse) VALUES
(3256,'808bis Pertuis Bardin, 25240 Châtelblanc'),
(3257,'762 "Jardin botanique ""Le Clos des Arômes""", 02290 Osly-Courtil');

INSERT INTO Organisation (numero,adresse) VALUES
(3258,'887 Le Petit Douaire, 58330 Saint-Saulge'),
(3259,'221 Les Pussalons, 68220 Hagenthal-le-Bas');

INSERT INTO Organisation (numero,adresse) VALUES
(3260,'558bis La Culee Lot, 22340 Maël-Carhaix'),
(3261,'109bis Laguiole, 71380 Saint-Marcel');

INSERT INTO Organisation (numero,adresse) VALUES
(3262,'718bis """ La Gagnerie """, 38980 Viriville'),
(3263,'460 Taravelle, 45210 Rozoy-le-Vieil');

INSERT INTO Organisation (numero,adresse) VALUES
(3264,'997bis En Gallepied, 13117 Martigues'),
(3265,'576 Malhussier le Bas, 24300 Abjat-sur-Bandiat');

INSERT INTO Organisation (numero,adresse) VALUES
(3266,'803bis Mas Fleuri, 60800 Trumilly'),
(3267,'198 Zone Industrielle Nord, 77350 Boissise-la-Bertrand');

INSERT INTO Organisation (numero,adresse) VALUES
(3268,'92 Meda, 28700 Francourville'),
(3269,'850 Place la de Victoire, 43370 Solignac-sur-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(3270,'752 Le Garde Bois, 23150 Mazeirat'),
(3271,'209 Pradals, 31320 Pechbusque');

INSERT INTO Organisation (numero,adresse) VALUES
(3272,'566 Les Ecros, 21510 Quemigny-sur-Seine'),
(3273,'335 Poteau Incendie, 41170 Arville');

INSERT INTO Organisation (numero,adresse) VALUES
(3274,'404bis Fournies, 28270 Beauche'),
(3275,'305bis lieu-dit Carol, 05320 La Grave');

INSERT INTO Organisation (numero,adresse) VALUES
(3276,'457 La Forge, 29790 Beuzec-Cap-Sizun'),
(3277,'332 Puech de Soulergues, 60440 Chèvreville');

INSERT INTO Organisation (numero,adresse) VALUES
(3278,'156 La Maynalie, 77126 Égligny'),
(3279,'52 Fontreine, 48230 Esclanèdes');

INSERT INTO Organisation (numero,adresse) VALUES
(3280,'290bis La Haye Malingre, 33820 Saint-Palais'),
(3281,'447bis Les Gourands Vieux, 45170 Neuville-aux-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(3282,'820bis Pre de Lage, 72300 Précigné'),
(3283,'247bis Nalviac, 59620 Leval');

INSERT INTO Organisation (numero,adresse) VALUES
(3284,'558 L''Espagnol, 46340 Rampoux'),
(3285,'979 Lieu dit L''Abeille, 07400 Saint-Pierre-la-Roche');

INSERT INTO Organisation (numero,adresse) VALUES
(3286,'33 Parking du Lavoir, 73310 Chindrieux'),
(3287,'630 Le Bagatelle A, 68460 Lutterbach');

INSERT INTO Organisation (numero,adresse) VALUES
(3288,'202 Valensibert, 30450 Malons-et-Elze'),
(3289,'191bis Le Parc Lautin A-B-C-D, 52160 Auberive');

INSERT INTO Organisation (numero,adresse) VALUES
(3290,'968 Villa Mine De Rien, 62370 Zutkerque'),
(3291,'135 Ladreyt de Sardiges, 70500 Villars-le-Pautel');

INSERT INTO Organisation (numero,adresse) VALUES
(3292,'554 La Baraque de Cussan, 08400 Tourcelles-Chaumont'),
(3293,'926 La Roulande, 41100 Saint-Ouen');

INSERT INTO Organisation (numero,adresse) VALUES
(3294,'815 Châteauvieux, 34725 Saint-André-de-Sangonis'),
(3295,'527bis Ambaron, 35170 Bruz');

INSERT INTO Organisation (numero,adresse) VALUES
(3296,'125bis Garrigous, 59670 Winnezeele'),
(3297,'255bis Champ Don, 32120 Monfort');

INSERT INTO Organisation (numero,adresse) VALUES
(3298,'491bis Le Buissonet, 14170 Bernières-d''Ailly'),
(3299,'722bis Merlande, 76340 Réalcamp');

INSERT INTO Organisation (numero,adresse) VALUES
(3300,'934 Le Ris Malnoce, 07320 Mars'),
(3301,'718bis Moulin des Salles, 27560 Saint-Siméon');

INSERT INTO Organisation (numero,adresse) VALUES
(3302,'656 Vieux Chemin de Cimiez, 55120 Autrécourt-sur-Aire'),
(3303,'198 Le Moulin de Beaumont, 67700 Gottenhouse');

INSERT INTO Organisation (numero,adresse) VALUES
(3304,'908 La Gleyzette, 01260 Sutrieu'),
(3305,'736bis Les_pigeonniers, 71960 Milly-Lamartine');

INSERT INTO Organisation (numero,adresse) VALUES
(3306,'355 Rond point Gilbert Auvergne, 16250 Champagne-Vigny'),
(3307,'935 Lieu-dit Ligny, 56130 Nivillac');

INSERT INTO Organisation (numero,adresse) VALUES
(3308,'674bis Les Romaniers, 39570 Condamine'),
(3309,'466 Parking du Fontanil, 28150 Villars');

INSERT INTO Organisation (numero,adresse) VALUES
(3310,'33 Soleil D''Or, 57510 Guebenhouse'),
(3311,'740bis Le Poyet, 09300 Carla-de-Roquefort');

INSERT INTO Organisation (numero,adresse) VALUES
(3312,'654 Antraygues, 57640 Bettelainville'),
(3313,'370 Bayzes, 53480 Saint-Georges-le-Fléchard');

INSERT INTO Organisation (numero,adresse) VALUES
(3314,'16 Impasse de la Pastoujade, 71460 Savigny-sur-Grosne'),
(3315,'575bis La Pique, 21130 Champdôtre');

INSERT INTO Organisation (numero,adresse) VALUES
(3316,'5 Grange du Crapaud, 17490 Bazauges'),
(3317,'763 La Tournelle, 57370 Mittelbronn');

INSERT INTO Organisation (numero,adresse) VALUES
(3318,'685 Ma Reine, 42640 Saint-Romain-la-Motte'),
(3319,'656 Le Triolet, 50160 Torigny-les-Villes');

INSERT INTO Organisation (numero,adresse) VALUES
(3320,'796 Coumo Loubero, 07270 Boucieu-le-Roi'),
(3321,'532 Chemin de Briquenay, 33840 Saint-Michel-de-Castelnau');

INSERT INTO Organisation (numero,adresse) VALUES
(3322,'723 Les Goreaux, 22250 Sévignac'),
(3323,'82 Les-grandes-gaudines, 21320 Essey');

INSERT INTO Organisation (numero,adresse) VALUES
(3324,'488 Saint Hubert, 01360 Béligneux'),
(3325,'73bis La Barbade, 72800 Coulongé');

INSERT INTO Organisation (numero,adresse) VALUES
(3326,'833 Les Clermonts Sud, 02600 Oigny-en-Valois'),
(3327,'91 Granges de Léo, 03450 Sussat');

INSERT INTO Organisation (numero,adresse) VALUES
(3328,'949bis Lons Appens, 36230 Neuvy-Saint-Sépulchre'),
(3329,'7 Domaine du Parc, 45510 Vannes-sur-Cosson');

INSERT INTO Organisation (numero,adresse) VALUES
(3330,'212bis Puech Cam, 09000 Ganac'),
(3331,'303 Moulin d’Aubignac, 57550 Berviller-en-Moselle');

INSERT INTO Organisation (numero,adresse) VALUES
(3332,'634 Les Savoyes, 55100 Vacherauville'),
(3333,'731 Trivalle, 02210 Billy-sur-Ourcq');

INSERT INTO Organisation (numero,adresse) VALUES
(3334,'264 Les Genevrieres, 07160 Saint-Michel-d''Aurance'),
(3335,'132 Montferrand, 61210 Bazoches-au-Houlme');

INSERT INTO Organisation (numero,adresse) VALUES
(3336,'826 Saint Martin, 74380 Nangy'),
(3337,'754 Lieu-dit les Coloumbet, 57170 Hampont');

INSERT INTO Organisation (numero,adresse) VALUES
(3338,'314 Courtal Fitou, 16710 Saint-Yrieix-sur-Charente'),
(3339,'263 La Croix de Provenchere, 77250 Villemer');

INSERT INTO Organisation (numero,adresse) VALUES
(3340,'52 Les Chaillots, 58700 Arzembouy'),
(3341,'17bis La Maurelière, 32350 Mirannes');

INSERT INTO Organisation (numero,adresse) VALUES
(3342,'784 Maeva, 27260 Le Bois-Hellain'),
(3343,'436 Raissac, 22290 Tréguidel');

INSERT INTO Organisation (numero,adresse) VALUES
(3344,'627 Le Meunier Noir, 52190 Le Val-d''Esnoms'),
(3345,'70bis """ Chantegrelet """, 71460 Saint-Marcelin-de-Cray');

INSERT INTO Organisation (numero,adresse) VALUES
(3346,'46 Les Crouzels, 16480 Oriolles'),
(3347,'89 Le Coustal, 71130 Vendenesse-sur-Arroux');

INSERT INTO Organisation (numero,adresse) VALUES
(3348,'69 Villa Ouf, 57810 Maizières-lès-Vic'),
(3349,'316 Canelle, 63670 La Roche-Blanche');

INSERT INTO Organisation (numero,adresse) VALUES
(3350,'225 Le Mas -de-Bastide, 33230 Les Églisottes-et-Chalaures'),
(3351,'139bis Rue de la Chaume-pillaud, 51170 Marfaux');

INSERT INTO Organisation (numero,adresse) VALUES
(3352,'343bis Les Positots, 37510 Villandry'),
(3353,'194 Corsin, 59233 Maing');

INSERT INTO Organisation (numero,adresse) VALUES
(3354,'519 Rue Louis Amésieu, 56190 Ambon'),
(3355,'854 Rue Charles de Gaulle, 57410 Bining');

INSERT INTO Organisation (numero,adresse) VALUES
(3356,'574bis La Peïruo, 02360 Archon'),
(3357,'188 Mayrinhac, 34700 Saint-Étienne-de-Gourgas');

INSERT INTO Organisation (numero,adresse) VALUES
(3358,'908bis Eychartet, 67140 Heiligenstein'),
(3359,'712 Parking de la Fighière, 16130 Ars');

INSERT INTO Organisation (numero,adresse) VALUES
(3360,'223 La Teule, 27370 Fouqueville'),
(3361,'775 Les Combeais, 80190 Villecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3362,'334 la Cruyatte, 09120 Saint-Félix-de-Rieutord'),
(3363,'733 Bella Vista, 76590 Les Cent-Acres');

INSERT INTO Organisation (numero,adresse) VALUES
(3364,'175bis Cadravals Haut, 06460 Escragnolles'),
(3365,'600 Palachin Est, 70220 Fougerolles');

INSERT INTO Organisation (numero,adresse) VALUES
(3366,'713bis Bât. G6, 04170 Lambruisse'),
(3367,'803 Bruguieras, 66210 Fontrabiouse');

INSERT INTO Organisation (numero,adresse) VALUES
(3368,'74 Rue du Levant, 01310 Montracol'),
(3369,'565 Route de la Bruyere, 04420 Prads-Haute-Bléone');

INSERT INTO Organisation (numero,adresse) VALUES
(3370,'115 Les Douze, 70130 Fretigney-et-Velloreille'),
(3371,'79 Lire Pire, 60350 Saint-Pierre-lès-Bitry');

INSERT INTO Organisation (numero,adresse) VALUES
(3372,'343 Bâtiment Les Violettes, 02130 Vézilly'),
(3373,'393 Rue de la Cuve, 15160 Allanche');

INSERT INTO Organisation (numero,adresse) VALUES
(3374,'775 Saint Gervais, 33160 Saint-Aubin-de-Médoc'),
(3375,'470bis Allée des Marguerites, 63220 Medeyrolles');

INSERT INTO Organisation (numero,adresse) VALUES
(3376,'425 La Beaumette, 18520 Bengy-sur-Craon'),
(3377,'491 À la Charité, 52190 Rivière-les-Fosses');

INSERT INTO Organisation (numero,adresse) VALUES
(3378,'277 Las Fustes, 24480 Le Buisson-de-Cadouin'),
(3379,'884bis Le Portal, 38290 La Verpillière');

INSERT INTO Organisation (numero,adresse) VALUES
(3380,'734 Les Couloubriers, 02680 Castres'),
(3381,'815 Masseau, 58330 Crux-la-Ville');

INSERT INTO Organisation (numero,adresse) VALUES
(3382,'23 Saint Igest, 09600 Le Peyrat'),
(3383,'406 Les Logis De La Mer A Et B, 57450 Barst');

INSERT INTO Organisation (numero,adresse) VALUES
(3384,'364 La Mejanie, 41250 Maslives'),
(3385,'890 Le Bas Plan, 62134 Boyaval');

INSERT INTO Organisation (numero,adresse) VALUES
(3386,'492bis la Grava, 42740 Doizieux'),
(3387,'779 Moulin d''en Haut, 77590 Fontaine-le-Port');

INSERT INTO Organisation (numero,adresse) VALUES
(3388,'566 Clabacon et la Preite, 15200 Le Vigean'),
(3389,'753bis Les Matriots, 24600 Saint-Pardoux-de-Drône');

INSERT INTO Organisation (numero,adresse) VALUES
(3390,'641 Villa La Rose, 27350 La Haye-de-Routot'),
(3391,'182 Brujidou, 47400 Villeton');

INSERT INTO Organisation (numero,adresse) VALUES
(3392,'234bis Résidence Les Tennis, 32200 Juilles'),
(3393,'969 Al Rieu, 02210 Armentières-sur-Ourcq');

INSERT INTO Organisation (numero,adresse) VALUES
(3394,'457bis Acy le bas, 57170 Lubécourt'),
(3395,'572bis Puech Palat, 42510 Balbigny');

INSERT INTO Organisation (numero,adresse) VALUES
(3396,'76 Grandveau, 30260 Cannes-et-Clairan'),
(3397,'271bis La Grabe, 14230 Géfosse-Fontenay');

INSERT INTO Organisation (numero,adresse) VALUES
(3398,'603bis Les Graves, 10200 Fresnay'),
(3399,'308 Quart En Reserve, 69200 Vénissieux');

INSERT INTO Organisation (numero,adresse) VALUES
(3400,'403bis Chemin d''exploitation n°1, 24460 Négrondes'),
(3401,'345 Rouze d''En Haut, 28290 Courtalain');

INSERT INTO Organisation (numero,adresse) VALUES
(3402,'660bis Le Puech d''Anglars, 62161 Agnez-lès-Duisans'),
(3403,'945 Le Causse de Nissac, 60440 Rosières');

INSERT INTO Organisation (numero,adresse) VALUES
(3404,'531 Lou Nidou, 39130 Étival'),
(3405,'538 Peyboué, 74350 Cruseilles');

INSERT INTO Organisation (numero,adresse) VALUES
(3406,'376bis Bus Nord, 35140 La Chapelle-Saint-Aubert'),
(3407,'400bis Les Hauts De Breguieres B1 B2 B3, 38290 Satolas-et-Bonce');

INSERT INTO Organisation (numero,adresse) VALUES
(3408,'800 Bernardille, 40370 Beylongue'),
(3409,'809bis Les Cigales, 02240 Brissay-Choigny');

INSERT INTO Organisation (numero,adresse) VALUES
(3410,'76 Pré des Narces, 59190 Hondeghem'),
(3411,'983 Les Pièces, 59124 Escaudain');

INSERT INTO Organisation (numero,adresse) VALUES
(3412,'985 Allée du Pont, 24160 Génis'),
(3413,'434 Cribas le Bas, 55200 Girauvoisin');

INSERT INTO Organisation (numero,adresse) VALUES
(3414,'214 Trezières, 12400 Les Costes-Gozon'),
(3415,'251 Frayssines, 51400 Billy-le-Grand');

INSERT INTO Organisation (numero,adresse) VALUES
(3416,'73 Chemin des Trop Pétris, 21290 Gurgy-le-Château'),
(3417,'258 EHPAD Les Magnolias, 67110 Oberbronn');

INSERT INTO Organisation (numero,adresse) VALUES
(3418,'10bis Lieu Dit Rochefort, 27180 Le Plessis-Grohan'),
(3419,'417 Bât A les Deux Moulins, 70140 Vadans');

INSERT INTO Organisation (numero,adresse) VALUES
(3420,'214 Impasse du Pont de Béraud, 35460 Tremblay'),
(3421,'174 Le Fragonard, 62153 Ablain-Saint-Nazaire');

INSERT INTO Organisation (numero,adresse) VALUES
(3422,'934 Pujade, 01800 Saint-Éloi'),
(3423,'61 Le Pérayret, 77230 Moussy-le-Neuf');

INSERT INTO Organisation (numero,adresse) VALUES
(3424,'429bis Le Serre, 54840 Sexey-les-Bois'),
(3425,'531 La-Marre, 71510 Essertenne');

INSERT INTO Organisation (numero,adresse) VALUES
(3426,'717 Route du Col de la Couillole, 27480 Lyons-la-Forêt'),
(3427,'149 Rue de l''Agal, 11380 Roquefère');

INSERT INTO Organisation (numero,adresse) VALUES
(3428,'555 Bâtiment Le grenadier, 45300 Bouilly-en-Gâtinais'),
(3429,'151 Les Agoutes, 10130 Courtaoult');

INSERT INTO Organisation (numero,adresse) VALUES
(3430,'71 Poucalbi, 61500 La Ferrière-Béchet'),
(3431,'669 Fouissagou, 52260 Chanoy');

INSERT INTO Organisation (numero,adresse) VALUES
(3432,'565 Résidence Port Plaisance, 61160 Villedieu-lès-Bailleul'),
(3433,'806 La Bonnetiere, 62650 Enquin-sur-Baillons');

INSERT INTO Organisation (numero,adresse) VALUES
(3434,'550 Valesques, 31130 Flourens'),
(3435,'187bis la jonchere, 60640 Fréniches');

INSERT INTO Organisation (numero,adresse) VALUES
(3436,'136 Mas Berthés, 03510 Chassenard'),
(3437,'396 Prés de Pargny, 76390 Nullemont');

INSERT INTO Organisation (numero,adresse) VALUES
(3438,'185bis L''Ensoleillado, 73350 Planay'),
(3439,'20 Le Grésil, 02450 La Neuville-lès-Dorengt');

INSERT INTO Organisation (numero,adresse) VALUES
(3440,'504bis Chassagne, 39250 Nozeroy'),
(3441,'968bis 1 ferme les morizets, 34420 Cers');

INSERT INTO Organisation (numero,adresse) VALUES
(3442,'581 Le Fosse Tire Louis, 78270 Rolleboise'),
(3443,'716bis Moulin Jaumeau, 32190 Vic-Fezensac');

INSERT INTO Organisation (numero,adresse) VALUES
(3444,'572 Villa Ouf, 32340 Miradoux'),
(3445,'118bis La Jonna, 74140 Excenevex');

INSERT INTO Organisation (numero,adresse) VALUES
(3446,'166bis Coste de Counil, 01480 Ars-sur-Formans'),
(3447,'769 Montiernoz, 11190 Camps-sur-l''Agly');

INSERT INTO Organisation (numero,adresse) VALUES
(3448,'991 Le Bancairon, 57535 Bronvaux'),
(3449,'779bis Chemin de las Coumes, 17620 La Gripperie-Saint-Symphorien');

INSERT INTO Organisation (numero,adresse) VALUES
(3450,'441 Patalus, 51300 Pringy'),
(3451,'328 La Molière Haute, 15130 Arpajon-sur-Cère');

INSERT INTO Organisation (numero,adresse) VALUES
(3452,'272 les Costes, 67270 Geiswiller-Zœbersdorf'),
(3453,'629bis """ La Gagnerie """, 11270 Brézilhac');

INSERT INTO Organisation (numero,adresse) VALUES
(3454,'388 Les Ormeaux, 36400 Lourouer-Saint-Laurent'),
(3455,'677 Graves de Ravouest, 14430 Saint-Léger-Dubosq');

INSERT INTO Organisation (numero,adresse) VALUES
(3456,'562bis La Peyrède, 10200 Proverville'),
(3457,'639bis Le Moulinel, 70140 Valay');

INSERT INTO Organisation (numero,adresse) VALUES
(3458,'251 Cayras, 50760 Gatteville-le-Phare'),
(3459,'486 Lavergne, 50190 Marchésieux');

INSERT INTO Organisation (numero,adresse) VALUES
(3460,'131bis Rue des Vosges, 51600 Aubérive'),
(3461,'184 Le Bois Grand, 01310 Saint-Rémy');

INSERT INTO Organisation (numero,adresse) VALUES
(3462,'715 Cailholie, 41210 Marcilly-en-Gault'),
(3463,'447 Vesvre, 67490 Littenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(3464,'544 Villa Tamaya, 34620 Puisserguier'),
(3465,'355bis Voie Communale La Pouge, 54260 Tellancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3466,'922 Jardin de Cessole, 18110 Allogny'),
(3467,'831 Bras, 42370 Renaison');

INSERT INTO Organisation (numero,adresse) VALUES
(3468,'142bis Claux de Lo Borio, 63530 Sayat'),
(3469,'143 Murlet, 39150 Grande-Rivière');

INSERT INTO Organisation (numero,adresse) VALUES
(3470,'108 Cabarroque, 32800 Ramouzens'),
(3471,'888 Les Besses, 25330 Saraz');

INSERT INTO Organisation (numero,adresse) VALUES
(3472,'521 Le Clos Netter, 16230 Saint-Groux'),
(3473,'144bis les palots, 03210 Chemilly');

INSERT INTO Organisation (numero,adresse) VALUES
(3474,'159 Lieu dit Charteix, 51490 Saint-Masmes'),
(3475,'874 Merli, 24450 Mialet');

INSERT INTO Organisation (numero,adresse) VALUES
(3476,'248bis Allée Bernard Schoeller, 34360 Prades-sur-Vernazobre'),
(3477,'811 Les Chandelières, 63000 Clermont-Ferrand');

INSERT INTO Organisation (numero,adresse) VALUES
(3478,'246 lieu-dit BELFORT HAUT, 22500 Kerfot'),
(3479,'984 La Pesquie, 01110 Thézillieu');

INSERT INTO Organisation (numero,adresse) VALUES
(3480,'103 Les Sillets, 67470 Schaffhouse-près-Seltz'),
(3481,'862bis Lanzano, 10280 Saint-Mesmin');

INSERT INTO Organisation (numero,adresse) VALUES
(3482,'153 Le Poumayriol, 69290 Saint-Genis-les-Ollières'),
(3483,'304 Déchetterie Intercommunale, 51800 Élise-Daucourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3484,'722 Chirol, 33650 Martillac'),
(3485,'828 Le Carreau Manceau, 54470 Dommartin-la-Chaussée');

INSERT INTO Organisation (numero,adresse) VALUES
(3486,'371 Courty Dalége, 09310 Les Cabannes'),
(3487,'822 Fourchue Pallas, 72460 Savigné-l''Évêque');

INSERT INTO Organisation (numero,adresse) VALUES
(3488,'151 Les Sansous, 64270 Labastide-Villefranche'),
(3489,'236 Grange de Bac, 20217 Saint-Florent');

INSERT INTO Organisation (numero,adresse) VALUES
(3490,'889bis Le Rank, 77260 Sainte-Aulde'),
(3491,'912 Centre Commercial Salvaza, 52000 Condes');

INSERT INTO Organisation (numero,adresse) VALUES
(3492,'555 La Montagne des Chevres, 51160 Fontaine-sur-Ay'),
(3493,'313 La Boriote, 12300 Flagnac');

INSERT INTO Organisation (numero,adresse) VALUES
(3494,'440 Petit Puy, 69001 Lyon 01'),
(3495,'971 Le Grand Lieu, 27520 Thénouville');

INSERT INTO Organisation (numero,adresse) VALUES
(3496,'860 Bec de Jun, 27600 Heudebouville'),
(3497,'706 La Roziere Basse, 16150 Chabanais');

INSERT INTO Organisation (numero,adresse) VALUES
(3498,'142 Parking des Muriers, 62820 Libercourt'),
(3499,'203 Le Cayre, 64420 Limendous');

INSERT INTO Organisation (numero,adresse) VALUES
(3500,'301 Les Mimosas, 58310 Saint-Vérain'),
(3501,'955bis Grand Cerisier, 63160 Neuville');

INSERT INTO Organisation (numero,adresse) VALUES
(3502,'511bis Vira Souleu, 31290 Villefranche-de-Lauragais'),
(3503,'334 Fénatéou, 79420 Clavé');

INSERT INTO Organisation (numero,adresse) VALUES
(3504,'371 Les Prairies, 52260 Beauchemin'),
(3505,'281 Campagnac, 16310 Le Lindois');

INSERT INTO Organisation (numero,adresse) VALUES
(3506,'409 Saint Amans Recoules P, 09500 Lapenne'),
(3507,'784bis Nemausa, 13980 Alleins');

INSERT INTO Organisation (numero,adresse) VALUES
(3508,'765 Avenue de la Plaine du Baylé, 31230 Anan'),
(3509,'922 Le Château du Mont, 40210 Labouheyre');

INSERT INTO Organisation (numero,adresse) VALUES
(3510,'592 Route du Bourg, 31370 Rieumes'),
(3511,'456bis Timonet, 02190 Lor');

INSERT INTO Organisation (numero,adresse) VALUES
(3512,'159 Pont de Grandfuel, 61300 Vitrai-sous-Laigle'),
(3513,'681 Gorge des Pres, 67860 Friesenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(3514,'282 Bordes, 54330 Forcelles-Saint-Gorgon'),
(3515,'905bis Le Puech des Hems, 77169 Boissy-le-Châtel');

INSERT INTO Organisation (numero,adresse) VALUES
(3516,'317 La_bache, 14340 Crèvecœur-en-Auge'),
(3517,'181bis Kiti, 49270 Orée d''Anjou');

INSERT INTO Organisation (numero,adresse) VALUES
(3518,'251 Le Camps des Romains, 43420 Saint-Arcons-de-Barges'),
(3519,'824bis Charlabeta, 79800 Salles');

INSERT INTO Organisation (numero,adresse) VALUES
(3520,'182bis Bairal, 60510 Le Fay-Saint-Quentin'),
(3521,'265bis Le Sorbier, 18300 Saint-Satur');

INSERT INTO Organisation (numero,adresse) VALUES
(3522,'304 Le Quartier Neuf, 77730 Citry'),
(3523,'987 Les Grands Près, 80200 Cizancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3524,'45 Castagnal d''Albin, 42370 Saint-Rirand'),
(3525,'948 Impasse du Pou Volant, 60850 Lalandelle');

INSERT INTO Organisation (numero,adresse) VALUES
(3526,'847 Sarbaute, 30340 Salindres'),
(3527,'799 Planétrieux, 65380 Azereix');

INSERT INTO Organisation (numero,adresse) VALUES
(3528,'960 Les Côtes Rouges, 39570 La Chailleuse'),
(3529,'498 Givarlais, 57200 Sarreguemines');

INSERT INTO Organisation (numero,adresse) VALUES
(3530,'580bis L''Oustalou, 52800 Lanques-sur-Rognon'),
(3531,'864 Escalier liaison avenue de la Forêt Avenue Cyrille Besset au n°115, 33470 Le Teich');

INSERT INTO Organisation (numero,adresse) VALUES
(3532,'829 Rue Jean Brunet, 63320 Ludesse'),
(3533,'776 Le Mas de Garric, 13110 Port-de-Bouc');

INSERT INTO Organisation (numero,adresse) VALUES
(3534,'228 Voie liaison Avenue Raymond Féraud n°32 Avenue Raymond Féraud n°50, 30260 Saint-Théodorit'),
(3535,'380 La Noue Flava, 71110 Chambilly');

INSERT INTO Organisation (numero,adresse) VALUES
(3536,'271bis Prost, 64121 Montardon'),
(3537,'556 Croix de Lenne, 07460 Saint-André-de-Cruzières');

INSERT INTO Organisation (numero,adresse) VALUES
(3538,'237 Le Crucifix, 80220 Maisnières'),
(3539,'240 Le Clausach, 61380 Moulins-la-Marche');

INSERT INTO Organisation (numero,adresse) VALUES
(3540,'107bis Le Pont du Loup, 22480 Sainte-Tréphine'),
(3541,'393bis Les Burles, 26170 Rioms');

INSERT INTO Organisation (numero,adresse) VALUES
(3542,'35 Petite Fache, 70320 La Vaivre'),
(3543,'744 Bonmort, 76360 Villers-Écalles');

INSERT INTO Organisation (numero,adresse) VALUES
(3544,'144 Rochebert, 33370 Artigues-près-Bordeaux'),
(3545,'949 Rabiere, 57220 Charleville-sous-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(3546,'428 Les Escons Partie-sud, 34710 Lespignan'),
(3547,'690 Tromparent, 80150 Vitz-sur-Authie');

INSERT INTO Organisation (numero,adresse) VALUES
(3548,'42 La Combe de Vaure, 08390 Le Mont-Dieu'),
(3549,'398 Les Logis De La Mer A Et B, 16110 La Rochefoucauld');

INSERT INTO Organisation (numero,adresse) VALUES
(3550,'932 La Chaponnière, 18350 Mornay-Berry'),
(3551,'707 Belmont, 14270 Percy-en-Auge');

INSERT INTO Organisation (numero,adresse) VALUES
(3552,'405 Les Aigues, 74120 Megève'),
(3553,'136 Serre Nouveau, 08260 Auvillers-les-Forges');

INSERT INTO Organisation (numero,adresse) VALUES
(3554,'560 La Casa, 11270 Orsans'),
(3555,'271bis Traverse du Cimetière, 42260 Saint-Polgues');

INSERT INTO Organisation (numero,adresse) VALUES
(3556,'352bis """ Les Brelans """, 31280 Aigrefeuille'),
(3557,'800 Hameau d''En Bonis, 08360 Taizy');

INSERT INTO Organisation (numero,adresse) VALUES
(3558,'70 Place du Barbier, 42410 Pavezin'),
(3559,'956 Résidence L''Etoile du Sud, 09140 Ustou');

INSERT INTO Organisation (numero,adresse) VALUES
(3560,'902 Vers la Rencontre, 71290 Préty'),
(3561,'211 Bois de Berlise, 32110 Panjas');

INSERT INTO Organisation (numero,adresse) VALUES
(3562,'602 St Maurice, 21270 Tellecey'),
(3563,'375 Villa Marie, 06220 Vallauris');

INSERT INTO Organisation (numero,adresse) VALUES
(3564,'14 Moulin de Landes, 07230 Saint-André-Lachamp'),
(3565,'782 La Ribeyre, 65140 Tostat');

INSERT INTO Organisation (numero,adresse) VALUES
(3566,'930 la Casseprunie, 70130 Vanne'),
(3567,'124 Domaine de Chassimpierre, 62128 Guémappe');

INSERT INTO Organisation (numero,adresse) VALUES
(3568,'739 Voie Verte, 61210 Bazoches-au-Houlme'),
(3569,'143bis lieu dit les Fontanelles, 01320 Châtillon-la-Palud');

INSERT INTO Organisation (numero,adresse) VALUES
(3570,'241bis Villa Fiorentina, 63850 Égliseneuve-d''Entraigues'),
(3571,'801bis Champ Bourdon, 68610 Lautenbach');

INSERT INTO Organisation (numero,adresse) VALUES
(3572,'27 Le Candeou-Ouest, 09160 Taurignan-Castet'),
(3573,'401 Clairefontaine C Et D, 42230 Saint-Étienne');

INSERT INTO Organisation (numero,adresse) VALUES
(3574,'247bis Le Clos Des Bréguières, 25580 Étalans'),
(3575,'178 La Librette, 43380 Aubazat');

INSERT INTO Organisation (numero,adresse) VALUES
(3576,'811bis Les fournils, 65700 Lascazères'),
(3577,'75 La Fubia, 67330 Neuwiller-lès-Saverne');

INSERT INTO Organisation (numero,adresse) VALUES
(3578,'727 Champ du Bourg, 61250 Saint-Céneri-le-Gérei'),
(3579,'989 Ile_ten_te_be, 39190 Vercia');

INSERT INTO Organisation (numero,adresse) VALUES
(3580,'415 Chemin du Vallon Monari, 21320 Châteauneuf'),
(3581,'121bis Les Gouthérauds, 60250 Bury');

INSERT INTO Organisation (numero,adresse) VALUES
(3582,'246 Rue du Rial, 57530 Coincy'),
(3583,'567 Le Haut de Culronde, 15500 Charmensac');

INSERT INTO Organisation (numero,adresse) VALUES
(3584,'806bis Le Cantonier, 32170 Sainte-Dode'),
(3585,'792 Rue du Hélin, 12500 Lassouts');

INSERT INTO Organisation (numero,adresse) VALUES
(3586,'329 Les Gouilles, 76490 Saint-Arnoult'),
(3587,'325 En Limorin Nord, 71960 Bussières');

INSERT INTO Organisation (numero,adresse) VALUES
(3588,'996 Mourviel, 17510 Les Éduts'),
(3589,'45bis Les Roussettes, 38260 Mottier');

INSERT INTO Organisation (numero,adresse) VALUES
(3590,'710 Laval Haute, 65330 Tournous-Devant'),
(3591,'539 Vers Fromentau, 73240 Champagneux');

INSERT INTO Organisation (numero,adresse) VALUES
(3592,'133 Voie d''accès nord Quai la Perouse, 50500 Méautis'),
(3593,'485bis La Quinaude, 50490 La Ronde-Haye');

INSERT INTO Organisation (numero,adresse) VALUES
(3594,'577 Vielmont, 14100 L''Hôtellerie'),
(3595,'526 La Pourquière, 47500 Blanquefort-sur-Briolance');

INSERT INTO Organisation (numero,adresse) VALUES
(3596,'839bis Lieu-dit Biarsses Hautes, 50490 La Ronde-Haye'),
(3597,'917bis Verchere Berthelet, 06440 Peille');

INSERT INTO Organisation (numero,adresse) VALUES
(3598,'216bis Rue Robert Thivin, 36100 Vouillon'),
(3599,'589bis Bégües, 31110 Benque-Dessous-et-Dessus');

INSERT INTO Organisation (numero,adresse) VALUES
(3600,'760 La Croix Saint Jean, 39230 Vers-sous-Sellières'),
(3601,'987 La Chaze Haute, 21630 Pommard');

INSERT INTO Organisation (numero,adresse) VALUES
(3602,'791 Laroque-Bouillac, 01360 Béligneux'),
(3603,'27 Route du Col de Buire, 21290 Recey-sur-Ource');

INSERT INTO Organisation (numero,adresse) VALUES
(3604,'275bis Route de l''Escrinet, 72350 Avessé'),
(3605,'658bis Bosquet Misère, 29600 Saint-Martin-des-Champs');

INSERT INTO Organisation (numero,adresse) VALUES
(3606,'292bis La motte, 12500 Le Cayrol'),
(3607,'549bis La Pièce à la Saulx, 44260 Savenay');

INSERT INTO Organisation (numero,adresse) VALUES
(3608,'678 Quartier Sambuc, 02330 Courboin'),
(3609,'1 Hameau de Banchin, 54200 Villey-Saint-Étienne');

INSERT INTO Organisation (numero,adresse) VALUES
(3610,'546 Les Maisons de la Mer 2 entrée 1, 11200 Argens-Minervois'),
(3611,'593 Le Parc Des Soldanelles A/B, 14700 Saint-Martin-de-Mieux');

INSERT INTO Organisation (numero,adresse) VALUES
(3612,'422 lieu-dit Rajol, 52100 Bettancourt-la-Ferrée'),
(3613,'828 Champ Jacques, 41100 Villiersfaux');

INSERT INTO Organisation (numero,adresse) VALUES
(3614,'329 As Paichous, 38300 Châteauvilain'),
(3615,'428 Montbioure, 64460 Labatut');

INSERT INTO Organisation (numero,adresse) VALUES
(3616,'136 Manaud, 12250 Tournemire'),
(3617,'176 Parc Mérovingien, 53300 Oisseau');

INSERT INTO Organisation (numero,adresse) VALUES
(3618,'443 La Contesterie, 76460 Drosay'),
(3619,'939 Le Petit Garayt, 76770 Malaunay');

INSERT INTO Organisation (numero,adresse) VALUES
(3620,'960 Pré Lafouan, 80240 Guyencourt-Saulcourt'),
(3621,'858 Les Fosses Grands Jean, 09130 Sainte-Suzanne');

INSERT INTO Organisation (numero,adresse) VALUES
(3622,'903bis En Leurperon, 65190 Lespouey'),
(3623,'106 Gabet, 03250 Châtel-Montagne');

INSERT INTO Organisation (numero,adresse) VALUES
(3624,'173bis Impasse des Commandeurs, 48340 Saint-Pierre-de-Nogaret'),
(3625,'800 Lieu-dit la tour, 44800 Saint-Herblain');

INSERT INTO Organisation (numero,adresse) VALUES
(3626,'642 Moulin de la Barlatte, 69390 Vourles'),
(3627,'415bis Lamalayrède, 54490 Joudreville');

INSERT INTO Organisation (numero,adresse) VALUES
(3628,'522 Le Seguinat, 27150 Hébécourt'),
(3629,'357 Les Bedils et Pailholo, 15110 Espinasse');

INSERT INTO Organisation (numero,adresse) VALUES
(3630,'688 Place Centrale, 48000 Lanuéjols'),
(3631,'870 Caton, 39240 La Boissière');

INSERT INTO Organisation (numero,adresse) VALUES
(3632,'86 Square François Pierre Cerutti, 80250 Louvrechy'),
(3633,'264 La Colline Aux Oliviers, 03200 Vichy');

INSERT INTO Organisation (numero,adresse) VALUES
(3634,'254 Courreste, 15600 Montmurat'),
(3635,'477 En Buisson, 55150 Villers-lès-Mangiennes');

INSERT INTO Organisation (numero,adresse) VALUES
(3636,'68 Le Rhan, 59218 Neuville-en-Avesnois'),
(3637,'573 Pladerum, 10120 Saint-Germain');

INSERT INTO Organisation (numero,adresse) VALUES
(3638,'841 Bois-Girard, 73240 Saint-Maurice-de-Rotherens'),
(3639,'185 Rue du Foyer, 60112 Bonnières');

INSERT INTO Organisation (numero,adresse) VALUES
(3640,'194 Raccourci Avenue de la Lanterne, 02590 Lanchy'),
(3641,'905 Abri bus scolaire, 25660 Mérey-sous-Montrond');

INSERT INTO Organisation (numero,adresse) VALUES
(3642,'255bis Tureluro, 05190 Rousset'),
(3643,'62 couleurs du temps - appt 2, 66280 Saleilles');

INSERT INTO Organisation (numero,adresse) VALUES
(3644,'813bis Villa Santanna, 19340 Merlines'),
(3645,'161bis En Libernet, 60730 Lachapelle-Saint-Pierre');

INSERT INTO Organisation (numero,adresse) VALUES
(3646,'549 Domaine du Piccolaret, 03360 Ainay-le-Château'),
(3647,'618 Résidence Villa Azur, 66500 Catllar');

INSERT INTO Organisation (numero,adresse) VALUES
(3648,'378bis Le Mas de Frayssinhes, 17210 Chatenet'),
(3649,'466 Le Pugneret, 64360 Monein');

INSERT INTO Organisation (numero,adresse) VALUES
(3650,'806 Parc Emeraude, 54490 Piennes'),
(3651,'442 Les Bartres du Rocher, 34600 Caussiniojouls');

INSERT INTO Organisation (numero,adresse) VALUES
(3652,'230 Chenevis, 63580 Chaméane'),
(3653,'417 Plan de Becouze, 24800 Saint-Martin-de-Fressengeas');

INSERT INTO Organisation (numero,adresse) VALUES
(3654,'18 La Pilière Haute, 01150 Lagnieu'),
(3655,'682 Le Corail, 22460 Allineuc');

INSERT INTO Organisation (numero,adresse) VALUES
(3656,'6 Chemin de la Place, 67630 Neewiller-près-Lauterbourg'),
(3657,'796 Lagasse, 40250 Mugron');

INSERT INTO Organisation (numero,adresse) VALUES
(3658,'395bis """ Champaigue """, 72170 Vernie'),
(3659,'296bis Florazur A, 07580 Saint-Pons');

INSERT INTO Organisation (numero,adresse) VALUES
(3660,'350 Le Puech de Balsac, 25620 Charbonnières-les-Sapins'),
(3661,'278 La Bastisse, 31370 Monès');

INSERT INTO Organisation (numero,adresse) VALUES
(3662,'248 Dessous La Grange, 61800 Moncy'),
(3663,'993 La Ruchelle, 68150 Ribeauvillé');

INSERT INTO Organisation (numero,adresse) VALUES
(3664,'701 Clot de Leve, 27930 Saint-Vigor'),
(3665,'918 Res Du Port A2, 57480 Ritzing');

INSERT INTO Organisation (numero,adresse) VALUES
(3666,'533bis Lieu-Dit Le Plan, 63120 Vollore-Montagne'),
(3667,'481 Hameau Mon Idée, 69390 Millery');

INSERT INTO Organisation (numero,adresse) VALUES
(3668,'694bis Voie Romaine, 42130 Débats-Rivière-d''Orpra'),
(3669,'88 Liaison Rue de l Eglise/Rue des Doriers, 02600 Fleury');

INSERT INTO Organisation (numero,adresse) VALUES
(3670,'496bis La Chaumine, 14260 Seulline'),
(3671,'110 La Vignola, 70190 Rioz');

INSERT INTO Organisation (numero,adresse) VALUES
(3672,'648 Champfeu, 69126 Brindas'),
(3673,'497bis La Rouge, 10800 Saint-Thibault');

INSERT INTO Organisation (numero,adresse) VALUES
(3674,'221bis Le Renvers de Conroy, 08190 Brienne-sur-Aisne'),
(3675,'956 La Baudre, 21330 Bouix');

INSERT INTO Organisation (numero,adresse) VALUES
(3676,'574 Vieille Forge, 07250 Rompon'),
(3677,'598 Les Magnolias, 60240 Fresne-Léguillon');

INSERT INTO Organisation (numero,adresse) VALUES
(3678,'42bis Champ de la Marie, 78980 Saint-Illiers-la-Ville'),
(3679,'697 La Saulaie, 80430 Le Quesne');

INSERT INTO Organisation (numero,adresse) VALUES
(3680,'54 Boissard, 48210 Gorges du Tarn Causses'),
(3681,'836 La Baraque de Vors, 76730 Sassetot-le-Malgardé');

INSERT INTO Organisation (numero,adresse) VALUES
(3682,'19 Le Vignaou, 46270 Bagnac-sur-Célé'),
(3683,'626 Les Tourneyres, 07160 Saint-Barthélemy-le-Meil');

INSERT INTO Organisation (numero,adresse) VALUES
(3684,'325 La Hajelette, 51270 La Chapelle-sous-Orbais'),
(3685,'665 Sarameille Nord, 24530 Quinsac');

INSERT INTO Organisation (numero,adresse) VALUES
(3686,'189bis Cezes, 72600 Saosnes'),
(3687,'595bis Les Gouilles, 26170 Beauvoisin');

INSERT INTO Organisation (numero,adresse) VALUES
(3688,'384bis Montfaucon d''en haut, 38350 Saint-Pierre-de-Méaroz'),
(3689,'184 Le Ventavon, 60310 Candor');

INSERT INTO Organisation (numero,adresse) VALUES
(3690,'974 Chemin des Plantades, 63410 Charbonnières-les-Vieilles'),
(3691,'267 Verte Bastide, 55120 Lachalade');

INSERT INTO Organisation (numero,adresse) VALUES
(3692,'539 Place de l''Eglise à St Jean, 46350 Lamothe-Fénelon'),
(3693,'624 Les Grands Riez, 77133 Féricy');

INSERT INTO Organisation (numero,adresse) VALUES
(3694,'266 Font Sainte, 46250 Marminiac'),
(3695,'52bis Ferme de Peyrouvier, 23130 Issoudun-Létrieix');

INSERT INTO Organisation (numero,adresse) VALUES
(3696,'125bis Buffan, 41110 Châteauvieux'),
(3697,'125 Mas Atché, 33540 Mesterrieux');

INSERT INTO Organisation (numero,adresse) VALUES
(3698,'462 La Rue de Bechaue, 30390 Théziers'),
(3699,'62 Ferme de Tinselves, 55000 Chardogne');

INSERT INTO Organisation (numero,adresse) VALUES
(3700,'370bis Résidence les Allées du Bourg, 27150 Martagny'),
(3701,'380 Bat I, 34220 Verreries-de-Moussans');

INSERT INTO Organisation (numero,adresse) VALUES
(3702,'624bis Chez Rebouin, 30210 Lédenon'),
(3703,'652 Les Fondes, 62136 Richebourg');

INSERT INTO Organisation (numero,adresse) VALUES
(3704,'22 Grange de la Lebouse, 43160 Félines'),
(3705,'418 Gary, 29550 Ploéven');

INSERT INTO Organisation (numero,adresse) VALUES
(3706,'580 Brandières, 59182 Loffre'),
(3707,'835 Pra Battaglier, 14370 Argences');

INSERT INTO Organisation (numero,adresse) VALUES
(3708,'455 Bois de cross, 19110 Bort-les-Orgues'),
(3709,'781bis Cros de Meyras, 60150 Thourotte');

INSERT INTO Organisation (numero,adresse) VALUES
(3710,'408 Zone Artisanale Delta Sud, 62127 Ambrines'),
(3711,'225 Alpy, 08410 Boulzicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3712,'146bis Hameau de Castanviels, 23300 Saint-Priest-la-Feuille'),
(3713,'232 Les Boudards, 27510 Tilly');

INSERT INTO Organisation (numero,adresse) VALUES
(3714,'448 Hameau de Vorages d’En Bas, 16130 Angeac-Champagne'),
(3715,'819bis Fevrier Nord, 57340 Suisse');

INSERT INTO Organisation (numero,adresse) VALUES
(3716,'460bis Pré des Rivieres, 34600 Taussac-la-Billière'),
(3717,'546 La Casse, 29860 Bourg-Blanc');

INSERT INTO Organisation (numero,adresse) VALUES
(3718,'249 Lotissement Plein Sud, 03150 Montaigu-le-Blin'),
(3719,'174 Casa Capella, 77320 Saint-Barthélemy');

INSERT INTO Organisation (numero,adresse) VALUES
(3720,'58bis Russol, 33490 Semens'),
(3721,'142 Pouloumoun, 43300 Chazelles');

INSERT INTO Organisation (numero,adresse) VALUES
(3722,'513 Aux Petites Mangettes, 02160 Chaudardes'),
(3723,'886bis Voie de liaison Avenue Chateaubriand Avenue Henry Dunant, 10100 Saint-Loup-de-Buffigny');

INSERT INTO Organisation (numero,adresse) VALUES
(3724,'609 Le Misaudor, 06420 Roure'),
(3725,'571 Impasse Auguste Donnet, 16500 Saint-Maurice-des-Lions');

INSERT INTO Organisation (numero,adresse) VALUES
(3726,'340 Domaine de Rigou, 36200 Argenton-sur-Creuse'),
(3727,'305 Le Domaine du Bois, 39150 Nanchez');

INSERT INTO Organisation (numero,adresse) VALUES
(3728,'574 Chemin Rural Dit de la Comtesse, 41300 Selles-Saint-Denis'),
(3729,'61 Tournebouich, 41220 La Ferté-Saint-Cyr');

INSERT INTO Organisation (numero,adresse) VALUES
(3730,'176bis Le Bessoul, 34700 Pégairolles-de-l''Escalette'),
(3731,'547 Hameau de Larremassadou, 62130 Brias');

INSERT INTO Organisation (numero,adresse) VALUES
(3732,'614bis Le Pas Redon, 14700 Fourneaux-le-Val'),
(3733,'393 Square  Sofiane Ouggad, 41370 La Madeleine-Villefrouin');

INSERT INTO Organisation (numero,adresse) VALUES
(3734,'361bis Place  Braille, 03190 Estivareilles'),
(3735,'138 Maint Dieu, 12000 Le Monastère');

INSERT INTO Organisation (numero,adresse) VALUES
(3736,'69 Cote-de-la-coliniere, 01280 Prévessin-Moëns'),
(3737,'381 domaine d''Arnauteille, 22830 Plouasne');

INSERT INTO Organisation (numero,adresse) VALUES
(3738,'932 La Paret, 36170 Vigoux'),
(3739,'259bis Bas-Chassagne, 29170 Pleuven');

INSERT INTO Organisation (numero,adresse) VALUES
(3740,'210 Le Vigne d’Agnac, 53640 Montreuil-Poulay'),
(3741,'420 Villa Sans Nom, 80200 Brie');

INSERT INTO Organisation (numero,adresse) VALUES
(3742,'783 Le Bois de Lislet, 71520 Tramayes'),
(3743,'994 Le LUC, 69410 Champagne-au-Mont-d''Or');

INSERT INTO Organisation (numero,adresse) VALUES
(3744,'408 Les Lucayas E, 27290 Thierville'),
(3745,'597 Les Coumanines, 18000 Bourges');

INSERT INTO Organisation (numero,adresse) VALUES
(3746,'230 Aubusson, 03140 Fleuriel'),
(3747,'813bis Hameau de Castanviels, 80140 Arguel');

INSERT INTO Organisation (numero,adresse) VALUES
(3748,'157bis Les Longs Pres, 25210 Montbéliardot'),
(3749,'235bis Cot, 62223 Saint-Laurent-Blangy');

INSERT INTO Organisation (numero,adresse) VALUES
(3750,'102 Saint Quentin, 73790 Tours-en-Savoie'),
(3751,'441 Chemin des Cappan (antenne 2), 80140 Neuville-au-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(3752,'14 Residence Beauregard, 59267 Flesquières'),
(3753,'845 Chemin de Tiragallo, 10360 Noé-les-Mallets');

INSERT INTO Organisation (numero,adresse) VALUES
(3754,'845 Noire Fontaine, 12100 Creissels'),
(3755,'178 Le Chapy, 20212 Alando');

INSERT INTO Organisation (numero,adresse) VALUES
(3756,'544 Moulin d''En Haut, 70500 Ouge'),
(3757,'63bis Le Miramar B, 27150 Mesnil-sous-Vienne');

INSERT INTO Organisation (numero,adresse) VALUES
(3758,'840 Route de saint Pourçain, 77114 Gouaix'),
(3759,'614bis Les Cabanes, 21500 Marmagne');

INSERT INTO Organisation (numero,adresse) VALUES
(3760,'568 Lieu-dit Guyotet, 30490 Montfrin'),
(3761,'438 La Terrasse et la Nataille, 19550 Soursac');

INSERT INTO Organisation (numero,adresse) VALUES
(3762,'810bis Tombalier, 40120 Sarbazan'),
(3763,'498 Le Valvert, 77730 Citry');

INSERT INTO Organisation (numero,adresse) VALUES
(3764,'643 Artigues, 03800 Le Mayet-d''École'),
(3765,'536bis Les Daniels, 48140 Paulhac-en-Margeride');

INSERT INTO Organisation (numero,adresse) VALUES
(3766,'306 Cimetiere 5 les Vignals, 60800 Lévignen'),
(3767,'594bis Route de Saint Jean, 62140 Wambercourt');

INSERT INTO Organisation (numero,adresse) VALUES
(3768,'6bis Impasse du Vieux Verger, 31360 Mancioux'),
(3769,'560bis Capitainerie, 10330 Pars-lès-Chavanges');

INSERT INTO Organisation (numero,adresse) VALUES
(3770,'413 La Palice, 64170 Labastide-Cézéracq'),
(3771,'20 Les Loges Barrault, 50320 La Lucerne-d''Outremer');

INSERT INTO Organisation (numero,adresse) VALUES
(3772,'53 Le Moulin de Navarre, 29120 Combrit'),
(3773,'693bis Bail, 64400 Eysus');

INSERT INTO Organisation (numero,adresse) VALUES
(3774,'767 Les Abatis et Rouva, 73590 La Giettaz'),
(3775,'332 Espace Charles de Gaulle, 08110 Williers');

INSERT INTO Organisation (numero,adresse) VALUES
(3776,'823bis Les Dorards, 61170 Bures'),
(3777,'338 Res De La Baie A5, 66470 Sainte-Marie-la-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(3778,'733 Font-Patine, 57412 Kalhausen'),
(3779,'169 Le Chan Baudoin, 63390 Espinasse');

INSERT INTO Organisation (numero,adresse) VALUES
(3780,'167bis Notre Dame de la Roudoule, 19210 Saint-Martin-Sepert'),
(3781,'910 La Cailholie, 63290 Ris');

INSERT INTO Organisation (numero,adresse) VALUES
(3782,'117 Blâches-Gombert, 04500 Riez'),
(3783,'725 Chadenas de l''Adreyt, 14610 Colomby-Anguerny');

INSERT INTO Organisation (numero,adresse) VALUES
(3784,'3 Font du Rocher, 31700 Cornebarrieu'),
(3785,'237 Clair Lotis, 63580 Saint-Genès-la-Tourette');

INSERT INTO Organisation (numero,adresse) VALUES
(3786,'875 Grand Dergis - Hauteville Lompnes, 53800 Saint-Martin-du-Limet'),
(3787,'240 Les Emoutouses, 62127 Ternas');

INSERT INTO Organisation (numero,adresse) VALUES
(3788,'328 Moulin de Vavres, 01210 Versonnex'),
(3789,'276 Bondance, 53290 Saint-Laurent-des-Mortiers');

INSERT INTO Organisation (numero,adresse) VALUES
(3790,'668bis Chemin de l''Aco de Martin, 52260 Faverolles'),
(3791,'5bis La Vallette, 29440 Trézilidé');

INSERT INTO Organisation (numero,adresse) VALUES
(3792,'91bis Parvis des Invalides, 09120 Cazaux'),
(3793,'664 Pré Courtin, 66210 Formiguères');

INSERT INTO Organisation (numero,adresse) VALUES
(3794,'966 Las Coumettos, 05150 Ribeyret'),
(3795,'474 Cougousse, 02840 Samoussy');

INSERT INTO Organisation (numero,adresse) VALUES
(3796,'977 Bellevesasses-sud, 01200 Billiat'),
(3797,'287 Rimonas, 68470 Husseren-Wesserling');

INSERT INTO Organisation (numero,adresse) VALUES
(3798,'829bis Riviera Parc A/B, 76640 Cliponville'),
(3799,'579bis Le Vieux Port, 33750 Baron');

INSERT INTO Organisation (numero,adresse) VALUES
(3800,'119bis Avenue Vigneronne, 52210 Villiers-sur-Suize'),
(3801,'900 L''Ouche Copin, 16300 Montmérac');

INSERT INTO Organisation (numero,adresse) VALUES
(3802,'391 Square Aimé Césaire, 26150 Barsac'),
(3803,'446bis Arculet, 52200 Saint-Martin-lès-Langres');

INSERT INTO Organisation (numero,adresse) VALUES
(3804,'274 Le Bois Randenay, 31800 Lodes'),
(3805,'774 Rieze de la Gruerie, 34820 Teyran');

INSERT INTO Organisation (numero,adresse) VALUES
(3806,'264 En Vernoset, 28360 La Bourdinière-Saint-Loup'),
(3807,'800 Residence le Ventoux, 43190 Tence');

INSERT INTO Organisation (numero,adresse) VALUES
(3808,'142 Le Civadal, 47140 Trémons'),
(3809,'401 Puech Moulènes, 40330 Brassempouy');

INSERT INTO Organisation (numero,adresse) VALUES
(3810,'325bis Laramade d''en Bas, 50480 Ravenoville'),
(3811,'445 La Laurence, 66450 Pollestres');

INSERT INTO Organisation (numero,adresse) VALUES
(3812,'706 Terouilhas, 18300 Saint-Satur'),
(3813,'746bis Le Vavrin, 57410 Siersthal');

INSERT INTO Organisation (numero,adresse) VALUES
(3814,'892 Le Verdie, 77950 Maincy'),
(3815,'819bis Baudis, 21220 Chevannes');

INSERT INTO Organisation (numero,adresse) VALUES
(3816,'777 Le Riva Bella E, 36260 Diou'),
(3817,'494 Les Potiers, 64570 Aramits');

INSERT INTO Organisation (numero,adresse) VALUES
(3818,'969 La Chave, 02120 Flavigny-le-Grand-et-Beaurain'),
(3819,'862bis Les Violettes, 39600 Vadans');

INSERT INTO Organisation (numero,adresse) VALUES
(3820,'481 Saint Roger, 38520 Villard-Reymond'),
(3821,'154 le Village, 31210 Clarac');

INSERT INTO Organisation (numero,adresse) VALUES
(3822,'426bis Le Bois Redon, 73700 Montvalezan'),
(3823,'36 Villa Marie Rene, 47180 Lagupie');

INSERT INTO Organisation (numero,adresse) VALUES
(3824,'895 La Crotte d''Oie, 60130 Quinquempoix'),
(3825,'916 Le Bois de Chérost, 51390 Bouilly');

INSERT INTO Organisation (numero,adresse) VALUES
(3826,'779 Montiernoz, 57220 Boulay-Moselle'),
(3827,'266 Lieu-dit Portet Las Rives, 61240 Ménil-Froger');

INSERT INTO Organisation (numero,adresse) VALUES
(3828,'600bis La Petite Fargeonnière, 02880 Nanteuil-la-Fosse'),
(3829,'287 Albouynes-Haut, 55500 Dammarie-sur-Saulx');

INSERT INTO Organisation (numero,adresse) VALUES
(3830,'833 Base de Loisirs de L''Astrée, 17340 Châtelaillon-Plage'),
(3831,'189bis Res Heliopolis, 67700 Gottenhouse');

INSERT INTO Organisation (numero,adresse) VALUES
(3832,'625 Le Pargat, 61130 Origny-le-Roux'),
(3833,'810 Les Monceaux, 59950 Auby');

INSERT INTO Organisation (numero,adresse) VALUES
(3834,'234 Hameau de Sandron, 39130 Menétrux-en-Joux'),
(3835,'97bis Montpellier le Vieux, 19600 Lissac-sur-Couze');

INSERT INTO Organisation (numero,adresse) VALUES
(3836,'855 Les Pouteaux, 61420 La Ferrière-Bochard'),
(3837,'609bis Les Verrets, 10260 Rumilly-lès-Vaudes');

INSERT INTO Organisation (numero,adresse) VALUES
(3838,'874 Villa Le Gai Retour, 57270 Uckange'),
(3839,'420bis Le Neuf Clos, 74100 Ville-la-Grand');

INSERT INTO Organisation (numero,adresse) VALUES
(3840,'119bis Les Michauds, 61320 Sainte-Marguerite-de-Carrouges'),
(3841,'961bis Condamine, 36340 Mouhers');

INSERT INTO Organisation (numero,adresse) VALUES
(3842,'374bis Puech des Garrigues, 24220 Allas-les-Mines'),
(3843,'970 Chemin  Paul Martin, 70800 Ainvelle');

INSERT INTO Organisation (numero,adresse) VALUES
(3844,'293 La Rue de Chatel, 24650 Chancelade'),
(3845,'455 Domaine de Bougna, 59213 Vendegies-sur-Écaillon');

INSERT INTO Organisation (numero,adresse) VALUES
(3846,'332bis Couchet, 16110 Pranzac'),
(3847,'817 Le Portail Ferrier, 78630 Morainvilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(3848,'88 Lieu dit Gestes et Palettes, 71490 Saint-Jean-de-Trézy'),
(3849,'560 Lieu-dit Clamens, 36220 Fontgombault');

INSERT INTO Organisation (numero,adresse) VALUES
(3850,'729 Les Campillous, 67150 Nordhouse'),
(3851,'606 Sillignieu, 14540 Bourguébus');

INSERT INTO Organisation (numero,adresse) VALUES
(3852,'987 La Couaste, 22250 Broons'),
(3853,'873bis Soubranche, 65190 Luc');

INSERT INTO Organisation (numero,adresse) VALUES
(3854,'480 Le Moulinel, 33390 Cartelègue'),
(3855,'37 Tour St Sebastien, 52200 Peigney');

INSERT INTO Organisation (numero,adresse) VALUES
(3856,'964 Place Lieutenant Henri Chemin, 22260 Quemper-Guézennec'),
(3857,'904 Bretelle Sortie Avenue des Sapeurs Pompiers de Nice - Garigliano Lion, 64120 Arbouet-Sussaute');

INSERT INTO Organisation (numero,adresse) VALUES
(3858,'848 La Galatiere, 65500 Saint-Lézer'),
(3859,'204bis Lotissement le Clos du Castel LOT 5, 67420 Plaine');

INSERT INTO Organisation (numero,adresse) VALUES
(3860,'265 Bravay, 16130 Angeac-Champagne'),
(3861,'480 Rue de la Piscine, 21140 Pont-et-Massène');

INSERT INTO Organisation (numero,adresse) VALUES
(3862,'918bis L’Afrique, 79160 Saint-Laurs'),
(3863,'448 Les Mourdous, 67240 Schirrhein');

INSERT INTO Organisation (numero,adresse) VALUES
(3864,'277bis Prés de Corcelles, 63200 Marsat'),
(3865,'0 lieu dit la Peyrusse, 80310 Picquigny');

INSERT INTO Organisation (numero,adresse) VALUES
(3866,'78 Ville Therese, 64530 Pontacq'),
(3867,'765bis Chabottes, 14420 Villers-Canivet');

INSERT INTO Organisation (numero,adresse) VALUES
(3868,'782 Chênefer, 39120 Gatey'),
(3869,'372 Chemin des Chênes verts, 12440 Tayrac');

INSERT INTO Organisation (numero,adresse) VALUES
(3870,'965 "Camping ""La Vie en vert""", 35440 Montreuil-sur-Ille'),
(3871,'57bis Ruelle des Naibes, 07410 Colombier-le-Vieux');

INSERT INTO Organisation (numero,adresse) VALUES
(3872,'736 Les Gallands, 30630 Montclus'),
(3873,'729 La Planche Torse, 76640 Normanville');

INSERT INTO Organisation (numero,adresse) VALUES
(3874,'17 La Queyraye, 24110 Léguillac-de-l''Auche'),
(3875,'768 Villa Calendale, 59810 Lesquin');

INSERT INTO Organisation (numero,adresse) VALUES
(3876,'914 Lotissement les Lavandes, 38850 Charavines'),
(3877,'212 Baillard, 12480 Saint-Izaire');

INSERT INTO Organisation (numero,adresse) VALUES
(3878,'270 """ Juchemilant """, 16390 Saint-Séverin'),
(3879,'976 La Pizette, 14370 Chicheboville');

INSERT INTO Organisation (numero,adresse) VALUES
(3880,'152 Le Verzolet, 62580 Farbus'),
(3881,'843 La Maïris, 76340 Saint-Riquier-en-Rivière');

INSERT INTO Organisation (numero,adresse) VALUES
(3882,'289 La Planeto, 50620 Amigny'),
(3883,'798 Montee_de_celles, 47600 Moncrabeau');

INSERT INTO Organisation (numero,adresse) VALUES
(3884,'830 La Cambuse, 33230 Guîtres'),
(3885,'609 Les Bousquets, 21270 Tellecey');

INSERT INTO Organisation (numero,adresse) VALUES
(3886,'968bis Le Banquet Bas, 49540 Martigné-Briand'),
(3887,'799 Le Petit Souvigny, 25600 Sochaux');

INSERT INTO Organisation (numero,adresse) VALUES
(3888,'819 Résidence du Château, 59171 Hélesmes'),
(3889,'805 Pont Boutiron, 57600 Folkling');

INSERT INTO Organisation (numero,adresse) VALUES
(3890,'311 Le Marchand, 02800 Nouvion-le-Comte'),
(3891,'79 Au Soleo, 09400 Saurat');

INSERT INTO Organisation (numero,adresse) VALUES
(3892,'722 La Graniere, 33860 Donnezac'),
(3893,'579 Le Moulin du Bousquet, 67270 Geiswiller-Zœbersdorf');

INSERT INTO Organisation (numero,adresse) VALUES
(3894,'452 L''Auche, 67160 Wissembourg'),
(3895,'683 Beaumege, 14130 Pierrefitte-en-Auge');

INSERT INTO Organisation (numero,adresse) VALUES
(3896,'825 Horizon Bleu, 61290 Bizou'),
(3897,'648 Vallée de St Martin, 25250 Gémonval');

INSERT INTO Organisation (numero,adresse) VALUES
(3898,'523bis Espace Fernande Bataille, 67330 Issenhausen'),
(3899,'778 Bois de Logis, 18140 Précy');

INSERT INTO Organisation (numero,adresse) VALUES
(3900,'805 Gibalaux le Bas, 47210 Saint-Étienne-de-Villeréal'),
(3901,'241bis Pre Margot, 62260 Ferfay');

INSERT INTO Organisation (numero,adresse) VALUES
(3902,'673bis Impasse de la Badasse, 11800 Villedubert'),
(3903,'967 Teoulet, 61140 Juvigny Val d''Andaine');

INSERT INTO Organisation (numero,adresse) VALUES
(3904,'747bis Grotte de NIaux, 33420 Saint-Aubin-de-Branne'),
(3905,'115 Le Vieux Mazert, 24520 Liorac-sur-Louyre');

INSERT INTO Organisation (numero,adresse) VALUES
(3906,'84bis Les Hauts De Breguieres B1 B2 B3, 08190 Gomont'),
(3907,'167 Le Mas Saint Georges, 08430 Touligny');

INSERT INTO Organisation (numero,adresse) VALUES
(3908,'320 Bas Cheyran, 62223 Saint-Laurent-Blangy'),
(3909,'427bis Pré la Cour, 21390 Normier');

INSERT INTO Organisation (numero,adresse) VALUES
(3910,'608 Mas de Pale, 42750 Maizilly'),
(3911,'161 Chemin de Bentefarine, 45520 Huêtre');

INSERT INTO Organisation (numero,adresse) VALUES
(3912,'488 Chemin G R 36, 07800 Saint-Laurent-du-Pape'),
(3913,'823 Les Doyatins, 50580 Canville-la-Rocque');

INSERT INTO Organisation (numero,adresse) VALUES
(3914,'18 Domaine du Moulin à Vent, 62840 Neuve-Chapelle'),
(3915,'464 Courteaux, 36150 Ménétréols-sous-Vatan');

INSERT INTO Organisation (numero,adresse) VALUES
(3916,'530bis Grand Romanans, 73310 Ruffieux'),
(3917,'306 Le Bastidon, 71240 Montceaux-Ragny');

INSERT INTO Organisation (numero,adresse) VALUES
(3918,'488 Cours du Palais, 76133 Épouville'),
(3919,'881 Le Caïre, 31590 Verfeil');

INSERT INTO Organisation (numero,adresse) VALUES
(3920,'442 ZI le Moulin, 08350 Vrigne-Meuse'),
(3921,'27 Le Pertus, 44730 Saint-Michel-Chef-Chef');

INSERT INTO Organisation (numero,adresse) VALUES
(3922,'303 Terre Lacroix, 67190 Grendelbruch'),
(3923,'218 Les Vignals, 25170 Placey');

INSERT INTO Organisation (numero,adresse) VALUES
(3924,'956 Moulin du Mourtayrol, 62770 Willeman'),
(3925,'222 La Borie de Saint-Meen, 61400 Saint-Mard-de-Réno');

INSERT INTO Organisation (numero,adresse) VALUES
(3926,'802bis Le Puech d’Eglan, 24170 Doissat'),
(3927,'688 Bretelle Sortie N°56 A8 - Monaco (Provenance Cannes), 46160 Carayac');

INSERT INTO Organisation (numero,adresse) VALUES
(3928,'254 Les Odilles, 55220 Les Trois-Domaines'),
(3929,'160 Quart de Franc, 68150 Ribeauvillé');

INSERT INTO Organisation (numero,adresse) VALUES
(3930,'936bis La Terrisse Basse, 07660 Issanlas'),
(3931,'928 Saute Mouches, 10200 Voigny');

INSERT INTO Organisation (numero,adresse) VALUES
(3932,'677 Chemin des Cimetières Anglais et Russes, 01230 Évosges'),
(3933,'926 L''Oliu, 23230 Bord-Saint-Georges');

INSERT INTO Organisation (numero,adresse) VALUES
(3934,'366 Les Béarnais, 25330 Flagey'),
(3935,'478bis Blandinières, 57590 Tincry');

INSERT INTO Organisation (numero,adresse) VALUES
(3936,'903 Resselves, 71250 Bray'),
(3937,'293bis Le Village - Rue Sainte Barbe, 59141 Thun-l''Évêque');

INSERT INTO Organisation (numero,adresse) VALUES
(3938,'248 chemin rural de Bar-sur-Aube à Voigny, 21310 Renève'),
(3939,'496 Les Terres de Fabrique, 62840 Lorgies');

INSERT INTO Organisation (numero,adresse) VALUES
(3940,'262 Barraque de Pégateuil, 18100 Vierzon'),
(3941,'43 Chemin de Roubia, 24380 Lacropte');

INSERT INTO Organisation (numero,adresse) VALUES
(3942,'715bis Place de l''Abbé Buès, 57490 L''Hôpital'),
(3943,'626bis Beret, 70360 La Neuvelle-lès-Scey');

INSERT INTO Organisation (numero,adresse) VALUES
(3944,'850 Ranc la Baume, 67210 Goxwiller'),
(3945,'139 Le Paddock, 54160 Pierreville');

INSERT INTO Organisation (numero,adresse) VALUES
(3946,'285 Parc de l''Eglise, 76270 Mortemer'),
(3947,'162 Le Baquié, 49490 Lasse');

INSERT INTO Organisation (numero,adresse) VALUES
(3948,'71bis La Peyrade Basse, 65700 Lafitole'),
(3949,'140 Rue des Restanques, 03130 Liernolles');

INSERT INTO Organisation (numero,adresse) VALUES
(3950,'178 Grand Domaine, 01540 Saint-Julien-sur-Veyle'),
(3951,'845 Le Gressentis, 53160 Vimarcé');

INSERT INTO Organisation (numero,adresse) VALUES
(3952,'818bis Chemin de Falicon à Tourrette-levens, 35390 Sainte-Anne-sur-Vilaine'),
(3953,'282 Villa Tropico, 51210 Le Breuil');

INSERT INTO Organisation (numero,adresse) VALUES
(3954,'655bis Les Gravats, 60190 Épineuse'),
(3955,'415 Garrissous le Bas, 14770 Cauville');

INSERT INTO Organisation (numero,adresse) VALUES
(3956,'719 La Garriguie, 24600 Saint-Martin-de-Ribérac'),
(3957,'122bis Mas de la Sagne, 21121 Darois');

INSERT INTO Organisation (numero,adresse) VALUES
(3958,'106 Les Margougnauds, 64220 Saint-Michel'),
(3959,'22 Potensac, 63200 Pessat-Villeneuve');

INSERT INTO Organisation (numero,adresse) VALUES
(3960,'85bis Saint-Lazare, 43130 Solignac-sous-Roche'),
(3961,'17 Le Garay, 76690 Saint-André-sur-Cailly');

INSERT INTO Organisation (numero,adresse) VALUES
(3962,'223 Basse Cairosina, 02720 Mesnil-Saint-Laurent'),
(3963,'775bis Le Mont d''Ecry, 55260 Lignières-sur-Aire');

INSERT INTO Organisation (numero,adresse) VALUES
(3964,'383 Les Montagnettes, 69620 Bagnols'),
(3965,'837bis Lot Dapeux, 71380 Châtenoy-en-Bresse');

INSERT INTO Organisation (numero,adresse) VALUES
(3966,'644bis Les Fouquetis, 35160 Le Verger'),
(3967,'918 La Reue, 56370 Le Tour-du-Parc');

INSERT INTO Organisation (numero,adresse) VALUES
(3968,'955bis En Belleville, 67170 Bernolsheim'),
(3969,'977 Mont Percinette, 39300 Syam');

INSERT INTO Organisation (numero,adresse) VALUES
(3970,'341bis Longs Buts, 21370 Prenois'),
(3971,'9bis Pumptrack, 46090 Francoulès');

INSERT INTO Organisation (numero,adresse) VALUES
(3972,'726 Devez des Coumbets, 63114 Authezat'),
(3973,'772 Pigranier, 43230 Chassagnes');

INSERT INTO Organisation (numero,adresse) VALUES
(3974,'191 Rue des Champs Longs, 18140 Argenvières'),
(3975,'468 Etang Guyon, 77370 Clos-Fontaine');

INSERT INTO Organisation (numero,adresse) VALUES
(3976,'453 Au-dessus de l''Eglise, 04200 Sisteron'),
(3977,'737 Vignes de Morion, 29310 Locunolé');

INSERT INTO Organisation (numero,adresse) VALUES
(3978,'224 La Roya Entree A-B-C-D, 50440 Sainte-Croix-Hague'),
(3979,'989 Portoy, 59550 Noyelles-sur-Sambre');

INSERT INTO Organisation (numero,adresse) VALUES
(3980,'437 Les Aousserots, 12290 Canet-de-Salars'),
(3981,'55 Chateau de Belle Isle, 77710 Paley');

INSERT INTO Organisation (numero,adresse) VALUES
(3982,'404bis Route Métropolitaine 330, 27930 Saint-Vigor'),
(3983,'17bis Le Clos Gobart, 63230 Saint-Jacques-d''Ambur');

INSERT INTO Organisation (numero,adresse) VALUES
(3984,'699 Rond-Point  Paul Fouque, 60600 Clermont'),
(3985,'746 Les Férrauds, 13480 Cabriès');

INSERT INTO Organisation (numero,adresse) VALUES
(3986,'273 Chemin du Radel, 20220 Monticello'),
(3987,'229bis le Biollet, 41170 Couëtron-au-Perche');

INSERT INTO Organisation (numero,adresse) VALUES
(3988,'763 Plan Rascas, 76540 Riville'),
(3989,'455 Migayrou, 46210 Saint-Hilaire');

INSERT INTO Organisation (numero,adresse) VALUES
(3990,'731 Brommes, 76400 Saint-Léonard'),
(3991,'13 Les Croyes, 54700 Vilcey-sur-Trey');

INSERT INTO Organisation (numero,adresse) VALUES
(3992,'300 Blanc, 28800 Neuvy-en-Dunois'),
(3993,'860 Capservy-Est, 68320 Muntzenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(3994,'215 Les Silves, 21380 Messigny-et-Vantoux'),
(3995,'647 Canalis, 51300 Les Rivières-Henruel');

INSERT INTO Organisation (numero,adresse) VALUES
(3996,'673 Le Phidias, 12200 Sanvensa'),
(3997,'916 Ruelle Eleup, 74140 Sciez');

INSERT INTO Organisation (numero,adresse) VALUES
(3998,'411bis Le Garay, 03340 Bessay-sur-Allier'),
(3999,'79bis Résidence La valeio, 38110 Saint-Didier-de-la-Tour');

INSERT INTO Organisation (numero,adresse) VALUES
(4000,'121 Le Bayounenc, 22530 Saint-Gilles-Vieux-Marché'),
(4001,'574 Route de Baires, 70120 Cornot');

INSERT INTO Organisation (numero,adresse) VALUES
(4002,'267 Hameau de Tabias, 52200 Langres'),
(4003,'571bis Parking du village, 12300 Boisse-Penchot');

INSERT INTO Organisation (numero,adresse) VALUES
(4004,'463bis Rue du Porche, 45210 Chevannes'),
(4005,'21 La Carrière Medard, 20125 Poggiolo');

INSERT INTO Organisation (numero,adresse) VALUES
(4006,'173bis Le Mas de Bardy, 51160 Aÿ-Champagne'),
(4007,'248 Le Rouland, 46150 Saint-Médard');

INSERT INTO Organisation (numero,adresse) VALUES
(4008,'585 Liaison Avenue du Mercantour - Rue Auguste Maicon, 62120 Lambres'),
(4009,'560 Ruelle du Rouillard, 80360 Étricourt-Manancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(4010,'437 Lieu-dit Grand Roche, 19500 Meyssac'),
(4011,'970bis Chp des Magaudes, 54800 Xonville');

INSERT INTO Organisation (numero,adresse) VALUES
(4012,'148bis Plan Gast, 69380 Dommartin'),
(4013,'227bis Bairal, 73660 Les Chavannes-en-Maurienne');

INSERT INTO Organisation (numero,adresse) VALUES
(4014,'536 Chemin de la Digue, 32500 Pauilhac'),
(4015,'423 Chemin de la Providence, 54470 Limey-Remenauville');

INSERT INTO Organisation (numero,adresse) VALUES
(4016,'605 Eglise Saint Jean Baptiste, 02190 Berry-au-Bac'),
(4017,'595bis Pouchole, 37500 Saint-Benoît-la-Forêt');

INSERT INTO Organisation (numero,adresse) VALUES
(4018,'524 Les Terres de la Planquette, 67390 Elsenheim'),
(4019,'219 Le Vallon, 03390 Saint-Priest-en-Murat');

INSERT INTO Organisation (numero,adresse) VALUES
(4020,'73 Mas des Trouillards, 62990 Royon'),
(4021,'398 Azur Paradis, 76740 Brametot');

INSERT INTO Organisation (numero,adresse) VALUES
(4022,'45 La Vigna, 19150 Marc-la-Tour'),
(4023,'685 Lieu-dit Le Genest, 70240 Châtenois');

INSERT INTO Organisation (numero,adresse) VALUES
(4024,'884 Chemin des Avayeux au Chêne, 14840 Cuverville'),
(4025,'399 Les Lazes, 66120 Targassonne');

INSERT INTO Organisation (numero,adresse) VALUES
(4026,'48 Champ Riond, 17430 Saint-Coutant-le-Grand'),
(4027,'335 Cap de l’Homme, 59144 Jenlain');

INSERT INTO Organisation (numero,adresse) VALUES
(4028,'301bis La Borie Graissac, 66150 Corsavy'),
(4029,'341bis Route du Bentaillou, 53190 Fougerolles-du-Plessis');

INSERT INTO Organisation (numero,adresse) VALUES
(4030,'267bis Lac de Pareloup, 57540 Petite-Rosselle'),
(4031,'753 Sours, 64800 Mirepeix');

INSERT INTO Organisation (numero,adresse) VALUES
(4032,'919 Avenue Notre-Dame, 15250 Marmanhac'),
(4033,'795 Champ de Vigne, 14360 Trouville-sur-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(4034,'626 Le Charpinet, 69280 Sainte-Consorce'),
(4035,'206 Le Pré Baron, 28310 Baudreville');

INSERT INTO Organisation (numero,adresse) VALUES
(4036,'457bis Les Escoffiers, 38270 Bellegarde-Poussieu'),
(4037,'968 Rond point de la chapelle Saint Jean, 55210 Woël');

INSERT INTO Organisation (numero,adresse) VALUES
(4038,'27bis Cantemrle, 30760 Saint-Christol-de-Rodières'),
(4039,'988 Rioupeyroux, 31800 Latoue');

INSERT INTO Organisation (numero,adresse) VALUES
(4040,'694bis Les Chabanons, 76590 Torcy-le-Petit'),
(4041,'784bis Bruguieras, 68780 Diefmatten');

INSERT INTO Organisation (numero,adresse) VALUES
(4042,'58 Villa Luce, 30660 Gallargues-le-Montueux'),
(4043,'431 Les Ribos, 10800 Moussey');

INSERT INTO Organisation (numero,adresse) VALUES
(4044,'188 Le Déves, 02190 Variscourt'),
(4045,'832 Parking de la croix, 16200 Mainxe');

INSERT INTO Organisation (numero,adresse) VALUES
(4046,'708 Le Combal, 60117 Vauciennes'),
(4047,'389 """ Les Deveaux """, 76540 Riville');

INSERT INTO Organisation (numero,adresse) VALUES
(4048,'752bis Fourteau, 26800 Beauvallon'),
(4049,'773 Rue des Jardins, 62580 Bailleul-Sir-Berthoult');

INSERT INTO Organisation (numero,adresse) VALUES
(4050,'7 Casa Verde, 10110 Fralignes'),
(4051,'947 Chateau de Montcoquier, 51300 Norrois');

INSERT INTO Organisation (numero,adresse) VALUES
(4052,'399 Rond Point Marcel PUT, 64350 Bassillon-Vauzé'),
(4053,'661bis Le_cabanon, 60240 Jouy-sous-Thelle');

INSERT INTO Organisation (numero,adresse) VALUES
(4054,'415 Le Carré des Muses, 10800 Saint-Léger-près-Troyes'),
(4055,'133bis Les Combalons, 23360 La Forêt-du-Temple');

INSERT INTO Organisation (numero,adresse) VALUES
(4056,'358 Roquefort, 79340 Chantecorps'),
(4057,'43 La Leude, 12240 Pradinas');

INSERT INTO Organisation (numero,adresse) VALUES
(4058,'858 Les Faiteaux, 34150 Lagamas'),
(4059,'633 Grand Champ, 60660 Rousseloy');

INSERT INTO Organisation (numero,adresse) VALUES
(4060,'249 Les Plans d''Hotonnes, 77390 Champdeuil'),
(4061,'54 Montsion, 21570 Brion-sur-Ource');

INSERT INTO Organisation (numero,adresse) VALUES
(4062,'580 Lotissement les Coteaux de Venelles II, 66500 Campôme'),
(4063,'36 Mas Savoye, 42600 Mornand-en-Forez');

INSERT INTO Organisation (numero,adresse) VALUES
(4064,'103 Erica, 51120 Le Meix-Saint-Epoing'),
(4065,'50 La Petite Jarry, 51130 Trécon');

INSERT INTO Organisation (numero,adresse) VALUES
(4066,'786 La Frayere, 43160 La Chaise-Dieu'),
(4067,'242 Les Coustetes, 73110 Le Verneil');

INSERT INTO Organisation (numero,adresse) VALUES
(4068,'227 Champ d’Isnard, 50450 Gavray'),
(4069,'556 Saint-Lazare, 08150 Rimogne');

INSERT INTO Organisation (numero,adresse) VALUES
(4070,'122 Impasse du Soleil Levant, 02480 Sommette-Eaucourt'),
(4071,'785bis Le Cabanou, 22250 Trédias');

INSERT INTO Organisation (numero,adresse) VALUES
(4072,'68 La Broussine, 55200 Saint-Julien-sous-les-Côtes'),
(4073,'353 Camp-Grand, 17120 Cozes');

INSERT INTO Organisation (numero,adresse) VALUES
(4074,'456 Moulin de Salelles, 46090 Le Montat'),
(4075,'166 Le Roudilhou, 72210 Chemiré-le-Gaudin');

INSERT INTO Organisation (numero,adresse) VALUES
(4076,'309bis Rue du Mei de Ville, 54540 Neuviller-lès-Badonviller'),
(4077,'814 Champ Moulin, 80150 Forest-l''Abbaye');

INSERT INTO Organisation (numero,adresse) VALUES
(4078,'522 En Bon Homme, 65670 Gaussan'),
(4079,'477 La Meyria, 39260 Martigna');

INSERT INTO Organisation (numero,adresse) VALUES
(4080,'892 La Bracadelle Haute, 52500 Genevrières'),
(4081,'457 Balviac, 31830 Plaisance-du-Touch');

INSERT INTO Organisation (numero,adresse) VALUES
(4082,'628 Cap del PLa, 44522 Mésanger'),
(4083,'740 La Chabanne, 71370 Saint-Christophe-en-Bresse');

INSERT INTO Organisation (numero,adresse) VALUES
(4084,'726 Combe Pelle, 02300 Bourguignon-sous-Coucy'),
(4085,'885 La Plaine de Raspaud, 11800 Monze');

INSERT INTO Organisation (numero,adresse) VALUES
(4086,'211 La Louisiere, 17150 Saint-Bonnet-sur-Gironde'),
(4087,'151bis L’Aigle et la Bouissonnade, 49220 Montreuil-sur-Maine');

INSERT INTO Organisation (numero,adresse) VALUES
(4088,'936 Rue des Gendarmes d''Ouvéa, 65500 Escaunets'),
(4089,'505bis Hameau de Galié, 02860 Chérêt');

INSERT INTO Organisation (numero,adresse) VALUES
(4090,'13 Petit Trevesse, 34520 Saint-Félix-de-l''Héras'),
(4091,'636 Billa d''en Haut, 39130 Pont-de-Poitte');

INSERT INTO Organisation (numero,adresse) VALUES
(4092,'39 Les Pinoux, 47600 Nérac'),
(4093,'1bis Courtiol Haut, 06670 Levens');

INSERT INTO Organisation (numero,adresse) VALUES
(4094,'486bis En Pommont, 01600 Saint-Bernard'),
(4095,'952 Lieu-dit Molle Las Rives, 26560 Séderon');

INSERT INTO Organisation (numero,adresse) VALUES
(4096,'887 Quartier de la Gare, 45170 Bougy-lez-Neuville'),
(4097,'281 Rue de la Roque, 36230 Gournay');

INSERT INTO Organisation (numero,adresse) VALUES
(4098,'116 Les Ouches de Peiges, 07380 Jaujac'),
(4099,'471 Pont de Bader, 54120 Gélacourt');

INSERT INTO Organisation (numero,adresse) VALUES
(4100,'759bis La Camparonie, 72610 Champfleur'),
(4101,'729bis Bois Blanchet, 62850 Surques');

INSERT INTO Organisation (numero,adresse) VALUES
(4102,'594 Argentolle, 11380 Miraval-Cabardès'),
(4103,'663 """ Champ Laurent """, 73300 Montvernier');

INSERT INTO Organisation (numero,adresse) VALUES
(4104,'691 Moulin Neuf, 70300 La Corbière'),
(4105,'443 Clos Cache, 21460 Forléans');

INSERT INTO Organisation (numero,adresse) VALUES
(4106,'0 La Clairierre, 22330 Le Mené'),
(4107,'501bis Le Vivaldi A, 62550 Sachin');

INSERT INTO Organisation (numero,adresse) VALUES
(4108,'495 Bretelle Sortie Corniglion-Molinier - Aéroport, 59620 Leval'),
(4109,'117bis Saint Rames, 54490 Piennes');

INSERT INTO Organisation (numero,adresse) VALUES
(4110,'344 Planeze, 20238 Morsiglia'),
(4111,'245 La Croix des Gaillards, 80140 Fontaine-le-Sec');

INSERT INTO Organisation (numero,adresse) VALUES
(4112,'777 Rue de la Carce, 76640 Cliponville'),
(4113,'589 Boucher, 46200 Pinsac');

INSERT INTO Organisation (numero,adresse) VALUES
(4114,'218bis Lieu-Dit Les Sanhes, 52320 Gudmont-Villiers'),
(4115,'621bis La Garriguette, 59400 Séranvillers-Forenville');

INSERT INTO Organisation (numero,adresse) VALUES
(4116,'574 Allée des Bugadières, 39330 Mouchard'),
(4117,'550bis Avenue Abel Bardin et Ch Benoit, 35580 Guichen');

INSERT INTO Organisation (numero,adresse) VALUES
(4118,'568 La Croix de Mounes, 74270 Clarafond-Arcine'),
(4119,'298 Puech Mignon, 46150 Boissières');

INSERT INTO Organisation (numero,adresse) VALUES
(4120,'139 Les Goupys, 58500 Surgy'),
(4121,'959bis Lo Coumbo, 65230 Caubous');

INSERT INTO Organisation (numero,adresse) VALUES
(4122,'113 Res L''Arlequin, 60250 Bury'),
(4123,'136 Planals et Taussos, 56230 Larré');

INSERT INTO Organisation (numero,adresse) VALUES
(4124,'885 Avenue du Stade Hlm Bretagne, 53250 Javron-les-Chapelles'),
(4125,'820 la Catière, 30128 Garons');

INSERT INTO Organisation (numero,adresse) VALUES
(4126,'585bis Le Claou, 62130 Saint-Michel-sur-Ternoise'),
(4127,'829 Domaine des trois Colombes, 79220 Champdeniers-Saint-Denis');

INSERT INTO Organisation (numero,adresse) VALUES
(4128,'561 La Coccinelle, 80500 Marestmontiers'),
(4129,'666bis La Côte de Chateloi, 78125 Gazeran');

INSERT INTO Organisation (numero,adresse) VALUES
(4130,'518bis Bregous, 07110 Loubaresse'),
(4131,'222 Grange Chaland, 21450 Baigneux-les-Juifs');

INSERT INTO Organisation (numero,adresse) VALUES
(4132,'804 Mas de Rogez, 39290 Frasne-les-Meulières'),
(4133,'662 Bouloc, 80340 Proyart');

INSERT INTO Organisation (numero,adresse) VALUES
(4134,'44 La Bastide Des Remparts, 14190 Le Bû-sur-Rouvres'),
(4135,'951 Pont de la Tour, 14100 Saint-Denis-de-Mailloc');

INSERT INTO Organisation (numero,adresse) VALUES
(4136,'546 Las Carreroles, 55230 Duzey'),
(4137,'230bis Moulin de Las Cravives, 25700 Valentigney');

INSERT INTO Organisation (numero,adresse) VALUES
(4138,'824 Centrale Hydrolique, 02250 Saint-Pierremont'),
(4139,'230 Clos de Fredville, 39800 Plasne');

INSERT INTO Organisation (numero,adresse) VALUES
(4140,'498bis Route de Chatelperron, 24320 Bertric-Burée'),
(4141,'149 Aire de Laffaux parking, 31510 Mont-de-Galié');

INSERT INTO Organisation (numero,adresse) VALUES
(4142,'80 Cavagnac, 35800 Dinard'),
(4143,'255bis Villa Helios, 22720 Saint-Péver');

INSERT INTO Organisation (numero,adresse) VALUES
(4144,'391bis Grange Rollet, 27480 Bosquentin'),
(4145,'346bis Impasse de l''Emigra, 43230 Vals-le-Chastel');

INSERT INTO Organisation (numero,adresse) VALUES
(4146,'680bis Les Barriasses, 71250 Cortambert'),
(4147,'920 Les Grands Jardins, 65170 Azet');

INSERT INTO Organisation (numero,adresse) VALUES
(4148,'927 Cap d''Ossèse, 14600 Fourneville'),
(4149,'297 La Bolardiere, 71380 Lans');

INSERT INTO Organisation (numero,adresse) VALUES
(4150,'86bis Sous Haute Rive, 68580 Largitzen'),
(4151,'134 Badassou, 77167 Faÿ-lès-Nemours');

INSERT INTO Organisation (numero,adresse) VALUES
(4152,'952 Riou Fouors, 53220 Saint-Mars-sur-la-Futaie'),
(4153,'814bis L''Astoria, 60220 Broquiers');

INSERT INTO Organisation (numero,adresse) VALUES
(4154,'294 Impasse du Pontet, 68130 Obermorschwiller'),
(4155,'925bis Goulajou de Charlemagne, 08000 Charleville-Mézières');

INSERT INTO Organisation (numero,adresse) VALUES
(4156,'541 Grande Serve, 16240 Empuré'),
(4157,'993bis La Rimade, 31190 Labruyère-Dorsa');

INSERT INTO Organisation (numero,adresse) VALUES
(4158,'781 EHPAD La Gloriette, 49420 Carbay'),
(4159,'459bis Les Pescayres, 25240 Reculfoz');

INSERT INTO Organisation (numero,adresse) VALUES
(4160,'572 Font Pourri, 02470 Marizy-Saint-Mard'),
(4161,'380bis Impasse Broch, 38160 Saint-Marcellin');

INSERT INTO Organisation (numero,adresse) VALUES
(4162,'825 Les Baumes et les Cresses, 01220 Grilly'),
(4163,'285 Route de Martigues, 44800 Saint-Herblain');

INSERT INTO Organisation (numero,adresse) VALUES
(4164,'577 Sentier Paul Viazzi, 24530 Quinsac'),
(4165,'533 Le Patus, 01680 Groslée-Saint-Benoit');

INSERT INTO Organisation (numero,adresse) VALUES
(4166,'606 Villa des Fleurs, 52600 Palaiseul'),
(4167,'975 La Ferail, 58800 Chitry-les-Mines');

INSERT INTO Organisation (numero,adresse) VALUES
(4168,'387 Marlavagne la Fournelade, 79160 Faye-sur-Ardin'),
(4169,'658bis Rouget, 53400 Niafles');

INSERT INTO Organisation (numero,adresse) VALUES
(4170,'762 Pouzoulet, 31530 Sainte-Livrade'),
(4171,'679 Pique Musel, 64300 Labeyrie');

INSERT INTO Organisation (numero,adresse) VALUES
(4172,'70 La Chapelle de Rosières, 27800 Franqueville'),
(4173,'622 Jones, 39400 Les Rousses');

INSERT INTO Organisation (numero,adresse) VALUES
(4174,'561bis Le Verger, 77840 Germigny-sous-Coulombs'),
(4175,'298bis Bedettes, 02880 Terny-Sorny');

INSERT INTO Organisation (numero,adresse) VALUES
(4176,'254 Etang Matras, 62223 Sainte-Catherine'),
(4177,'904 Cazaublingue, 50000 Saint-Georges-Montcocq');

INSERT INTO Organisation (numero,adresse) VALUES
(4178,'384bis Le Moulin de Marc, 70000 Mailley-et-Chazelot'),
(4179,'196 Le Plo de la Besse, 77890 Beaumont-du-Gâtinais');

INSERT INTO Organisation (numero,adresse) VALUES
(4180,'770 Hameau de la Grande Bastide, 08390 Les Petites-Armoises'),
(4181,'836 Avenue Rose France, 63220 Saint-Alyre-d''Arlanc');

INSERT INTO Organisation (numero,adresse) VALUES
(4182,'901 Le Bois Randenay, 40700 Beyries'),
(4183,'219 Maillac de Brevinque, 51120 Queudes');

INSERT INTO Organisation (numero,adresse) VALUES
(4184,'893 Noyer des Six Tiges, 52170 Chevillon'),
(4185,'551 Jardin de Samarcande, 02270 Froidmont-Cohartille');

INSERT INTO Organisation (numero,adresse) VALUES
(4186,'156 Villa Saint Pierre, 26160 Rochefort-en-Valdaine'),
(4187,'331 La Bussière, 40800 Duhort-Bachen');

INSERT INTO Organisation (numero,adresse) VALUES
(4188,'525 Chemin du Pastelier, 21320 Blancey'),
(4189,'926 Escalier Boulevard Jean Jaurès Calada Auguste Escoffier, 31370 Le Pin-Murelet');

INSERT INTO Organisation (numero,adresse) VALUES
(4190,'674 Le Parc de Ferney-Ville, 77160 Rouilly'),
(4191,'170 Les Combettes, 80220 Bouvaincourt-sur-Bresle');

INSERT INTO Organisation (numero,adresse) VALUES
(4192,'207 Le Rivazur, 54520 Laxou'),
(4193,'134 Le Seyte et Mauchier, 14190 Saint-Germain-le-Vasson');

INSERT INTO Organisation (numero,adresse) VALUES
(4194,'173 Domaine Alcouffe, 33710 Bayon-sur-Gironde'),
(4195,'221bis La Cluse, 21440 Vaux-Saules');

INSERT INTO Organisation (numero,adresse) VALUES
(4196,'368bis Les Pres-Garlot, 28700 Voise'),
(4197,'285 Antrolles, 09000 Vernajoul');

INSERT INTO Organisation (numero,adresse) VALUES
(4198,'649 La Bessarede, 03210 Besson'),
(4199,'760 Serpollet, 28700 Vierville');

INSERT INTO Organisation (numero,adresse) VALUES
(4200,'197bis Azur Paradis, 70400 Courmont'),
(4201,'902bis Pont de Bru, 39300 Équevillon');

INSERT INTO Organisation (numero,adresse) VALUES
(4202,'484 Les Chadiaux, 65220 Antin'),
(4203,'873bis Verrières, 41250 Mont-près-Chambord');

INSERT INTO Organisation (numero,adresse) VALUES
(4204,'195 Le Mas de la Fon, 71510 Essertenne'),
(4205,'944 L''Eglantine, 18500 Sainte-Thorette');

INSERT INTO Organisation (numero,adresse) VALUES
(4206,'690bis Le Vernugeat, 29260 Lesneven'),
(4207,'933 Ouyre Haute, 10320 Longeville-sur-Mogne');

INSERT INTO Organisation (numero,adresse) VALUES
(4208,'350 """Au Champ des Joncs """, 24550 Campagnac-lès-Quercy'),
(4209,'207 Laudie et le Sarret, 78200 Jouy-Mauvoisin');

INSERT INTO Organisation (numero,adresse) VALUES
(4210,'928 Les Faisses de Fauchier, 06470 Guillaumes'),
(4211,'8 Château de Fajac, 76390 Haudricourt');

INSERT INTO Organisation (numero,adresse) VALUES
(4212,'621 Le Sufron, 25270 Villeneuve-d''Amont'),
(4213,'344 Des Granges du Bois, 31110 Mayrègne');

INSERT INTO Organisation (numero,adresse) VALUES
(4214,'380 La Gache, 29360 Clohars-Carnoët'),
(4215,'344 La Plate Pierre, 17340 Châtelaillon-Plage');

INSERT INTO Organisation (numero,adresse) VALUES
(4216,'411 Castellar Soutran, 57480 Apach'),
(4217,'808 Feneyrols, 80270 Heucourt-Croquoison');

INSERT INTO Organisation (numero,adresse) VALUES
(4218,'603 Bât. G4, 52120 Blessonville'),
(4219,'914 """ Le Lanceron """, 56270 Ploemeur');

INSERT INTO Organisation (numero,adresse) VALUES
(4220,'55 La Valade Haute, 65200 Astugue'),
(4221,'565bis La Vilhaine, 54510 Tomblaine');

INSERT INTO Organisation (numero,adresse) VALUES
(4222,'864 Sermur, 37510 Ballan-Miré'),
(4223,'522 Pompède, 69820 Vauxrenard');

INSERT INTO Organisation (numero,adresse) VALUES
(4224,'452 Les Petites Taboutes, 65370 Troubat'),
(4225,'106 Mas du Pré, 27390 La Goulafrière');

INSERT INTO Organisation (numero,adresse) VALUES
(4226,'698 Place du 19 mars 1962, 63310 Villeneuve-les-Cerfs'),
(4227,'590 Résidence Les Terrasses de la Méditerranée 1 Bât B, 14540 Soliers');

INSERT INTO Organisation (numero,adresse) VALUES
(4228,'160 Baus de Mars, 57590 Bacourt'),
(4229,'94 Parlan, 41290 Sainte-Gemmes');

INSERT INTO Organisation (numero,adresse) VALUES
(4230,'542 Les Bastides De L''Hubac 2-3, 77123 Noisy-sur-École'),
(4231,'867 La Réginie, 67600 Ebersmunster');

INSERT INTO Organisation (numero,adresse) VALUES
(4232,'264 Hauts De L''Hubac Lot 6, 31360 Roquefort-sur-Garonne'),
(4233,'908 Mirebeau, 11330 Lanet');

INSERT INTO Organisation (numero,adresse) VALUES
(4234,'823 Relais St Martin, 69210 Chevinay'),
(4235,'909 La Petite Forge, 28120 Meslay-le-Grenet');

INSERT INTO Organisation (numero,adresse) VALUES
(4236,'393 Sessouens, 80200 Athies'),
(4237,'59 Collets de Marroc St Hilaire, 65670 Laran');

INSERT INTO Organisation (numero,adresse) VALUES
(4238,'69 Raccourci Avenue Gravier, 07660 Lavillatte'),
(4239,'490 Le Peyrié, 21190 Corcelles-les-Arts');

INSERT INTO Organisation (numero,adresse) VALUES
(4240,'663 Salsogne, 71230 Saint-Vallier'),
(4241,'199 Les Grandes Forges, 79500 Saint-Léger-de-la-Martinière');

INSERT INTO Organisation (numero,adresse) VALUES
(4242,'682 Rec de Cugnol, 80300 Montauban-de-Picardie'),
(4243,'150bis Au Dessus du Fond de Manil, 41100 Rocé');

INSERT INTO Organisation (numero,adresse) VALUES
(4244,'465 Saint Charles, 62410 Bénifontaine'),
(4245,'997 Avenue de Beauregard, 72130 Gesnes-le-Gandelin');

INSERT INTO Organisation (numero,adresse) VALUES
(4246,'661 Villa Miranda, 76280 Cuverville'),
(4247,'839 En Castel, 45480 Greneville-en-Beauce');

INSERT INTO Organisation (numero,adresse) VALUES
(4248,'563bis Le Cros de Lucante, 67360 Oberdorf-Spachbach'),
(4249,'531 Chemin des Fontainiers de Bellet, 71390 Saint-Martin-d''Auxy');

INSERT INTO Organisation (numero,adresse) VALUES
(4250,'2bis Puech del Soyt, 24210 Fossemagne'),
(4251,'466 Le Bois Piou, 30190 Aubussargues');

INSERT INTO Organisation (numero,adresse) VALUES
(4252,'881 Lotissement Le Sart, 75003 Paris 03'),
(4253,'84 Chemin Saint Amour, 35235 Thorigné-Fouillard');

INSERT INTO Organisation (numero,adresse) VALUES
(4254,'23 Les Brouals, 47500 Saint-Vite'),
(4255,'307 La Marinie, 57320 Tromborn');

INSERT INTO Organisation (numero,adresse) VALUES
(4256,'289 Baudiniere, 52150 Outremécourt'),
(4257,'703 Village de la Chalaguère, 21500 Saint-Rémy');

INSERT INTO Organisation (numero,adresse) VALUES
(4258,'232 Astared, 55230 Gouraincourt'),
(4259,'952 Les Caux, 02600 Villers-Hélon');

INSERT INTO Organisation (numero,adresse) VALUES
(4260,'937 Le Mas du Causse, 26350 Miribel'),
(4261,'903bis Plan d''Escalle St Martin, 40500 Eyres-Moncube');

INSERT INTO Organisation (numero,adresse) VALUES
(4262,'651bis Gros Bois, 68730 Michelbach-le-Bas'),
(4263,'390 le petit Laréna, 78250 Tessancourt-sur-Aubette');

INSERT INTO Organisation (numero,adresse) VALUES
(4264,'36bis La Micoulade, 39100 Baverans'),
(4265,'851bis Square  Jane Aublet, 67220 Fouchy');

INSERT INTO Organisation (numero,adresse) VALUES
(4266,'916bis Le Vigny, 02200 Chaudun'),
(4267,'577 Liaison rue Françoise Giroud - boulevard du Mercantour, 07260 Ribes');

INSERT INTO Organisation (numero,adresse) VALUES
(4268,'880 Beau-sejour, 54370 Bathelémont'),
(4269,'911bis Le Bari, 51500 Écueil');

INSERT INTO Organisation (numero,adresse) VALUES
(4270,'832 Les Froyes, 57810 Réchicourt-le-Château'),
(4271,'759 Auray, 14960 Saint-Côme-de-Fresné');

INSERT INTO Organisation (numero,adresse) VALUES
(4272,'714 Fontbouillenq, 52110 Brachay'),
(4273,'288 Roussolles, 70240 La Villeneuve-Bellenoye-et-la-Maize');

INSERT INTO Organisation (numero,adresse) VALUES
(4274,'549 Les Terres du Pave, 16460 Bayers'),
(4275,'181 Fontaine Thomas, 32500 Fleurance');

INSERT INTO Organisation (numero,adresse) VALUES
(4276,'286bis L''Haut Brenot, 47180 Castelnau-sur-Gupie'),
(4277,'508bis lieu dit Berdot, 57070 Metz');

INSERT INTO Organisation (numero,adresse) VALUES
(4278,'575bis Clos Azur A, 63160 Bongheat'),
(4279,'263 Terres de Lyon, 32130 Nizas');

INSERT INTO Organisation (numero,adresse) VALUES
(4280,'795 Lieu dit Les Fillières, 11160 Trassanel'),
(4281,'430 Bois d''Aboul, 79400 Saint-Georges-de-Noisné');

INSERT INTO Organisation (numero,adresse) VALUES
(4282,'955 """ Rouinaire """, 65140 Sénac'),
(4283,'315bis Acy le bas, 28240 Saint-Éliph');

INSERT INTO Organisation (numero,adresse) VALUES
(4284,'525 Craissac, 51420 Witry-lès-Reims'),
(4285,'429bis Rabateau, 80560 Authie');

INSERT INTO Organisation (numero,adresse) VALUES
(4286,'983 Rue du Prat del Poumié, 63600 Grandrif'),
(4287,'85bis Square Louis Pretazzini, 16200 Chassors');

INSERT INTO Organisation (numero,adresse) VALUES
(4288,'472 Romette, 01200 Bellegarde-sur-Valserine'),
(4289,'636 Le Moulin d''Ambercy, 16210 Rouffiac');

INSERT INTO Organisation (numero,adresse) VALUES
(4290,'447 Granouleou, 45170 Aschères-le-Marché'),
(4291,'636bis Pont des Chevres, 55220 Osches');

INSERT INTO Organisation (numero,adresse) VALUES
(4292,'682 L’Oustal Neuf, 21400 Villotte-sur-Ource'),
(4293,'890 Fontenille, 28400 Coudreceau');

INSERT INTO Organisation (numero,adresse) VALUES
(4294,'113bis Sableyre, 24200 Carsac-Aillac'),
(4295,'354 Lieu dit Chartex, 40300 Cagnotte');

INSERT INTO Organisation (numero,adresse) VALUES
(4296,'33 Escalier Place de l''Eglise, 16390 Palluaud'),
(4297,'675 Rue François Roux, 70160 Fleurey-lès-Faverney');

INSERT INTO Organisation (numero,adresse) VALUES
(4298,'129 Le Pesqué, 66200 Corneilla-del-Vercol'),
(4299,'439 Lotissement Plein Sud, 40350 Pouillon');

INSERT INTO Organisation (numero,adresse) VALUES
(4300,'408 Marjolaine, 66760 Dorres'),
(4301,'676 Le Vaysset, 64240 Hasparren');

INSERT INTO Organisation (numero,adresse) VALUES
(4302,'581 Rec Del Prue, 57590 Lucy'),
(4303,'70 Quai Pierre Merli, 57420 Sailly-Achâtel');

INSERT INTO Organisation (numero,adresse) VALUES
(4304,'485 Oratoire Serre des Vertues, 37310 Tauxigny-Saint-Bauld'),
(4305,'418bis Suquairie, 73170 Billième');

INSERT INTO Organisation (numero,adresse) VALUES
(4306,'128 Le Principal, 11410 Payra-sur-l''Hers'),
(4307,'197 Rue de la mairie, 33660 Saint-Seurin-sur-l''Isle');

INSERT INTO Organisation (numero,adresse) VALUES
(4308,'605 Les Guillaumes, 54620 Boismont'),
(4309,'515 Ruelle des Jardins, 73440 Les Belleville');

INSERT INTO Organisation (numero,adresse) VALUES
(4310,'26 Le Brieu, 32390 Mirepoix'),
(4311,'408 Impasse de Fontcartal, 42260 Saint-Germain-Laval');

INSERT INTO Organisation (numero,adresse) VALUES
(4312,'860bis Camping La Riviere, 44650 Touvois'),
(4313,'146bis La Goute, 46110 Bétaille');

INSERT INTO Organisation (numero,adresse) VALUES
(4314,'597 Cap Sud, 61570 Médavy'),
(4315,'21 Ephad Mariposa, 31440 Baren');

INSERT INTO Organisation (numero,adresse) VALUES
(4316,'969 Combe Terraillon, 67120 Kolbsheim'),
(4317,'774 Le Peyral, 54800 Bruville');

INSERT INTO Organisation (numero,adresse) VALUES
(4318,'112 Les Vignals, 57340 Haboudange'),
(4319,'416 Le Château Artonges, 12780 Vézins-de-Lévézou');

INSERT INTO Organisation (numero,adresse) VALUES
(4320,'752 Le Causse de la Baldare, 02830 Saint-Michel'),
(4321,'83bis Deuxieme Gayan, 32130 Samatan');

INSERT INTO Organisation (numero,adresse) VALUES
(4322,'176 Les Tipliés, 74160 Beaumont'),
(4323,'664 Passage Flores, 62140 Raye-sur-Authie');

INSERT INTO Organisation (numero,adresse) VALUES
(4324,'685 Les Constellations, 41140 Saint-Romain-sur-Cher'),
(4325,'230bis L''Ouliayre, 26800 Beauvallon');

INSERT INTO Organisation (numero,adresse) VALUES
(4326,'528 Chemin de Chans, 59263 Houplin-Ancoisne'),
(4327,'320 La Terrasse et la Nataille, 14430 Cresseveuille');

INSERT INTO Organisation (numero,adresse) VALUES
(4328,'6 Lieu-Dit Les Cadettes, 45290 Le Moulinet-sur-Solin'),
(4329,'788bis Milhac-Haut, 42370 Saint-Haon-le-Châtel');

INSERT INTO Organisation (numero,adresse) VALUES
(4330,'600bis Ventajou, 62980 Vermelles'),
(4331,'285 Pre de Biche, 28360 La Bourdinière-Saint-Loup');

INSERT INTO Organisation (numero,adresse) VALUES
(4332,'497 Tennis, 52110 Dommartin-le-Saint-Père'),
(4333,'530 Frère Jean, 57930 Berthelming');

INSERT INTO Organisation (numero,adresse) VALUES
(4334,'450 Lieucamp, 50530 Champeaux'),
(4335,'213 Bourgougnou, 45700 Cortrat');

INSERT INTO Organisation (numero,adresse) VALUES
(4336,'961 Le Burguet, 35140 Saint-Hilaire-des-Landes'),
(4337,'766 Pre Porche, 30630 Verfeuil');

INSERT INTO Organisation (numero,adresse) VALUES
(4338,'789 Coularive, 30210 Remoulins'),
(4339,'453 Corpillere, 25870 Cussey-sur-l''Ognon');

INSERT INTO Organisation (numero,adresse) VALUES
(4340,'404 Bâtiment Le thym Entrée 41, 04500 Riez'),
(4341,'731 Bac d''Al Devez, 74350 Villy-le-Pelloux');

INSERT INTO Organisation (numero,adresse) VALUES
(4342,'381 La Tolosane, 25110 Fourbanne'),
(4343,'602 Pérols, 56400 Brech');

INSERT INTO Organisation (numero,adresse) VALUES
(4344,'279 Barbarin, 07160 Saint-Cierge-sous-le-Cheylard'),
(4345,'160 Puech de Rougis, 65140 Sarriac-Bigorre');

INSERT INTO Organisation (numero,adresse) VALUES
(4346,'528bis Chez le Pré, 51460 Courtisols'),
(4347,'608 Impasse  Fleurie, 21220 Clémencey');

INSERT INTO Organisation (numero,adresse) VALUES
(4348,'198bis Pré de la Foire, 55190 Villeroy-sur-Méholle'),
(4349,'64bis Route de Chauny, 51390 Germigny');

INSERT INTO Organisation (numero,adresse) VALUES
(4350,'314 Bois Communaux de Laifour, 59830 Cobrieux'),
(4351,'629 Jouas, 28140 Guillonville');

INSERT INTO Organisation (numero,adresse) VALUES
(4352,'880 ferme de la croix bleue, 60130 Saint-Remy-en-l''Eau'),
(4353,'218 Derriere les Fosses, 12220 Vaureilles');

INSERT INTO Organisation (numero,adresse) VALUES
(4354,'553 """ Champ du Bois """, 30630 Goudargues'),
(4355,'365 Layat, 11580 Missègre');

INSERT INTO Organisation (numero,adresse) VALUES
(4356,'161bis San Juan, 08200 Fleigneux'),
(4357,'867 La Plane du Riol, 57330 Zoufftgen');

INSERT INTO Organisation (numero,adresse) VALUES
(4358,'33 Combe Terraillon, 57720 Waldhouse'),
(4359,'614bis Goutte Morte, 61250 Damigny');

INSERT INTO Organisation (numero,adresse) VALUES
(4360,'173bis Cougne Proumie, 45300 Courcelles'),
(4361,'902 Place Gustave Civatte, 80240 Aizecourt-le-Bas');

INSERT INTO Organisation (numero,adresse) VALUES
(4362,'927 La Ramade, 33300 Bordeaux'),
(4363,'213 Le Mas de Capus, 32800 Réans');

INSERT INTO Organisation (numero,adresse) VALUES
(4364,'363bis Saint-christ, 77940 La Brosse-Montceaux'),
(4365,'649bis La Perrière, 45300 Pithiviers');

INSERT INTO Organisation (numero,adresse) VALUES
(4366,'809bis Diege, 71570 La Chapelle-de-Guinchay'),
(4367,'750bis Montée Riviéra Palace, 42330 Saint-Médard-en-Forez');

INSERT INTO Organisation (numero,adresse) VALUES
(4368,'662bis Chemin de Peyarnaud, 48310 Termes'),
(4369,'42bis Les Peltes, 39800 Villerserine');

INSERT INTO Organisation (numero,adresse) VALUES
(4370,'667 Le Chemin Vert, 31790 Saint-Jory'),
(4371,'47 Le Carré des Muses, 67290 La Petite-Pierre');

INSERT INTO Organisation (numero,adresse) VALUES
(4372,'436 Chemin Départemental 121, 65400 Artalens-Souin'),
(4373,'332 Ferrus, 77130 Varennes-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(4374,'10 Le Rank, 78660 Paray-Douaville'),
(4375,'868 La Borie Graissac, 53600 Sainte-Gemmes-le-Robert');

INSERT INTO Organisation (numero,adresse) VALUES
(4376,'34 Puech de Tiouliere, 62910 Serques'),
(4377,'110 Square Jean Henri Fabre, 08140 Villers-Cernay');

INSERT INTO Organisation (numero,adresse) VALUES
(4378,'652 Les Champs Francois, 70120 Confracourt'),
(4379,'172 La Javanaise, 57420 Liéhon');

INSERT INTO Organisation (numero,adresse) VALUES
(4380,'965 Le Jardin, 06260 Saint-Léger'),
(4381,'708 Col des Allongs, 13360 Roquevaire');

INSERT INTO Organisation (numero,adresse) VALUES
(4382,'189 Les Heures Claires Bat 1, 36340 Maillet'),
(4383,'514 Salle Polyvalente Cinéma de Pays, 44320 Saint-Père-en-Retz');

INSERT INTO Organisation (numero,adresse) VALUES
(4384,'74 Bésséat Sud, 05700 Trescléoux'),
(4385,'987 Le Musée Départemental de l''Ecole Publique, 58170 Millay');

INSERT INTO Organisation (numero,adresse) VALUES
(4386,'715 L''Ardillat, 29950 Bénodet'),
(4387,'299 Place du 10 Mars 1946, 45170 Montigny');

INSERT INTO Organisation (numero,adresse) VALUES
(4388,'861 Défibrillateur intérieur, 02210 Montgru-Saint-Hilaire'),
(4389,'976 Huédour, 57810 Maizières-lès-Vic');

INSERT INTO Organisation (numero,adresse) VALUES
(4390,'994 Les Coudennasses, 60112 Pierrefitte-en-Beauvaisis'),
(4391,'29 Chomette, 02110 La Vallée-Mulâtre');

INSERT INTO Organisation (numero,adresse) VALUES
(4392,'821 Prairie Saint Christophe, 17800 Chadenac'),
(4393,'193 Fosse Noe, 52200 Champigny-lès-Langres');

INSERT INTO Organisation (numero,adresse) VALUES
(4394,'479bis Les Libellules, 18350 Ignol'),
(4395,'245 les cazals, 34500 Béziers');

INSERT INTO Organisation (numero,adresse) VALUES
(4396,'526 Mas de Carmes, 76390 Illois'),
(4397,'745 Pra Neuf, 51260 Bagneux');

INSERT INTO Organisation (numero,adresse) VALUES
(4398,'792 Village des Gabets, 14320 Feuguerolles-Bully'),
(4399,'239 Althérophilie, 30100 Alès');

INSERT INTO Organisation (numero,adresse) VALUES
(4400,'804bis Les Croyes, 69460 Saint-Étienne-la-Varenne'),
(4401,'655 Ham de Gros Loup, 46360 Nadillac');

INSERT INTO Organisation (numero,adresse) VALUES
(4402,'129 Les Gillards, 59750 Feignies'),
(4403,'770 Allée de Vaublanc, 63450 Chanonat');

INSERT INTO Organisation (numero,adresse) VALUES
(4404,'685bis Les Auches, 76590 Sainte-Foy'),
(4405,'263 Fontrevade, 24220 Allas-les-Mines');

INSERT INTO Organisation (numero,adresse) VALUES
(4406,'512bis Les-Combes, 79190 Lorigné'),
(4407,'72bis Badens, 14380 Le Mesnil-Benoist');

INSERT INTO Organisation (numero,adresse) VALUES
(4408,'878 Place Stade, 56160 Ploërdut'),
(4409,'709 Rouquette, 52160 Poinsenot');

INSERT INTO Organisation (numero,adresse) VALUES
(4410,'569 La Fajole, 08240 Vaux-en-Dieulet'),
(4411,'505 Lilou, 39210 Voiteur');

INSERT INTO Organisation (numero,adresse) VALUES
(4412,'20bis Résidence Les Sentinières, 09000 Le Bosc'),
(4413,'416bis La Barrère, 46150 Nuzéjouls');

INSERT INTO Organisation (numero,adresse) VALUES
(4414,'105 Les Carbonnieres, 30132 Caissargues'),
(4415,'864 En Barvier, 39150 La Chaumusse');

INSERT INTO Organisation (numero,adresse) VALUES
(4416,'620 Fereyre, 08240 Authe'),
(4417,'565 En Leurperon, 27370 Houlbec-près-le-Gros-Theil');

INSERT INTO Organisation (numero,adresse) VALUES
(4418,'494 Les Granges Teillières - Cormaranche-en-Bugey, 34160 Castries'),
(4419,'258 Limouze-Haut, 59830 Bachy');

INSERT INTO Organisation (numero,adresse) VALUES
(4420,'771bis Le Mas de Ferrieres, 28220 Douy'),
(4421,'503bis Les_chaputs, 53150 Saint-Céneré');

INSERT INTO Organisation (numero,adresse) VALUES
(4422,'12 Liaison rue Françoise Giroud - boulevard du Mercantour, 27480 Beauficel-en-Lyons'),
(4423,'126bis Corgenay, 61310 Courménil');

INSERT INTO Organisation (numero,adresse) VALUES
(4424,'166 Gaujac, 47120 Saint-Sernin'),
(4425,'836 Voie Cap 3000, 52310 Viéville');

INSERT INTO Organisation (numero,adresse) VALUES
(4426,'393 La patte d''oie, 59252 Wasnes-au-Bac'),
(4427,'710 Bergerie La Lavine, 16300 Montmérac');

INSERT INTO Organisation (numero,adresse) VALUES
(4428,'970 Bois de Garette, 45390 Boësses'),
(4429,'226 """ Montcoulon """, 12850 Onet-le-Château');

INSERT INTO Organisation (numero,adresse) VALUES
(4430,'1 Pont de Poiron, 68630 Mittelwihr'),
(4431,'474 Domaine de la Guirlande, 67370 Schnersheim');

INSERT INTO Organisation (numero,adresse) VALUES
(4432,'907 Le Mas Emilie, 30190 Saint-Geniès-de-Malgoirès'),
(4433,'549bis Comayras, 65100 Arrodets-ez-Angles');

INSERT INTO Organisation (numero,adresse) VALUES
(4434,'777 La Barthole St Laurent, 70360 La Neuvelle-lès-Scey'),
(4435,'181 Les Bodières, 72540 Vallon-sur-Gée');

INSERT INTO Organisation (numero,adresse) VALUES
(4436,'903 Cinquieme Etoile, 37370 Villebourg'),
(4437,'930 La Tremoliere, 12480 Brousse-le-Château');

INSERT INTO Organisation (numero,adresse) VALUES
(4438,'791 La Couaste, 65200 Orignac'),
(4439,'469 Jas de Berle, 01800 Joyeux');

INSERT INTO Organisation (numero,adresse) VALUES
(4440,'28 Ecole primaire des Capitelles, 60420 Maignelay-Montigny'),
(4441,'366 Resson, 55500 Chanteraine');

INSERT INTO Organisation (numero,adresse) VALUES
(4442,'647 Chouris, 62129 Thérouanne'),
(4443,'167bis Les Fagettes, 32170 Aux-Aussat');

INSERT INTO Organisation (numero,adresse) VALUES
(4444,'349 La Grand Vigne, 62116 Douchy-lès-Ayette'),
(4445,'598 Le Pied Gris, 04110 Villemus');

INSERT INTO Organisation (numero,adresse) VALUES
(4446,'198bis Domaine de la Nartassière, 78890 Garancières'),
(4447,'775 Lentou, 76460 Saint-Valery-en-Caux');

INSERT INTO Organisation (numero,adresse) VALUES
(4448,'736 Baragne, 64260 Aste-Béon'),
(4449,'127 bel air, 25380 La Grange');

INSERT INTO Organisation (numero,adresse) VALUES
(4450,'794bis Le Collet de Matroou, 05110 Vitrolles'),
(4451,'570bis Parking des Loges, 39110 Clucy');

INSERT INTO Organisation (numero,adresse) VALUES
(4452,'410 En Daye, 02290 Osly-Courtil'),
(4453,'623 La Boriote, 60640 Catigny');

INSERT INTO Organisation (numero,adresse) VALUES
(4454,'760 Le Bertrand, 01990 Saint-Trivier-sur-Moignans'),
(4455,'463 Les Fargues, 58130 Vaux d''Amognes');

INSERT INTO Organisation (numero,adresse) VALUES
(4456,'960 Voie Claude Vignon, 51270 Talus-Saint-Prix'),
(4457,'9 Résidence Belles Fontaines, 24240 Monestier');

INSERT INTO Organisation (numero,adresse) VALUES
(4458,'803bis La Goutte-Oiseaux, 35134 Thourie'),
(4459,'401 La Ringade, 36190 Cuzion');

INSERT INTO Organisation (numero,adresse) VALUES
(4460,'446 Les Romarins Ii, 62158 La Herlière'),
(4461,'804 La grange des carquois, 36300 Douadic');

INSERT INTO Organisation (numero,adresse) VALUES
(4462,'802 La Voie de Brienne, 45230 Sainte-Geneviève-des-Bois'),
(4463,'550 Lieu-dit Les Bayles, 61120 Sap-en-Auge');

INSERT INTO Organisation (numero,adresse) VALUES
(4464,'723 Parcy, 03250 Le Mayet-de-Montagne'),
(4465,'900bis Residence Castel Rosso, 47290 Saint-Maurice-de-Lestapel');

INSERT INTO Organisation (numero,adresse) VALUES
(4466,'746bis Dolce via, 32310 Bezolles'),
(4467,'842 Vieille Vayssiere, 78930 Boinville-en-Mantois');

INSERT INTO Organisation (numero,adresse) VALUES
(4468,'75 Fretech, 28270 Crucey-Villages'),
(4469,'46bis lieu-dit BELFORT HAUT, 65370 Sacoué');

INSERT INTO Organisation (numero,adresse) VALUES
(4470,'447 le petit tourtouil, 80270 Bettencourt-Rivière'),
(4471,'387 Chez Pillaud, 79230 Prahecq');

INSERT INTO Organisation (numero,adresse) VALUES
(4472,'770bis Aux Granges de Montvernier, 01190 Chevroux'),
(4473,'791bis Momplaisir, 41100 Crucheray');

INSERT INTO Organisation (numero,adresse) VALUES
(4474,'22 La Reue, 33240 Saint-Gervais'),
(4475,'485 Le Champ des Ormes, 16400 Puymoyen');

INSERT INTO Organisation (numero,adresse) VALUES
(4476,'702 La chèvre verte, 04320 Sausses'),
(4477,'964bis Place Sainte-Marguerite, 76790 Le Tilleul');

INSERT INTO Organisation (numero,adresse) VALUES
(4478,'68 Tiecs Inferieur, 65700 Labatut-Rivière'),
(4479,'271bis Domaine des Vallées, 59267 Cantaing-sur-Escaut');

INSERT INTO Organisation (numero,adresse) VALUES
(4480,'405 Les Vaysses, 20251 Piedicorte-di-Gaggio'),
(4481,'619bis Champ Famin, 69800 Saint-Priest');

INSERT INTO Organisation (numero,adresse) VALUES
(4482,'983bis Le Grand bois, 64470 Laguinge-Restoue'),
(4483,'796 Lieu-dit Les Baraques, 46230 Bach');

INSERT INTO Organisation (numero,adresse) VALUES
(4484,'762 Les Charmes, 11240 Hounoux'),
(4485,'279 Puech Haut, 26160 Félines-sur-Rimandoule');

INSERT INTO Organisation (numero,adresse) VALUES
(4486,'300bis Chemin de Nivolon, 27160 Sainte-Marie-d''Attez'),
(4487,'369bis Le Grand Picard, 52600 Rivières-le-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(4488,'955 Col de Lieges Sud, 30140 Thoiras'),
(4489,'423bis Déchèterie, 68250 Munwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(4490,'543 Guirole, 70120 Bourguignon-lès-Morey'),
(4491,'644bis La Casita, 77350 Boissettes');

INSERT INTO Organisation (numero,adresse) VALUES
(4492,'940 La Perrière, 54980 Batilly'),
(4493,'887 Bâtiment Le pétunia, 62120 Racquinghem');

INSERT INTO Organisation (numero,adresse) VALUES
(4494,'333 Barrage de Sarrans, 57590 Morville-sur-Nied'),
(4495,'258 Fonds de la Plaine, 65130 Tilhouse');

INSERT INTO Organisation (numero,adresse) VALUES
(4496,'468 Plan de la Tour Nord, 77178 Oissery'),
(4497,'652bis Impasse sans nom 2, 02220 Paars');

INSERT INTO Organisation (numero,adresse) VALUES
(4498,'171 Bois du Tournié, 62127 Monchy-Breton'),
(4499,'312 Chemin des Sagnes, 61490 Saint-Clair-de-Halouze');

INSERT INTO Organisation (numero,adresse) VALUES
(4500,'719 Montlouis, 54470 Grosrouvres'),
(4501,'787 Aux Janges, 51170 Poilly');

INSERT INTO Organisation (numero,adresse) VALUES
(4502,'615 Les Coudels, 02600 Laversine'),
(4503,'154bis Le Chemin de Clermont, 65100 Lézignan');

INSERT INTO Organisation (numero,adresse) VALUES
(4504,'89 Font Basse, 42460 La Gresle'),
(4505,'162bis Pailles, 32120 Sarrant');

INSERT INTO Organisation (numero,adresse) VALUES
(4506,'294bis l''Albespy, 45310 Rouvray-Sainte-Croix'),
(4507,'485bis Plan Chavonnet, 53600 Voutré');

INSERT INTO Organisation (numero,adresse) VALUES
(4508,'601 Perbencous-Haut, 02130 Fère-en-Tardenois'),
(4509,'692 Le Fresne, 42110 Chambéon');

INSERT INTO Organisation (numero,adresse) VALUES
(4510,'851 Sichon, 34080 Montpellier'),
(4511,'680 Résidence Le Fou Chantant, 45270 Nesploy');

INSERT INTO Organisation (numero,adresse) VALUES
(4512,'914 La Plasse-Ouest, 31450 Corronsac'),
(4513,'984bis Chemin des Plantades, 26800 Étoile-sur-Rhône');

INSERT INTO Organisation (numero,adresse) VALUES
(4514,'662 Le Porgue, 16130 Saint-Preuil'),
(4515,'726 Moucherelle Ferme, 59190 Hazebrouck');

INSERT INTO Organisation (numero,adresse) VALUES
(4516,'578 Le Clos de Souche, 54250 Champigneulles'),
(4517,'649 Le Marengo C, 51130 Val-des-Marais');

INSERT INTO Organisation (numero,adresse) VALUES
(4518,'305 Champ de Faire, 60420 Ferrières'),
(4519,'868 Bonhoure, 25310 Glay');

INSERT INTO Organisation (numero,adresse) VALUES
(4520,'134 La Rabotine, 67440 Westhouse-Marmoutier'),
(4521,'486 Combe de Veyle Sud, 53150 Montourtier');

INSERT INTO Organisation (numero,adresse) VALUES
(4522,'515bis Boulouysset, 49390 Parçay-les-Pins'),
(4523,'233 Les Manisselles, 43400 Le Chambon-sur-Lignon');

INSERT INTO Organisation (numero,adresse) VALUES
(4524,'971 résidence Le Bellini, 17580 Le Bois-Plage-en-Ré'),
(4525,'651bis Grandes Vignes, 29860 Plouvien');

INSERT INTO Organisation (numero,adresse) VALUES
(4526,'960 Fontaine Rouge, 66820 Fillols'),
(4527,'392bis Garrabet, 66000 Perpignan');

INSERT INTO Organisation (numero,adresse) VALUES
(4528,'662 Pont Momains, 09420 Esplas-de-Sérou'),
(4529,'981 Nauriol Bas, 42480 La Fouillouse');

INSERT INTO Organisation (numero,adresse) VALUES
(4530,'654 Rond point de la Mer, 41300 La Ferté-Imbault'),
(4531,'150 Le Paget et Graffine, 80250 Quiry-le-Sec');

INSERT INTO Organisation (numero,adresse) VALUES
(4532,'820bis Al Pech de Garrigue, 30250 Souvignargues'),
(4533,'329 Hameau de Gandalous, 59222 Croix-Caluyau');

INSERT INTO Organisation (numero,adresse) VALUES
(4534,'897 Encastel, 38420 Murianette'),
(4535,'793 Le Burgas la Terrisse, 24250 Castelnaud-la-Chapelle');

INSERT INTO Organisation (numero,adresse) VALUES
(4536,'202 La Croix Morel, 21450 Villaines-en-Duesmois'),
(4537,'653 Chevrier, 51260 Courcemain');

INSERT INTO Organisation (numero,adresse) VALUES
(4538,'599 Las Coujounes, 56620 Cléguer'),
(4539,'494 N° rue, 40120 Bourriot-Bergonce');

INSERT INTO Organisation (numero,adresse) VALUES
(4540,'492 Les Carries, 56400 Plougoumelen'),
(4541,'188bis La Rayasse, 77540 Rozay-en-Brie');

INSERT INTO Organisation (numero,adresse) VALUES
(4542,'915 Boundes, 22480 Saint-Gilles-Pligeaux'),
(4543,'562 Chene Est, 16140 Ligné');

INSERT INTO Organisation (numero,adresse) VALUES
(4544,'249 Champ Maconnais, 23500 La Nouaille'),
(4545,'629bis La Pointe, 71390 Messey-sur-Grosne');

INSERT INTO Organisation (numero,adresse) VALUES
(4546,'965bis Les Chaumettes, 57230 Baerenthal'),
(4547,'921bis Le Phoébus, 60190 Cressonsacq');

INSERT INTO Organisation (numero,adresse) VALUES
(4548,'844 Reserve des Daubois, 49540 Aubigné-sur-Layon'),
(4549,'908 Lieu dit Palette, 68290 Sewen');

INSERT INTO Organisation (numero,adresse) VALUES
(4550,'607 Le coulet-Sud, 63190 Saint-Jean-d''Heurs'),
(4551,'57bis Le Mijea, 39380 La Loye');

INSERT INTO Organisation (numero,adresse) VALUES
(4552,'19bis Res Du Port B3, 07570 Désaignes'),
(4553,'374 Les Oeufs, 67250 Merkwiller-Pechelbronn');

INSERT INTO Organisation (numero,adresse) VALUES
(4554,'320 Jean Blanc, 02000 Étouvelles'),
(4555,'494bis Marlavagne, 70000 Pusy-et-Épenoux');

INSERT INTO Organisation (numero,adresse) VALUES
(4556,'755 Ozon, 35450 Landavran'),
(4557,'808 Gambilliere, 41310 Ambloy');

INSERT INTO Organisation (numero,adresse) VALUES
(4558,'53bis Domaine Panet, 41240 Saint-Laurent-des-Bois'),
(4559,'278bis Le Bois de la Haute Borne, 46320 Saint-Simon');

INSERT INTO Organisation (numero,adresse) VALUES
(4560,'57 Escalier Avenue Julien - Chemin de la Passerelle, 41140 Noyers-sur-Cher'),
(4561,'63 Les Hauts de Las Cours, 22520 Binic-Étables-sur-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(4562,'562bis Impasse du Bois fort, 11580 Missègre'),
(4563,'918 La Cote du Sourderon, 39700 Amange');

INSERT INTO Organisation (numero,adresse) VALUES
(4564,'130 Bente Farine, 43300 Vissac-Auteyrac'),
(4565,'849bis Ayvides et le Clos, 36170 Parnac');

INSERT INTO Organisation (numero,adresse) VALUES
(4566,'428 La Brouelenque, 62360 Condette'),
(4567,'634 À la Carême, 11510 Feuilla');

INSERT INTO Organisation (numero,adresse) VALUES
(4568,'395 Les Champs Panais, 21170 Magny-lès-Aubigny'),
(4569,'209 La Petite Forêt, 32260 Labarthe');

INSERT INTO Organisation (numero,adresse) VALUES
(4570,'72 Bât C les Deux Moulins, 27230 La Chapelle-Hareng'),
(4571,'72 Saint-Benoit, 44330 Mouzillon');

INSERT INTO Organisation (numero,adresse) VALUES
(4572,'665bis Le Vigny, 80250 Lawarde-Mauger-l''Hortoy'),
(4573,'166 Serre de Laric, 52200 Humes-Jorquenay');

INSERT INTO Organisation (numero,adresse) VALUES
(4574,'628bis Canalis, 70000 Velle-le-Châtel'),
(4575,'709bis Les Hauches, 33490 Verdelais');

INSERT INTO Organisation (numero,adresse) VALUES
(4576,'624 Les Paliès, 72610 Villeneuve-en-Perseigne'),
(4577,'268 Le Cros Saint Pierre A, 70190 Trésilley');

INSERT INTO Organisation (numero,adresse) VALUES
(4578,'261 Le Grand Courty, 65190 Bernadets-Dessus'),
(4579,'941 Foret de Dreuille, 31110 Gouaux-de-Larboust');

INSERT INTO Organisation (numero,adresse) VALUES
(4580,'311 Plagueben, 76750 Bois-Héroult'),
(4581,'0 Les Placettes, 31140 Saint-Alban');

INSERT INTO Organisation (numero,adresse) VALUES
(4582,'343bis Serin, 79200 La Peyratte'),
(4583,'958 Le Parc Des Soldanelles A/B, 76560 Berville-en-Caux');

INSERT INTO Organisation (numero,adresse) VALUES
(4584,'825 Le Cantonnier, 07230 Payzac'),
(4585,'567 Route de Gabriac-Le Bourgnou, 62690 Savy-Berlette');

INSERT INTO Organisation (numero,adresse) VALUES
(4586,'95bis Montrepos, 61570 Boischampré'),
(4587,'221 Chateau de la Lande, 63330 Pionsat');

INSERT INTO Organisation (numero,adresse) VALUES
(4588,'44 La Beguine, 31140 Fonbeauzard'),
(4589,'534 Magreou, 38400 Saint-Martin-d''Hères');

INSERT INTO Organisation (numero,adresse) VALUES
(4590,'746bis Bât A3 les hauts de Septèmes sud, 17330 Vergné'),
(4591,'710bis Lotissement Les Graviers II, 60400 Pont-l''Évêque');

INSERT INTO Organisation (numero,adresse) VALUES
(4592,'869 Riguetorte, 14250 Brouay'),
(4593,'842bis Tremolieres, 46150 Thédirac');

INSERT INTO Organisation (numero,adresse) VALUES
(4594,'30 La Renardière, 15210 Ydes'),
(4595,'175 Les Causses, 77850 Héricy');

INSERT INTO Organisation (numero,adresse) VALUES
(4596,'633 Place du Souvenir, 11400 Verdun-en-Lauragais'),
(4597,'57 Lieu-Dit Les Gavottes, 03210 Bresnay');

INSERT INTO Organisation (numero,adresse) VALUES
(4598,'344 Les Pieces de Mandrant, 40270 Larrivière-Saint-Savin'),
(4599,'4 Allée Cavendish, 14190 Soignolles');

INSERT INTO Organisation (numero,adresse) VALUES
(4600,'653 Lieudit Le Château, 40270 Saint-Maurice-sur-Adour'),
(4601,'239 Saint Martin des Faux, 02350 Gizy');

INSERT INTO Organisation (numero,adresse) VALUES
(4602,'315bis Mont de l''Ubac, 01130 Les Neyrolles'),
(4603,'11bis Gimelette, 42360 Panissières');

INSERT INTO Organisation (numero,adresse) VALUES
(4604,'102 Potardière, 02490 Pontru'),
(4605,'800bis Bel Air 2, 59134 Beaucamps-Ligny');

INSERT INTO Organisation (numero,adresse) VALUES
(4606,'126 Chemin Vicinal 5 Thenailles à la Verte Va, 62480 Le Portel'),
(4607,'449bis Le Mont de Blesmes(ferme), 80140 Vaux-Marquenneville');

INSERT INTO Organisation (numero,adresse) VALUES
(4608,'561 Lacalm, 28120 Épeautrolles'),
(4609,'307 Chatarusse, 45140 Ingré');

INSERT INTO Organisation (numero,adresse) VALUES
(4610,'686 Granges de Léo, 11300 Castelreng'),
(4611,'114 La Réserve, 32400 Aurensan');

INSERT INTO Organisation (numero,adresse) VALUES
(4612,'730 Villa Belle Escale, 64150 Bésingrand'),
(4613,'100bis Ferme de Bucy le Bras, 32350 Mirannes');

INSERT INTO Organisation (numero,adresse) VALUES
(4614,'879 La Farigoulette, 67700 Waldolwisheim'),
(4615,'900bis Le Cap del Pouech, 38440 Saint-Jean-de-Bournay');

INSERT INTO Organisation (numero,adresse) VALUES
(4616,'72 Lieu-dit Las Gouttes, 67500 Weitbruch'),
(4617,'705bis Domaine de la Rencontre, 58330 Sainte-Marie');

INSERT INTO Organisation (numero,adresse) VALUES
(4618,'206 Font Galoune, 24360 Soudat'),
(4619,'972 Courteaux, 02260 Clairfontaine');

INSERT INTO Organisation (numero,adresse) VALUES
(4620,'358 Rue Docteur Ciaudo, 01450 Leyssard'),
(4621,'237bis Hameau de Cayrac, 41210 Saint-Viâtre');

INSERT INTO Organisation (numero,adresse) VALUES
(4622,'641 Place du Souvenir Français, 35320 Crevin'),
(4623,'14 Pierlou, 14400 Monceaux-en-Bessin');

INSERT INTO Organisation (numero,adresse) VALUES
(4624,'619bis Maison de la Chasse, 08260 Antheny'),
(4625,'263 Contree du Port, 53300 Oisseau');

INSERT INTO Organisation (numero,adresse) VALUES
(4626,'428bis Combe de Bordeaux, 11360 Albas'),
(4627,'712 Villa Lou Nespoulie, 21110 Bretenière');

INSERT INTO Organisation (numero,adresse) VALUES
(4628,'82 ramouns, 19200 Thalamy'),
(4629,'362bis Le Chassin, 64330 Ribarrouy');

INSERT INTO Organisation (numero,adresse) VALUES
(4630,'476 Labrot, 11430 Gruissan'),
(4631,'159 Devant la Ferme, 09100 Escosse');

INSERT INTO Organisation (numero,adresse) VALUES
(4632,'193 Le Petit Tanvol, 02210 Vichel-Nanteuil'),
(4633,'221 Baruze, 64120 Bunus');

INSERT INTO Organisation (numero,adresse) VALUES
(4634,'695 Collet de Mouton, 21600 Fénay'),
(4635,'407 Soualeou, 18200 Colombiers');

INSERT INTO Organisation (numero,adresse) VALUES
(4636,'789 Bretelle Sortie N°54 A8 - Rémond (Provenance Vintimille), 64270 Lahontan'),
(4637,'268 Las Forgues d''en Haut, 42155 Saint-Léger-sur-Roanne');

INSERT INTO Organisation (numero,adresse) VALUES
(4638,'9 Les Sagnières, 39260 Montcusel'),
(4639,'342bis Provencheres, 58350 Saint-Malo-en-Donziois');

INSERT INTO Organisation (numero,adresse) VALUES
(4640,'810bis Pra Moussiou, 46210 Bessonies'),
(4641,'692 La Barlandie, 10200 Dolancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(4642,'840 Le Bouyssou Bas, 10320 Lirey'),
(4643,'233 Parking de l''Alp, 50200 Monthuchon');

INSERT INTO Organisation (numero,adresse) VALUES
(4644,'87bis Plagnoulet, 11140 La Fajolle'),
(4645,'154 Les Sesquières, 17520 Celles');

INSERT INTO Organisation (numero,adresse) VALUES
(4646,'584 Le Pouret, 71400 Antully'),
(4647,'676bis Ruelle Eleup, 63160 Espirat');

INSERT INTO Organisation (numero,adresse) VALUES
(4648,'744 Escalier RM-rue des remparts, 33670 Créon'),
(4649,'732 Appt 101, 69520 Grigny');

INSERT INTO Organisation (numero,adresse) VALUES
(4650,'23bis Saint-Thibaut, 10190 Messon'),
(4651,'308 Villa Missicia, 31210 Ardiège');

INSERT INTO Organisation (numero,adresse) VALUES
(4652,'681 Gautrinière, 33160 Saint-Aubin-de-Médoc'),
(4653,'629 Pigailh, 70270 Fresse');

INSERT INTO Organisation (numero,adresse) VALUES
(4654,'104 Le Puech Roux, 60240 Boury-en-Vexin'),
(4655,'984 Ferme de Fauroux, 50630 Octeville-l''Avenel');

INSERT INTO Organisation (numero,adresse) VALUES
(4656,'289bis Jannicou, 27230 Folleville'),
(4657,'732 Bichateau, 62450 Morval');

INSERT INTO Organisation (numero,adresse) VALUES
(4658,'123bis Escalier Avenue de la Conca d''Or/Chemin de l''école des Moulins, 44460 Fégréac'),
(4659,'859 À la Grange Neuve, 02100 Neuville-Saint-Amand');

INSERT INTO Organisation (numero,adresse) VALUES
(4660,'227 Pont de Bru, 62810 Berlencourt-le-Cauroy'),
(4661,'708 Les prés de Lachamp, 78117 Toussus-le-Noble');

INSERT INTO Organisation (numero,adresse) VALUES
(4662,'730 Plane de Caussou, 19200 Valiergues'),
(4663,'963bis Les Tourelles, 60620 Rosoy-en-Multien');

INSERT INTO Organisation (numero,adresse) VALUES
(4664,'301bis Place de Champagne, 69620 Ternand'),
(4665,'28 La Salze, 76340 Bazinval');

INSERT INTO Organisation (numero,adresse) VALUES
(4666,'348 Au Dessus des Plantes, 47330 Montauriol'),
(4667,'284 Campouries, 31370 Poucharramet');

INSERT INTO Organisation (numero,adresse) VALUES
(4668,'476 L''Abaguie, 26170 La Rochette-du-Buis'),
(4669,'744bis Champ des Morts, 24800 Saint-Sulpice-d''Excideuil');

INSERT INTO Organisation (numero,adresse) VALUES
(4670,'414 Escapat le Neuf, 41190 Tourailles'),
(4671,'180 Passerelle Paul Durand-Cazelles, 25160 Montperreux');

INSERT INTO Organisation (numero,adresse) VALUES
(4672,'357 Monatgne de Bassibie, 47290 Monbahus'),
(4673,'366 Montclarou, 71250 Jalogny');

INSERT INTO Organisation (numero,adresse) VALUES
(4674,'859 Barbazan, 25510 Domprel'),
(4675,'856 Jardin des Fusillés de Saint-Julien du Verdon, 57220 Condé-Northen');

INSERT INTO Organisation (numero,adresse) VALUES
(4676,'901bis Lieu Dit Chapayrou, 76150 La Vaupalière'),
(4677,'337 L’Albrespy, 02820 Saint-Erme-Outre-et-Ramecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(4678,'594 Miquels, 54610 Clémery'),
(4679,'380bis Villa Solange, 57580 Herny');

INSERT INTO Organisation (numero,adresse) VALUES
(4680,'593 En Chossagne, 62860 Saudemont'),
(4681,'823 Roumier, 47250 Bouglon');

INSERT INTO Organisation (numero,adresse) VALUES
(4682,'912 Terre Rebotet, 62232 Annezin'),
(4683,'790 Le Grauzel, 49310 Cernusson');

INSERT INTO Organisation (numero,adresse) VALUES
(4684,'997bis Aux Ruliers, 44800 Saint-Herblain'),
(4685,'886 Vers Comte, 70140 Lieucourt');

INSERT INTO Organisation (numero,adresse) VALUES
(4686,'273 La Granget, 51430 Tinqueux'),
(4687,'946 Impasse des Bruyeres, 62810 Grand-Rullecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(4688,'400 Villa Emilia, 69290 Pollionnay'),
(4689,'194 Le Vieux Besset, 22160 Maël-Pestivien');

INSERT INTO Organisation (numero,adresse) VALUES
(4690,'250 Doumengé, 70120 Arbecey'),
(4691,'407 Normandie, 10400 Fontenay-de-Bossery');

INSERT INTO Organisation (numero,adresse) VALUES
(4692,'821 Le Chambon de Langlade, 67430 Vœllerdingen'),
(4693,'272 Les Bondes, 65170 Tramezaïgues');

INSERT INTO Organisation (numero,adresse) VALUES
(4694,'473 Lieu Gueulet, 21540 Montoillot'),
(4695,'440 Place des Droits de l''Homme, 67170 Olwisheim');

INSERT INTO Organisation (numero,adresse) VALUES
(4696,'194bis Plan de Ribiers, 02110 Saint-Martin-Rivière'),
(4697,'909bis La Béziane, 60400 Appilly');

INSERT INTO Organisation (numero,adresse) VALUES
(4698,'874 Catary, 36260 Migny'),
(4699,'202 La Ringade, 63380 Pontaumur');

INSERT INTO Organisation (numero,adresse) VALUES
(4700,'917 Res L''Arlequin, 49140 Seiches-sur-le-Loir'),
(4701,'942 Les Veynas, 26340 Espenel');

INSERT INTO Organisation (numero,adresse) VALUES
(4702,'939 Soueix du Baup, 29760 Penmarch'),
(4703,'523bis Les Loges Barrault, 45120 Cepoy');

INSERT INTO Organisation (numero,adresse) VALUES
(4704,'953 Lazons, 31660 Bessières'),
(4705,'736 lieu-dit Les Carreroles, 12300 Boisse-Penchot');

INSERT INTO Organisation (numero,adresse) VALUES
(4706,'111 Grange de Prele, 17350 Taillant'),
(4707,'544 À la Poype, 38122 Chalon');

INSERT INTO Organisation (numero,adresse) VALUES
(4708,'388 Les Potiers, 22690 La Vicomté-sur-Rance'),
(4709,'825 La Pomarède, 18140 Sancergues');

INSERT INTO Organisation (numero,adresse) VALUES
(4710,'510 Lieu-dit La Calmette, 51300 Loisy-sur-Marne'),
(4711,'269 Regalido, 73630 Sainte-Reine');

INSERT INTO Organisation (numero,adresse) VALUES
(4712,'602 Le Viable, 78125 Émancé'),
(4713,'692 Le Pradilou, 01400 Sandrans');

INSERT INTO Organisation (numero,adresse) VALUES
(4714,'242bis Les Oignons Est, 62152 Nesles'),
(4715,'976 Cossonod, 32220 Montpézat');

INSERT INTO Organisation (numero,adresse) VALUES
(4716,'58 Palauti, 34270 Sainte-Croix-de-Quintillargues'),
(4717,'952 Betonesque, 61200 Sarceaux');

INSERT INTO Organisation (numero,adresse) VALUES
(4718,'514 Route de Soueix, 49330 Querré'),
(4719,'694 La Grande Fargeonnière, 42260 Bussy-Albieux');

INSERT INTO Organisation (numero,adresse) VALUES
(4720,'168 Charalon, 60420 Tricot'),
(4721,'361 Roumegouse, 27520 Theillement');

INSERT INTO Organisation (numero,adresse) VALUES
(4722,'643 Sainte-girbelle, 58110 Rouy'),
(4723,'683 La Fontette, 24340 Léguillac-de-Cercles');

INSERT INTO Organisation (numero,adresse) VALUES
(4724,'80 Moa, 35320 Le Sel-de-Bretagne'),
(4725,'996 Porte du soubeyran, 51600 Somme-Tourbe');

INSERT INTO Organisation (numero,adresse) VALUES
(4726,'305 Quai Julien Baudino, 61570 Boischampré'),
(4727,'149 Les Balayes Nord, 14690 Cossesseville');

INSERT INTO Organisation (numero,adresse) VALUES
(4728,'393 Ruzière, 42380 Saint-Nizier-de-Fornas'),
(4729,'502 Arreou et Peyrega, 36130 Montierchaume');

INSERT INTO Organisation (numero,adresse) VALUES
(4730,'177 Jourda, 34800 Ceyras'),
(4731,'489 Lieu-dit Courdille, 19170 Bonnefond');

INSERT INTO Organisation (numero,adresse) VALUES
(4732,'862bis Etang Girard, 51170 Ville-en-Tardenois'),
(4733,'36bis Combe de Carles, 67320 Gœrlingen');

INSERT INTO Organisation (numero,adresse) VALUES
(4734,'489bis Lotissement les Planes, 47700 Saint-Martin-Curton'),
(4735,'931 Villa Tassadite, 16560 Tourriers');

INSERT INTO Organisation (numero,adresse) VALUES
(4736,'581 Place Jean Flory, 03120 Andelaroche'),
(4737,'516 Saint Eloy, 10200 Saulcy');

INSERT INTO Organisation (numero,adresse) VALUES
(4738,'197 Cuernegre, 26510 Cornillac'),
(4739,'857 Quartier de la Gardi, 57635 Bickenholtz');

INSERT INTO Organisation (numero,adresse) VALUES
(4740,'299bis Sauze-vieux, 10110 Ville-sur-Arce'),
(4741,'329 Chemin rural de la Colle, 75011 Paris 11');

INSERT INTO Organisation (numero,adresse) VALUES
(4742,'234 Mairie annexe de Sclos de Contes, 24520 Lamonzie-Montastruc'),
(4743,'208bis Le Mas du Pastel, 24210 Limeyrat');

INSERT INTO Organisation (numero,adresse) VALUES
(4744,'293 Ferme de la Siège, 80400 Sancourt'),
(4745,'746bis Moulin Bataille, 44850 Ligné');

INSERT INTO Organisation (numero,adresse) VALUES
(4746,'150 "Les Blancs, ""La Fruitière""", 52290 Éclaron-Braucourt-Sainte-Livière'),
(4747,'428 L’Equateur Maisons des Sables 3, 51420 Witry-lès-Reims');

INSERT INTO Organisation (numero,adresse) VALUES
(4748,'616 Galot, 08220 Banogne-Recouvrance'),
(4749,'235 Pechengailler, 62127 Ligny-Saint-Flochel');

INSERT INTO Organisation (numero,adresse) VALUES
(4750,'197bis Domaine de Grand Condom, 12400 Montlaur'),
(4751,'787 La Bergerette, 45320 Foucherolles');

INSERT INTO Organisation (numero,adresse) VALUES
(4752,'345 L''Etang René, 76520 Mesnil-Raoul'),
(4753,'873 Local Technique, 23480 Le Donzeil');

INSERT INTO Organisation (numero,adresse) VALUES
(4754,'973 Les Forges, 40660 Moliets-et-Maa'),
(4755,'481 Basse Vaucluse, 24130 La Force');

INSERT INTO Organisation (numero,adresse) VALUES
(4756,'525 La Maléne Hameau, 46340 Rampoux'),
(4757,'57 Residence les Fougeres, 51340 Heiltz-l''Évêque');

INSERT INTO Organisation (numero,adresse) VALUES
(4758,'361 Mont Pelet, 21500 Planay'),
(4759,'420bis Trespeymia, 39290 Archelange');

INSERT INTO Organisation (numero,adresse) VALUES
(4760,'880bis Fontrevade, 28260 Saint-Ouen-Marchefroy'),
(4761,'752 Domaine du Bois d''Arreux, 27230 Drucourt');

INSERT INTO Organisation (numero,adresse) VALUES
(4762,'89bis Tennis Club Moulinois, 02000 Barenton-Bugny'),
(4763,'937 Chemin des Trillos, 33440 Ambarès-et-Lagrave');

INSERT INTO Organisation (numero,adresse) VALUES
(4764,'528bis Mas Del Sol, 33420 Dardenac'),
(4765,'204 Pas Del Theil, 14190 Saint-Germain-le-Vasson');

INSERT INTO Organisation (numero,adresse) VALUES
(4766,'664 La Pontière, 53500 Vautorte'),
(4767,'964 Borde Mounoy, 02110 Prémont');

INSERT INTO Organisation (numero,adresse) VALUES
(4768,'763bis Zone d’Activite du Bois Fortant, 48260 Recoules-d''Aubrac'),
(4769,'880 Parking de la Baignoire, 07590 Laval-d''Aurelle');

INSERT INTO Organisation (numero,adresse) VALUES
(4770,'19bis Arandon Hameau, 16120 Nonaville'),
(4771,'355 Puech Grimal Bas, 11420 Peyrefitte-sur-l''Hers');

INSERT INTO Organisation (numero,adresse) VALUES
(4772,'156 Le Grand Ligneux, 41100 Renay'),
(4773,'491bis Chemin du Mouriez, 42380 Périgneux');

INSERT INTO Organisation (numero,adresse) VALUES
(4774,'599 Beque, 19160 Roche-le-Peyroux'),
(4775,'451bis Le Petit Poirier, 41100 Saint-Ouen');

INSERT INTO Organisation (numero,adresse) VALUES
(4776,'881bis Les Bros, 71220 Ballore'),
(4777,'929 Modé, 29470 Loperhet');

INSERT INTO Organisation (numero,adresse) VALUES
(4778,'2bis Avenue René Behaine, 67130 Fouday'),
(4779,'704 Les cabanes de L''Espinal, 77820 Les Écrennes');

INSERT INTO Organisation (numero,adresse) VALUES
(4780,'423bis Bretelle Entrée N°51 Digue des Français - A8 (Direction Cannes), 47150 Monségur'),
(4781,'679bis En Darbonnet, 16210 Rioux-Martin');

INSERT INTO Organisation (numero,adresse) VALUES
(4782,'456 Laspiécère, 66750 Saint-Cyprien'),
(4783,'784 Voie de l''Ecole du Bois de Boulogne est, 53340 Val-du-Maine');

INSERT INTO Organisation (numero,adresse) VALUES
(4784,'451 La Fon Négre, 43290 Raucoules'),
(4785,'674 Le Navech, 28130 Hanches');

INSERT INTO Organisation (numero,adresse) VALUES
(4786,'71 Les Epinois, 63750 Savennes'),
(4787,'360 Domaine de l''Etang, 68780 Le Haut Soultzbach');

INSERT INTO Organisation (numero,adresse) VALUES
(4788,'906 Les Paturails, 18800 Farges-en-Septaine'),
(4789,'631bis La Noirée, 06420 Isola');

INSERT INTO Organisation (numero,adresse) VALUES
(4790,'11 Aux Sesquières, 21340 Thury'),
(4791,'44 Les Geraniums, 47110 Sainte-Livrade-sur-Lot');

INSERT INTO Organisation (numero,adresse) VALUES
(4792,'408 Chemin du Scaillon, 45340 Nancray-sur-Rimarde'),
(4793,'836bis Cantaranne, 55130 Abainville');

INSERT INTO Organisation (numero,adresse) VALUES
(4794,'514 Chemin du Canal CGE : Saint-Pancrace, 61220 Saires-la-Verrerie'),
(4795,'106 Puech Burgairou, 12580 Villecomtal');

INSERT INTO Organisation (numero,adresse) VALUES
(4796,'204bis Les Verrets, 01680 Groslée-Saint-Benoit'),
(4797,'852bis Marais de Sergy, 41200 Villefranche-sur-Cher');

INSERT INTO Organisation (numero,adresse) VALUES
(4798,'832bis Champs des Chaumes, 07230 Faugères'),
(4799,'950 Puot, 64420 Gomer');

INSERT INTO Organisation (numero,adresse) VALUES
(4800,'713 Villa Genia Et Michel, 76340 Hodeng-au-Bosc'),
(4801,'6 Rue Haute, 26470 Chalancon');

INSERT INTO Organisation (numero,adresse) VALUES
(4802,'178 Le Coumel, 25340 Viéthorey'),
(4803,'830 La Ribarole, 47800 La Sauvetat-du-Dropt');

INSERT INTO Organisation (numero,adresse) VALUES
(4804,'174 Les Grands Bergers, 36150 Saint-Florentin'),
(4805,'790bis L''Hérété, 17210 Chatenet');

INSERT INTO Organisation (numero,adresse) VALUES
(4806,'510 L''Epine Aubet, 71460 Saint-Martin-du-Tartre'),
(4807,'95bis Noel Bois, 30140 Bagard');

INSERT INTO Organisation (numero,adresse) VALUES
(4808,'886 Le Village de Casteljau, 55000 Culey'),
(4809,'417 Les Cotes de Geneve, 61350 Passais Villages');

INSERT INTO Organisation (numero,adresse) VALUES
(4810,'400 Bois Vernet, 76440 Sommery'),
(4811,'366 Avenue Louis Pasteur, 23130 Chénérailles');

INSERT INTO Organisation (numero,adresse) VALUES
(4812,'695bis Place Fernand Merle, 65240 Guchen'),
(4813,'996 Hameau des Ecopets, 24120 Coly');

INSERT INTO Organisation (numero,adresse) VALUES
(4814,'893 Laumet, 15130 Ytrac'),
(4815,'247 Villa L''Oasis, 46400 Saint-Laurent-les-Tours');

INSERT INTO Organisation (numero,adresse) VALUES
(4816,'702 Le Petit Claux, 38470 Chasselay'),
(4817,'476 La Couture du Chem de Mort, 63880 Olmet');

INSERT INTO Organisation (numero,adresse) VALUES
(4818,'75 La Côte Lac, 10200 Montier-en-l''Isle'),
(4819,'647 Guzet Neige, 65130 Capvern');

INSERT INTO Organisation (numero,adresse) VALUES
(4820,'208bis Les Prouards, 35660 Renac'),
(4821,'431 La Plaine et Las Lannes, 24330 Eyliac');

INSERT INTO Organisation (numero,adresse) VALUES
(4822,'622 Les Mejas, 22100 Saint-Carné'),
(4823,'349 Lieu dit Chartex, 12520 Paulhe');

INSERT INTO Organisation (numero,adresse) VALUES
(4824,'194 Lieu-dit Les Ochiers, 09500 Roumengoux'),
(4825,'464 Fontales, 57720 Loutzviller');

INSERT INTO Organisation (numero,adresse) VALUES
(4826,'52 La Couffignale, 10400 La Villeneuve-au-Châtelot'),
(4827,'556 Doumengé, 16320 Gardes-le-Pontaroux');

INSERT INTO Organisation (numero,adresse) VALUES
(4828,'104 Les Traverses, 38110 Dolomieu'),
(4829,'462 Terres du Ru Preux, 14220 Fresney-le-Vieux');

INSERT INTO Organisation (numero,adresse) VALUES
(4830,'129 Quartier La Fonde, 34560 Montbazin'),
(4831,'913 Les Pres de la Culee, 26220 Comps');

INSERT INTO Organisation (numero,adresse) VALUES
(4832,'953 Cabrespine, 18200 Orval'),
(4833,'69 Hameaux De La Riviere, 06470 Beuil');

INSERT INTO Organisation (numero,adresse) VALUES
(4834,'810 Villa Adriana, 17130 Expiremont'),
(4835,'611 Costo d''Amouro, 60320 Saint-Sauveur');

INSERT INTO Organisation (numero,adresse) VALUES
(4836,'872bis Le Gasquet, 76690 Le Bocasse'),
(4837,'634bis La Petite Maison, 21380 Asnières-lès-Dijon');

INSERT INTO Organisation (numero,adresse) VALUES
(4838,'797 Allée de la Tosca, 68840 Pulversheim'),
(4839,'933 Payranel, 53170 Saint-Charles-la-Forêt');

INSERT INTO Organisation (numero,adresse) VALUES
(4840,'292bis Le Grand Bouchet, 25120 Mancenans-Lizerne'),
(4841,'154 Les Saudais, 80150 Canchy');

INSERT INTO Organisation (numero,adresse) VALUES
(4842,'246bis Le Bas des Bordes, 38150 Sonnay'),
(4843,'204 La Barthole St Laurent, 21390 Bierre-lès-Semur');

INSERT INTO Organisation (numero,adresse) VALUES
(4844,'720bis Grand Matrignat Est, 73130 Montaimont'),
(4845,'826 Finteuiller, 25640 Châtillon-Guyotte');

INSERT INTO Organisation (numero,adresse) VALUES
(4846,'875 Bouychet, 55250 Èvres'),
(4847,'502 Camin de Roundo, 05190 Rousset');

INSERT INTO Organisation (numero,adresse) VALUES
(4848,'618 L''Espagnol, 63720 Ennezat'),
(4849,'687 Le Mas d’Hurtes, 72800 La Chapelle-aux-Choux');

INSERT INTO Organisation (numero,adresse) VALUES
(4850,'351bis Rue du Vieux Four, 77140 Saint-Pierre-lès-Nemours'),
(4851,'136 Allée Colonel Beltrame, 71460 Saint-Maurice-des-Champs');

INSERT INTO Organisation (numero,adresse) VALUES
(4852,'415 Sta Agathe & Bienville, 21350 Brain'),
(4853,'863 Lotissement les Planes, 40320 Puyol-Cazalet');

INSERT INTO Organisation (numero,adresse) VALUES
(4854,'330bis Saint Cau, 63730 Plauzat'),
(4855,'359 Salle EDF, 01660 Mézériat');

INSERT INTO Organisation (numero,adresse) VALUES
(4856,'524bis La Grabe, 06460 Escragnolles'),
(4857,'46 Route du parking de Sainte Catherine, 59116 Houplines');

INSERT INTO Organisation (numero,adresse) VALUES
(4858,'839bis Le Suey et la Verane, 55000 Loisey'),
(4859,'615 Plan d''Escalle, 25250 L''Isle-sur-le-Doubs');

INSERT INTO Organisation (numero,adresse) VALUES
(4860,'982 Champ Dilain, 59600 Bettignies'),
(4861,'440bis Bois des Grosses Herbes, 31430 Montégut-Bourjac');

INSERT INTO Organisation (numero,adresse) VALUES
(4862,'155bis Pouchole, 16300 Barbezieux-Saint-Hilaire'),
(4863,'181 La coste, 24660 Coulounieix-Chamiers');

INSERT INTO Organisation (numero,adresse) VALUES
(4864,'466 Mignou Bas, 30450 Ponteils-et-Brésis'),
(4865,'780bis La Burguiere Basse, 52700 Ecot-la-Combe');

INSERT INTO Organisation (numero,adresse) VALUES
(4866,'515 Coume de Canals, 31160 Razecueillé'),
(4867,'256bis Champ Jupon, 34140 Loupian');

INSERT INTO Organisation (numero,adresse) VALUES
(4868,'236 Condomines, 03340 Saint-Gérand-de-Vaux'),
(4869,'198 Lotissement les Maisons des Vignes, 74500 Évian-les-Bains');

INSERT INTO Organisation (numero,adresse) VALUES
(4870,'133 Hlm le Plessis bat. D1, 52320 Gudmont-Villiers'),
(4871,'523 Gendarmerie Nationale, 04180 Villeneuve');

INSERT INTO Organisation (numero,adresse) VALUES
(4872,'851bis Square Marie Cadgène, 66210 Fontrabiouse'),
(4873,'316 Ferme des Sarteles, 28630 Mignières');

INSERT INTO Organisation (numero,adresse) VALUES
(4874,'373bis Le Moulin de Ribiere, 70280 Saint-Bresson'),
(4875,'780bis Cours des Colles et Regagnade, 57320 Brettnach');

INSERT INTO Organisation (numero,adresse) VALUES
(4876,'714 Les Cousins, 68250 Gundolsheim'),
(4877,'113bis L''Enclos du Chesne, 45500 Poilly-lez-Gien');

INSERT INTO Organisation (numero,adresse) VALUES
(4878,'305 Pre de la Blonde, 64570 Issor'),
(4879,'575 Saint Exupère, 76400 Froberville');

INSERT INTO Organisation (numero,adresse) VALUES
(4880,'415bis Puech du Mazet, 45310 Coinces'),
(4881,'484 Les Curbales, 77200 Torcy');

INSERT INTO Organisation (numero,adresse) VALUES
(4882,'269 Montargues, 68210 Retzwiller'),
(4883,'386 Les Bagnardes, 70150 Cult');

INSERT INTO Organisation (numero,adresse) VALUES
(4884,'47bis Les Ébouchis, 54540 Badonviller'),
(4885,'104 Place la de Victoire, 78260 Achères');

INSERT INTO Organisation (numero,adresse) VALUES
(4886,'735 Sainte Barbe, 32190 Belmont'),
(4887,'169 La Couarde, 76740 Autigny');

INSERT INTO Organisation (numero,adresse) VALUES
(4888,'383 L''Hoste, 36500 Villegouin'),
(4889,'524 Orlhaguet Ouest, 76940 Notre-Dame-de-Bliquetuit');

INSERT INTO Organisation (numero,adresse) VALUES
(4890,'242 Le Couletas, 68130 Berentzwiller'),
(4891,'75 Villa Marianne, 21290 Chambain');

INSERT INTO Organisation (numero,adresse) VALUES
(4892,'588 Adrech du Ciai, 66300 Llauro'),
(4893,'732 Lotissement Les Lucioles, 36170 Roussines');

INSERT INTO Organisation (numero,adresse) VALUES
(4894,'46bis Bâtiment l''arc Entrée 1, 69380 Dommartin'),
(4895,'82 Grande Queylane, 42260 Saint-Polgues');

INSERT INTO Organisation (numero,adresse) VALUES
(4896,'3bis Roc de Matha, 35560 Noyal-sous-Bazouges'),
(4897,'549 Lieu-dit Serde, 20237 Quercitello');

INSERT INTO Organisation (numero,adresse) VALUES
(4898,'429 Bourinet, 29820 Bohars'),
(4899,'558bis Les Glycines de Fernex, 31450 Montesquieu-Lauragais');

INSERT INTO Organisation (numero,adresse) VALUES
(4900,'249 Hlm les Chartreux Bat B2, 61700 Avrilly'),
(4901,'428 Res Santa Rosa, 44570 Trignac');

INSERT INTO Organisation (numero,adresse) VALUES
(4902,'350bis Le Saut de la Dame, 57340 Bermering'),
(4903,'426bis La Baraque de Cussan, 35220 Marpiré');

INSERT INTO Organisation (numero,adresse) VALUES
(4904,'314 Collet du Grand Pré, 25150 Villars-sous-Écot'),
(4905,'79 Chareyrade, 06540 Saorge');

INSERT INTO Organisation (numero,adresse) VALUES
(4906,'454bis Chem des Vivandiers, 61120 Pontchardon'),
(4907,'188bis Le Grand Abergement, 27380 Val d''Orger');

INSERT INTO Organisation (numero,adresse) VALUES
(4908,'197bis Les Petits Pioux, 55100 Champneuville'),
(4909,'569 La Murasse, 21370 Pasques');

INSERT INTO Organisation (numero,adresse) VALUES
(4910,'17 Route de saint Pourçain, 14270 Le Mesnil-Mauger'),
(4911,'24bis Appt 201, 76570 Pavilly');

INSERT INTO Organisation (numero,adresse) VALUES
(4912,'381bis Impasse des Bruyères, 58110 Châtillon-en-Bazois'),
(4913,'577bis Le Clos De La Vigne, 17580 Le Bois-Plage-en-Ré');

INSERT INTO Organisation (numero,adresse) VALUES
(4914,'196 Pailles, 26310 Les Prés'),
(4915,'188 Tunnel de l''Avenue, 43160 Cistrières');

INSERT INTO Organisation (numero,adresse) VALUES
(4916,'89 Peu Chenu, 55120 Les Islettes'),
(4917,'866 Prat des Couns, 80170 Folies');

INSERT INTO Organisation (numero,adresse) VALUES
(4918,'740 Hameau Le Four, 46260 Puyjourdes'),
(4919,'573 Four de Saint-Urbain, 59157 Beauvois-en-Cambrésis');

INSERT INTO Organisation (numero,adresse) VALUES
(4920,'756 Les Neufs Pres, 21350 Velogny'),
(4921,'75 La Vignette Haute, 59740 Dimechaux');

INSERT INTO Organisation (numero,adresse) VALUES
(4922,'631 Les Crochets Liards, 21540 Bussy-la-Pesle'),
(4923,'728bis Hameau de Chassericourt, 63230 Saint-Ours');

INSERT INTO Organisation (numero,adresse) VALUES
(4924,'676 Place des Tonnelles, 64390 Athos-Aspis'),
(4925,'512bis Les Arques, 51510 Cheniers');

INSERT INTO Organisation (numero,adresse) VALUES
(4926,'938 Ravin de Melane, 80140 Woirel'),
(4927,'641bis Résidence Les Leucatines 2, 60640 Guiscard');

INSERT INTO Organisation (numero,adresse) VALUES
(4928,'318 Carpe Diem, 35560 Saint-Rémy-du-Plain'),
(4929,'551 Le Champ de Rompay, 14380 Champ-du-Boult');

INSERT INTO Organisation (numero,adresse) VALUES
(4930,'920 Noussols, 55600 Breux'),
(4931,'77 La Nouveauté, 31800 Saint-Marcet');

INSERT INTO Organisation (numero,adresse) VALUES
(4932,'431 Le Rauzel, 07170 Saint-Germain'),
(4933,'267 Gendarmerie, 25190 Soulce-Cernay');

INSERT INTO Organisation (numero,adresse) VALUES
(4934,'585bis Route de Verpel, 47700 Fargues-sur-Ourbise'),
(4935,'202 La Pierre, 41350 Vineuil');

INSERT INTO Organisation (numero,adresse) VALUES
(4936,'667 La Terre des Manens, 57420 Moncheux'),
(4937,'154 Domaine de Bouilletiere, 35800 Saint-Lunaire');

INSERT INTO Organisation (numero,adresse) VALUES
(4938,'551 Les Champons, 47310 Saint-Vincent-de-Lamontjoie'),
(4939,'685bis Mardaric Est, 77230 Montgé-en-Goële');

INSERT INTO Organisation (numero,adresse) VALUES
(4940,'385 Grande Paroisse, 26450 Roynac'),
(4941,'602 Morlot, 57570 Basse-Rentgen');

INSERT INTO Organisation (numero,adresse) VALUES
(4942,'145bis Rivoli, 17590 Saint-Clément-des-Baleines'),
(4943,'947 Chemin de Rodery, 67490 Littenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(4944,'964 Moulin de la Barthe, 25111 Montgesoye'),
(4945,'375 La Flacheyre, 71120 Vendenesse-lès-Charolles');

INSERT INTO Organisation (numero,adresse) VALUES
(4946,'35 Rue de Vouarces, 67330 Kirrwiller'),
(4947,'640bis Hameau de Courjumelles, 50390 Sainte-Colombe');

INSERT INTO Organisation (numero,adresse) VALUES
(4948,'291bis Villa Caprice, 24600 Celles'),
(4949,'326 Le Clos du Bois, 65170 Bazus-Aure');

INSERT INTO Organisation (numero,adresse) VALUES
(4950,'179 Fosse-clinchamp, 62850 Sanghen'),
(4951,'362bis Grousson, 02490 Vermand');

INSERT INTO Organisation (numero,adresse) VALUES
(4952,'393 Impasse Médard Simonetti, 39300 Montrond'),
(4953,'876 Couronne Du Cros A, 22250 Broons');

INSERT INTO Organisation (numero,adresse) VALUES
(4954,'373 La Richonnière, 29460 Hôpital-Camfrout'),
(4955,'669 Les Carterons Hauts, 58800 Anthien');

INSERT INTO Organisation (numero,adresse) VALUES
(4956,'228bis Bordeblanque, 56230 Questembert'),
(4957,'958 Caupels, 12250 Saint-Jean-et-Saint-Paul');

INSERT INTO Organisation (numero,adresse) VALUES
(4958,'663 Cantafau de Cirou, 07410 Saint-Victor'),
(4959,'416 Belair, 61190 Beaulieu');

INSERT INTO Organisation (numero,adresse) VALUES
(4960,'625 Splans Ouest, 31450 Pouze'),
(4961,'497bis Cascail, 57370 Hangviller');

INSERT INTO Organisation (numero,adresse) VALUES
(4962,'357bis La Quillerie, 64190 Ossenx'),
(4963,'141 Papyli, 17610 Chaniers');

INSERT INTO Organisation (numero,adresse) VALUES
(4964,'533 Cassignoles, 02210 Latilly'),
(4965,'891 La Couarde Ouest, 40190 Pujo-le-Plan');

INSERT INTO Organisation (numero,adresse) VALUES
(4966,'436 Place du Cours, 62670 Mazingarbe'),
(4967,'180 Voie d''accès au Reposoir, 02550 Origny-en-Thiérache');

INSERT INTO Organisation (numero,adresse) VALUES
(4968,'661 Le Petit Méchatin, 01430 Chevillard'),
(4969,'951 l''Enclos, 59193 Erquinghem-Lys');

INSERT INTO Organisation (numero,adresse) VALUES
(4970,'338bis Résidence Les Gémeaux, 66100 Perpignan'),
(4971,'368 Pillaud, 29233 Cléder');

INSERT INTO Organisation (numero,adresse) VALUES
(4972,'30bis Hameau de Chamblances, 69270 Fontaines-Saint-Martin'),
(4973,'388 Rue du Tribunal, 11220 Lagrasse');

INSERT INTO Organisation (numero,adresse) VALUES
(4974,'827bis Rue des 55 ème et 61 ème Régiment d''Infanterie, 38260 Bossieu'),
(4975,'366bis Rue Chemin des Sources, 33380 Mios');

INSERT INTO Organisation (numero,adresse) VALUES
(4976,'453 Maison provisoire musée, 27930 Émalleville'),
(4977,'822 Les Vernates, 25680 Nans');

INSERT INTO Organisation (numero,adresse) VALUES
(4978,'620 Espace Saint-Marc, 77810 Thomery'),
(4979,'765 Lieu-dit les Places, 66820 Fillols');

INSERT INTO Organisation (numero,adresse) VALUES
(4980,'638bis Greffets Sud, 48210 Montbrun'),
(4981,'658 Les Causses, 59211 Santes');

INSERT INTO Organisation (numero,adresse) VALUES
(4982,'187bis Château d''eau, 52200 Langres'),
(4983,'632bis Serieys, 60150 Le Plessis-Brion');

INSERT INTO Organisation (numero,adresse) VALUES
(4984,'47 La Vayssette, 15400 Apchon'),
(4985,'637 Moulin du Mourtayrol, 65700 Estirac');

INSERT INTO Organisation (numero,adresse) VALUES
(4986,'836 Escalier de la place de la fontaine, 57340 Eincheville'),
(4987,'924 L''Hoste Blanc, 61270 Saint-Hilaire-sur-Risle');

INSERT INTO Organisation (numero,adresse) VALUES
(4988,'998 Le Mas Nord, 34130 Mauguio'),
(4989,'780bis lieu dit le Goutel, 25750 Désandans');

INSERT INTO Organisation (numero,adresse) VALUES
(4990,'125 Les Vieux Moines, 54610 Rouves'),
(4991,'736 Résidence Port la Galère, 25360 Adam-lès-Passavant');

INSERT INTO Organisation (numero,adresse) VALUES
(4992,'214 Ferme de la Folie, 24500 Sainte-Innocence'),
(4993,'565 Mauron, 03250 Le Mayet-de-Montagne');

INSERT INTO Organisation (numero,adresse) VALUES
(4994,'874 Les Houstesses, 25330 Déservillers'),
(4995,'543 Vigne du Riez, 50720 Saint-Cyr-du-Bailleul');

INSERT INTO Organisation (numero,adresse) VALUES
(4996,'773bis Saint Rames, 54200 Lagney'),
(4997,'475 Le Portet, 32120 Sérempuy');

INSERT INTO Organisation (numero,adresse) VALUES
(4998,'808 Serni, 67690 Rittershoffen'),
(4999,'614 Mandrats, 64800 Arthez-d''Asson');

INSERT INTO Organisation (numero,adresse) VALUES
(5000,'280 Villa Domi, 27190 Le Val-Doré'),
(5001,'645 Montee L''Escourcha, 14130 Saint-André-d''Hébertot');

INSERT INTO Organisation (numero,adresse) VALUES
(5002,'645bis Res Les Palmiers, 07800 Beauchastel'),
(5003,'27 Cousin, 21700 Agencourt');

INSERT INTO Organisation (numero,adresse) VALUES
(5004,'652 Prat-Long, 27190 Champ-Dolent'),
(5005,'639 Passage Rue du Commandant Gaston Cahuzac/Route des Vespins, 66500 Campôme');

INSERT INTO Organisation (numero,adresse) VALUES
(5006,'661 Le Chalet, 37320 Truyes'),
(5007,'611 Le Mouly, 32130 Pébées');

INSERT INTO Organisation (numero,adresse) VALUES
(5008,'62 La Louvière, 67580 Forstheim'),
(5009,'94 Le Colysee Indivisible, 59147 Herrin');

INSERT INTO Organisation (numero,adresse) VALUES
(5010,'86bis Les Hauts De Caucours, 18390 Osmoy'),
(5011,'890 La Roche du Milieu, 03140 Fleuriel');

INSERT INTO Organisation (numero,adresse) VALUES
(5012,'650bis Le Bas de Frolle, 40700 Castaignos-Souslens'),
(5013,'39 Pre Chauvet, 74350 Menthonnex-en-Bornes');

INSERT INTO Organisation (numero,adresse) VALUES
(5014,'132bis Avenue Didier Daurat, 47350 Montignac-Toupinerie'),
(5015,'407 Le Gralet, 44460 Fégréac');

INSERT INTO Organisation (numero,adresse) VALUES
(5016,'703 Moulin de Boutonnat, 28170 Châteauneuf-en-Thymerais'),
(5017,'767 Les Périgons, 59156 Lourches');

INSERT INTO Organisation (numero,adresse) VALUES
(5018,'388bis Stade Marius Jacquard, 60640 Frétoy-le-Château'),
(5019,'820 Font Orbe, 58240 Luthenay-Uxeloup');

INSERT INTO Organisation (numero,adresse) VALUES
(5020,'968 La Bourdique, 07300 Plats'),
(5021,'620 Les Galets Escalier 3, 31220 Sana');

INSERT INTO Organisation (numero,adresse) VALUES
(5022,'692 Relais mobile Free, 17330 Lozay'),
(5023,'161 Mas de l’Ombre, 14140 Vieux-Pont-en-Auge');

INSERT INTO Organisation (numero,adresse) VALUES
(5024,'300bis Pre de Bord, 14540 Rocquancourt'),
(5025,'929 Grand Berlie, 46320 Reyrevignes');

INSERT INTO Organisation (numero,adresse) VALUES
(5026,'72 Couavise, 55190 Sorcy-Saint-Martin'),
(5027,'609 Moulin de Landes, 26770 Saint-Pantaléon-les-Vignes');

INSERT INTO Organisation (numero,adresse) VALUES
(5028,'902 Chez Boirot, 71480 Joudes'),
(5029,'965 Le Causse Maigre, 21690 Source-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(5030,'69 Rue de la Maladrerie, 25250 Blussans'),
(5031,'369bis Cambajou, 50530 Sartilly-Baie-Bocage');

INSERT INTO Organisation (numero,adresse) VALUES
(5032,'276 Rue des Vignes, 51390 Vrigny'),
(5033,'948 Coucourdas, 02190 Juvincourt-et-Damary');

INSERT INTO Organisation (numero,adresse) VALUES
(5034,'609bis Cap de Front Entrée 3, 66540 Baho'),
(5035,'992 Le Moulin Brule, 35490 Sens-de-Bretagne');

INSERT INTO Organisation (numero,adresse) VALUES
(5036,'235 Larlenque, 58140 Mhère'),
(5037,'763bis Villa Helene, 07110 Valgorge');

INSERT INTO Organisation (numero,adresse) VALUES
(5038,'785 Voye de Brévilly, 57710 Aumetz'),
(5039,'473 Croix de Belley, 47480 Bajamont');

INSERT INTO Organisation (numero,adresse) VALUES
(5040,'312 Bouno Fenno, 67400 Illkirch-Graffenstaden'),
(5041,'903bis Ferme de la Tourauderie, 30200 Saint-Laurent-de-Carnols');

INSERT INTO Organisation (numero,adresse) VALUES
(5042,'800 Le Rhan, 06400 Cannes'),
(5043,'577 Ile Sainte Marguerite, 79170 Villefollet');

INSERT INTO Organisation (numero,adresse) VALUES
(5044,'543 Les Trois Chemins, 09140 Soueix-Rogalle'),
(5045,'181 Les Jardins Des Tuilieres 2, 61400 Loisail');

INSERT INTO Organisation (numero,adresse) VALUES
(5046,'149 Planesty, 11200 Roubia'),
(5047,'14 Causse de Las Cayroules, 18350 Flavigny');

INSERT INTO Organisation (numero,adresse) VALUES
(5048,'111 Le Chaumat, 79500 Saint-Martin-lès-Melle'),
(5049,'979 Ka Ru Ke Ra, 14210 Esquay-Notre-Dame');

INSERT INTO Organisation (numero,adresse) VALUES
(5050,'933 Res De La Mer B, 03600 Hyds'),
(5051,'149 La Louve, 26170 Le Poët-en-Percip');

INSERT INTO Organisation (numero,adresse) VALUES
(5052,'660 Moulin Boulan, 56490 Guilliers'),
(5053,'956bis Placette Abbé Perdigon, 51420 Berru');

INSERT INTO Organisation (numero,adresse) VALUES
(5054,'964 La Combelle, 21570 Riel-les-Eaux'),
(5055,'483 La Carral, 07260 Vernon');

INSERT INTO Organisation (numero,adresse) VALUES
(5056,'402 Pesso Loungo, 02240 Regny'),
(5057,'767 Allée Françoise Dolto, 35111 La Fresnais');

INSERT INTO Organisation (numero,adresse) VALUES
(5058,'87bis Mignou Bas, 32410 Cézan'),
(5059,'364 La Rochette, 14140 Le Mesnil-Simon');

INSERT INTO Organisation (numero,adresse) VALUES
(5060,'439 Le Vieux Chateau, 67480 Forstfeld'),
(5061,'536 Les Radurons, 28700 Denonville');

INSERT INTO Organisation (numero,adresse) VALUES
(5062,'820 Gabriac, 52400 Coiffy-le-Bas'),
(5063,'470 Esplanade des Droits de l''Homme et du Citoyen, 10400 Nogent-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(5064,'169 Cathala, 70160 Purgerot'),
(5065,'36bis Les Sézeaux, 52110 Nully');

INSERT INTO Organisation (numero,adresse) VALUES
(5066,'367 Modé, 51260 Anglure'),
(5067,'285 Le Bouscatel, 56190 Noyal-Muzillac');

INSERT INTO Organisation (numero,adresse) VALUES
(5068,'763 En Vieu, 80290 Poix-de-Picardie'),
(5069,'704 Lecune Basse, 10210 Lagesse');

INSERT INTO Organisation (numero,adresse) VALUES
(5070,'565 Quartier des Pins, 57880 Guerting'),
(5071,'511 My Lou, 57570 Cattenom');

INSERT INTO Organisation (numero,adresse) VALUES
(5072,'187 En Cresenal, 28310 Oinville-Saint-Liphard'),
(5073,'889 Vignals, 45250 Briare');

INSERT INTO Organisation (numero,adresse) VALUES
(5074,'132bis Defends de Saint-Marc, 06510 Bouyon'),
(5075,'617bis Piece Longue, 33500 Les Billaux');

INSERT INTO Organisation (numero,adresse) VALUES
(5076,'70bis Lieu-dit La Combe, 32390 Puységur'),
(5077,'725bis Les Bousigues, 36150 Meunet-sur-Vatan');

INSERT INTO Organisation (numero,adresse) VALUES
(5078,'608bis Le Moulin de la Voûte, 67110 Niederbronn-les-Bains'),
(5079,'15 Hlm les Durantats Bat B1, 45400 Semoy');

INSERT INTO Organisation (numero,adresse) VALUES
(5080,'24 Péneyrols, 13110 Port-de-Bouc'),
(5081,'911 Le Vayssieyrou, 35460 Saint-Ouen-la-Rouërie');

INSERT INTO Organisation (numero,adresse) VALUES
(5082,'303 Petit Bochet, 12550 Montclar'),
(5083,'239bis Combe de Fontay, 29217 Le Conquet');

INSERT INTO Organisation (numero,adresse) VALUES
(5084,'288 Cluny Le Neuf, 17600 Saint-Sornin'),
(5085,'198 La Ribarole, 23190 Bellegarde-en-Marche');

INSERT INTO Organisation (numero,adresse) VALUES
(5086,'77 Le Jardin Jean Richet, 27390 Saint-Laurent-du-Tencement'),
(5087,'262 Lotissement les Maisons des Vignes, 67320 Baerendorf');

INSERT INTO Organisation (numero,adresse) VALUES
(5088,'738 Res Felicita Aa/Ab/B, 72150 Pruillé-l''Éguillé'),
(5089,'22 Chemin de La Croix Saint-Joseph, 77114 Villiers-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(5090,'287bis Izernans Sud, 02330 Courboin'),
(5091,'904 En Bourravier, 68280 Logelheim');

INSERT INTO Organisation (numero,adresse) VALUES
(5092,'602 Bruna Fraiche, 40330 Marpaps'),
(5093,'364 Longue Roie, 76210 Saint-Eustache-la-Forêt');

INSERT INTO Organisation (numero,adresse) VALUES
(5094,'427 Champ du Bois du Milieu, 28350 Saint-Lubin-des-Joncherets'),
(5095,'243 Placette Abbé Robert Jarre, 16310 Massignac');

INSERT INTO Organisation (numero,adresse) VALUES
(5096,'174 La Mignone, 14710 Saint-Martin-de-Blagny'),
(5097,'317 La Crête Warinet, 14380 Le Mesnil-Caussois');

INSERT INTO Organisation (numero,adresse) VALUES
(5098,'517bis Les Burlons Bas, 70320 Aillevillers-et-Lyaumont'),
(5099,'236bis quartier Arimonda, 59181 Steenwerck');

INSERT INTO Organisation (numero,adresse) VALUES
(5100,'756 Bouchonniere, 22530 Saint-Guen'),
(5101,'406 Les Narces de Chabanis, 19340 Monestier-Merlines');

INSERT INTO Organisation (numero,adresse) VALUES
(5102,'371 Darre l''Airo, 77860 Quincy-Voisins'),
(5103,'55 Daudou, 45170 Aschères-le-Marché');

INSERT INTO Organisation (numero,adresse) VALUES
(5104,'439 Le Puech Roux, 29680 Roscoff'),
(5105,'532 Villa Etienne, 40250 Caupenne');

INSERT INTO Organisation (numero,adresse) VALUES
(5106,'217 Lotissement Res Barbès, 60220 Moliens'),
(5107,'338 Skate Park, 08160 Saint-Marceau');

INSERT INTO Organisation (numero,adresse) VALUES
(5108,'749bis Tauzuc, 32300 Ponsampère'),
(5109,'149bis Allée des Italiens, 22250 Rouillac');

INSERT INTO Organisation (numero,adresse) VALUES
(5110,'108bis chemin rural dit des Bouvottes, 18260 Assigny'),
(5111,'201 Les Reboulides, 24260 Savignac-de-Miremont');

INSERT INTO Organisation (numero,adresse) VALUES
(5112,'427 Montmouth, 65140 Ansost'),
(5113,'45bis Collanges Hautes, 65120 Luz-Saint-Sauveur');

INSERT INTO Organisation (numero,adresse) VALUES
(5114,'634 Brahinel, 42620 Saint-Martin-d''Estréaux'),
(5115,'650 Grange neuve, 50610 Jullouville');

INSERT INTO Organisation (numero,adresse) VALUES
(5116,'374bis Le Puech Broual, 57670 Francaltroff'),
(5117,'520bis Peyre Boeuf, 53230 La Chapelle-Craonnaise');

INSERT INTO Organisation (numero,adresse) VALUES
(5118,'167 Lous Triniols, 76280 Criquetot-l''Esneval'),
(5119,'826 Camp Grand Haut, 19200 Veyrières');

INSERT INTO Organisation (numero,adresse) VALUES
(5120,'826 Vaubelle, 64330 Conchez-de-Béarn'),
(5121,'637 Lieu-Dit Val Martine, 33450 Montussan');

INSERT INTO Organisation (numero,adresse) VALUES
(5122,'272bis Le Gilcor A Et B, 08240 Fossé'),
(5123,'253bis La Grange Robert, 17570 Les Mathes');

INSERT INTO Organisation (numero,adresse) VALUES
(5124,'910 Le Plot de la Laonne, 67440 Kleingœft'),
(5125,'392bis Avenue Severina, 25340 Pompierre-sur-Doubs');

INSERT INTO Organisation (numero,adresse) VALUES
(5126,'795bis Bâtiment la touloubre, 79210 Priaires'),
(5127,'249 Le Moulin de Mandy, 46100 Lunan');

INSERT INTO Organisation (numero,adresse) VALUES
(5128,'45 Escalier Raymond Barbier, 39260 Moirans-en-Montagne'),
(5129,'503 L’Espital, 76260 Millebosc');

INSERT INTO Organisation (numero,adresse) VALUES
(5130,'429bis Rond point Weisweiller, 19360 Cosnac'),
(5131,'171 Marioune, 27430 Saint-Pierre-du-Vauvray');

INSERT INTO Organisation (numero,adresse) VALUES
(5132,'198bis Le Burgatel, 39570 Moiron'),
(5133,'45bis Roche Pelaz, 55000 Naives-Rosières');

INSERT INTO Organisation (numero,adresse) VALUES
(5134,'569bis Chemin du Moulin de Bourimont, 03140 Barberier'),
(5135,'895 Serve Rion, 69007 Lyon 07');

INSERT INTO Organisation (numero,adresse) VALUES
(5136,'52bis La Voliere, 71260 Azé'),
(5137,'472 Lavise, 41100 Thoré-la-Rochette');

INSERT INTO Organisation (numero,adresse) VALUES
(5138,'422 La Borie de Cabrol, 47470 Dondas'),
(5139,'531 La Landelle-Haute, 63170 Pérignat-lès-Sarliève');

INSERT INTO Organisation (numero,adresse) VALUES
(5140,'565 Sagnard, 10130 Courtaoult'),
(5141,'94bis Bellerica, 38710 Tréminis');

INSERT INTO Organisation (numero,adresse) VALUES
(5142,'785bis Vieilles Vignes, 61230 Cisai-Saint-Aubin'),
(5143,'132 Lieu-dit Les Bels, 17400 La Vergne');

INSERT INTO Organisation (numero,adresse) VALUES
(5144,'838bis Moulin de Peysset, 02100 Morcourt'),
(5145,'19bis Bouriech, 49120 Chemillé-en-Anjou');

INSERT INTO Organisation (numero,adresse) VALUES
(5146,'294 Vigne Merle, 57580 Chanville'),
(5147,'174bis Nacheyre, 62910 Serques');

INSERT INTO Organisation (numero,adresse) VALUES
(5148,'900bis Lou Bly, 14117 Tracy-sur-Mer'),
(5149,'868 La Fayolle, 76440 Longmesnil');

INSERT INTO Organisation (numero,adresse) VALUES
(5150,'66 Junquères, 52000 Treix'),
(5151,'967 Le Colibri, 76660 Fréauville');

INSERT INTO Organisation (numero,adresse) VALUES
(5152,'652bis Champs Rosiers, 60850 Saint-Pierre-es-Champs'),
(5153,'22bis L''Arboudeysse, 02440 Hinacourt');

INSERT INTO Organisation (numero,adresse) VALUES
(5154,'947 La Grande Matray, 06670 Levens'),
(5155,'739bis Lieu-dit Gaudi, 76360 Barentin');

INSERT INTO Organisation (numero,adresse) VALUES
(5156,'347 Le Bon Poirier, 74290 Alex'),
(5157,'566 maisonnette de l''ancienne gare, 57420 Goin');

INSERT INTO Organisation (numero,adresse) VALUES
(5158,'525 Les Terres Bleues, 04170 Thorame-Haute'),
(5159,'281 Les Chadiaux, 77130 Marolles-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(5160,'533 Parc des Papillons, 66320 Glorianes'),
(5161,'769bis Villa La Prunelle, 20164 Cargiaca');

INSERT INTO Organisation (numero,adresse) VALUES
(5162,'5bis Les Quatre Saisons, 09460 Le Puch'),
(5163,'115 Ambly Haut, 25300 Les Alliés');

INSERT INTO Organisation (numero,adresse) VALUES
(5164,'73 Janery, 57670 Lhor'),
(5165,'797 La Puaille, 57260 Domnom-lès-Dieuze');

INSERT INTO Organisation (numero,adresse) VALUES
(5166,'529 La Dausse, 35560 La Fontenelle'),
(5167,'593 Les Spinies, 37310 Dolus-le-Sec');

INSERT INTO Organisation (numero,adresse) VALUES
(5168,'778bis Clos De L Olivier, 78730 Ponthévrard'),
(5169,'422 Bois de Trou, 65190 Poumarous');

INSERT INTO Organisation (numero,adresse) VALUES
(5170,'349 Plat du Feu, 06950 Falicon'),
(5171,'526bis Le Langousty, 23340 Gentioux-Pigerolles');

INSERT INTO Organisation (numero,adresse) VALUES
(5172,'502 Patio Riviera, 48200 Saint-Pierre-le-Vieux'),
(5173,'272 Lorette, 28230 Épernon');

INSERT INTO Organisation (numero,adresse) VALUES
(5174,'775 Aux Egrillons, 78790 Hargeville'),
(5175,'136 Les Moulières, 03600 Commentry');

INSERT INTO Organisation (numero,adresse) VALUES
(5176,'474bis Les Fouillons, 62770 Éclimeux'),
(5177,'546bis Les Fons, 76450 Auberville-la-Manuel');

INSERT INTO Organisation (numero,adresse) VALUES
(5178,'419 Rue du Passe, 15230 Saint-Martin-sous-Vigouroux'),
(5179,'371 Le Canton, 59175 Templemars');

INSERT INTO Organisation (numero,adresse) VALUES
(5180,'620 Les Sablons d''En Haut, 51320 Le Meix-Tiercelin'),
(5181,'184bis La Matte, 40430 Luxey');

INSERT INTO Organisation (numero,adresse) VALUES
(5182,'678 Rivière Basse, 67290 Weislingen'),
(5183,'245 La Roche Amère, 65370 Gaudent');

INSERT INTO Organisation (numero,adresse) VALUES
(5184,'966 Saint Pierre, 60350 Cuise-la-Motte'),
(5185,'888bis Axiat, 10500 Épothémont');

INSERT INTO Organisation (numero,adresse) VALUES
(5186,'678 Armères, 41250 Neuvy'),
(5187,'923 "Chambres d''Hôtes ""Le Joséphine""", 68290 Lauw');

INSERT INTO Organisation (numero,adresse) VALUES
(5188,'664 La Demeure, 61600 Lonlay-le-Tesson'),
(5189,'61 Brommes, 30150 Montfaucon');

INSERT INTO Organisation (numero,adresse) VALUES
(5190,'215 La Roche du Milieu, 07270 Gilhoc-sur-Ormèze'),
(5191,'897 Bât D les Deux Moulins, 18250 Achères');

INSERT INTO Organisation (numero,adresse) VALUES
(5192,'390bis Bois d''Arzay, 21400 Chaumont-le-Bois'),
(5193,'293bis Gadelle, 23360 Nouzerolles');

INSERT INTO Organisation (numero,adresse) VALUES
(5194,'78 Blejarde, 06320 Cap-d''Ail'),
(5195,'397 Manhols, 31120 Roques');

INSERT INTO Organisation (numero,adresse) VALUES
(5196,'133 Pesse Blanque, 70800 Conflans-sur-Lanterne'),
(5197,'838 Le Ser, 48210 Gorges du Tarn Causses');

INSERT INTO Organisation (numero,adresse) VALUES
(5198,'385 Le Bas Planet, 54970 Landres'),
(5199,'475 Tront, 03260 Marcenat');

INSERT INTO Organisation (numero,adresse) VALUES
(5200,'369 Mas de Galy, 53400 Mée'),
(5201,'556 Hameau de Morgelas, 60120 Beauvoir');

INSERT INTO Organisation (numero,adresse) VALUES
(5202,'133 Pont de Blayac, 63500 Le Broc'),
(5203,'114bis Gardin, 25640 Champoux');

INSERT INTO Organisation (numero,adresse) VALUES
(5204,'313 Le Perron, 62152 Nesles'),
(5205,'628 Guilhem Marty, 12400 Rebourguil');

INSERT INTO Organisation (numero,adresse) VALUES
(5206,'909bis Combe Del Pous, 34160 Buzignargues'),
(5207,'772bis Le Deves, 53420 Chailland');

INSERT INTO Organisation (numero,adresse) VALUES
(5208,'856bis La Pagésié, 09140 Soueix-Rogalle'),
(5209,'571 Rue du 19 Mars 1962 Recoules, 20215 Venzolasca');

INSERT INTO Organisation (numero,adresse) VALUES
(5210,'608 Puech Caubel, 40260 Taller'),
(5211,'801bis passage des écoliers, 11170 Carlipa');

INSERT INTO Organisation (numero,adresse) VALUES
(5212,'284 Moulin du Montjard, 03440 Buxières-les-Mines'),
(5213,'646 May, 45400 Fleury-les-Aubrais');

INSERT INTO Organisation (numero,adresse) VALUES
(5214,'371bis Debonnas, 14520 Port-en-Bessin-Huppain'),
(5215,'220 Serieux, 51310 Esternay');

INSERT INTO Organisation (numero,adresse) VALUES
(5216,'522 Niquel, 63420 Rentières'),
(5217,'642 Route de Versailles, 72440 Coudrecieux');

INSERT INTO Organisation (numero,adresse) VALUES
(5218,'66 La Trape et Marette, 71000 Varennes-lès-Mâcon'),
(5219,'363 Le-bois-lambert, 59117 Wervicq-Sud');

INSERT INTO Organisation (numero,adresse) VALUES
(5220,'847 Champs au Daim, 28210 Croisilles'),
(5221,'53 L''Araignee et la Reynarde, 51260 Chantemerle');

INSERT INTO Organisation (numero,adresse) VALUES
(5222,'538bis La Grange Bardin, 48160 Ventalon en Cévennes'),
(5223,'658 Fourcadelle, 02600 Puiseux-en-Retz');

INSERT INTO Organisation (numero,adresse) VALUES
(5224,'600 Au Pre Pery, 60210 Thieuloy-Saint-Antoine'),
(5225,'18bis Les Mailhols Basses, 28480 Vichères');

INSERT INTO Organisation (numero,adresse) VALUES
(5226,'785bis Le Pointet, 53150 Saint-Ouën-des-Vallons'),
(5227,'575 Le Laudat, 27120 Jouy-sur-Eure');

INSERT INTO Organisation (numero,adresse) VALUES
(5228,'130 En Marmorain, 09230 Bagert'),
(5229,'880 Pracoulet, 50200 Saint-Pierre-de-Coutances');

INSERT INTO Organisation (numero,adresse) VALUES
(5230,'739 Cassaing Bas, 17800 Saint-Quantin-de-Rançanne'),
(5231,'567 Brins D''Avoine, 36120 Jeu-les-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(5232,'577 La Plaissade, 67700 Monswiller'),
(5233,'51 Vernhonette, 39200 Saint-Claude');

INSERT INTO Organisation (numero,adresse) VALUES
(5234,'141 Le Petit Merle, 20272 Ampriani'),
(5235,'854bis As Cascals, 55160 Ronvaux');

INSERT INTO Organisation (numero,adresse) VALUES
(5236,'748bis Bâtiment Le tournesol, 60380 Loueuse'),
(5237,'568 Le Cros Saint Pierre B, 11580 Terroles');

INSERT INTO Organisation (numero,adresse) VALUES
(5238,'861 La-Fenerie, 50180 Saint-Gilles'),
(5239,'66bis Brienne, 57220 Fouligny');

INSERT INTO Organisation (numero,adresse) VALUES
(5240,'966 Grand Jayr, 80300 Englebelmer'),
(5241,'732 La Ramadio, 56300 Pontivy');

INSERT INTO Organisation (numero,adresse) VALUES
(5242,'999 Bat C-D-E, 14310 Villers-Bocage'),
(5243,'792bis La Voie des Ziebbes, 63980 Aix-la-Fayette');

INSERT INTO Organisation (numero,adresse) VALUES
(5244,'877 Villa Valéria, 45200 Amilly'),
(5245,'428bis Rue de la Montagne Noire, 28140 Dambron');

INSERT INTO Organisation (numero,adresse) VALUES
(5246,'745 Bruguet, 07310 Saint-Martin-de-Valamas'),
(5247,'452bis Serre de Guignon, 02450 Bergues-sur-Sambre');

INSERT INTO Organisation (numero,adresse) VALUES
(5248,'303 La Planeto, 74550 Cervens'),
(5249,'998 Proche les Vénets, 57680 Corny-sur-Moselle');

INSERT INTO Organisation (numero,adresse) VALUES
(5250,'479 Eolienne, 61430 Sainte-Honorine-la-Chardonne'),
(5251,'620 Le Buisson Creux, 21540 Blaisy-Haut');

INSERT INTO Organisation (numero,adresse) VALUES
(5252,'415 Langlerie, 58270 Saint-Benin-d''Azy'),
(5253,'485 Lotissement Montolive, 55400 Moranville');

INSERT INTO Organisation (numero,adresse) VALUES
(5254,'558 Le Bois d''Hartennes, 01630 Péron'),
(5255,'893 Lotissement Saint-Eloi, 21270 Montmançon');

INSERT INTO Organisation (numero,adresse) VALUES
(5256,'915 Manhaval, 25580 Fallerans'),
(5257,'120 Les Aubets, 59570 Bermeries');

INSERT INTO Organisation (numero,adresse) VALUES
(5258,'260bis La Malenie, 24390 Tourtoirac'),
(5259,'443 La Petite Ponche, 72170 Le Tronchet');

INSERT INTO Organisation (numero,adresse) VALUES
(5260,'816bis Le Serre, 28330 Charbonnières'),
(5261,'331 Le Durétch, 78770 Auteuil');

INSERT INTO Organisation (numero,adresse) VALUES
(5262,'493 Le Paire, 52160 Chalancey'),
(5263,'195 Courassou, 31320 Rebigue');

INSERT INTO Organisation (numero,adresse) VALUES
(5264,'618 Hlm les Chartreux Bat E1, 56430 Mauron'),
(5265,'851 Les Aliberts, 28160 Bullou');

INSERT INTO Organisation (numero,adresse) VALUES
(5266,'511 Le Chateau - Laprade-Basse, 71500 Montcony'),
(5267,'308 Peire Ficade, 08130 Suzanne');

INSERT INTO Organisation (numero,adresse) VALUES
(5268,'560 Résidence des Frères Montgolfier 1, 39700 Auxange'),
(5269,'269 Place Mozart, 50520 Le Mesnil-Adelée');

INSERT INTO Organisation (numero,adresse) VALUES
(5270,'462bis Chemin rural dit Tertre, 77480 Montigny-le-Guesdier'),
(5271,'113 La Carriere des Pacauds, 77120 Giremoutiers');

INSERT INTO Organisation (numero,adresse) VALUES
(5272,'789 Petite Couture de Thibaudi, 41270 Villebout'),
(5273,'510 La Grange du Moulin, 45400 Chanteau');

INSERT INTO Organisation (numero,adresse) VALUES
(5274,'959 Bachiou, 57590 Xocourt'),
(5275,'136 Chouplat d''En Haut, 40990 Herm');

INSERT INTO Organisation (numero,adresse) VALUES
(5276,'384 Rue du Pré Caillat, 02590 Douchy'),
(5277,'476 La Medusa, 14600 La Rivière-Saint-Sauveur');

INSERT INTO Organisation (numero,adresse) VALUES
(5278,'936 La Laurentie, 10190 Fontvannes'),
(5279,'501bis Camping du Bel Étang, 72320 Champrond');

INSERT INTO Organisation (numero,adresse) VALUES
(5280,'60bis Moulin Serein, 16170 Genac-Bignac'),
(5281,'362 La Fontaine de Bolmont, 59178 Millonfosse');

INSERT INTO Organisation (numero,adresse) VALUES
(5282,'821bis Romette Eglise, 52140 Dammartin-sur-Meuse'),
(5283,'486 La Couvelie Basse, 22540 Tréglamus');

INSERT INTO Organisation (numero,adresse) VALUES
(5284,'583bis Prat du juge, 67350 Buswiller'),
(5285,'767bis Lieu-Dit Bella Vista, 64800 Bordères');

INSERT INTO Organisation (numero,adresse) VALUES
(5286,'948 La Sarrate de la Gorre, 78260 Achères'),
(5287,'624 Le Pestier, 47380 Villebramar');

INSERT INTO Organisation (numero,adresse) VALUES
(5288,'319 Traverse Garibaldi, 78570 Chanteloup-les-Vignes'),
(5289,'543bis Fond de la Tombe, 55160 Doncourt-aux-Templiers');

INSERT INTO Organisation (numero,adresse) VALUES
(5290,'105 Les Couffours, 48100 Marvejols'),
(5291,'327bis Saint-Jacques-d''Albas, 71800 Varennes-sous-Dun');

INSERT INTO Organisation (numero,adresse) VALUES
(5292,'175 La Fabrie, 53700 Saint-Mars-du-Désert'),
(5293,'135bis L''Hubac de Longe Faye, 02600 Cutry');

INSERT INTO Organisation (numero,adresse) VALUES
(5294,'481 Champ Maria, 32400 Cahuzac-sur-Adour'),
(5295,'921 Lieu Dit Clarette, 53220 Saint-Berthevin-la-Tannière');

INSERT INTO Organisation (numero,adresse) VALUES
(5296,'12 Le Puech de Caussin, 08290 La Férée'),
(5297,'132 Le Pigeon, 50340 Sotteville');

INSERT INTO Organisation (numero,adresse) VALUES
(5298,'842 Malpérié le Bas, 27220 La Baronnie'),
(5299,'35bis Rez de la Mine, 30770 Campestre-et-Luc');

INSERT INTO Organisation (numero,adresse) VALUES
(5300,'733 Cité Joliot Curie Normalisee, 02260 Papleux'),
(5301,'443bis Peneyrols, 62122 Lapugnoy');

INSERT INTO Organisation (numero,adresse) VALUES
(5302,'80 Lespillou, 10190 Chennegy'),
(5303,'705bis Impasse des Minets, 21700 Marey-lès-Fussey');

INSERT INTO Organisation (numero,adresse) VALUES
(5304,'846 Calinette, 52150 Germainvilliers'),
(5305,'314 Cimetière de Glaire, 09140 Ustou');

INSERT INTO Organisation (numero,adresse) VALUES
(5306,'856bis Le Caupy, 51170 Poilly'),
(5307,'625 Hameau de La Selle, 79120 Sainte-Soline');

INSERT INTO Organisation (numero,adresse) VALUES
(5308,'91 Blanches Terres, 51520 Saint-Martin-sur-le-Pré'),
(5309,'964bis Bas Montagneux, 24320 Vendoire');

INSERT INTO Organisation (numero,adresse) VALUES
(5310,'80 Ben Salem, 62540 Marles-les-Mines'),
(5311,'927 Manhols, 78910 Tacoignières');

INSERT INTO Organisation (numero,adresse) VALUES
(5312,'779 Le Haut Montvillers, 45470 Loury'),
(5313,'912 Moulin de Grandvaux, 21250 Grosbois-lès-Tichey');

INSERT INTO Organisation (numero,adresse) VALUES
(5314,'924 La Queune, 78125 Orphin'),
(5315,'521 Espace Jean Buffelan, 41310 Prunay-Cassereau');

INSERT INTO Organisation (numero,adresse) VALUES
(5316,'873bis Sentier de l''Ecole de Bon Voyage, 64120 Arhansus'),
(5317,'378bis Les Barreaux, 27310 Flancourt-Crescy-en-Roumois');

INSERT INTO Organisation (numero,adresse) VALUES
(5318,'538 Rue du cimetière, 76220 Cuy-Saint-Fiacre'),
(5319,'948 La Grande Pâture, 62144 Villers-au-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(5320,'331 Domaine de la Guirlande, 62550 Pernes'),
(5321,'463 Verte Bastide, 33790 Landerrouat');

INSERT INTO Organisation (numero,adresse) VALUES
(5322,'454 Hameau de Lagremounal, 78140 Vélizy-Villacoublay'),
(5323,'21bis Montée du Château, 07110 Tauriers');

INSERT INTO Organisation (numero,adresse) VALUES
(5324,'958 Base TEREGA, 77910 Barcy'),
(5325,'236 Doussanne et la Veyrouse, 02160 Roucy');

INSERT INTO Organisation (numero,adresse) VALUES
(5326,'837bis La Râpe, 05400 Oze'),
(5327,'304 Lieu dit Les collets rouges, 76730 Thil-Manneville');

INSERT INTO Organisation (numero,adresse) VALUES
(5328,'511 Le Rosier, 12360 Tauriac-de-Camarès'),
(5329,'838bis Les Guillaumes, 38550 Le Péage-de-Roussillon');

INSERT INTO Organisation (numero,adresse) VALUES
(5330,'269 Jardin Charles Dalmas, 80500 Davenescourt'),
(5331,'594bis Impasse des Aires, 22610 Kerbors');

INSERT INTO Organisation (numero,adresse) VALUES
(5332,'251 À la Doux Nord, 32380 Bivès'),
(5333,'267 Le Puech de Ceor, 73340 Aillon-le-Jeune');

INSERT INTO Organisation (numero,adresse) VALUES
(5334,'618bis Pierre-Avons, 44160 Sainte-Reine-de-Bretagne'),
(5335,'402 Les-Gras, 26600 Crozes-Hermitage');

INSERT INTO Organisation (numero,adresse) VALUES
(5336,'119 La Bonne Fontaine, 29190 Lothey'),
(5337,'318bis La Sartenaise, 53340 Préaux');

INSERT INTO Organisation (numero,adresse) VALUES
(5338,'58bis Chemin de Seteras, 32390 Sainte-Christie'),
(5339,'355 Rue Ampère, 02120 Tupigny');

INSERT INTO Organisation (numero,adresse) VALUES
(5340,'448bis En Chirol, 21190 Nantoux'),
(5341,'838 Louveton Nord, 76570 Fresquiennes');

INSERT INTO Organisation (numero,adresse) VALUES
(5342,'9bis Cite Administrative Vassaules, 50570 Hauteville-la-Guichard'),
(5343,'522bis Beo Pais, 01250 Bohas-Meyriat-Rignat');

INSERT INTO Organisation (numero,adresse) VALUES
(5344,'978 Rue Christophe Colomb, 02160 La Ville-aux-Bois-lès-Pontavert'),
(5345,'359bis Les Avoulards, 46210 Saint-Hilaire');

INSERT INTO Organisation (numero,adresse) VALUES
(5346,'692 Landry, 30350 Maruéjols-lès-Gardon'),
(5347,'54bis Le Clos des Arts, 60620 Étavigny');

INSERT INTO Organisation (numero,adresse) VALUES
(5348,'268 Les Petits et Grands Ruiss, 49700 Les Ulmes'),
(5349,'958bis Le Ray, 38270 Beaurepaire');

INSERT INTO Organisation (numero,adresse) VALUES
(5350,'233 Lieu-dit Les Lanes, 35140 Saint-Ouen-des-Alleux'),
(5351,'657 Buissieres, 53290 Saint-Denis-d''Anjou');

INSERT INTO Organisation (numero,adresse) VALUES
(5352,'937bis Chemin de Bascau, 59190 Staple'),
(5353,'56bis Chateau des Gouttes, 23430 Saint-Martin-Sainte-Catherine');

INSERT INTO Organisation (numero,adresse) VALUES
(5354,'908 Las Treytes, 02590 Savy'),
(5355,'851 Le Bout, 16290 Saint-Saturnin');

INSERT INTO Organisation (numero,adresse) VALUES
(5356,'151 Lourdres, 32300 Cuélas'),
(5357,'42 Gennetines, 18120 Massay');

INSERT INTO Organisation (numero,adresse) VALUES
(5358,'699bis ZA des Varennes, 12600 Brommat'),
(5359,'903bis Conservatoire Municipal de Musique, 11380 Labastide-Esparbairenque');

INSERT INTO Organisation (numero,adresse) VALUES
(5360,'100bis Seveyrac-Haut, 65420 Ibos'),
(5361,'145 Promenade Pierre Merli, 22460 Merléac');

INSERT INTO Organisation (numero,adresse) VALUES
(5362,'162bis L''orée du bois, 39230 Chaumergy'),
(5363,'547bis Chemin de la Vigne jeune, 45300 Pannecières');

INSERT INTO Organisation (numero,adresse) VALUES
(5364,'635 Casa D''Ev, 50570 Marigny-Le-Lozon'),
(5365,'915 Laubies, 28260 Gilles');

INSERT INTO Organisation (numero,adresse) VALUES
(5366,'678 Petit Granoux Ouest, 59600 Maubeuge'),
(5367,'995 Le Bouis, 72600 Blèves');

INSERT INTO Organisation (numero,adresse) VALUES
(5368,'361bis Fouleties, 60240 Monneville'),
(5369,'236 Champ Filliol, 31410 Lavernose-Lacasse');

INSERT INTO Organisation (numero,adresse) VALUES
(5370,'933 L''Orme Laguette, 51700 Vincelles'),
(5371,'350 Lindieres, 32160 Saint-Aunix-Lengros');

INSERT INTO Organisation (numero,adresse) VALUES
(5372,'741 Lintez, 76480 Épinay-sur-Duclair'),
(5373,'504bis La Grande Rigollee, 36340 Cluis');

INSERT INTO Organisation (numero,adresse) VALUES
(5374,'395 La Croix Soleil, 03450 Sussat'),
(5375,'614 Pistolet, 62500 Salperwick');

INSERT INTO Organisation (numero,adresse) VALUES
(5376,'643 La Gabache, 56300 Saint-Thuriau'),
(5377,'878 Lombart, 71230 Saint-Romain-sous-Gourdon');

INSERT INTO Organisation (numero,adresse) VALUES
(5378,'494 Siech, 25110 Lomont-sur-Crête'),
(5379,'875 Farramous et le Cambou, 60620 Cuvergnon');

INSERT INTO Organisation (numero,adresse) VALUES
(5380,'520 Lieu-dit Las Gouttes, 16360 Baignes-Sainte-Radegonde'),
(5381,'450 Les Fréaux, 39300 Le Pasquier');

INSERT INTO Organisation (numero,adresse) VALUES
(5382,'865bis En l''Ile, 76970 Flamanville'),
(5383,'312 Virieu-le-Petit - Hameau de Munet, 72120 Saint-Gervais-de-Vic');

INSERT INTO Organisation (numero,adresse) VALUES
(5384,'120 chemin rural dit du Coquerillon, 63450 Chanonat'),
(5385,'266 Eden Rose, 39460 Foncine-le-Haut');

INSERT INTO Organisation (numero,adresse) VALUES
(5386,'372bis d''esbrayat, 24300 Saint-Front-sur-Nizonne'),
(5387,'610 Mousset, 80110 Aubercourt');

INSERT INTO Organisation (numero,adresse) VALUES
(5388,'273 Le Cheret des moutons, 71520 Matour'),
(5389,'265bis Camping GCU, 66210 Formiguères');

INSERT INTO Organisation (numero,adresse) VALUES
(5390,'433 Les Petites Landes, 12260 Saint-Igest'),
(5391,'512 Le Passelis, 73100 Saint-Offenge');

INSERT INTO Organisation (numero,adresse) VALUES
(5392,'761 Le Communal de Bord, 15150 Saint-Gérons'),
(5393,'229bis Le Devez Ouest, 20244 Érone');

INSERT INTO Organisation (numero,adresse) VALUES
(5394,'888 Les Brais, 21310 Beaumont-sur-Vingeanne'),
(5395,'453 Darre, 76660 Clais');

INSERT INTO Organisation (numero,adresse) VALUES
(5396,'635 Cité Bel Air, 52500 Savigny'),
(5397,'564 Le Vieux Vézilly, 24400 Saint-Laurent-des-Hommes');

INSERT INTO Organisation (numero,adresse) VALUES
(5398,'627 La croix de Pierre, 19160 Roche-le-Peyroux'),
(5399,'582bis Ruelle du Cornet, 65190 Tournay');

INSERT INTO Organisation (numero,adresse) VALUES
(5400,'557 Les Razes, 62260 Amettes'),
(5401,'474 Esplanade des Victoires, 52500 Genevrières');

INSERT INTO Organisation (numero,adresse) VALUES
(5402,'617 Pre Grevet, 61100 La Bazoque'),
(5403,'706 Les Fontettes, 67116 Reichstett');

INSERT INTO Organisation (numero,adresse) VALUES
(5404,'188 Les Vignes Blanches, 62120 Roquetoire'),
(5405,'676 Haut Falcon, 02000 Barenton-Cel');

INSERT INTO Organisation (numero,adresse) VALUES
(5406,'302 Tante Rose, 59135 Wallers'),
(5407,'763bis Col de Fourniero-ouest, 02210 Saint-Rémy-Blanzy');

INSERT INTO Organisation (numero,adresse) VALUES
(5408,'757bis Basse Roche, 38680 Choranche'),
(5409,'647 Route de Rignac, 46800 Le Boulvé');

INSERT INTO Organisation (numero,adresse) VALUES
(5410,'928 Tatonne, 23350 La Cellette'),
(5411,'313 Bairal, 23250 La Pouge');

INSERT INTO Organisation (numero,adresse) VALUES
(5412,'612 Le Théreson, 54800 Tronville'),
(5413,'568 Les Silhols, 55190 Villeroy-sur-Méholle');

INSERT INTO Organisation (numero,adresse) VALUES
(5414,'107 Moulin de Vigne, 02720 Homblières'),
(5415,'703 Domaine de Beaupré, 31340 Villematier');

INSERT INTO Organisation (numero,adresse) VALUES
(5416,'400bis Les Turaux, 02500 Mondrepuis'),
(5417,'36 Rue de Gratenas, 27170 Bray');

INSERT INTO Organisation (numero,adresse) VALUES
(5418,'676 Les Oustals Cremats, 17460 Chermignac'),
(5419,'859 Domaine de Sannes, 23600 Leyrat');

INSERT INTO Organisation (numero,adresse) VALUES
(5420,'308 Gardin, 43230 Montclard'),
(5421,'313 Residence du Parc, 16200 Sainte-Sévère');

INSERT INTO Organisation (numero,adresse) VALUES
(5422,'641 Chavornay - Hameau de Ouche, 49350 Gennes-Val-de-Loire'),
(5423,'689 La Grangeasse, 07580 Saint-Gineis-en-Coiron');

INSERT INTO Organisation (numero,adresse) VALUES
(5424,'783 Les Grands Hôpitaux, 16330 Saint-Amant-de-Boixe'),
(5425,'35 Le Serre de Paulet, 54420 Cerville');

INSERT INTO Organisation (numero,adresse) VALUES
(5426,'814 Teste-partide, 65100 Barlest'),
(5427,'103bis Boumajou, 24380 Chalagnac');

INSERT INTO Organisation (numero,adresse) VALUES
(5428,'468 La Chapelle des Glands, 42800 Châteauneuf'),
(5429,'926 Robert-sud, 80440 Blangy-Tronville');

INSERT INTO Organisation (numero,adresse) VALUES
(5430,'601 La Basse Gréyère, 43340 Barges'),
(5431,'186 Le Bois de Geys, 63480 Vertolaye');

INSERT INTO Organisation (numero,adresse) VALUES
(5432,'225 Les Soulereux, 39600 Grange-de-Vaivre'),
(5433,'745 La Glorie, 52400 Coiffy-le-Bas');

INSERT INTO Organisation (numero,adresse) VALUES
(5434,'710 Muratel, 27220 La Forêt-du-Parc'),
(5435,'446 La Roujarie, 12220 Peyrusse-le-Roc');

INSERT INTO Organisation (numero,adresse) VALUES
(5436,'307 Les Sartrons, 57530 Maizery'),
(5437,'528bis Les Ecros, 76760 Saussay');

INSERT INTO Organisation (numero,adresse) VALUES
(5438,'402 Villa De Paradis, 02830 Saint-Michel'),
(5439,'761 Mas Antoni, 46300 Saint-Cirq-Souillaguet');

INSERT INTO Organisation (numero,adresse) VALUES
(5440,'839 Impasse Régina, 37110 Saunay'),
(5441,'608 Allée des Bruyères, 62760 Halloy');

INSERT INTO Organisation (numero,adresse) VALUES
(5442,'363 Pré Frais - Hauteville-Lompnes, 65170 Bourisp'),
(5443,'392bis L''Ibac, 08170 Fumay');

INSERT INTO Organisation (numero,adresse) VALUES
(5444,'66 Les Costes Septentrionales, 78270 Rolleboise'),
(5445,'951 Maisons Neuves, 21500 Villaines-les-Prévôtes');

INSERT INTO Organisation (numero,adresse) VALUES
(5446,'21 Chemin du Clairon, 18120 Cerbois'),
(5447,'159 Saint-jaume, 63530 Sayat');

INSERT INTO Organisation (numero,adresse) VALUES
(5448,'761 Puy-Richard, 39170 Cuttura'),
(5449,'776 Pierre à Croix, 02880 Clamecy');

INSERT INTO Organisation (numero,adresse) VALUES
(5450,'726 les Îles, 26400 Plan-de-Baix'),
(5451,'924 Rue Michel de Tarnowsky, 62990 Boubers-lès-Hesmond');

INSERT INTO Organisation (numero,adresse) VALUES
(5452,'240 Riou Sébirou, 22230 Illifaut'),
(5453,'130 Gourd Maurel, 42600 Bard');

INSERT INTO Organisation (numero,adresse) VALUES
(5454,'458 La Voie des Vaches, 76560 Yvecrique'),
(5455,'532bis Creve Coeur, 32230 Juillac');

INSERT INTO Organisation (numero,adresse) VALUES
(5456,'614bis Bourboutane, 70210 Fontenois-la-Ville'),
(5457,'737bis Plaine de Combal, 61500 Chailloué');

INSERT INTO Organisation (numero,adresse) VALUES
(5458,'310bis Poste de Relèvement, 59600 Mairieux'),
(5459,'827 Au Pavillon, 24540 Saint-Romain-de-Monpazier');

INSERT INTO Organisation (numero,adresse) VALUES
(5460,'886 Chemin de Tacel, 24550 Villefranche-du-Périgord'),
(5461,'642 Chemin des Grands Pins, 63160 Glaine-Montaigut');

INSERT INTO Organisation (numero,adresse) VALUES
(5462,'200 Usine Hydro de Mérens, 14320 May-sur-Orne'),
(5463,'135 Château du Villard, 51300 Les Rivières-Henruel');

INSERT INTO Organisation (numero,adresse) VALUES
(5464,'582 Fontanilles, 70700 Sainte-Reine'),
(5465,'690 Crots, 54470 Jaulny');

INSERT INTO Organisation (numero,adresse) VALUES
(5466,'116 Place  Jean Martinez, 68380 Mittlach'),
(5467,'132 Les Govignons, 03400 Yzeure');

INSERT INTO Organisation (numero,adresse) VALUES
(5468,'316 Le Saint Lieu, 60480 Saint-André-Farivillers'),
(5469,'6 Hautes Combes, 42155 Pouilly-les-Nonains');

INSERT INTO Organisation (numero,adresse) VALUES
(5470,'295 Collège Jean Mermoz, 51240 Saint-Jean-sur-Moivre'),
(5471,'936 L’Elouffier, 08150 Rimogne');

INSERT INTO Organisation (numero,adresse) VALUES
(5472,'875 Le Fosse Troue, 52400 Parnoy-en-Bassigny'),
(5473,'939 Les Parties, 67440 Thal-Marmoutier');

INSERT INTO Organisation (numero,adresse) VALUES
(5474,'703 Escalier Caravadossi, 38119 Saint-Théoffrey'),
(5475,'208 Mas Du Cadran Solaire, 77440 Mary-sur-Marne');

INSERT INTO Organisation (numero,adresse) VALUES
(5476,'97bis Combe des Planes, 17210 Mérignac'),
(5477,'79 Paradiso, 44430 La Remaudière');

INSERT INTO Organisation (numero,adresse) VALUES
(5478,'280 La Frigoule, 76490 Saint-Arnoult'),
(5479,'241 Chemin des Carrères, 74200 Reyvroz');

INSERT INTO Organisation (numero,adresse) VALUES
(5480,'187 Plateau des Forges, 09310 Albiès'),
(5481,'429 le Bourg, 74250 Ville-en-Sallaz');

INSERT INTO Organisation (numero,adresse) VALUES
(5482,'888 Revire, 13100 Le Tholonet'),
(5483,'831bis Les Mondons, 25390 Loray');

INSERT INTO Organisation (numero,adresse) VALUES
(5484,'589 Sente de Quincy, 11340 Roquefeuil'),
(5485,'660 Grand-Vallat, 08450 Remilly-Aillicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(5486,'251 Allée des Bruyères, 63910 Vertaizon'),
(5487,'295 Gremgi Pre, 51600 Suippes');

INSERT INTO Organisation (numero,adresse) VALUES
(5488,'774 Horts de Nadal, 24480 Bouillac'),
(5489,'48bis Rauset, 67270 Minversheim');

INSERT INTO Organisation (numero,adresse) VALUES
(5490,'510 Terre du Plat, 38650 Monestier-de-Clermont'),
(5491,'184bis Le Pré de la Vieille, 60240 Parnes');

INSERT INTO Organisation (numero,adresse) VALUES
(5492,'409 Borie Del Mas, 76450 Ocqueville'),
(5493,'190 La Foret, 70190 Quenoche');

INSERT INTO Organisation (numero,adresse) VALUES
(5494,'559 Camp de la Porte, 54450 Harbouey'),
(5495,'989 La Redondette, 80360 Ginchy');

INSERT INTO Organisation (numero,adresse) VALUES
(5496,'149 Domaine Les trois pechs, 80200 Éterpigny'),
(5497,'787bis Baoussoles, 76570 Cideville');

INSERT INTO Organisation (numero,adresse) VALUES
(5498,'667 Lavergne, 69170 Saint-Marcel-l''Éclairé'),
(5499,'91 La Verchere, 29840 Lanildut');

INSERT INTO Organisation (numero,adresse) VALUES
(5500,'733bis Camp Santane, 75116 Paris 16'),
(5501,'516bis Cantine scolaire, 76280 Gonneville-la-Mallet');

INSERT INTO Organisation (numero,adresse) VALUES
(5502,'581 Les Marteliez Hauts, 69640 Cogny'),
(5503,'81 Bella Riva, 34230 Campagnan');

INSERT INTO Organisation (numero,adresse) VALUES
(5504,'847 Chemin Frédéric Mistral, 80270 Heucourt-Croquoison'),
(5505,'815bis Route du Rials Haut, 01600 Trévoux');

INSERT INTO Organisation (numero,adresse) VALUES
(5506,'548 Grande Seillere, 57920 Metzeresche'),
(5507,'553 Bouquié, 56870 Baden');

INSERT INTO Organisation (numero,adresse) VALUES
(5508,'224 Les Chaumes Blanches, 25680 Avilley'),
(5509,'591 Villa Majola, 61550 Saint-Evroult-Notre-Dame-du-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(5510,'717 Domaine de Notre Dame du Quatourze, 63720 Chavaroux'),
(5511,'739 Route de Mouzon, 46350 Reilhaguet');

INSERT INTO Organisation (numero,adresse) VALUES
(5512,'429bis Puy Vallée, 76520 Fresne-le-Plan'),
(5513,'939 Hameau du Monteil, 21150 Gissey-sous-Flavigny');

INSERT INTO Organisation (numero,adresse) VALUES
(5514,'763bis Aco de Muraire, 18270 Saint-Maur'),
(5515,'906 Impasse Emile Zola, 50240 Saint-Laurent-de-Terregatte');

INSERT INTO Organisation (numero,adresse) VALUES
(5516,'571 La Parisienne, 14370 Argences'),
(5517,'79 La Mole Ste Geneviève, 17600 Saint-Romain-de-Benet');

INSERT INTO Organisation (numero,adresse) VALUES
(5518,'390bis La Robinette Roland, 53440 La Bazoge-Montpinçon'),
(5519,'76 Les Sables et les Vignes, 40800 Duhort-Bachen');

INSERT INTO Organisation (numero,adresse) VALUES
(5520,'247 Le Petit Ruisseau, 33190 Bourdelles'),
(5521,'608bis Pradelasses, 15110 Fridefont');

INSERT INTO Organisation (numero,adresse) VALUES
(5522,'16bis Bâtiment technique, 49620 Mauges-sur-Loire'),
(5523,'965 Le Grand Roustain, 31580 Balesta');

INSERT INTO Organisation (numero,adresse) VALUES
(5524,'22 Les Romaniers, 42940 Châtelneuf'),
(5525,'979 Vente, 47700 Ruffiac');

INSERT INTO Organisation (numero,adresse) VALUES
(5526,'48 Résidence Les Fermes Marines, 39500 Molay'),
(5527,'539 Impasse de Montplaisir, 62580 Vimy');

INSERT INTO Organisation (numero,adresse) VALUES
(5528,'908 Le Moulin de Mandy, 66130 Corbère-les-Cabanes'),
(5529,'445bis Les Bastides Du Soleil, 64700 Biriatou');

INSERT INTO Organisation (numero,adresse) VALUES
(5530,'266 Bertholene, 68510 Magstatt-le-Bas'),
(5531,'883 Le Bois de Vergis, 64270 Bellocq');

INSERT INTO Organisation (numero,adresse) VALUES
(5532,'312bis Impasse du Zodiaque, 25380 Belleherbe'),
(5533,'4 Taussac, 44440 Teillé');

INSERT INTO Organisation (numero,adresse) VALUES
(5534,'164 Puech Fumoux, 31800 Latoue'),
(5535,'754 Parkings Gioan, 26160 Rochebaudin');

INSERT INTO Organisation (numero,adresse) VALUES
(5536,'277bis La Flotte, 52110 Charmes-en-l''Angle'),
(5537,'179bis moulin de vaurseine, 49140 Cornillé-les-Caves');

INSERT INTO Organisation (numero,adresse) VALUES
(5538,'498 Pinet, 02840 Festieux'),
(5539,'220 La Planarie, 77260 Sammeron');

INSERT INTO Organisation (numero,adresse) VALUES
(5540,'433 Bôle, 27600 Heudebouville'),
(5541,'201 La-Crotte, 17700 Surgères');

INSERT INTO Organisation (numero,adresse) VALUES
(5542,'234bis Billard, 23000 Saint-Christophe'),
(5543,'982 Roc Fendut, 33750 Saint-Quentin-de-Baron');

INSERT INTO Organisation (numero,adresse) VALUES
(5544,'9 Les Barthes, 01560 Saint-Trivier-de-Courtes'),
(5545,'714 Raissac le neuf, 20215 Casalta');

INSERT INTO Organisation (numero,adresse) VALUES
(5546,'488 Le Bouyssonis, 01240 Lent'),
(5547,'479 Le Jeu du Mail, 32130 Nizas');

INSERT INTO Organisation (numero,adresse) VALUES
(5548,'474 En Bessant, 29720 Plonéour-Lanvern'),
(5549,'563bis La Mouchonnière, 07580 Saint-Gineis-en-Coiron');

INSERT INTO Organisation (numero,adresse) VALUES
(5550,'9 Carnejac de GRAND-VABRE, 76750 Buchy'),
(5551,'666 Impasse du Verger, 65360 Salles-Adour');

INSERT INTO Organisation (numero,adresse) VALUES
(5552,'553 Le Livernais, 22100 Trélivan'),
(5553,'129 Petit Arbessier, 80170 Wiencourt-l''Équipée');

INSERT INTO Organisation (numero,adresse) VALUES
(5554,'963bis La Regagnhade, 47220 Astaffort'),
(5555,'500bis Thoys, 80500 Fignières');

INSERT INTO Organisation (numero,adresse) VALUES
(5556,'707 Camp Franc, 80370 Hiermont'),
(5557,'953 Le Louage des Bois, 08130 Vaux-Champagne');

INSERT INTO Organisation (numero,adresse) VALUES
(5558,'802bis Traverse Isabelle, 18140 Argenvières'),
(5559,'347bis Chemin du Canal CGE : Sainte-Thècle (Partie basse), 57412 Achen');

INSERT INTO Organisation (numero,adresse) VALUES
(5560,'845bis Le Bois de Bleone, 32600 Beaupuy'),
(5561,'841 Villa Charmevalo, 41110 Châteauvieux');

INSERT INTO Organisation (numero,adresse) VALUES
(5562,'515bis Hameau de Clavet, 30160 Bessèges'),
(5563,'300bis Cérarges Tupin - Hauteville-Lompnes, 15110 Saint-Urcize');

INSERT INTO Organisation (numero,adresse) VALUES
(5564,'267 En Roux, 66360 Sansa'),
(5565,'644bis Route de Montclar, 44430 La Boissière-du-Doré');

INSERT INTO Organisation (numero,adresse) VALUES
(5566,'412bis La Fabasse, 55200 Chonville-Malaumont'),
(5567,'516bis Bertholon, 43300 Vissac-Auteyrac');

INSERT INTO Organisation (numero,adresse) VALUES
(5568,'380 Parvis Simone Weil, 38260 Gillonnay'),
(5569,'209bis Les Rippes, 61130 Dame-Marie');

INSERT INTO Organisation (numero,adresse) VALUES
(5570,'225 Basse Vaucluse, 02250 Cilly'),
(5571,'303 Le presbytère de Bajou, 52190 Villiers-lès-Aprey');

INSERT INTO Organisation (numero,adresse) VALUES
(5572,'475 Le Mas Manier, 25170 Chevigney-sur-l''Ognon'),
(5573,'316 La Salze, 11230 Sonnac-sur-l''Hers');

INSERT INTO Organisation (numero,adresse) VALUES
(5574,'432bis Les Quarante Arpents, 69230 Saint-Genis-Laval'),
(5575,'763 Hauts Ilons Nord, 25310 Glay');

INSERT INTO Organisation (numero,adresse) VALUES
(5576,'142 Solignac, 28170 Saint-Sauveur-Marville'),
(5577,'234 Puech de Teulieres, 14860 Bavent');

INSERT INTO Organisation (numero,adresse) VALUES
(5578,'661 Bâtiment Le lavandin Entrée 16, 07530 Mézilhac'),
(5579,'572 Rieu Negre, 40500 Montgaillard');

INSERT INTO Organisation (numero,adresse) VALUES
(5580,'746bis La Ricardiere, 60400 Ville'),
(5581,'288 Maguèrets, 01270 Domsure');

INSERT INTO Organisation (numero,adresse) VALUES
(5582,'478 chicane, 25370 Jougne'),
(5583,'624 La_grenadiere, 30210 Valliguières');

INSERT INTO Organisation (numero,adresse) VALUES
(5584,'908 Frontière, 68127 Niederentzen'),
(5585,'787 Moliere-nord, 51210 Le Vézier');

INSERT INTO Organisation (numero,adresse) VALUES
(5586,'486 Baille, 73450 Valmeinier'),
(5587,'812 La Raza, 31260 Urau');

INSERT INTO Organisation (numero,adresse) VALUES
(5588,'985 La Borie Blanche, 35540 Plerguer'),
(5589,'289bis Foyer de la Baigneuse -ERP, 60210 Brombos');

INSERT INTO Organisation (numero,adresse) VALUES
(5590,'421 Moulin de Cazottes, 26600 Crozes-Hermitage'),
(5591,'740 Appt 101, 39270 Reithouse');

INSERT INTO Organisation (numero,adresse) VALUES
(5592,'246bis Camp Roux, 59630 Brouckerque'),
(5593,'685 Fonvayse, 23200 Alleyrat');

INSERT INTO Organisation (numero,adresse) VALUES
(5594,'549bis Clubieres, 70120 Lavigney'),
(5595,'902 Bente Farine, 19150 Laguenne');

INSERT INTO Organisation (numero,adresse) VALUES
(5596,'120 Curnat d''en Haut, 48200 Les Monts-Verts'),
(5597,'150 Le Pesqué, 18300 Sancerre');

INSERT INTO Organisation (numero,adresse) VALUES
(5598,'925 Bout des Blancs et Lachens, 17430 Cabariot'),
(5599,'927 La Vuillat d''En Haut, 65150 Nestier');

INSERT INTO Organisation (numero,adresse) VALUES
(5600,'675 Ranque Souque, 48400 Barre-des-Cévennes'),
(5601,'848 Route du Moulin Haut, 65390 Andrest');

INSERT INTO Organisation (numero,adresse) VALUES
(5602,'562bis Saint Rome, 14910 Benerville-sur-Mer'),
(5603,'827bis Avenue du Stade Hlm Touraine, 31600 Labastidette');

INSERT INTO Organisation (numero,adresse) VALUES
(5604,'102 Borde de Rolland, 17350 Fenioux'),
(5605,'648 Res De La Baie A5, 64130 Aussurucq');

INSERT INTO Organisation (numero,adresse) VALUES
(5606,'679 Gabre Jean, 10330 Donnement'),
(5607,'408bis Rille Station de pompage, 76720 Cropus');

INSERT INTO Organisation (numero,adresse) VALUES
(5608,'348 Les Bonnets, 72610 Béthon'),
(5609,'371 Boulouis, 27390 Montreuil-l''Argillé');

INSERT INTO Organisation (numero,adresse) VALUES
(5610,'188 Champ de la Jus, 74160 Feigères'),
(5611,'514 Voie d''accès au CADAM, 56230 Molac');

INSERT INTO Organisation (numero,adresse) VALUES
(5612,'675bis Les Iscles, 26730 La Baume-d''Hostun'),
(5613,'966 La Grand Terre, 22570 Perret');

INSERT INTO Organisation (numero,adresse) VALUES
(5614,'395 """ La Garenne """, 14790 Mouen'),
(5615,'512 Tillet, 69250 Neuville-sur-Saône');

INSERT INTO Organisation (numero,adresse) VALUES
(5616,'832bis Grange du Pre Henry, 19410 Saint-Bonnet-l''Enfantier'),
(5617,'758bis Cazalets, 20226 Costa');

INSERT INTO Organisation (numero,adresse) VALUES
(5618,'419 Le Castéra, 17800 Fléac-sur-Seugne'),
(5619,'996bis Les Vieilles Bordes, 21330 Fontaines-les-Sèches');

INSERT INTO Organisation (numero,adresse) VALUES
(5620,'72 La Grande Rigollee, 65140 Saint-Sever-de-Rustan'),
(5621,'161bis Ruelle de la Mairie, 61250 Ménil-Erreux');

INSERT INTO Organisation (numero,adresse) VALUES
(5622,'272 Saint Georges, 27930 Saint-Vigor'),
(5623,'510 Francois Huguet, 76220 Montroty');

INSERT INTO Organisation (numero,adresse) VALUES
(5624,'560 Saint-Brès, 64370 Hagetaubin'),
(5625,'386 Le Bouscal, 31800 Savarthès');

INSERT INTO Organisation (numero,adresse) VALUES
(5626,'736 L''Enclos Camar, 74200 Marin'),
(5627,'249 Les Vernas, 58420 Taconnay');

INSERT INTO Organisation (numero,adresse) VALUES
(5628,'853 Le Poteau de Saussaye, 41150 Mesland'),
(5629,'928bis Le Baragoin, 66500 Campôme');

INSERT INTO Organisation (numero,adresse) VALUES
(5630,'839bis Villa Florentine, 44110 Noyal-sur-Brutz'),
(5631,'315 Traverse de Reipierre, 77720 La Chapelle-Gauthier');

INSERT INTO Organisation (numero,adresse) VALUES
(5632,'916 Champ de l''Ort, 76260 Ponts-et-Marais'),
(5633,'271 Canonge, 07110 Valgorge');

INSERT INTO Organisation (numero,adresse) VALUES
(5634,'643bis Case Sovrane, 77370 Nangis'),
(5635,'120 Moulin d''Aval, 02480 Dury');

INSERT INTO Organisation (numero,adresse) VALUES
(5636,'297bis La Capucine, 04210 Brunet'),
(5637,'372bis Les Hauts de Las Cours, 39800 Vaux-sur-Poligny');

INSERT INTO Organisation (numero,adresse) VALUES
(5638,'112 Bas Basset, 45310 La Chapelle-Onzerain'),
(5639,'710 La Batherie Basse, 14380 Saint-Aubin-des-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(5640,'843 Narmand Est, 62310 Maisoncelle'),
(5641,'373bis Le Petit Sablon, 77720 Mormant');

INSERT INTO Organisation (numero,adresse) VALUES
(5642,'435bis Rebusson, 05460 Abriès'),
(5643,'866 Sente dite de Montaigu, 56140 Réminiac');

INSERT INTO Organisation (numero,adresse) VALUES
(5644,'477 L''Hopital Bellegarde, 10170 Chauchigny'),
(5645,'773bis Rond-point des Tilleuls, 08110 Sachy');

INSERT INTO Organisation (numero,adresse) VALUES
(5646,'898 Alpoulils, 07370 Ozon'),
(5647,'888bis Serenity, 09700 Gaudiès');

INSERT INTO Organisation (numero,adresse) VALUES
(5648,'77 Le Cotton, 30330 Pougnadoresse'),
(5649,'986 Castelline, 14340 Formentin');

INSERT INTO Organisation (numero,adresse) VALUES
(5650,'665 Le Séguela, 71460 Ameugny'),
(5651,'614 Bois Coutté, 31440 Fos');

INSERT INTO Organisation (numero,adresse) VALUES
(5652,'488 Paulhac, 15170 Peyrusse'),
(5653,'514bis Chemin de Las Barthos, 34150 Lagamas');

INSERT INTO Organisation (numero,adresse) VALUES
(5654,'493 Bourgnounet, 62760 Couin'),
(5655,'985bis """ Boucaumont """, 66120 Égat');

INSERT INTO Organisation (numero,adresse) VALUES
(5656,'308bis Lieu-dit La Moulasse, 57480 Laumesfeld'),
(5657,'889 Place Guyemer, 10700 Champfleury');

INSERT INTO Organisation (numero,adresse) VALUES
(5658,'676 Les Estivals, 02250 Cilly'),
(5659,'669 Felicity Bat B, 33126 Saint-Michel-de-Fronsac');

INSERT INTO Organisation (numero,adresse) VALUES
(5660,'219 Station d''épuration, 55290 Bure'),
(5661,'156 Prats-de-Bres, 57220 Boucheporn');

INSERT INTO Organisation (numero,adresse) VALUES
(5662,'522bis Siols, 14220 Martainville'),
(5663,'704 Résidence les Églantines, 61000 Saint-Germain-du-Corbéis');

INSERT INTO Organisation (numero,adresse) VALUES
(5664,'85 Champ des Louvettes, 51600 Somme-Tourbe'),
(5665,'424 Pra Prunier, 61600 Lonlay-le-Tesson');

INSERT INTO Organisation (numero,adresse) VALUES
(5666,'837 Route de Beille, 76340 Fallencourt'),
(5667,'742 Les Vieux Moulins, 29310 Locunolé');

INSERT INTO Organisation (numero,adresse) VALUES
(5668,'814 Béninie, 71530 Virey-le-Grand'),
(5669,'666 Mas de Geysse, 37380 Reugny');

INSERT INTO Organisation (numero,adresse) VALUES
(5670,'97 Les Jonchiers, 54200 Toul'),
(5671,'230 Pechcarbou, 57230 Schorbach');

INSERT INTO Organisation (numero,adresse) VALUES
(5672,'915 Chemin Départemental 74 de Bucilly à Chaourse, 72610 Béthon'),
(5673,'111 La Manne, 30580 Seynes');

INSERT INTO Organisation (numero,adresse) VALUES
(5674,'3 Bessous, 01250 Bohas-Meyriat-Rignat'),
(5675,'418bis Hameau de Jouandou, 22290 Pléguien');

INSERT INTO Organisation (numero,adresse) VALUES
(5676,'904bis Rieu Négre, 12300 Decazeville'),
(5677,'117 La Maison de Paille, 61550 Saint-Evroult-Notre-Dame-du-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(5678,'353bis Escaliers de la Recluse, 47340 Castella'),
(5679,'82 Place rue Maurice Maccario, 67730 Châtenois');

INSERT INTO Organisation (numero,adresse) VALUES
(5680,'859 Domaine des Cofins, 25570 Grand''Combe-Châteleu'),
(5681,'416 Les Pâtureaux, 55200 Broussey-Raulecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(5682,'591 La Meule, 45340 Barville-en-Gâtinais'),
(5683,'689bis Le-bois-lambert, 47180 Saint-Martin-Petit');

INSERT INTO Organisation (numero,adresse) VALUES
(5684,'986bis La Queue des Barbettes, 42210 Unias'),
(5685,'292 Artis, 80160 Flers-sur-Noye');

INSERT INTO Organisation (numero,adresse) VALUES
(5686,'451bis Point Eau Incendie n°1005 (borne d''incendie), 14520 Commes'),
(5687,'189 Rolland, 72340 Loir en Vallée');

INSERT INTO Organisation (numero,adresse) VALUES
(5688,'240 Tarissou de Valette, 29690 Plouyé'),
(5689,'368 Gallean, 60510 Oroër');

INSERT INTO Organisation (numero,adresse) VALUES
(5690,'273 Nauriol Haut, 58700 Beaumont-la-Ferrière'),
(5691,'954 Résidence Lavoisier, 07200 Lanas');

INSERT INTO Organisation (numero,adresse) VALUES
(5692,'971 Manoray, 03500 Loriges'),
(5693,'544bis Siguens, 79420 Saint-Martin-du-Fouilloux');

INSERT INTO Organisation (numero,adresse) VALUES
(5694,'342bis La Borie Alte, 51340 Scrupt'),
(5695,'190 Rue du Candelas, 71490 Tintry');

INSERT INTO Organisation (numero,adresse) VALUES
(5696,'168 Gallean, 50190 Nay'),
(5697,'713 L''Hôpital, 12120 Sainte-Juliette-sur-Viaur');

INSERT INTO Organisation (numero,adresse) VALUES
(5698,'512bis Prat Del Priou, 52260 Chanoy'),
(5699,'486bis Jeanery, 07260 Joyeuse');

INSERT INTO Organisation (numero,adresse) VALUES
(5700,'636 Boutaric Bas, 60510 Therdonne'),
(5701,'473 Bourse Longue, 77130 La Grande-Paroisse');

INSERT INTO Organisation (numero,adresse) VALUES
(5702,'3 Malan, 74200 Marin'),
(5703,'526 Segures, 23200 Saint-Avit-de-Tardes');

INSERT INTO Organisation (numero,adresse) VALUES
(5704,'11bis Escalier Saint Martin, 31190 Auragne'),
(5705,'67 Prost, 62380 Seninghem');

INSERT INTO Organisation (numero,adresse) VALUES
(5706,'261 L’Espital, 24550 Villefranche-du-Périgord'),
(5707,'500bis Cantagrel-Bas, 18360 La Celette');

INSERT INTO Organisation (numero,adresse) VALUES
(5708,'476 La Vallée Guerbette, 33690 Sigalens'),
(5709,'710 Allée du Parc Fiorentina, 45340 Nancray-sur-Rimarde');

INSERT INTO Organisation (numero,adresse) VALUES
(5710,'130bis Le Cabra D''Or, 09420 Rimont'),
(5711,'116 Bois Serret, 68890 Meyenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(5712,'931bis Agols, 03290 Saint-Pourçain-sur-Besbre'),
(5713,'454 Chateau de Beaumont, 79100 Tourtenay');

INSERT INTO Organisation (numero,adresse) VALUES
(5714,'799 Les Dris, 53190 Landivy'),
(5715,'548 Prani de Haut, 44390 Les Touches');

INSERT INTO Organisation (numero,adresse) VALUES
(5716,'780 Les Chaunes, 67350 Engwiller'),
(5717,'904 Place du 15 octobre 1918, 61320 Rouperroux');

INSERT INTO Organisation (numero,adresse) VALUES
(5718,'514 Chp Fromentot, 80240 Liéramont'),
(5719,'217 Bois d''Aboul, 76740 Fontaine-le-Dun');

INSERT INTO Organisation (numero,adresse) VALUES
(5720,'341 Place Cour Toulouse, 67250 Memmelshoffen'),
(5721,'769bis Les_revols_ouest, 41400 Faverolles-sur-Cher');

INSERT INTO Organisation (numero,adresse) VALUES
(5722,'127 Le Bosquet A, 37530 Nazelles-Négron'),
(5723,'896 Les Côtes de La Croze, 40800 Saint-Agnet');

INSERT INTO Organisation (numero,adresse) VALUES
(5724,'91bis Le Jas d''Estelle, 59222 Bousies'),
(5725,'270 Casseloup, 03160 Saint-Plaisir');

INSERT INTO Organisation (numero,adresse) VALUES
(5726,'435 Domaine Nesme, 31590 Verfeil'),
(5727,'797 Les Batignolles, 18380 Ivoy-le-Pré');

INSERT INTO Organisation (numero,adresse) VALUES
(5728,'683 Les Hauts Guyarts, 68730 Ranspach-le-Bas'),
(5729,'852 Tredos, 39290 Montmirey-la-Ville');

INSERT INTO Organisation (numero,adresse) VALUES
(5730,'36 Le Vialaret Lapanouse, 41160 Rahart'),
(5731,'678 Pré Collet, 79500 Chail');

INSERT INTO Organisation (numero,adresse) VALUES
(5732,'282 Lieu-dit Clamens, 50450 Saint-Denis-le-Gast'),
(5733,'201 Parvis Église Saint Maurice, 24330 Boulazac Isle Manoire');

INSERT INTO Organisation (numero,adresse) VALUES
(5734,'199 Au Soleo, 76116 Grainville-sur-Ry'),
(5735,'159bis Bonde de Mairisette, 58370 Villapourçon');

INSERT INTO Organisation (numero,adresse) VALUES
(5736,'421 Sinhalac, 13310 Saint-Martin-de-Crau'),
(5737,'416 """ Les Saulais """, 38440 Lieudieu');

INSERT INTO Organisation (numero,adresse) VALUES
(5738,'111 Senseby d''en Bas, 32380 Saint-Léonard'),
(5739,'902 Pré Domenge, 24600 Allemans');

INSERT INTO Organisation (numero,adresse) VALUES
(5740,'409bis Le Tournier, 76540 Thiétreville'),
(5741,'728 Montgervis-Est, 57920 Hombourg-Budange');

INSERT INTO Organisation (numero,adresse) VALUES
(5742,'363bis Gauax, 21500 Viserny'),
(5743,'552bis Devant Vière, 72150 Saint-Vincent-du-Lorouër');

INSERT INTO Organisation (numero,adresse) VALUES
(5744,'811 Le Ray Noir, 54115 Grimonviller'),
(5745,'45 Le Mas Des Caucours, 33440 Ambarès-et-Lagrave');

INSERT INTO Organisation (numero,adresse) VALUES
(5746,'424bis Chalayet de Robert, 57420 Solgne'),
(5747,'521 Zone Artisanale La Cornella - Hauteville-Lompnes, 05320 La Grave');

INSERT INTO Organisation (numero,adresse) VALUES
(5748,'623 Chemin rural n°3 de Maranwez à Saint-Jean-aux-Bois, 17730 Port-des-Barques'),
(5749,'60 Le Gaoulet, 76560 Harcanville');

INSERT INTO Organisation (numero,adresse) VALUES
(5750,'50 Chazeaux le Haut, 64350 Crouseilles'),
(5751,'863 Le Techeyre, 59870 Bouvignies');

INSERT INTO Organisation (numero,adresse) VALUES
(5752,'596 Cammeau, 14420 Soumont-Saint-Quentin'),
(5753,'34 Route de Requista, 57480 Manderen');

INSERT INTO Organisation (numero,adresse) VALUES
(5754,'606 Parking du crématorium, 64160 Gabaston'),
(5755,'591 Le Coeur Center, 34480 Magalas');

INSERT INTO Organisation (numero,adresse) VALUES
(5756,'101 Bretelle Entrée Saint-Philippe - Mathis (Chaussée sud), 54180 Houdemont'),
(5757,'508bis Hameau le petit bois, 10440 Torvilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(5758,'401 Bonnard-Est, 01250 Saint-Just'),
(5759,'85 Archelles, 35380 Treffendel');

INSERT INTO Organisation (numero,adresse) VALUES
(5760,'848 Longcol, 39600 Villers-Farlay'),
(5761,'16 Aubert, 03260 Saint-Germain-des-Fossés');

INSERT INTO Organisation (numero,adresse) VALUES
(5762,'545 Laragnou, 09800 Engomer'),
(5763,'111bis Voie de la Marnière, 67700 Monswiller');

INSERT INTO Organisation (numero,adresse) VALUES
(5764,'970 La Barthasse, 37360 Sonzay'),
(5765,'561 Pre Porche, 57200 Blies-Guersviller');

INSERT INTO Organisation (numero,adresse) VALUES
(5766,'51bis Amandonne Basse, 15500 Auriac-l''Église'),
(5767,'689 La-fosse-aux-renards, 60680 Grandfresnoy');

INSERT INTO Organisation (numero,adresse) VALUES
(5768,'360 Hameau du roux, 22570 Perret'),
(5769,'566bis Jas de Berle, 58210 Marcy');

INSERT INTO Organisation (numero,adresse) VALUES
(5770,'387 La Pascalette, 68560 Ruederbach'),
(5771,'954bis Moulin de l''Espine, 22150 Gausson');

INSERT INTO Organisation (numero,adresse) VALUES
(5772,'455 Frayssinet-Bas, 62140 Guigny'),
(5773,'115 Hawaï 1, 40250 Lamothe');

INSERT INTO Organisation (numero,adresse) VALUES
(5774,'654 Domaine Alcouffe, 41100 Villemardy'),
(5775,'484 Le Rata, 61370 Échauffour');

INSERT INTO Organisation (numero,adresse) VALUES
(5776,'716 Le Moulin Brûle, 03210 Noyant-d''Allier'),
(5777,'133 Le Grand Logisson, 17430 Saint-Coutant-le-Grand');

INSERT INTO Organisation (numero,adresse) VALUES
(5778,'833 Residence Jean Miquel, 20140 Petreto-Bicchisano'),
(5779,'631 Le Clos Saint Michel Villas 6 A 12, 76210 Bolbec');

INSERT INTO Organisation (numero,adresse) VALUES
(5780,'35 Residence les Grands Ax, 50630 Videcosville'),
(5781,'169 Route Departementale 119, 68270 Ruelisheim');

INSERT INTO Organisation (numero,adresse) VALUES
(5782,'194 Impasse Thevenin, 09160 Mauvezin-de-Prat'),
(5783,'918 Quartier CHABROLS, 78590 Noisy-le-Roi');

INSERT INTO Organisation (numero,adresse) VALUES
(5784,'291 Montramech, 27290 Touville'),
(5785,'572 Aux Petites Mangettes, 45640 Sandillon');

INSERT INTO Organisation (numero,adresse) VALUES
(5786,'846 Vieux Chemin de Saint-Antoine raccourci n°2, 22780 Plougras'),
(5787,'63bis Les Mas Du Leouve, 53190 Fougerolles-du-Plessis');

INSERT INTO Organisation (numero,adresse) VALUES
(5788,'447 Lacombe, 67250 Schœnenbourg'),
(5789,'436 Escalier public, 38460 Vénérieu');

INSERT INTO Organisation (numero,adresse) VALUES
(5790,'376bis La Vernne, 01090 Lurcy'),
(5791,'150 Caponsac, 28170 Favières');

INSERT INTO Organisation (numero,adresse) VALUES
(5792,'182 Le Sales, 38200 Chuzelles'),
(5793,'380 Le Mas de Soïo, 10700 Poivres');

INSERT INTO Organisation (numero,adresse) VALUES
(5794,'640 Cayssiolet, 77120 Saints'),
(5795,'345bis Bois Royal de Cournaube, 35120 Baguer-Morvan');

INSERT INTO Organisation (numero,adresse) VALUES
(5796,'219 Levers Del Code, 30160 Robiac-Rochessadoule'),
(5797,'731bis Le Cloutas, 33430 Cudos');

INSERT INTO Organisation (numero,adresse) VALUES
(5798,'928 La Blache Ronde, 14240 Les Loges'),
(5799,'677 Autopont Centre Commercial Lingostière Sud, 14270 Monteille');

INSERT INTO Organisation (numero,adresse) VALUES
(5800,'348 Le Champ Gouny, 60240 Bachivillers'),
(5801,'229 L''Orphane RD 30, 60810 Raray');

INSERT INTO Organisation (numero,adresse) VALUES
(5802,'991 Les Gravas, 17470 Loiré-sur-Nie'),
(5803,'678 Quai du Canelot, 70150 Courcuire');

INSERT INTO Organisation (numero,adresse) VALUES
(5804,'134 Hlm les Gâteaux Bat A1, 69700 Beauvallon'),
(5805,'511bis La penderie, 17430 Bords');

INSERT INTO Organisation (numero,adresse) VALUES
(5806,'905 Sente des Paons, 31150 Fenouillet'),
(5807,'938bis Le Petit Criquet, 14480 Saint-Gabriel-Brécy');

INSERT INTO Organisation (numero,adresse) VALUES
(5808,'166 La Saussiere, 27470 Fontaine-l''Abbé'),
(5809,'894 La Treille Haute, 52150 Graffigny-Chemin');

INSERT INTO Organisation (numero,adresse) VALUES
(5810,'396 Puechmainade, 62132 Hardinghen'),
(5811,'438 La Villefranche d''En Bas, 72230 Mulsanne');

INSERT INTO Organisation (numero,adresse) VALUES
(5812,'1bis Chabbert, 01480 Chaleins'),
(5813,'943bis Les Quatre Fauchees, 60430 Silly-Tillard');

INSERT INTO Organisation (numero,adresse) VALUES
(5814,'548bis Moulin de Florentin, 32450 Castelnau-Barbarens'),
(5815,'478 Avenue des Sapeurs Pompiers de Nice, 40320 Samadet');

INSERT INTO Organisation (numero,adresse) VALUES
(5816,'875 Le Mas de Colomb, 29410 Pleyber-Christ'),
(5817,'328bis Village de Lacroix, 28220 Romilly-sur-Aigre');

INSERT INTO Organisation (numero,adresse) VALUES
(5818,'447bis Les_fayes_et_la_roue, 29460 Logonna-Daoulas'),
(5819,'640 Champ Millet, 68870 Bartenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(5820,'187bis Les Meles, 29510 Landrévarzec'),
(5821,'996bis La Villatte, 28630 Morancez');

INSERT INTO Organisation (numero,adresse) VALUES
(5822,'728 Impasse de la Forêt, 70500 Corre'),
(5823,'16 Rue du Longeon, 57910 Neufgrange');

INSERT INTO Organisation (numero,adresse) VALUES
(5824,'436 Lotissement du Bosquet, 63660 La Chaulme'),
(5825,'890 Centre de Loisirs, 76570 Pavilly');

INSERT INTO Organisation (numero,adresse) VALUES
(5826,'455 Le Grand Gouillat, 49330 Juvardeil'),
(5827,'708 Aire de camping cars, 39570 Vernantois');

INSERT INTO Organisation (numero,adresse) VALUES
(5828,'13 Passage du Bicentenaire, 27210 Saint-Maclou'),
(5829,'886bis Aire du Plan d''Eau du Radal, 61240 Lignères');

INSERT INTO Organisation (numero,adresse) VALUES
(5830,'734 Pinsounet, 32340 Saint-Antoine'),
(5831,'681 Espace Joseph Manzone, 59217 Carnières');

INSERT INTO Organisation (numero,adresse) VALUES
(5832,'601bis Pinson, 49310 Saint-Paul-du-Bois'),
(5833,'813 Avenue Centrale, 69360 Communay');

INSERT INTO Organisation (numero,adresse) VALUES
(5834,'524 Chemin de la Ligne, 73110 Villaroux'),
(5835,'939 Le Mourou, 73490 La Ravoire');

INSERT INTO Organisation (numero,adresse) VALUES
(5836,'662 Ferme des Ormées, 25110 Cusance'),
(5837,'396 Bois de l''Eau, 07000 Ajoux');

INSERT INTO Organisation (numero,adresse) VALUES
(5838,'950 Les Godillons de Chaux, 31450 Belberaud'),
(5839,'473bis Mas de Bousquel, 71460 Saint-Micaud');

INSERT INTO Organisation (numero,adresse) VALUES
(5840,'145 Moulin d''Holières, 39360 Chassal'),
(5841,'504 Bastaysse, 73220 Montgilbert');

INSERT INTO Organisation (numero,adresse) VALUES
(5842,'248 Mas de Cousis, 65140 Mansan'),
(5843,'37 Four de Saint-Urbain, 61100 La Lande-Patry');

INSERT INTO Organisation (numero,adresse) VALUES
(5844,'271 Flavin, 43160 Saint-Pal-de-Senouire'),
(5845,'22 Les-Dragons, 68230 Turckheim');

INSERT INTO Organisation (numero,adresse) VALUES
(5846,'247 Porche Cité du Parc - Quai Etats-Unis : n°75 - Cité du Parc, 18570 Le Subdray'),
(5847,'567bis Moulintour, 02140 Prisces');

INSERT INTO Organisation (numero,adresse) VALUES
(5848,'869 Derriere les Varennes, 22240 La Bouillie'),
(5849,'476 Buffalieres, 29530 Collorec');

INSERT INTO Organisation (numero,adresse) VALUES
(5850,'312bis Rue du Trigan, 50630 Octeville-l''Avenel'),
(5851,'882bis Montpeyroux, 72130 Saint-Léonard-des-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(5852,'767 Passage Rosset, 16230 Lonnes'),
(5853,'134 Le Chemin de Favières, 02330 Courboin');

INSERT INTO Organisation (numero,adresse) VALUES
(5854,'57 Lotissement OUSTRIC (OAP), 14400 Subles'),
(5855,'243 Les Clauses Basses, 22390 Bourbriac');

INSERT INTO Organisation (numero,adresse) VALUES
(5856,'596 Place du Ravelin, 43000 Ceyssac'),
(5857,'721 Combe-Lantard, 64300 Salles-Mongiscard');

INSERT INTO Organisation (numero,adresse) VALUES
(5858,'359 Le Dauphin Bleu A, 37340 Savigné-sur-Lathan'),
(5859,'992 Le Creux de l''Eume, 63230 Pulvérières');

INSERT INTO Organisation (numero,adresse) VALUES
(5860,'871 Ferme de Sauvresy, 29880 Guissény'),
(5861,'969bis L’Esperance, 77230 Longperrier');

INSERT INTO Organisation (numero,adresse) VALUES
(5862,'302bis Les Petits Chaux, 33490 Le Pian-sur-Garonne'),
(5863,'494bis Contre Allée Route de Gattières, 14880 Hermanville-sur-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(5864,'407 La Cote Notre Dame, 63450 Le Crest'),
(5865,'30 Rue de l''Agal, 27700 Guiseniers');

INSERT INTO Organisation (numero,adresse) VALUES
(5866,'355 Le Lus, 46160 Montbrun'),
(5867,'994bis le Landie, 14380 Pont-Bellanger');

INSERT INTO Organisation (numero,adresse) VALUES
(5868,'559 La Pitchoune, 02200 Venizel'),
(5869,'946 Le Bas des Bordes, 32240 Maupas');

INSERT INTO Organisation (numero,adresse) VALUES
(5870,'923 Tracol, 02600 Mortefontaine'),
(5871,'416 Bois d''Aboul, 60400 Ville');

INSERT INTO Organisation (numero,adresse) VALUES
(5872,'173bis Rue de la 1ère Division Française Libre, 43800 Saint-Vincent'),
(5873,'907 Valentin, 32200 Montiron');

INSERT INTO Organisation (numero,adresse) VALUES
(5874,'756 Le Matou, 71700 Ozenay'),
(5875,'454 Grange de Bac, 18320 Beffes');

INSERT INTO Organisation (numero,adresse) VALUES
(5876,'62 Communal de Puot, 08300 Amagne'),
(5877,'887 Buffe-arnaud, 39300 Sapois');

INSERT INTO Organisation (numero,adresse) VALUES
(5878,'659 Grande Brande de la Corre, 03420 Sainte-Thérence'),
(5879,'744bis Villa Carla, 29233 Cléder');

INSERT INTO Organisation (numero,adresse) VALUES
(5880,'23 Place Charles Cros, 03310 Villebret'),
(5881,'729 Rond-Point  Jean Boulitreau, 67210 Goxwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(5882,'43 Les Mas Du Soleil, 39300 Loulle'),
(5883,'348bis Le Castéra, 43800 Lavoûte-sur-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(5884,'709bis Villa Calendale, 28210 Le Boullay-Mivoye'),
(5885,'256bis Local Boules de Rival, 63820 Briffons');

INSERT INTO Organisation (numero,adresse) VALUES
(5886,'267 La Fosse aux Bois, 28340 La Ferté-Vidame'),
(5887,'159bis Restouline, 64200 Bassussarry');

INSERT INTO Organisation (numero,adresse) VALUES
(5888,'644 Le Bari, 54150 Lubey'),
(5889,'48bis Les Prés Houés, 76730 Hermanville');

INSERT INTO Organisation (numero,adresse) VALUES
(5890,'488 As Cascals, 10700 Mesnil-la-Comtesse'),
(5891,'990 Pra Manson, 09160 Taurignan-Castet');

INSERT INTO Organisation (numero,adresse) VALUES
(5892,'11 Saint Jean de Veau, 39240 Lavans-sur-Valouse'),
(5893,'390 Jardin de Saint Martin, 26560 Séderon');

INSERT INTO Organisation (numero,adresse) VALUES
(5894,'766 Doumingète, 59330 Éclaibes'),
(5895,'445 Le Serayet, 25330 Bolandoz');

INSERT INTO Organisation (numero,adresse) VALUES
(5896,'213 Le Patio Renoir A, 34110 Vic-la-Gardiole'),
(5897,'287 Le Brountoulou, 33430 Lignan-de-Bazas');

INSERT INTO Organisation (numero,adresse) VALUES
(5898,'618 Champelovier, 50600 Lapenty'),
(5899,'169 Maladrech, 28500 Sainte-Gemme-Moronval');

INSERT INTO Organisation (numero,adresse) VALUES
(5900,'41 Panrient, 10190 Estissac'),
(5901,'569bis Le Riollet, 33690 Grignols');

INSERT INTO Organisation (numero,adresse) VALUES
(5902,'962bis Chemin de Prat Sauvage, 70130 Fresne-Saint-Mamès'),
(5903,'561 Bois de Juery, 35310 Saint-Thurial');

INSERT INTO Organisation (numero,adresse) VALUES
(5904,'698 Les Estrets, 38930 Saint-Martin-de-Clelles'),
(5905,'279 Saint-sornin Ouest, 24500 Serres-et-Montguyard');

INSERT INTO Organisation (numero,adresse) VALUES
(5906,'522bis Route des Quéribets, 45500 Saint-Gondon'),
(5907,'16 Gourgouras Dessous, 05160 Savines-le-Lac');

INSERT INTO Organisation (numero,adresse) VALUES
(5908,'662 La Cremade et Tres Bouisso, 62134 Eps'),
(5909,'944 Grange de Prele, 70110 Gouhenans');

INSERT INTO Organisation (numero,adresse) VALUES
(5910,'151 Res Campanette A Et B, 37320 Truyes'),
(5911,'107 """ Les Ravereux """, 20217 Nonza');

INSERT INTO Organisation (numero,adresse) VALUES
(5912,'322 Voie résidence Saint-Roch - Extension, 62124 Bus'),
(5913,'496 L’Hubac et la Joie, 06230 Saint-Jean-Cap-Ferrat');

INSERT INTO Organisation (numero,adresse) VALUES
(5914,'7 Grand Charrière, 46700 Sérignac'),
(5915,'832bis Route de Vezaponin, 39160 Véria');

INSERT INTO Organisation (numero,adresse) VALUES
(5916,'995bis Combe Fontmalle, 67470 Trimbach'),
(5917,'308 Les Auches de Colombier, 71290 Jouvençon');

INSERT INTO Organisation (numero,adresse) VALUES
(5918,'959 Les Bonnets Sud, 76760 Saussay'),
(5919,'556 Le Barre Bas, 08290 Aouste');

INSERT INTO Organisation (numero,adresse) VALUES
(5920,'102 Communal de Cornadouire, 14490 Saint-Paul-du-Vernay'),
(5921,'817 La Bignasse, 55400 Rouvres-en-Woëvre');

INSERT INTO Organisation (numero,adresse) VALUES
(5922,'442bis Les Charlats, 08400 Monthois'),
(5923,'796 Le Champ Signeux, 17350 Annepont');

INSERT INTO Organisation (numero,adresse) VALUES
(5924,'184bis Borie de Rinhodes, 58400 Bulcy'),
(5925,'628 En Germanet, 06380 Sospel');

INSERT INTO Organisation (numero,adresse) VALUES
(5926,'495 la Gazelle, 65370 Sainte-Marie'),
(5927,'92 Listournel, 68480 Kiffis');

INSERT INTO Organisation (numero,adresse) VALUES
(5928,'309bis Le Molard, 38260 Faramans'),
(5929,'530 Les Gillets, 30120 Bréau-et-Salagosse');

INSERT INTO Organisation (numero,adresse) VALUES
(5930,'683 Clos Bourdon, 48140 Le Malzieu-Ville'),
(5931,'26 Hlm le Plessis Bat I2, 22100 Bobital');

INSERT INTO Organisation (numero,adresse) VALUES
(5932,'628 L''Etang des Bois, 47150 Gavaudun'),
(5933,'977 Cian de Morion, 33240 Saint-Gervais');

INSERT INTO Organisation (numero,adresse) VALUES
(5934,'665 Les Baucheyres, 32400 Saint-Germé'),
(5935,'234 Sarradials, 61500 Essay');

INSERT INTO Organisation (numero,adresse) VALUES
(5936,'8 Le Monnet, 28120 Ermenonville-la-Petite'),
(5937,'796bis Rue du Pont, 69430 Régnié-Durette');

INSERT INTO Organisation (numero,adresse) VALUES
(5938,'681 La Rue du Moulin, 21150 Alise-Sainte-Reine'),
(5939,'514 Las Graves, 07590 Saint-Laurent-les-Bains');

INSERT INTO Organisation (numero,adresse) VALUES
(5940,'287bis Le Soulage, 46130 Saint-Michel-Loubéjou'),
(5941,'138 Le Vas, 26130 Clansayes');

INSERT INTO Organisation (numero,adresse) VALUES
(5942,'93 Résidence Le Lagon, 72130 Saint-Paul-le-Gaultier'),
(5943,'679 Fournel, 34190 Brissac');

INSERT INTO Organisation (numero,adresse) VALUES
(5944,'519 Les Donhes Basses, 32220 Puylausic'),
(5945,'951 Maugard, 25800 Étray');

INSERT INTO Organisation (numero,adresse) VALUES
(5946,'572 Solanes, 26230 Colonzelle'),
(5947,'893 La Coutarie-Basse, 44460 Saint-Nicolas-de-Redon');

INSERT INTO Organisation (numero,adresse) VALUES
(5948,'379 Le Garrigou, 59750 Feignies'),
(5949,'232bis Res Marie-Jeanne, 51240 Vésigneul-sur-Marne');

INSERT INTO Organisation (numero,adresse) VALUES
(5950,'267 Rond point de la Croix Rouge, 42440 Saint-Jean-la-Vêtre'),
(5951,'762 Marchonnet, 71140 Vitry-sur-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(5952,'953 Panrient, 10500 Petit-Mesnil'),
(5953,'970 Villa Laurette, 17150 Saint-Georges-des-Agoûts');

INSERT INTO Organisation (numero,adresse) VALUES
(5954,'589 Le Clos Des Bréguières, 71130 Vendenesse-sur-Arroux'),
(5955,'203 Flavin, 65700 Sombrun');

INSERT INTO Organisation (numero,adresse) VALUES
(5956,'141bis Lilou, 02480 Cugny'),
(5957,'323 Res Les Palmiers, 40430 Luxey');

INSERT INTO Organisation (numero,adresse) VALUES
(5958,'625 Route de la première division de la France libre, 22490 Plouër-sur-Rance'),
(5959,'228 Valayssac, 53170 Ruillé-Froid-Fonds');

INSERT INTO Organisation (numero,adresse) VALUES
(5960,'678 Bois de Badel, 74370 Nâves-Parmelan'),
(5961,'702 Couteret, 37130 Cinq-Mars-la-Pile');

INSERT INTO Organisation (numero,adresse) VALUES
(5962,'684 Villa Les Lauriers, 79170 Villefollet'),
(5963,'891 Chaudagne, 54640 Tucquegnieux');

INSERT INTO Organisation (numero,adresse) VALUES
(5964,'72 Le Bouchet, 30270 Saint-Jean-du-Gard'),
(5965,'346 Brule_biasse, 54115 Favières');

INSERT INTO Organisation (numero,adresse) VALUES
(5966,'402 Toilettes publiques, 10260 Vaudes'),
(5967,'461 Citerne incendie 1 de 45 m3, 39110 Pont-d''Héry');

INSERT INTO Organisation (numero,adresse) VALUES
(5968,'87bis Font Orbe, 12330 Saint-Christophe-Vallon'),
(5969,'171 Le Domaine de Cadenat, 33450 Saint-Loubès');

INSERT INTO Organisation (numero,adresse) VALUES
(5970,'600bis Villa L''Oustaou, 42140 Saint-Denis-sur-Coise'),
(5971,'278 Le Combet, 02140 Vervins');

INSERT INTO Organisation (numero,adresse) VALUES
(5972,'458 Terre de Cressieu, 37220 Crouzilles'),
(5973,'645 Le Gravie, 02460 La Ferté-Milon');

INSERT INTO Organisation (numero,adresse) VALUES
(5974,'620 La Fighiera, 76440 Sommery'),
(5975,'20 Place du 8 Mai, 58190 Metz-le-Comte');

INSERT INTO Organisation (numero,adresse) VALUES
(5976,'364 Bederet, 77148 Salins'),
(5977,'808 Les Vernhes, 64640 Hélette');

INSERT INTO Organisation (numero,adresse) VALUES
(5978,'874 Le Cros Pouthier, 24260 Saint-Avit-de-Vialard'),
(5979,'859 Lieu-dit Las Bourdettos, 37160 Buxeuil');

INSERT INTO Organisation (numero,adresse) VALUES
(5980,'611 Etang Vernay, 77860 Saint-Germain-sur-Morin'),
(5981,'206 Les Galets Escalier 3, 14710 Formigny La Bataille');

INSERT INTO Organisation (numero,adresse) VALUES
(5982,'560 Les Regnauds, 44170 Vay'),
(5983,'801bis Les Malenies, 77390 Champdeuil');

INSERT INTO Organisation (numero,adresse) VALUES
(5984,'948 Sainte Eulalie, 43510 Ouides'),
(5985,'917bis Le Mareton, 64350 Crouseilles');

INSERT INTO Organisation (numero,adresse) VALUES
(5986,'65 Le Gory, 01570 Vésines'),
(5987,'771 Rue Basse, 62390 Boffles');

INSERT INTO Organisation (numero,adresse) VALUES
(5988,'636 Le Mas de Vinaigre, 42990 Sauvain'),
(5989,'186 Les Pradilios, 68130 Hausgauen');

INSERT INTO Organisation (numero,adresse) VALUES
(5990,'757 Plage Marquet, 45170 Santeau'),
(5991,'414bis Las Plantes, 29800 Saint-Urbain');

INSERT INTO Organisation (numero,adresse) VALUES
(5992,'304bis Versols, 68150 Aubure'),
(5993,'211 Clos Coquille, 76260 Canehan');

INSERT INTO Organisation (numero,adresse) VALUES
(5994,'454 Lauzac, 31310 Gouzens'),
(5995,'790 Les Merles, 24530 Saint-Pancrace');

INSERT INTO Organisation (numero,adresse) VALUES
(5996,'589 Les Barras, 47600 Saumont'),
(5997,'852 La Batherie Haute, 30160 Bessèges');

INSERT INTO Organisation (numero,adresse) VALUES
(5998,'75 Notre Dame des Prés, 47170 Sos'),
(5999,'336 Ladrix, 28480 Miermaigne');

INSERT INTO Organisation (numero,adresse) VALUES
(6000,'919 Le Bourgnounet, 71260 Clessé'),
(6001,'810 Hameau de la Cerise, 15170 Valjouze');

INSERT INTO Organisation (numero,adresse) VALUES
(6002,'417 Les Beugnants, 70000 Noroy-le-Bourg'),
(6003,'331 Coste Jalet Sud, 55840 Thierville-sur-Meuse');

INSERT INTO Organisation (numero,adresse) VALUES
(6004,'157 Les Heuillots, 40500 Bas-Mauco'),
(6005,'410 Chez-Insnard, 28240 Vaupillon');

INSERT INTO Organisation (numero,adresse) VALUES
(6006,'332 Passage du Cordonnier, 07300 Mauves'),
(6007,'458 Les Cordeliers, 65250 Montoussé');

INSERT INTO Organisation (numero,adresse) VALUES
(6008,'74 Moulin d''En Haut, 40130 Capbreton'),
(6009,'473 Le Laussier, 68580 Largitzen');

INSERT INTO Organisation (numero,adresse) VALUES
(6010,'281 Impasse des Anges, 77400 Pomponne'),
(6011,'522 Lotissement les Vieilles Vignes, 80250 Folleville');

INSERT INTO Organisation (numero,adresse) VALUES
(6012,'445 Bost, 52600 Palaiseul'),
(6013,'172bis La Souleille d’Escayrie, 69480 Ambérieux');

INSERT INTO Organisation (numero,adresse) VALUES
(6014,'438 Tuilerie des Molles, 42560 Gumières'),
(6015,'769bis Mas de l''Hort, 07400 Sceautres');

INSERT INTO Organisation (numero,adresse) VALUES
(6016,'73 Hlm Pierre Leroux, 31600 Saubens'),
(6017,'369 Vierisnarde, 62810 Denier');

INSERT INTO Organisation (numero,adresse) VALUES
(6018,'471 Bergerie d''Alberny, 80300 Dernancourt'),
(6019,'292bis Moulin de Boutonnat, 63460 Artonne');

INSERT INTO Organisation (numero,adresse) VALUES
(6020,'652 Puech Bernard, 12270 Najac'),
(6021,'395 Res Les Hauts De Ziem, 33690 Lavazan');

INSERT INTO Organisation (numero,adresse) VALUES
(6022,'25bis Les Combales, 14260 Malherbe-sur-Ajon'),
(6023,'976 Pre de Malet, 65190 Mascaras');

INSERT INTO Organisation (numero,adresse) VALUES
(6024,'939bis Soulergues, 21290 Leuglay'),
(6025,'769 Perrin, 09460 Mijanès');

INSERT INTO Organisation (numero,adresse) VALUES
(6026,'898 Cavaille, 21360 Crugey'),
(6027,'281 Saint Jean le Froid, 76260 Le Mesnil-Réaume');

INSERT INTO Organisation (numero,adresse) VALUES
(6028,'467bis Ferme d''Hameret, 14400 Guéron'),
(6029,'439 Les Jardins De Cagnes, 68130 Berentzwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(6030,'518 Champ de Laporte, 20117 Eccica-Suarella'),
(6031,'653bis Froideau, 12800 Tauriac-de-Naucelle');

INSERT INTO Organisation (numero,adresse) VALUES
(6032,'24 Domaine Glennet Bas, 52310 Ormoy-lès-Sexfontaines'),
(6033,'426 Rue Charles de Gaulle, 34290 Espondeilhan');

INSERT INTO Organisation (numero,adresse) VALUES
(6034,'963 Terre Neuve, 67500 Weitbruch'),
(6035,'536bis Metrosc, 61570 Montmerrei');

INSERT INTO Organisation (numero,adresse) VALUES
(6036,'369 La Rue Mérié, 58300 Cossaye'),
(6037,'839 Moradi, 39210 Montain');

INSERT INTO Organisation (numero,adresse) VALUES
(6038,'133 Bourrelot, 65310 Horgues'),
(6039,'16 La Fumadette, 49140 Soucelles');

INSERT INTO Organisation (numero,adresse) VALUES
(6040,'938 Le Calvaire, 79200 Adilly'),
(6041,'659 Verduegne, 59252 Wasnes-au-Bac');

INSERT INTO Organisation (numero,adresse) VALUES
(6042,'161 Les Nesmes, 71240 Saint-Cyr'),
(6043,'442 Place Gabriel Cordier, 76640 Rocquefort');

INSERT INTO Organisation (numero,adresse) VALUES
(6044,'95 Allée Henry Ruhl, 57370 Phalsbourg'),
(6045,'540 La Pinèe, 77690 Montigny-sur-Loing');

INSERT INTO Organisation (numero,adresse) VALUES
(6046,'805 Coste Vieille (la), 79420 Reffannes'),
(6047,'459bis Bas Chevalet, 80310 Le Mesge');

INSERT INTO Organisation (numero,adresse) VALUES
(6048,'78 L’Eyrouse, 59730 Vertain'),
(6049,'733 Puech Palalie, 31290 Villefranche-de-Lauragais');

INSERT INTO Organisation (numero,adresse) VALUES
(6050,'709 Metches Basses, 29440 Plougar'),
(6051,'95bis Chez Régnier, 55120 Clermont-en-Argonne');

INSERT INTO Organisation (numero,adresse) VALUES
(6052,'941 Compoulong, 73800 Cruet'),
(6053,'357 Taravelle, 36000 Châteauroux');

INSERT INTO Organisation (numero,adresse) VALUES
(6054,'798 Résidence la Vicairie, 55000 Ville-sur-Saulx'),
(6055,'707 Impasse des Lavandes, 62870 Maintenay');

INSERT INTO Organisation (numero,adresse) VALUES
(6056,'567 Le Renvers de Conroy, 09290 Gabre'),
(6057,'552 Holes-de-la-belle-croix, 18350 Tendron');

INSERT INTO Organisation (numero,adresse) VALUES
(6058,'614 Avenue Jean Rostand, 09600 Régat'),
(6059,'461bis Résidence Terrasses des Pecheurs, 31440 Marignac');

INSERT INTO Organisation (numero,adresse) VALUES
(6060,'154 Le Navech, 16190 Salles-Lavalette'),
(6061,'283bis Montclarou, 31460 Ségreville');

INSERT INTO Organisation (numero,adresse) VALUES
(6062,'634bis Vedeilles, 54300 Xermaménil'),
(6063,'970 Rond-Point  Rond-Point Chef de bataillon Patrice Rebout, 54150 Lantéfontaine');

INSERT INTO Organisation (numero,adresse) VALUES
(6064,'618 Pont-Noir, 27220 Fresney'),
(6065,'659bis """ Salles """, 34490 Causses-et-Veyran');

INSERT INTO Organisation (numero,adresse) VALUES
(6066,'909 Les Curtils Neufs, 76560 Doudeville'),
(6067,'151 Villa Rejo, 06470 Saint-Martin-d''Entraunes');

INSERT INTO Organisation (numero,adresse) VALUES
(6068,'846 La Borde de Bas, 07110 Montréal'),
(6069,'645 Pré Courbe, 59191 Caullery');

INSERT INTO Organisation (numero,adresse) VALUES
(6070,'854 Pont de Duniere, 58150 Garchy'),
(6071,'560 Le Moulin Ganot, 57790 Lorquin');

INSERT INTO Organisation (numero,adresse) VALUES
(6072,'170bis Chemin du Canal CGE : Corniche des Oliviers, 39100 Parcey'),
(6073,'7 Grand Corvey, 54120 Pettonville');

INSERT INTO Organisation (numero,adresse) VALUES
(6074,'882 La Germanie, 50160 Saint-Amand-Villages'),
(6075,'179 Les Foulons, 05600 Guillestre');

INSERT INTO Organisation (numero,adresse) VALUES
(6076,'82 Chemin de l''Ecole Jules Verne, 14570 La Villette'),
(6077,'20bis Las Coumes, 60580 Coye-la-Forêt');

INSERT INTO Organisation (numero,adresse) VALUES
(6078,'261 Roque de Barau, 39140 Fontainebrux'),
(6079,'661 La Terre de l''Homme, 41170 Baillou');

INSERT INTO Organisation (numero,adresse) VALUES
(6080,'949 Terre de Cressieu, 46500 Reilhac'),
(6081,'955 Route Métropolitaine 6202bis - Nice/Carros, 68116 Guewenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(6082,'380 L''espaï, 50480 Carentan les Marais'),
(6083,'738 Les Platières, 10220 Mesnil-Sellières');

INSERT INTO Organisation (numero,adresse) VALUES
(6084,'486 Impasse des Acacias, 71270 Longepierre'),
(6085,'552 La Mouline, 17380 Torxé');

INSERT INTO Organisation (numero,adresse) VALUES
(6086,'445 Aux Etteppes, 44410 La Chapelle-des-Marais'),
(6087,'935 Bois de Bégut, 80500 Le Cardonnois');

INSERT INTO Organisation (numero,adresse) VALUES
(6088,'707 En Devotay, 38470 Cognin-les-Gorges'),
(6089,'968bis Les Rutis, 42600 Pralong');

INSERT INTO Organisation (numero,adresse) VALUES
(6090,'740 Pre Fromente, 39570 La Chailleuse'),
(6091,'355 Espine, 30480 Saint-Paul-la-Coste');

INSERT INTO Organisation (numero,adresse) VALUES
(6092,'938 Château de Donnaud, 54140 Jarville-la-Malgrange'),
(6093,'560 Usine Hydro Hospitalet, 18220 Aubinges');

INSERT INTO Organisation (numero,adresse) VALUES
(6094,'22 Beau Vallon, 26600 Pont-de-l''Isère'),
(6095,'849 Le Basset, 50200 Nicorps');

INSERT INTO Organisation (numero,adresse) VALUES
(6096,'222 Rond Point Auguste Maicon, 02130 Villeneuve-sur-Fère'),
(6097,'221 Le Mondou, 36700 Cléré-du-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(6098,'89 Ruelle Charpentier, 57810 Rhodes'),
(6099,'503 Lieu-dit Les Tueries, 31350 Saint-Pé-Delbosc');

INSERT INTO Organisation (numero,adresse) VALUES
(6100,'108 Ferme de Bernardy, 54450 Gogney'),
(6101,'4bis Ferme de la Fontaine Olive, 25870 Thurey-le-Mont');

INSERT INTO Organisation (numero,adresse) VALUES
(6102,'633 Mas Desy, 18340 Plaimpied-Givaudins'),
(6103,'345bis Cimetière de Menay, 77130 Ville-Saint-Jacques');

INSERT INTO Organisation (numero,adresse) VALUES
(6104,'291bis Champ Dilain, 76890 Saint-Denis-sur-Scie'),
(6105,'995 Allée du Carimai, 70500 Aisey-et-Richecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(6106,'580 Pre d’Aubert, 44170 La Grigonnais'),
(6107,'61 Les Grandes Demaines, 10200 Voigny');

INSERT INTO Organisation (numero,adresse) VALUES
(6108,'159bis Le Moulin Bavard, 08220 Draize'),
(6109,'22 Favi, 35800 Dinard');

INSERT INTO Organisation (numero,adresse) VALUES
(6110,'174bis Les Dezard, 39250 Doye'),
(6111,'472 Grange de Prele, 27630 Heubécourt-Haricourt');

INSERT INTO Organisation (numero,adresse) VALUES
(6112,'204 Avenue des Grenouillères, 70230 Montbozon'),
(6113,'209 Lieu-dit La Marine, 39570 Courbouzon');

INSERT INTO Organisation (numero,adresse) VALUES
(6114,'620 Résidence Les Grandes Bleues 2, 19150 Saint-Bonnet-Avalouze'),
(6115,'14 Parc Christian Lescos, 76560 Reuville');

INSERT INTO Organisation (numero,adresse) VALUES
(6116,'809bis La Parra d’Engaline, 04200 Peipin'),
(6117,'619 Cuolla, 76540 Thiergeville');

INSERT INTO Organisation (numero,adresse) VALUES
(6118,'332 """ La Salle """, 25680 Gouhelans'),
(6119,'685 Rond Point d''Ostende, 23140 Vigeville');

INSERT INTO Organisation (numero,adresse) VALUES
(6120,'113 Ferme de la Maison du Bois, 27680 Saint-Samson-de-la-Roque'),
(6121,'497 Les Cazazils, 24580 Fleurac');

INSERT INTO Organisation (numero,adresse) VALUES
(6122,'642 La Cruz, 70400 Échavanne'),
(6123,'521 Le Lavour, 55700 Beauclair');

INSERT INTO Organisation (numero,adresse) VALUES
(6124,'803 Le Fond du Buisson Genin, 45340 Batilly-en-Gâtinais'),
(6125,'214 Le Clot de la Molo, 51210 Bergères-sous-Montmirail');

INSERT INTO Organisation (numero,adresse) VALUES
(6126,'52bis Bretelle Sortie Mercantour - Vérola (chaussée est), 62390 Vaulx'),
(6127,'849bis Vigne Robert, 60600 Rémécourt');

INSERT INTO Organisation (numero,adresse) VALUES
(6128,'818bis """ Les Chereux """, 61110 Verrières'),
(6129,'56 Res Alexander, 61300 L''Aigle');

INSERT INTO Organisation (numero,adresse) VALUES
(6130,'406 La Plane de Saint Julien, 50680 Saint-Georges-d''Elle'),
(6131,'151 Citerne incendie 1 de 45 m3, 35430 Saint-Père');

INSERT INTO Organisation (numero,adresse) VALUES
(6132,'372 Villa Birdy, 33420 Lugaignac'),
(6133,'861bis Le Puech de Cunhac, 45260 Presnoy');

INSERT INTO Organisation (numero,adresse) VALUES
(6134,'837 Le Molard, 70170 Bougnon'),
(6135,'699bis Grand Ligneux, 12600 Thérondels');

INSERT INTO Organisation (numero,adresse) VALUES
(6136,'518 Marquet-haut, 38490 Saint-Ondras'),
(6137,'32bis Planal de Villemajou, 60810 Montépilloy');

INSERT INTO Organisation (numero,adresse) VALUES
(6138,'855 Derrière les Haies, 22460 Merléac'),
(6139,'112 Verdillon, 68210 Montreux-Jeune');

INSERT INTO Organisation (numero,adresse) VALUES
(6140,'540 Mas de Bousquet, 39140 Bletterans'),
(6141,'256bis La Mirondière, 27680 Vieux-Port');

INSERT INTO Organisation (numero,adresse) VALUES
(6142,'680 chemin rural dit du Val de Thors, 43290 Montfaucon-en-Velay'),
(6143,'916 Rue du Rial, 23350 Nouziers');

INSERT INTO Organisation (numero,adresse) VALUES
(6144,'597 Place A. Millo, 60590 Éragny-sur-Epte'),
(6145,'209 Les Boueix, 45170 Montigny');

INSERT INTO Organisation (numero,adresse) VALUES
(6146,'29 Lieu Dit St Laurent, 61500 La Chapelle-près-Sées'),
(6147,'483 La Petite Gendarme, 73300 Saint-Jean-de-Maurienne');

INSERT INTO Organisation (numero,adresse) VALUES
(6148,'893 Rond point de la Brague, 35550 Saint-Ganton'),
(6149,'272bis La Flachière, 77390 Verneuil-l''Étang');

INSERT INTO Organisation (numero,adresse) VALUES
(6150,'828 Les Menens, 41110 Couffy'),
(6151,'283 Dominique, 26740 La Laupie');

INSERT INTO Organisation (numero,adresse) VALUES
(6152,'232 Pla de Ferriol-sud, 60210 Dargies'),
(6153,'778 Goulou-Haut, 63440 Marcillat');

INSERT INTO Organisation (numero,adresse) VALUES
(6154,'689 La Bonélie, 66300 Sainte-Colombe-de-la-Commanderie'),
(6155,'289bis Les Jasmins, 02370 Ostel');

INSERT INTO Organisation (numero,adresse) VALUES
(6156,'965 Rue Nicot de Villemain, 71640 Barizey'),
(6157,'421bis Las Ginestos, 64460 Ponson-Dessus');

INSERT INTO Organisation (numero,adresse) VALUES
(6158,'858 Carmaillas, 44440 Joué-sur-Erdre'),
(6159,'761 Le Castel Du Cros A/B, 71118 Saint-Martin-Belle-Roche');

INSERT INTO Organisation (numero,adresse) VALUES
(6160,'927 Dergis Michaud - Hauteville-Lompnes, 40380 Montfort-en-Chalosse'),
(6161,'572 Bâtiment L''argeiras, 51700 Igny-Comblizy');

INSERT INTO Organisation (numero,adresse) VALUES
(6162,'691 Saint-jean de Caps-ouest, 14260 Bonnemaison'),
(6163,'425bis Peire Grosse, 01130 Charix');

INSERT INTO Organisation (numero,adresse) VALUES
(6164,'388bis Laurent, 32380 Saint-Léonard'),
(6165,'854bis Col de Jean Long et l''Adre, 55230 Pillon');

INSERT INTO Organisation (numero,adresse) VALUES
(6166,'602 Résidence Bellevue, 20212 Castellare-di-Mercurio'),
(6167,'182 Montferrand, 80310 Belloy-sur-Somme');

INSERT INTO Organisation (numero,adresse) VALUES
(6168,'369 Le Brialon, 80300 Grandcourt'),
(6169,'295bis Lieu Chevalier, 38570 Le Cheylas');

INSERT INTO Organisation (numero,adresse) VALUES
(6170,'74bis Lieu Dit Surveillas, 25320 Byans-sur-Doubs'),
(6171,'660 Les Grandes Soulières, 03800 Gannat');

INSERT INTO Organisation (numero,adresse) VALUES
(6172,'515 Les Perrots, 27500 Tourville-sur-Pont-Audemer'),
(6173,'132 La Plate Pierre, 57790 Hermelange');

INSERT INTO Organisation (numero,adresse) VALUES
(6174,'379 Canecaude, 10180 Saint-Lyé'),
(6175,'321 Domaine de la Charmoye, 07110 Largentière');

INSERT INTO Organisation (numero,adresse) VALUES
(6176,'343 Catalic, 11580 Missègre'),
(6177,'362bis Le Bousquet-Haut, 22630 Saint-Judoce');

INSERT INTO Organisation (numero,adresse) VALUES
(6178,'975 Valberg, 60190 Arsy'),
(6179,'473 Bas Ilons Nord, 63790 Murol');

INSERT INTO Organisation (numero,adresse) VALUES
(6180,'721 La Croix Peloux, 02380 Verneuil-sous-Coucy'),
(6181,'686 """ 1 La Doustrie """, 42470 Fourneaux');

INSERT INTO Organisation (numero,adresse) VALUES
(6182,'69bis Al Rec Escur, 53110 Thubœuf'),
(6183,'290 Les Montades et Méraville, 74130 Brizon');

INSERT INTO Organisation (numero,adresse) VALUES
(6184,'120 Baraqueville, 56250 La Vraie-Croix'),
(6185,'525bis Co d''en cens, 25370 Saint-Antoine');

INSERT INTO Organisation (numero,adresse) VALUES
(6186,'18 La Maillerie, 66760 Latour-de-Carol'),
(6187,'449 Piece Godo, 22400 Andel');

INSERT INTO Organisation (numero,adresse) VALUES
(6188,'711 Place du Belvédère, 61420 Fontenai-les-Louvets'),
(6189,'893 Les Glauds, 11200 Argens-Minervois');

INSERT INTO Organisation (numero,adresse) VALUES
(6190,'810 Bât B2 les hauts de Septèmes nord, 08240 Boult-aux-Bois'),
(6191,'915bis Rue du Coudercou, 63500 Pardines');

INSERT INTO Organisation (numero,adresse) VALUES
(6192,'997 Volpillac Haut, 24700 Ménesplet'),
(6193,'713 La Croix d''en Bord, 24320 Bertric-Burée');

INSERT INTO Organisation (numero,adresse) VALUES
(6194,'850 Allée des Ferrants, 72240 Neuvillalais'),
(6195,'348 Les Guyonnieres, 70100 Chargey-lès-Gray');

INSERT INTO Organisation (numero,adresse) VALUES
(6196,'909 Rue Charles de Tabaret, 52330 Vaudrémont'),
(6197,'464 Fadasse, 76220 Elbeuf-en-Bray');

INSERT INTO Organisation (numero,adresse) VALUES
(6198,'527 Les Blottons, 62113 Verquigneul'),
(6199,'121 Parking des Vignes, 26160 Manas');

INSERT INTO Organisation (numero,adresse) VALUES
(6200,'829 Rue Saint-Jean-Baptiste, 51150 Athis'),
(6201,'494 Résidence Cosy Diem, 27150 Longchamps');

INSERT INTO Organisation (numero,adresse) VALUES
(6202,'143 Voie desserte de l''UFR - STAPS, 13270 Fos-sur-Mer'),
(6203,'265bis Grange Mayoux, 39800 Vaux-sur-Poligny');

INSERT INTO Organisation (numero,adresse) VALUES
(6204,'530bis Champ Juveniet, 57330 Entrange'),
(6205,'592bis Les Pres Lavaux, 62450 Warlencourt-Eaucourt');

INSERT INTO Organisation (numero,adresse) VALUES
(6206,'407 Al Riou, 62390 Tollent'),
(6207,'479bis Les Gérolles, 43100 Mercœur');

INSERT INTO Organisation (numero,adresse) VALUES
(6208,'193 Giscard, 07380 Lalevade-d''Ardèche'),
(6209,'843bis Lotissement le Pilon, 76220 Ernemont-la-Villette');

INSERT INTO Organisation (numero,adresse) VALUES
(6210,'363bis Lei Verdoulin''S, 54740 Gerbécourt-et-Haplemont'),
(6211,'544 La Parra, 28200 Moléans');

INSERT INTO Organisation (numero,adresse) VALUES
(6212,'815 Lacos Ouest, 70300 La Chapelle-lès-Luxeuil'),
(6213,'37 Traverse du Grand Pin, 67660 Betschdorf');

INSERT INTO Organisation (numero,adresse) VALUES
(6214,'424bis Blaque et Bout de Nice Est, 17330 Saint-Séverin-sur-Boutonne'),
(6215,'267 Michel, 69250 Fleurieu-sur-Saône');

INSERT INTO Organisation (numero,adresse) VALUES
(6216,'225 Ham de Charoué, 14420 Ussy'),
(6217,'145bis Mas De Cocagne, 05300 Éourres');

INSERT INTO Organisation (numero,adresse) VALUES
(6218,'227 Au Bois de Salvaza, 33750 Camarsac'),
(6219,'331 Les-grandes-gaudines, 08160 Étrépigny');

INSERT INTO Organisation (numero,adresse) VALUES
(6220,'27 Saleyrac, 09120 Rieux-de-Pelleport'),
(6221,'270 Femas et le Serre, 63910 Vertaizon');

INSERT INTO Organisation (numero,adresse) VALUES
(6222,'274 Voie d''accès sud Quai la Perouse, 78550 Bazainville'),
(6223,'101bis Vaubelle, 19200 Saint-Exupéry-les-Roches');

INSERT INTO Organisation (numero,adresse) VALUES
(6224,'316bis Les Clauzels, 12510 Druelle Balsac'),
(6225,'656 Le Yal, 02210 Vierzy');

INSERT INTO Organisation (numero,adresse) VALUES
(6226,'481 Chemin des Cyprès, 31120 Portet-sur-Garonne'),
(6227,'479 La Garde de Dieu, 63320 Chidrac');

INSERT INTO Organisation (numero,adresse) VALUES
(6228,'687bis Rond point Antoine Meilland, 08250 Sommerance'),
(6229,'867 Lagardelle, 55130 Vouthon-Bas');

INSERT INTO Organisation (numero,adresse) VALUES
(6230,'518 Parc Général Lecuyer, 80160 Bosquel'),
(6231,'542 Prat de Jacquou, 65220 Luby-Betmont');

INSERT INTO Organisation (numero,adresse) VALUES
(6232,'651 Le Haut des Fosses, 21450 Fontaines-en-Duesmois'),
(6233,'38 Le Combal, 49510 Beaupréau-en-Mauges');

INSERT INTO Organisation (numero,adresse) VALUES
(6234,'893 La Peeta et la Grand Terre, 27440 Touffreville'),
(6235,'487 La Bastisse de Menay, 72130 Fresnay-sur-Sarthe');

INSERT INTO Organisation (numero,adresse) VALUES
(6236,'875 L''Esplanade, 44540 Bonnœuvre'),
(6237,'582 Combe de Garce-sud, 68125 Houssen');

INSERT INTO Organisation (numero,adresse) VALUES
(6238,'900 Lachon, 01430 Chevillard'),
(6239,'486 La Piche, 30120 Arphy');

INSERT INTO Organisation (numero,adresse) VALUES
(6240,'669 Haut Falcon, 51270 Étoges'),
(6241,'366 Verupt Hameau, 66360 Mantet');

INSERT INTO Organisation (numero,adresse) VALUES
(6242,'23bis la Campe, 01680 Lompnas'),
(6243,'721 Sentier Caravadossi, 26770 Le Pègue');

INSERT INTO Organisation (numero,adresse) VALUES
(6244,'158 Fontantige, 79360 Villiers-en-Bois'),
(6245,'36 Resselves, 21580 Avot');

INSERT INTO Organisation (numero,adresse) VALUES
(6246,'491 Serre Jurus, 60190 Sacy-le-Petit'),
(6247,'772 Allée de la Résidence Le Panoramic, 71290 Ormes');

INSERT INTO Organisation (numero,adresse) VALUES
(6248,'67 "Camping ""Le Pas de l''Ours""", 20236 Omessa'),
(6249,'350bis La Futaie, 30770 Campestre-et-Luc');

INSERT INTO Organisation (numero,adresse) VALUES
(6250,'686 Les Chabanons, 07400 Alba-la-Romaine'),
(6251,'725 Les Bruyères de Briette, 25240 Mouthe');

INSERT INTO Organisation (numero,adresse) VALUES
(6252,'896 Le Courret, 77120 Mauperthuis'),
(6253,'264 D''1044 Ferme de Pienne, 08450 La Neuville-à-Maire');

INSERT INTO Organisation (numero,adresse) VALUES
(6254,'388 Plage de la Fighière, 59216 Beugnies'),
(6255,'417 Les Grangettes, 72610 Rouessé-Fontaine');

INSERT INTO Organisation (numero,adresse) VALUES
(6256,'868 Le Terne Jean Servais, 07000 Freyssenet'),
(6257,'343 La Halle, 11350 Paziols');

INSERT INTO Organisation (numero,adresse) VALUES
(6258,'722bis La Carnicousie, 02800 Vendeuil'),
(6259,'916 Le Viable, 43300 Prades');

INSERT INTO Organisation (numero,adresse) VALUES
(6260,'475 ZA Pièce de l''Orme, 66170 Néfiach'),
(6261,'240 Petit Arbessier, 03410 Domérat');

INSERT INTO Organisation (numero,adresse) VALUES
(6262,'406bis Les Piaux, 38112 Autrans-Méaudre en Vercors'),
(6263,'4 Rec du Sauze-sud, 26210 Lens-Lestang');

INSERT INTO Organisation (numero,adresse) VALUES
(6264,'585bis Lauthier le Haut, 78830 Bonnelles'),
(6265,'872 Moulin de Charrier, 40090 Gaillères');

INSERT INTO Organisation (numero,adresse) VALUES
(6266,'228bis Pellaborie, 30200 Orsan'),
(6267,'886 Vers Carella, 08150 Renwez');

INSERT INTO Organisation (numero,adresse) VALUES
(6268,'532bis L''Etang Gorgeas, 71400 Autun'),
(6269,'508bis Les Croix de l’Hom, 17160 Mons');

INSERT INTO Organisation (numero,adresse) VALUES
(6270,'458 Le Paroir, 30430 Saint-Privat-de-Champclos'),
(6271,'598 Escalier Chemin des Crêtes du Mont Boron, 30570 Notre-Dame-de-la-Rouvière');

INSERT INTO Organisation (numero,adresse) VALUES
(6272,'985 Les Bachasses, 58300 Verneuil'),
(6273,'338bis Pomies, 18240 Léré');

INSERT INTO Organisation (numero,adresse) VALUES
(6274,'860bis Les Asterines, 31370 Rieumes'),
(6275,'98bis Le Petit Bosquet entrée A (1à9), 40320 Urgons');

INSERT INTO Organisation (numero,adresse) VALUES
(6276,'502bis Ruelle des Courcoussoun, 30960 Saint-Florent-sur-Auzonnet'),
(6277,'325 Lotissement Les Jardins de Milady, 78117 Châteaufort');

INSERT INTO Organisation (numero,adresse) VALUES
(6278,'175 La Raffanelle, 60640 Le Plessis-Patte-d''Oie'),
(6279,'366 La Plaine d’Ozon, 62910 Moulle');

INSERT INTO Organisation (numero,adresse) VALUES
(6280,'397 Le Moulin Infernal, 70270 La Lanterne-et-les-Armonts'),
(6281,'548 Château des Bluziaux, 38490 Charancieu');

INSERT INTO Organisation (numero,adresse) VALUES
(6282,'529 """ Juchemilant """, 29640 Plougonven'),
(6283,'192 L’Escarrassat, 54370 Raville-sur-Sânon');

INSERT INTO Organisation (numero,adresse) VALUES
(6284,'70 Residence St Maurice Bat à, 28630 Le Coudray'),
(6285,'51 Cap Long, 25110 Villers-Saint-Martin');

INSERT INTO Organisation (numero,adresse) VALUES
(6286,'982 Pranier, 63730 Les Martres-de-Veyre'),
(6287,'117 La Clouissa, 56800 Guillac');

INSERT INTO Organisation (numero,adresse) VALUES
(6288,'405 Saint Sauveur, 09000 Baulou'),
(6289,'719 Jamborie, 67260 Rimsdorf');

INSERT INTO Organisation (numero,adresse) VALUES
(6290,'172 Le Perie, 38140 Saint-Blaise-du-Buis'),
(6291,'682bis La Pesturie, 66300 Castelnou');

INSERT INTO Organisation (numero,adresse) VALUES
(6292,'487bis Le Coeur Center, 67770 Sessenheim'),
(6293,'757 Les Colombis, 34130 Saint-Aunès');

INSERT INTO Organisation (numero,adresse) VALUES
(6294,'95 Hameau de Lupieu, 55100 Vacherauville'),
(6295,'603bis La Grande Mouillere, 45490 Courtempierre');

INSERT INTO Organisation (numero,adresse) VALUES
(6296,'616 Impasse Numéro 12, 64480 Halsou'),
(6297,'938 Aire de bivouac gratuite, 27520 Saint-Denis-des-Monts');

INSERT INTO Organisation (numero,adresse) VALUES
(6298,'748 Jardin et Parc-autos Corvésy, 61380 Soligny-la-Trappe'),
(6299,'254 Cambajou, 63350 Culhat');

INSERT INTO Organisation (numero,adresse) VALUES
(6300,'487bis L''Avent-Centre, 64270 Puyoô'),
(6301,'316 Dany, 03230 Gannay-sur-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(6302,'449 Bestex, 27230 Bournainville-Faverolles'),
(6303,'911 Pièce del Miech, 25680 Mondon');

INSERT INTO Organisation (numero,adresse) VALUES
(6304,'663 Lou Ventoulet, 33124 Berthez'),
(6305,'470 Les Gouillettes, 27240 Roman');

INSERT INTO Organisation (numero,adresse) VALUES
(6306,'474 La Renarde, 20160 Guagno'),
(6307,'468 Allée Barney Wilen, 54200 Lucey');

INSERT INTO Organisation (numero,adresse) VALUES
(6308,'62 Le Cazalas, 02310 Pavant'),
(6309,'615bis Les Noisetiers, 25170 Sauvagney');

INSERT INTO Organisation (numero,adresse) VALUES
(6310,'76 Les Breteaux, 61160 Fontaine-les-Bassets'),
(6311,'842 Champ Latier, 25300 Chaffois');

INSERT INTO Organisation (numero,adresse) VALUES
(6312,'201 La Champaye, 12800 Saint-Just-sur-Viaur'),
(6313,'451bis Cimetière communal, 52800 Poulangy');

INSERT INTO Organisation (numero,adresse) VALUES
(6314,'125 Les Combes Ste Geneviève, 61160 Saint-Gervais-des-Sablons'),
(6315,'293 Salle polyvalente du Village, 71100 Saint-Rémy');

INSERT INTO Organisation (numero,adresse) VALUES
(6316,'301 Les Vautes, 24290 Aubas'),
(6317,'575bis L’Oustal Nau, 54370 Athienville');

INSERT INTO Organisation (numero,adresse) VALUES
(6318,'962 Grange de Biziat, 61800 Saint-Christophe-de-Chaulieu'),
(6319,'299 Parking du Pigeonniers, 21250 Bousselange');

INSERT INTO Organisation (numero,adresse) VALUES
(6320,'911bis Les Donhes Hautes, 21110 Chambeire'),
(6321,'192 Castanet, 35360 Landujan');

INSERT INTO Organisation (numero,adresse) VALUES
(6322,'734 Vévin, 10270 Montaulin'),
(6323,'104 Lou Puech, 40330 Arsague');

INSERT INTO Organisation (numero,adresse) VALUES
(6324,'244 Allée Laura Borla, 15190 Marcenat'),
(6325,'595bis Combe de Simon, 80300 Authuille');

INSERT INTO Organisation (numero,adresse) VALUES
(6326,'416 """ Livrot """, 08400 Quatre-Champs'),
(6327,'595 Rue du Bourg, 24130 Laveyssière');

INSERT INTO Organisation (numero,adresse) VALUES
(6328,'497 Le Burguet, 61560 Courgeoût'),
(6329,'646 La Casterie, 31160 Aspet');

INSERT INTO Organisation (numero,adresse) VALUES
(6330,'589 Villa Bonne Aventure, 02110 Saint-Martin-Rivière'),
(6331,'151bis Le Deauville, 62860 Sains-lès-Marquion');

INSERT INTO Organisation (numero,adresse) VALUES
(6332,'490 Port Nouveau Port, 23000 Saint-Fiel'),
(6333,'716bis Parking Peyra Strecchia, 59123 Bray-Dunes');

INSERT INTO Organisation (numero,adresse) VALUES
(6334,'9bis La Prairie de Tavaux, 33690 Masseilles'),
(6335,'217bis Champbourgeois, 76260 Melleville');

INSERT INTO Organisation (numero,adresse) VALUES
(6336,'686 Le Bourgnou, 59540 Caudry'),
(6337,'404 Rouquisse, 37500 La Roche-Clermault');

INSERT INTO Organisation (numero,adresse) VALUES
(6338,'1bis Les Hayes Vieville, 07140 Saint-Pierre-Saint-Jean'),
(6339,'623bis Malleret, 41800 Sougé');

INSERT INTO Organisation (numero,adresse) VALUES
(6340,'128 Lotissement Saint Pierre, 80500 Remaugies'),
(6341,'314bis Relais St Martin, 38460 Panossas');

INSERT INTO Organisation (numero,adresse) VALUES
(6342,'563 Les Chênes Blancs, 22730 Trégastel'),
(6343,'526bis la Molardière, 17330 Bernay-Saint-Martin');

INSERT INTO Organisation (numero,adresse) VALUES
(6344,'462bis Les Plantées, 02000 Urcel'),
(6345,'467 Le Ségayrenq, 09500 Vals');

INSERT INTO Organisation (numero,adresse) VALUES
(6346,'611 Château du Carla, 62570 Pihem'),
(6347,'586 France, 64560 Sainte-Engrâce');

INSERT INTO Organisation (numero,adresse) VALUES
(6348,'573bis Le Maurinot, 62173 Rivière'),
(6349,'244 Pimiehol, 33480 Moulis-en-Médoc');

INSERT INTO Organisation (numero,adresse) VALUES
(6350,'694 Moray Pres, 09350 Loubaut'),
(6351,'753 L''Etoile, 31810 Clermont-le-Fort');

INSERT INTO Organisation (numero,adresse) VALUES
(6352,'138 Le Clos de la Bonnette, 40110 Ousse-Suzan'),
(6353,'474bis La Ille et Bourdals, 14770 Danvou-la-Ferrière');

INSERT INTO Organisation (numero,adresse) VALUES
(6354,'10bis La Pitchina Maion, 46120 Lacapelle-Marival'),
(6355,'976 Notre Etoile, 23210 Marsac');

INSERT INTO Organisation (numero,adresse) VALUES
(6356,'730bis L''Orée de La Lombardière, 64200 Arcangues'),
(6357,'466 Le Camps de Serin, 07210 Rochessauve');

INSERT INTO Organisation (numero,adresse) VALUES
(6358,'43 La Croix Gibon, 26220 Vesc'),
(6359,'843 Jardin et Parc-autos Corvésy, 24320 Cercles');

INSERT INTO Organisation (numero,adresse) VALUES
(6360,'210 Trinquies, 65370 Siradan'),
(6361,'706bis Champ d''Anne, 69440 Saint-Didier-sous-Riverie');

INSERT INTO Organisation (numero,adresse) VALUES
(6362,'351 Reylier, 57830 Xouaxange'),
(6363,'904 La Maléne Hameau, 65700 Lascazères');

INSERT INTO Organisation (numero,adresse) VALUES
(6364,'527 Bessy, 25120 Mont-de-Vougney'),
(6365,'350 Montcalmet, 33610 Cestas');

INSERT INTO Organisation (numero,adresse) VALUES
(6366,'506 Pres de la Bouchere, 14100 Hermival-les-Vaux'),
(6367,'844 Avenue des Grenouillères, 02480 Cugny');

INSERT INTO Organisation (numero,adresse) VALUES
(6368,'37 Résidence Les Oustalous, 56350 Rieux'),
(6369,'618bis La Mûre, 68380 Muhlbach-sur-Munster');

INSERT INTO Organisation (numero,adresse) VALUES
(6370,'809 Les Pièces Longues, 37500 Marçay'),
(6371,'659 Savelet, 69970 Marennes');

INSERT INTO Organisation (numero,adresse) VALUES
(6372,'683bis La Charpene, 25660 Fontain'),
(6373,'901bis Les Bonnets, 62000 Dainville');

INSERT INTO Organisation (numero,adresse) VALUES
(6374,'770 Parvis Alain Le Blevennec, 64190 Viellenave-de-Navarrenx'),
(6375,'211 Ferme de la Grange des Prés, 21500 Athie');

INSERT INTO Organisation (numero,adresse) VALUES
(6376,'700 Champenas, 45700 Saint-Hilaire-sur-Puiseaux'),
(6377,'540bis Boîte courrier Postal, 16460 Saint-Sulpice-de-Ruffec');

INSERT INTO Organisation (numero,adresse) VALUES
(6378,'817 Lai Barrai, 76890 Saint-Victor-l''Abbaye'),
(6379,'865 Place Leon Carrie, 15600 Saint-Étienne-de-Maurs');

INSERT INTO Organisation (numero,adresse) VALUES
(6380,'406 Les Cyrillis, 66230 Serralongue'),
(6381,'770 Route Métropolitaine 473, 69510 Soucieu-en-Jarrest');

INSERT INTO Organisation (numero,adresse) VALUES
(6382,'548 Breils Mieges, 30127 Bellegarde'),
(6383,'41 Les Rousseaux, 70160 Faverney');

INSERT INTO Organisation (numero,adresse) VALUES
(6384,'70 Ferme de Taffournay, 70230 Cenans'),
(6385,'205 Les Bartassades, 26200 Montélimar');

INSERT INTO Organisation (numero,adresse) VALUES
(6386,'367 Crêt Merland - Hauteville-Lompnes, 21500 Nogent-lès-Montbard'),
(6387,'857 Les Fortuneries, 73160 Saint-Cassin');

INSERT INTO Organisation (numero,adresse) VALUES
(6388,'465bis Cante Coucut, 62140 Tortefontaine'),
(6389,'547 lieu-dit Le Maneït, 72130 Saint-Léonard-des-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(6390,'807bis Ban de la Morteau, 64300 Maslacq'),
(6391,'373 Place Pierre Sauvaigo, 27210 Beuzeville');

INSERT INTO Organisation (numero,adresse) VALUES
(6392,'276 Gayrosse, 02450 Bergues-sur-Sambre'),
(6393,'527 Chateau du Plessis, 08300 Barby');

INSERT INTO Organisation (numero,adresse) VALUES
(6394,'170 Bissieux, 23240 Le Grand-Bourg'),
(6395,'75 Jardin Axel Kahn, 58210 Villiers-le-Sec');

INSERT INTO Organisation (numero,adresse) VALUES
(6396,'884 Voie du lotissement Vigna, 71350 Bragny-sur-Saône'),
(6397,'928bis Le Treillal, 36170 Sacierges-Saint-Martin');

INSERT INTO Organisation (numero,adresse) VALUES
(6398,'540bis lieu-dit Corneille, 02860 Chermizy-Ailles'),
(6399,'816 Boucherie, 31160 Cazaunous');

INSERT INTO Organisation (numero,adresse) VALUES
(6400,'238 L''Arnouze, 22800 Lanfains'),
(6401,'754 Font Giraud, 64260 Bilhères');

INSERT INTO Organisation (numero,adresse) VALUES
(6402,'498 Route de Bazoches, 69430 Avenas'),
(6403,'601 Le Pût, 41330 Fossé');

INSERT INTO Organisation (numero,adresse) VALUES
(6404,'710 Lissard, 74570 Groisy'),
(6405,'18 Goulelonne, 36130 Coings');

INSERT INTO Organisation (numero,adresse) VALUES
(6406,'298 Allee de la Saladine, 70290 Champagney'),
(6407,'458bis Hameau d''Aurent, 20140 Petreto-Bicchisano');

INSERT INTO Organisation (numero,adresse) VALUES
(6408,'899 Route de Wassigny, 59151 Hamel'),
(6409,'845 Les Granges Sud, 11120 Mirepeisset');

INSERT INTO Organisation (numero,adresse) VALUES
(6410,'649 La Grotte, 64340 Boucau'),
(6411,'224 Les Grads de Naves, 60620 Bouillancy');

INSERT INTO Organisation (numero,adresse) VALUES
(6412,'16 Hameau de Chatel, 40090 Laglorieuse'),
(6413,'329bis La Goutte d''Or et Clos Fle, 24500 Serres-et-Montguyard');

INSERT INTO Organisation (numero,adresse) VALUES
(6414,'122 Les Grandes Epargnes, 02200 Pommiers'),
(6415,'490bis Prés Trouillards, 39570 Pannessières');

INSERT INTO Organisation (numero,adresse) VALUES
(6416,'227 Rauly, 35390 Grand-Fougeray'),
(6417,'865bis Rozier, 11250 Montclar');

INSERT INTO Organisation (numero,adresse) VALUES
(6418,'172bis Route de Loda, 61300 Crulai'),
(6419,'74bis route de Cosne-d''Allier, 19410 Perpezac-le-Noir');

INSERT INTO Organisation (numero,adresse) VALUES
(6420,'666bis Voie Privée, 06000 Nice'),
(6421,'12 Lompnieu, 62121 Hamelincourt');

INSERT INTO Organisation (numero,adresse) VALUES
(6422,'76bis Castelles, 09140 Couflens'),
(6423,'744 Lieu dit Souet, 15100 Coren');

INSERT INTO Organisation (numero,adresse) VALUES
(6424,'680 Jean-Jacques, 33710 Lansac'),
(6425,'54 Sentier des Grenadiers, 26170 Beauvoisin');

INSERT INTO Organisation (numero,adresse) VALUES
(6426,'414bis Christian, 23320 Fleurat'),
(6427,'687bis Résidence les Goelands, 14130 Les Authieux-sur-Calonne');

INSERT INTO Organisation (numero,adresse) VALUES
(6428,'11 Castanies, 09240 Montels'),
(6429,'628 Bouldou, 03500 Louchy-Montfand');

INSERT INTO Organisation (numero,adresse) VALUES
(6430,'15bis Le Bois de Fervacques, 53100 Contest'),
(6431,'229 Domaine de Petit Rivage, 57930 Bettborn');

INSERT INTO Organisation (numero,adresse) VALUES
(6432,'39 Fourès, 43430 Fay-sur-Lignon'),
(6433,'291 Ferme de la Haute Cour, 48100 Bourgs sur Colagne');

INSERT INTO Organisation (numero,adresse) VALUES
(6434,'973bis Monument aux morts, 67117 Furdenheim'),
(6435,'775 Pelat, 14400 Saint-Vigor-le-Grand');

INSERT INTO Organisation (numero,adresse) VALUES
(6436,'963 Rue  Bir Hakeim, 72800 Saint-Germain-d''Arcé'),
(6437,'608 Le Fort, 62470 Camblain-Châtelain');

INSERT INTO Organisation (numero,adresse) VALUES
(6438,'52 Cailla, 01600 Saint-Bernard'),
(6439,'593 Les Terrasses Fleuries, 70200 Lantenot');

INSERT INTO Organisation (numero,adresse) VALUES
(6440,'811 la Borie, 45600 Sully-sur-Loire'),
(6441,'328 Escalier E3, 16350 Vieux-Ruffec');

INSERT INTO Organisation (numero,adresse) VALUES
(6442,'473 La Lèbre, 67190 Grendelbruch'),
(6443,'689 Les Communaux, 24160 Saint-Martial-d''Albarède');

INSERT INTO Organisation (numero,adresse) VALUES
(6444,'923bis Vers, 61200 Sai'),
(6445,'329 Le Misserou, 72800 Aubigné-Racan');

INSERT INTO Organisation (numero,adresse) VALUES
(6446,'322bis Le Haut de la Mouline, 54360 Méhoncourt'),
(6447,'123 Fevrier Nord, 77390 Crisenoy');

INSERT INTO Organisation (numero,adresse) VALUES
(6448,'826 Les Joyats, 14230 Isigny-sur-Mer'),
(6449,'630 Chemin de Balaives, 70400 Coisevaux');

INSERT INTO Organisation (numero,adresse) VALUES
(6450,'331bis La Baraque d’Isidore, 49140 Montreuil-sur-Loir'),
(6451,'421 Mammajou, 73590 Saint-Nicolas-la-Chapelle');

INSERT INTO Organisation (numero,adresse) VALUES
(6452,'83 Le Puech de Ceor, 60380 Villers-Vermont'),
(6453,'38 Les Plantiers-Nord, 71300 Mary');

INSERT INTO Organisation (numero,adresse) VALUES
(6454,'754 Vigne de le Croze, 59231 Villers-Plouich'),
(6455,'516bis Le Puech Broual, 50460 Urville-Nacqueville');

INSERT INTO Organisation (numero,adresse) VALUES
(6456,'404bis Valléra Da Geija, 77130 Montereau-Fault-Yonne'),
(6457,'229bis Chemin Daniel, 62810 Warluzel');

INSERT INTO Organisation (numero,adresse) VALUES
(6458,'451 Trableine, 19120 Astaillac'),
(6459,'836 Le Trimaran, 76750 Bosc-Édeline');

INSERT INTO Organisation (numero,adresse) VALUES
(6460,'426 Les Coustats, 73370 Bourdeau'),
(6461,'624bis Pre du Tour, 44310 Saint-Lumine-de-Coutais');

INSERT INTO Organisation (numero,adresse) VALUES
(6462,'531bis Allée des Marroniers (Parc De L''Amadour), 32220 Montadet'),
(6463,'875 Riau Berton, 62490 Noyelles-sous-Bellonne');

INSERT INTO Organisation (numero,adresse) VALUES
(6464,'658 La Garne, 38260 Bossieu'),
(6465,'868 Villa Terwa, 32170 Aux-Aussat');

INSERT INTO Organisation (numero,adresse) VALUES
(6466,'832 étang C, 70120 Mont-Saint-Léger'),
(6467,'742 Esplanade Georges Pompidou, 52120 Châteauvillain');

INSERT INTO Organisation (numero,adresse) VALUES
(6468,'425 Charmille, 23400 Faux-Mazuras'),
(6469,'615 Le Grand Cammas, 02200 Nampteuil-sous-Muret');

INSERT INTO Organisation (numero,adresse) VALUES
(6470,'630 La Montagne des Chevres, 60300 Courteuil'),
(6471,'409bis Route de Montclar, 80120 Nampont');

INSERT INTO Organisation (numero,adresse) VALUES
(6472,'188 Vallée de St Martin, 03360 Valigny'),
(6473,'932 Parking de la Colle, 54260 Fresnois-la-Montagne');

INSERT INTO Organisation (numero,adresse) VALUES
(6474,'890 Logues Bas, 49500 Louvaines'),
(6475,'586 Canabiere, 46120 Thémines');

INSERT INTO Organisation (numero,adresse) VALUES
(6476,'343bis Ravourier - La Combe, 54115 Vandeléville'),
(6477,'250 Le Cabrol, 02360 Iviers');

INSERT INTO Organisation (numero,adresse) VALUES
(6478,'746 Tizac, 58170 Avrée'),
(6479,'38 Le Chauchay, 08250 Fléville');

INSERT INTO Organisation (numero,adresse) VALUES
(6480,'153 WC Publics, 04290 Sourribes'),
(6481,'908bis Escalier Avenue Val Marie - Avenue Val Marie, 67640 Fegersheim');

INSERT INTO Organisation (numero,adresse) VALUES
(6482,'675 Les Bruyères des Corats, 18370 Préveranges'),
(6483,'457 Les Combes de Banne, 64400 Estos');

INSERT INTO Organisation (numero,adresse) VALUES
(6484,'237 Bravay, 62490 Fresnes-lès-Montauban'),
(6485,'569 La Pinede, 50560 Blainville-sur-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(6486,'440bis Hameau de Buges, 14100 Saint-Martin-de-Mailloc'),
(6487,'17 Théron, 27580 Bourth');

INSERT INTO Organisation (numero,adresse) VALUES
(6488,'969 La Feige, 58250 Montaron'),
(6489,'229 Le Cristal, 62560 Thiembronne');

INSERT INTO Organisation (numero,adresse) VALUES
(6490,'416 Layos, 52120 Dinteville'),
(6491,'314bis Place du Jeu de l''Arc, 70150 Bay');

INSERT INTO Organisation (numero,adresse) VALUES
(6492,'882bis Segonds, 31280 Mons'),
(6493,'862 Le Clos Miette, 10200 Ailleville');

INSERT INTO Organisation (numero,adresse) VALUES
(6494,'224 Rue del Peyrié, 69380 Saint-Jean-des-Vignes'),
(6495,'546 Pachy Marquon, 31580 Sédeilhac');

INSERT INTO Organisation (numero,adresse) VALUES
(6496,'846 L''Islet Bas, 08220 Seraincourt'),
(6497,'199 Le Gravillia, 47350 Lachapelle');

INSERT INTO Organisation (numero,adresse) VALUES
(6498,'444 Le Florea B, 41300 Souesmes'),
(6499,'62bis Pont d''Iron, 52500 Arbigny-sous-Varennes');

INSERT INTO Organisation (numero,adresse) VALUES
(6500,'616 Sente des Paons, 80300 Senlis-le-Sec'),
(6501,'982 Le Besson, 38890 Vasselin');

INSERT INTO Organisation (numero,adresse) VALUES
(6502,'633bis Le Causse de la Baldare, 44660 Fercé'),
(6503,'466 Espace Louis Camous, 27180 Arnières-sur-Iton');

INSERT INTO Organisation (numero,adresse) VALUES
(6504,'245bis Camps d’Arbas, 23260 Beissat'),
(6505,'65 Rue  Saint-Thomas de Villeneuve, 60650 Blacourt');

INSERT INTO Organisation (numero,adresse) VALUES
(6506,'805 Tabelles, 43190 Tence'),
(6507,'477 Champ de Joux, 26250 Livron-sur-Drôme');

INSERT INTO Organisation (numero,adresse) VALUES
(6508,'564bis La Fumade, 14170 Boissey'),
(6509,'732 Chenevière, 72150 Villaines-sous-Lucé');

INSERT INTO Organisation (numero,adresse) VALUES
(6510,'532bis Le Laus, 59670 Noordpeene'),
(6511,'257 Terre du Chien, 53200 Azé');

INSERT INTO Organisation (numero,adresse) VALUES
(6512,'657 Le Bardas, 15150 Nieudan'),
(6513,'644bis Allée Lucie et Raymond Aubrac, 24750 Cornille');

INSERT INTO Organisation (numero,adresse) VALUES
(6514,'339 Ranc la Baume, 17400 Mazeray'),
(6515,'742 Le Bois-Piou, 54290 Brémoncourt');

INSERT INTO Organisation (numero,adresse) VALUES
(6516,'344bis Impasse des Carrières Coutures, 18300 Sancerre'),
(6517,'550 Camp Del Sol, 08260 Girondelle');

INSERT INTO Organisation (numero,adresse) VALUES
(6518,'504bis La Vallee du Charmier, 74500 Chevenoz'),
(6519,'39 La Roseraie, 16230 Saint-Amant-de-Bonnieure');

INSERT INTO Organisation (numero,adresse) VALUES
(6520,'360 Mas Des Romarins 1 Villa 2, 54480 Petitmont'),
(6521,'231bis Les Combes des Monts, 48100 Lachamp');

INSERT INTO Organisation (numero,adresse) VALUES
(6522,'679bis La Finiera, 78910 Osmoy'),
(6523,'681bis La Brigio, 57560 Saint-Quirin');

INSERT INTO Organisation (numero,adresse) VALUES
(6524,'596 Allée de la Fraternité, 38730 Panissage'),
(6525,'516bis Place Jean Flory, 07660 Lanarce');

INSERT INTO Organisation (numero,adresse) VALUES
(6526,'694 Coteau du Pigeonnier, 49320 Luigné'),
(6527,'338 La Trivalle Haute, 24460 Négrondes');

INSERT INTO Organisation (numero,adresse) VALUES
(6528,'122 Résidence Les Deux Moulins, 35210 Châtillon-en-Vendelais'),
(6529,'459 Carcassonne, 27400 Le Mesnil-Jourdain');

INSERT INTO Organisation (numero,adresse) VALUES
(6530,'945 Pres du Moulin, 20242 Noceta'),
(6531,'527 Champ Roland, 76660 Smermesnil');

INSERT INTO Organisation (numero,adresse) VALUES
(6532,'519 Regnier, 12220 Galgan'),
(6533,'119 Le Bois de la Cerusiere, 30190 Collorgues');

INSERT INTO Organisation (numero,adresse) VALUES
(6534,'733 Le Décousu, 74160 Beaumont'),
(6535,'325bis Chemin de la Graviere, 54119 Domgermain');

INSERT INTO Organisation (numero,adresse) VALUES
(6536,'504 Quartier CHAMPREDON, 17360 La Clotte'),
(6537,'671 Clos Mague, 62190 Ham-en-Artois');

INSERT INTO Organisation (numero,adresse) VALUES
(6538,'48 Maraujean, 17290 Landrais'),
(6539,'152bis Charrière torse, 28340 Morvilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(6540,'802 Hameau Les Pervenchères, 27290 Pont-Authou'),
(6541,'719 L''Auribault, 63720 Entraigues');

INSERT INTO Organisation (numero,adresse) VALUES
(6542,'46 Escalier du n°40 Boulevard du Mont Boron à la voie au n°46 Boulevard du Mont Boron, 20229 Polveroso'),
(6543,'110 La Motte, 27530 Ézy-sur-Eure');

INSERT INTO Organisation (numero,adresse) VALUES
(6544,'626bis Fédac, 40990 Herm'),
(6545,'780bis Soulergues, 38410 Vaulnaveys-le-Haut');

INSERT INTO Organisation (numero,adresse) VALUES
(6546,'693 Allée des Paquerettes, 02470 Macogny'),
(6547,'835 Lac Long Supérieur, 15000 Ytrac');

INSERT INTO Organisation (numero,adresse) VALUES
(6548,'156 La Piece de la Dreve, 02840 Parfondru'),
(6549,'387 Le Clos de la Cense, 57440 Algrange');

INSERT INTO Organisation (numero,adresse) VALUES
(6550,'81bis Le Cas, 50320 Folligny'),
(6551,'373bis Le Champ d''Astier, 71250 Salornay-sur-Guye');

INSERT INTO Organisation (numero,adresse) VALUES
(6552,'559bis la Catière, 64270 Bergouey-Viellenave'),
(6553,'177bis Lotissement le Cabagnol, 32480 La Romieu');

INSERT INTO Organisation (numero,adresse) VALUES
(6554,'839 Rue Ampère, 67230 Huttenheim'),
(6555,'497bis La Palomba, 12240 Le Bas Ségala');

INSERT INTO Organisation (numero,adresse) VALUES
(6556,'854 La Roucanelle, 20212 Bustanico'),
(6557,'764 La Baraque du Puech, 59138 Bachant');

INSERT INTO Organisation (numero,adresse) VALUES
(6558,'77bis Chemin de la Mairie, 80500 Rubescourt'),
(6559,'275 Le Rouillon Adele, 21290 Chaugey');

INSERT INTO Organisation (numero,adresse) VALUES
(6560,'704 Montée du Grand Palais, 40700 Peyre'),
(6561,'591bis Bouchonniere, 77640 Signy-Signets');

INSERT INTO Organisation (numero,adresse) VALUES
(6562,'935bis Chez Say, 49520 Bouillé-Ménard'),
(6563,'697 Le Bachas, 31360 Sepx');

INSERT INTO Organisation (numero,adresse) VALUES
(6564,'888bis La Fontaine Sainte Croix, 57590 Oriocourt'),
(6565,'201 Route de Pont-Lung, 77320 Sancy-lès-Provins');

INSERT INTO Organisation (numero,adresse) VALUES
(6566,'763 Les Terrasses, 37220 Crissay-sur-Manse'),
(6567,'312bis Le Vieux Charnay, 57800 Béning-lès-Saint-Avold');

INSERT INTO Organisation (numero,adresse) VALUES
(6568,'716bis Le Mirador, 67600 Bindernheim'),
(6569,'926 Sainte Colombe, 78940 La Queue-les-Yvelines');

INSERT INTO Organisation (numero,adresse) VALUES
(6570,'525 Salle communale, 10240 Coclois'),
(6571,'172 La Brugere, 33540 Saint-Laurent-du-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(6572,'809bis Square Roger Boyer, 14800 Vauville'),
(6573,'923bis Lotissement le Grand Pré, 77410 Saint-Mesmes');

INSERT INTO Organisation (numero,adresse) VALUES
(6574,'890 Le Mont de Féquir, 60280 Bienville'),
(6575,'155bis Aux Cinq Chenes, 78440 Lainville-en-Vexin');

INSERT INTO Organisation (numero,adresse) VALUES
(6576,'276bis Les Fougeriaux, 03440 Chavenon'),
(6577,'493 Pendant, 54420 Saulxures-lès-Nancy');

INSERT INTO Organisation (numero,adresse) VALUES
(6578,'872 Le Florea E, 22560 Pleumeur-Bodou'),
(6579,'298 Lados, 15320 Ruynes-en-Margeride');

INSERT INTO Organisation (numero,adresse) VALUES
(6580,'194 Chemin des Chênes, 26150 Vachères-en-Quint'),
(6581,'25 le Mollard, 52500 Gilley');

INSERT INTO Organisation (numero,adresse) VALUES
(6582,'539 Serre Chaud, 51320 Soudron'),
(6583,'117 Mas Amado, 21290 Lucey');

INSERT INTO Organisation (numero,adresse) VALUES
(6584,'87 Voie Communale Plateau de la Malle, 18290 Chârost'),
(6585,'477 Le Terron, 47290 Boudy-de-Beauregard');

INSERT INTO Organisation (numero,adresse) VALUES
(6586,'32 L''Aire, 59132 Ohain'),
(6587,'554 Le Mas du Puech, 80370 Épécamps');

INSERT INTO Organisation (numero,adresse) VALUES
(6588,'874bis Hameau-du-Roure, 55230 Amel-sur-l''Étang'),
(6589,'316bis Le Sapho A, 21320 Civry-en-Montagne');

INSERT INTO Organisation (numero,adresse) VALUES
(6590,'741 Route Métropolitaine 72, 59152 Chéreng'),
(6591,'685 Prat Neuf, 01370 Courmangoux');

INSERT INTO Organisation (numero,adresse) VALUES
(6592,'110 Lieu dit Moureou, 25640 Chaudefontaine'),
(6593,'5bis Le Domaine, 61230 Croisilles');

INSERT INTO Organisation (numero,adresse) VALUES
(6594,'318 Les Myosotis A, 02870 Crépy'),
(6595,'901bis Les Fossés, 55210 Heudicourt-sous-les-Côtes');

INSERT INTO Organisation (numero,adresse) VALUES
(6596,'706bis Balsac Village, 56160 Langoëlan'),
(6597,'708 Les Terrasses Du Chateau B, 47200 Marcellus');

INSERT INTO Organisation (numero,adresse) VALUES
(6598,'89 Granges de Léo, 51330 Épense'),
(6599,'452bis La Penterie, 22800 Saint-Brandan');

INSERT INTO Organisation (numero,adresse) VALUES
(6600,'865 Le Coulet, 21640 Vougeot'),
(6601,'774 Le Rial Haut, 55000 Montplonne');

INSERT INTO Organisation (numero,adresse) VALUES
(6602,'602 Les Aiguillons, 63920 Peschadoires'),
(6603,'866bis Avenue Nicolas II prolongée, 24140 Clermont-de-Beauregard');

INSERT INTO Organisation (numero,adresse) VALUES
(6604,'337 Campo Don Passeroni, 57970 Inglange'),
(6605,'752 La Cabredie, 57580 Han-sur-Nied');

INSERT INTO Organisation (numero,adresse) VALUES
(6606,'966 Le Bottin Cour Exterieure, 61210 Sainte-Honorine-la-Guillaume'),
(6607,'186bis Le Dsu du Chem de Longuevi, 27480 Fleury-la-Forêt');

INSERT INTO Organisation (numero,adresse) VALUES
(6608,'359 Arculet, 69003 Lyon 03'),
(6609,'727 Le Clauzet, 08000 Prix-lès-Mézières');

INSERT INTO Organisation (numero,adresse) VALUES
(6610,'475 Le Triou, 31210 Martres-de-Rivière'),
(6611,'922 La Richonnière, 34150 Gignac');

INSERT INTO Organisation (numero,adresse) VALUES
(6612,'672 Marais Chasselin, 80440 Boves'),
(6613,'176bis Pont Clavel, 15260 Neuvéglise-sur-Truyère');

INSERT INTO Organisation (numero,adresse) VALUES
(6614,'477bis Eychartet, 42800 Sainte-Croix-en-Jarez'),
(6615,'62 Previnquieres, 78790 Rosay');

INSERT INTO Organisation (numero,adresse) VALUES
(6616,'161 Preslier, 68580 Hindlingen'),
(6617,'609 Domaine Des Sables, 25370 Les Hôpitaux-Vieux');

INSERT INTO Organisation (numero,adresse) VALUES
(6618,'626 La-longue-haie, 08130 Saulces-Champenoises'),
(6619,'948 Coeur D''Azur Bat A, 03370 Saint-Sauvier');

INSERT INTO Organisation (numero,adresse) VALUES
(6620,'406 Hameau des Lavandes, 62770 Incourt'),
(6621,'582 Fontaine des Parmagnes, 76850 Bosc-le-Hard');

INSERT INTO Organisation (numero,adresse) VALUES
(6622,'54 Le Laussier, 15350 Veyrières'),
(6623,'361 Chemin de Tiecs, 31770 Colomiers');

INSERT INTO Organisation (numero,adresse) VALUES
(6624,'326 Sinhalaguet, 69310 Pierre-Bénite'),
(6625,'643 Ladeyrolles, 74160 Feigères');

INSERT INTO Organisation (numero,adresse) VALUES
(6626,'694 La Jouanade, 15200 Mauriac'),
(6627,'929 Champ de Saint Mayme, 47330 Douzains');

INSERT INTO Organisation (numero,adresse) VALUES
(6628,'724 Charrier, 08220 Chaumont-Porcien'),
(6629,'279 Chemin du Raouaste, 32130 Bézéril');

INSERT INTO Organisation (numero,adresse) VALUES
(6630,'616 Route de Séverac, 71710 Les Bizots'),
(6631,'74 Domaine Sainte Colombe, 10230 Mailly-le-Camp');

INSERT INTO Organisation (numero,adresse) VALUES
(6632,'703bis Majoulet, 33670 Blésignac'),
(6633,'158 Les Nayses, 02250 Erlon');

INSERT INTO Organisation (numero,adresse) VALUES
(6634,'880 Carmaillas, 62120 Racquinghem'),
(6635,'24 La_roussille, 58250 Thaix');

INSERT INTO Organisation (numero,adresse) VALUES
(6636,'370 Chemin du Cimetiere, 73110 Villard-Sallet'),
(6637,'382 Mas de Mouli, 19340 Couffy-sur-Sarsonne');

INSERT INTO Organisation (numero,adresse) VALUES
(6638,'876 Les Roques, 63630 Saint-Bonnet-le-Chastel'),
(6639,'529 Halle de Loisirs, 14210 Goupillières');

INSERT INTO Organisation (numero,adresse) VALUES
(6640,'395 L''Adroit de la Tour, 75013 Paris 13'),
(6641,'890bis La Vexiere, 05140 Saint-Pierre-d''Argençon');

INSERT INTO Organisation (numero,adresse) VALUES
(6642,'640bis Saint-Avons, 70500 Corre'),
(6643,'802 Rond-Point  Paul Fouque, 56230 Le Cours');

INSERT INTO Organisation (numero,adresse) VALUES
(6644,'111 Les Crots, 14440 Cresserons'),
(6645,'481bis Nathalie, 51510 Saint-Gibrien');

INSERT INTO Organisation (numero,adresse) VALUES
(6646,'801 Soutouls, 67110 Gundershoffen'),
(6647,'0 Peyboué, 70310 Amont-et-Effreney');

INSERT INTO Organisation (numero,adresse) VALUES
(6648,'67 La Loge Tristan, 62890 Bonningues-lès-Ardres'),
(6649,'982 Rue Nicot de Villemain, 70800 Saint-Loup-sur-Semouse');

INSERT INTO Organisation (numero,adresse) VALUES
(6650,'989 Cirols, 41400 Chissay-en-Touraine'),
(6651,'703bis Bouzastre, 03110 Charmeil');

INSERT INTO Organisation (numero,adresse) VALUES
(6652,'204 Clos des Trois Noyers, 52150 Outremécourt'),
(6653,'272bis Centry, 10500 Épagne');

INSERT INTO Organisation (numero,adresse) VALUES
(6654,'152 Courviac Bas, 74140 Saint-Cergues'),
(6655,'629bis Les Ourliacs, 09320 Aleu');

INSERT INTO Organisation (numero,adresse) VALUES
(6656,'102 Rouge Terre, 17810 Écurat'),
(6657,'451 Derrière la Poste, 62550 Nédonchel');

INSERT INTO Organisation (numero,adresse) VALUES
(6658,'432 Reserve de Ponchaux, 38260 Pommier-de-Beaurepaire'),
(6659,'342 Bonneface, 67270 Durningen');

INSERT INTO Organisation (numero,adresse) VALUES
(6660,'696 Le Poulinet, 78125 Mittainville'),
(6661,'860bis La Baraque d’Isidore, 60400 Caisnes');

INSERT INTO Organisation (numero,adresse) VALUES
(6662,'945bis Le Jardin d''Isabelle, 70100 Autrey-lès-Gray'),
(6663,'736bis Le Miramar C, 01150 Chazey-sur-Ain');

INSERT INTO Organisation (numero,adresse) VALUES
(6664,'214bis Le Saint Jacques, 29217 Le Conquet'),
(6665,'488bis Bretelle Sortie Mathis (Chaussée sud) - Gloria, 33124 Brannens');

INSERT INTO Organisation (numero,adresse) VALUES
(6666,'496 Au-dessus des Hauts Bois, 42440 Saint-Priest-la-Vêtre'),
(6667,'208 Aunas, 37390 Charentilly');

INSERT INTO Organisation (numero,adresse) VALUES
(6668,'428 Tunnel Saint-Etienne, 68570 Osenbach'),
(6669,'757bis Hameau de Heyre, 65400 Ouzous');

INSERT INTO Organisation (numero,adresse) VALUES
(6670,'986 Salle Polyvalente de Blomac, 32110 Sorbets'),
(6671,'746 Saint-Georges, 19150 Lagarde-Enval');

INSERT INTO Organisation (numero,adresse) VALUES
(6672,'600 Puech-Tournie, 25113 Sainte-Marie'),
(6673,'694 Telot, 67330 Bosselshausen');

INSERT INTO Organisation (numero,adresse) VALUES
(6674,'734 Residence les Anemones, 27300 Boissy-Lamberville'),
(6675,'964 Les carquois, 57530 Ogy');

INSERT INTO Organisation (numero,adresse) VALUES
(6676,'495 Sauvage, 62980 Noyelles-lès-Vermelles'),
(6677,'882bis Le Riou, 16370 Saint-Sulpice-de-Cognac');

INSERT INTO Organisation (numero,adresse) VALUES
(6678,'342bis Val de Cuberte, 07460 Banne'),
(6679,'259 Les Amouroux, 59490 Somain');

INSERT INTO Organisation (numero,adresse) VALUES
(6680,'254 la Clape, 79360 Plaine-d''Argenson'),
(6681,'773 Le Defends, 51300 Changy');

INSERT INTO Organisation (numero,adresse) VALUES
(6682,'257bis Hameau-de-margy, 39110 Clucy'),
(6683,'147 Tarrisse, 61380 Saint-Martin-des-Pézerits');

INSERT INTO Organisation (numero,adresse) VALUES
(6684,'250bis Les Molieres, 14850 Hérouvillette'),
(6685,'28 Preynel, 80150 Machiel');

INSERT INTO Organisation (numero,adresse) VALUES
(6686,'635 Vallée du Pran, 39700 La Barre'),
(6687,'50bis Les Vergers Villa 4, 76400 Saint-Léonard');

INSERT INTO Organisation (numero,adresse) VALUES
(6688,'424 Metches Basses, 27290 Thierville'),
(6689,'604 Champ du Max, 47340 La Croix-Blanche');

INSERT INTO Organisation (numero,adresse) VALUES
(6690,'898 Quartier Bardinat, 34700 Poujols'),
(6691,'700 Hameau Renoir, 24430 Razac-sur-l''Isle');

INSERT INTO Organisation (numero,adresse) VALUES
(6692,'605 Le Glacis du Moulin, 28160 Moulhard'),
(6693,'394 Les Rouges Terres, 68580 Mooslargue');

INSERT INTO Organisation (numero,adresse) VALUES
(6694,'442 Le Trap, 02110 Prémont'),
(6695,'231bis La Vinasse, 59670 Oudezeele');

INSERT INTO Organisation (numero,adresse) VALUES
(6696,'149 Lagardie, 07230 Lablachère'),
(6697,'475 Sentier de la Montagne, 01350 Béon');

INSERT INTO Organisation (numero,adresse) VALUES
(6698,'48 Mount Connus, 49610 Les Garennes sur Loire'),
(6699,'744 Thaons, 25440 Courcelles');

INSERT INTO Organisation (numero,adresse) VALUES
(6700,'727 Escalier Avenue de la Réserve - Avenue Saint-Aignan, 45260 Vieilles-Maisons-sur-Joudry'),
(6701,'821 Avenue Louis Thaon, 62910 Serques');

INSERT INTO Organisation (numero,adresse) VALUES
(6702,'434 Le Vieux Pressoir, 02370 Celles-sur-Aisne'),
(6703,'860 Le Terme des Chiens, 24160 Clermont-d''Excideuil');

INSERT INTO Organisation (numero,adresse) VALUES
(6704,'494 lieu-dit Germa, 76110 Angerville-Bailleul'),
(6705,'547 Rue Bombe Cul, 57830 Héming');

INSERT INTO Organisation (numero,adresse) VALUES
(6706,'124 Les Bardous, 17700 Puyravault'),
(6707,'735 Roques le Vieux, 21210 Villargoix');

INSERT INTO Organisation (numero,adresse) VALUES
(6708,'809 Le Colibri, 71160 Gilly-sur-Loire'),
(6709,'92 St Jacques de l''Arnouze, 15380 Anglards-de-Salers');

INSERT INTO Organisation (numero,adresse) VALUES
(6710,'772 Lieu dit Charteix, 62170 Écuires'),
(6711,'398bis Voie liaison Rue Paul Bounin - Petite Avenue du Patrimoine, 21350 Massingy-lès-Vitteaux');

INSERT INTO Organisation (numero,adresse) VALUES
(6712,'11 Le Plo Bas, 40430 Argelouse'),
(6713,'924 Coumo d''Encoux et Autres, 57790 Fraquelfing');

INSERT INTO Organisation (numero,adresse) VALUES
(6714,'30 Chaudon, 41700 Contres'),
(6715,'840 Cagnac, 74540 Viuz-la-Chiésaz');

INSERT INTO Organisation (numero,adresse) VALUES
(6716,'66 Le_deves, 38370 Saint-Prim'),
(6717,'560bis Chemin rural dit Tertre, 67460 Souffelweyersheim');

INSERT INTO Organisation (numero,adresse) VALUES
(6718,'871 La Chiandre, 30210 Castillon-du-Gard'),
(6719,'648 Les Guillards, 56580 Bréhan');

INSERT INTO Organisation (numero,adresse) VALUES
(6720,'811 Parvis Simone Weil, 21700 Bagnot'),
(6721,'277 Passerelle Ernest Hildesheimer, 45300 Bouzonville-aux-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(6722,'229 Les Fayolles, 50690 Virandeville'),
(6723,'331 Lieu-dit Castouleres, 54470 Fey-en-Haye');

INSERT INTO Organisation (numero,adresse) VALUES
(6724,'970 Manhac, 17380 Puyrolland'),
(6725,'57 Negrou, 02210 Parcy-et-Tigny');

INSERT INTO Organisation (numero,adresse) VALUES
(6726,'244 Lous Triniols, 69870 Chambost-Allières'),
(6727,'888bis Brusque Vieille, 80310 Riencourt');

INSERT INTO Organisation (numero,adresse) VALUES
(6728,'30 Le Mas de Lacal, 52220 Planrupt'),
(6729,'527 La Rotonde, 14100 Saint-Désir');

INSERT INTO Organisation (numero,adresse) VALUES
(6730,'442bis Linder, 38190 Villard-Bonnot'),
(6731,'658 Saint Sauveur, 80370 Agenville');

INSERT INTO Organisation (numero,adresse) VALUES
(6732,'787 Les Hameaux d''Oraison, 76660 Osmoy-Saint-Valery'),
(6733,'750 Pre de Maison, 29250 Plougoulm');

INSERT INTO Organisation (numero,adresse) VALUES
(6734,'819 Rue Edouard Herriot, 23160 Bazelat'),
(6735,'734 Chemin de Sainte Catherine, 09230 Barjac');

INSERT INTO Organisation (numero,adresse) VALUES
(6736,'293 Plan de Braut, 71300 Mont-Saint-Vincent'),
(6737,'161 Bout des Blancs et Lachens, 69440 Chabanière');

INSERT INTO Organisation (numero,adresse) VALUES
(6738,'180 Found des Prats, 02150 Lappion'),
(6739,'906 À Moreau, 08240 Landres-et-Saint-Georges');

INSERT INTO Organisation (numero,adresse) VALUES
(6740,'571 Champ Fond Net, 41210 Marcilly-en-Gault'),
(6741,'751 Les Sauterons, 67210 Meistratzheim');

INSERT INTO Organisation (numero,adresse) VALUES
(6742,'155 Devant Vière et Pre la Cour, 33370 Loupes'),
(6743,'211 Les Planquettes, 20229 Stazzona');

INSERT INTO Organisation (numero,adresse) VALUES
(6744,'552 Route de Landreville, 26560 Mévouillon'),
(6745,'612bis Chaucholes, 35134 Coësmes');

INSERT INTO Organisation (numero,adresse) VALUES
(6746,'444 Jardin Jacques Ibert, 10500 Hampigny'),
(6747,'574 Impasse des Genêts, 30140 Mialet');

INSERT INTO Organisation (numero,adresse) VALUES
(6748,'866 Les Culleries, 42360 Cottance'),
(6749,'46 Conques (village), 76400 Épreville');

INSERT INTO Organisation (numero,adresse) VALUES
(6750,'764 Labade, 05700 Sigottier'),
(6751,'287bis Les Pradets, 02700 Barisis-aux-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(6752,'478bis La Fosse au Pommier, 80170 Warvillers'),
(6753,'184 Métairie Romieu, 78230 Le Pecq');

INSERT INTO Organisation (numero,adresse) VALUES
(6754,'793bis Le Champ de Bataille, 38320 Eybens'),
(6755,'260bis Bouras, 57480 Kirschnaumen');

INSERT INTO Organisation (numero,adresse) VALUES
(6756,'9bis la Grande Prairea, 47800 Moustier'),
(6757,'24 Lieu Dit Binsou, 42410 Vérin');

INSERT INTO Organisation (numero,adresse) VALUES
(6758,'951bis Parking des Rives, 74390 Châtel'),
(6759,'265 Route des Fargues, 54112 Uruffe');

INSERT INTO Organisation (numero,adresse) VALUES
(6760,'72 Le Pradier, 77890 Ichy'),
(6761,'588 Le Pouget de Carelis, 04300 Sigonce');

INSERT INTO Organisation (numero,adresse) VALUES
(6762,'44 Le Grand Poenat, 57480 Grindorff-Bizing'),
(6763,'276bis La Planque Haute, 28150 Allonnes');

INSERT INTO Organisation (numero,adresse) VALUES
(6764,'592 En Boillard, 11600 Villegly'),
(6765,'488 Chateau de Pringy, 63460 Combronde');

INSERT INTO Organisation (numero,adresse) VALUES
(6766,'44 Résidence La Baie des Oliviers III, 50510 Le Loreur'),
(6767,'626 Au Quart d''Ecus, 38570 La Pierre');

INSERT INTO Organisation (numero,adresse) VALUES
(6768,'285 Résidence L''iléo Bâtiment A, 16300 Barbezieux-Saint-Hilaire'),
(6769,'945 Les Grangettes, 54540 Sainte-Pôle');

INSERT INTO Organisation (numero,adresse) VALUES
(6770,'37 Sous La Ville, 27250 Les Bottereaux'),
(6771,'807 Libaret, 01090 Guéreins');

INSERT INTO Organisation (numero,adresse) VALUES
(6772,'766 Ciapagne Sottan, 53240 La Bigottière'),
(6773,'340 Derrière les Haies, 37320 Cormery');

INSERT INTO Organisation (numero,adresse) VALUES
(6774,'162 La Tour du Loup, 43100 Saint-Laurent-Chabreuges'),
(6775,'25bis La Buchere, 35580 Lassy');

INSERT INTO Organisation (numero,adresse) VALUES
(6776,'398bis Pichobaco, 38650 Saint-Paul-lès-Monestier'),
(6777,'782 Rec du Pouget, 07340 Thorrenc');

INSERT INTO Organisation (numero,adresse) VALUES
(6778,'867bis L''île, 66300 Sainte-Colombe-de-la-Commanderie'),
(6779,'909 Résidence Anglade Bat Cagire E - Salau, 63350 Joze');

INSERT INTO Organisation (numero,adresse) VALUES
(6780,'172 Le Bosc Nord, 27400 Surville'),
(6781,'428bis Pres la Fontaine des Loups, 47110 Dolmayrac');

INSERT INTO Organisation (numero,adresse) VALUES
(6782,'146 Place de la Libération, 11230 Sonnac-sur-l''Hers'),
(6783,'223 Hotel Le Grimaldi, 66730 Campoussy');

INSERT INTO Organisation (numero,adresse) VALUES
(6784,'947 Elze et Malichet, 50260 Rocheville'),
(6785,'963 Turcou, 13790 Châteauneuf-le-Rouge');

INSERT INTO Organisation (numero,adresse) VALUES
(6786,'958 Les Tritons, 47600 Francescas'),
(6787,'813 Résidence Le Ségovent 3, 15290 Parlan');

INSERT INTO Organisation (numero,adresse) VALUES
(6788,'473 Impasse Ferrand, 37230 Fondettes'),
(6789,'9 Cimetière Carré Israélite, 49140 Cornillé-les-Caves');

INSERT INTO Organisation (numero,adresse) VALUES
(6790,'700 Résidence Le Capitoul Terrasses du Soleil, 59730 Solesmes'),
(6791,'387bis Jasse des Clapouses, 30460 Colognac');

INSERT INTO Organisation (numero,adresse) VALUES
(6792,'259 La Croix de la Prade, 15190 Saint-Amandin'),
(6793,'602bis Timonet, 01460 Montréal-la-Cluse');

INSERT INTO Organisation (numero,adresse) VALUES
(6794,'455 Domaine Derriers, 62130 Conteville-en-Ternois'),
(6795,'927 La Bouloie, 04270 Châteauredon');

INSERT INTO Organisation (numero,adresse) VALUES
(6796,'894bis Tapianes, 08350 Bosseval-et-Briancourt'),
(6797,'443 Le Paillas, 31370 Montastruc-Savès');

INSERT INTO Organisation (numero,adresse) VALUES
(6798,'711 La Gariette, 42370 Saint-Rirand'),
(6799,'630bis Brie, 11240 Cailhau');

INSERT INTO Organisation (numero,adresse) VALUES
(6800,'919bis Rue Pierre Barthelemy, 64410 Lonçon'),
(6801,'609 Le Poujol, 24310 Bourdeilles');

INSERT INTO Organisation (numero,adresse) VALUES
(6802,'294bis Le Pre Bretet, 51480 Fleury-la-Rivière'),
(6803,'229 Vers Taleaud, 62140 Hesdin');

INSERT INTO Organisation (numero,adresse) VALUES
(6804,'146 Le Cussol, 24400 Saint-Louis-en-l''Isle'),
(6805,'497 Camp-Grand, 23240 Le Grand-Bourg');

INSERT INTO Organisation (numero,adresse) VALUES
(6806,'627 Des Granges du Bois, 52150 Goncourt'),
(6807,'632 Champ Paure et les Faysses, 54290 Saint-Boingt');

INSERT INTO Organisation (numero,adresse) VALUES
(6808,'534 Chemin des Peyrous, 77260 Sammeron'),
(6809,'608 Lou Bouissou Haut, 72290 Lucé-sous-Ballon');

INSERT INTO Organisation (numero,adresse) VALUES
(6810,'666 La Grand Borde, 14340 Montreuil-en-Auge'),
(6811,'172 Centre Aquatique, 80150 Lamotte-Buleux');

INSERT INTO Organisation (numero,adresse) VALUES
(6812,'966 Camp Fronts, 74430 Saint-Jean-d''Aulps'),
(6813,'884 Voie Verte, 74210 Val de Chaise');

INSERT INTO Organisation (numero,adresse) VALUES
(6814,'921 Route de la Faoussiéra, 03130 Neuilly-en-Donjon'),
(6815,'784 Ancien Chemin de Caucade, 64370 Morlanne');

INSERT INTO Organisation (numero,adresse) VALUES
(6816,'968 Grand Avignon, 80450 Lamotte-Brebière'),
(6817,'96 La Bruyere, 26560 Vers-sur-Méouge');

INSERT INTO Organisation (numero,adresse) VALUES
(6818,'92 Résidence Le Trimaran, 32720 Vergoignan'),
(6819,'319 La Verderie, 70150 Vregille');

INSERT INTO Organisation (numero,adresse) VALUES
(6820,'882 Annat, 70120 Melin'),
(6821,'419bis Plateau de la Justice, 38440 Lieudieu');

INSERT INTO Organisation (numero,adresse) VALUES
(6822,'857bis La Plate Pierre, 61370 Échauffour'),
(6823,'119bis Le Petit Méchatin, 77660 Changis-sur-Marne');

INSERT INTO Organisation (numero,adresse) VALUES
(6824,'879 Lescarras, 20164 Cargiaca'),
(6825,'977 La Pontière, 25160 Malbuisson');

INSERT INTO Organisation (numero,adresse) VALUES
(6826,'812 Les Bataillots, 19130 Saint-Aulaire'),
(6827,'636 La Maisonnette, 76210 Trouville');

INSERT INTO Organisation (numero,adresse) VALUES
(6828,'677 Verchere de Jouvancy, 67390 Marckolsheim'),
(6829,'559bis La Granget, 31110 Cier-de-Luchon');

INSERT INTO Organisation (numero,adresse) VALUES
(6830,'186bis Lauzic, 47550 Boé'),
(6831,'772 Route de Contrazy, 68118 Hirtzbach');

INSERT INTO Organisation (numero,adresse) VALUES
(6832,'481bis Champ de la Croux, 63730 Mirefleurs'),
(6833,'562 L''Epsom A-B-C-D, 02550 Origny-en-Thiérache');

INSERT INTO Organisation (numero,adresse) VALUES
(6834,'89 Les Combelles Hautes, 31600 Seysses'),
(6835,'731 Chemin Croix de Balé, 10210 Chaserey');

INSERT INTO Organisation (numero,adresse) VALUES
(6836,'695 Papyli, 39800 Aumont'),
(6837,'703bis Tabias, 47500 Saint-Front-sur-Lémance');

INSERT INTO Organisation (numero,adresse) VALUES
(6838,'685 Bois de Lanaud, 18370 Beddes'),
(6839,'360 Peyronenq, 51130 Germinon');

INSERT INTO Organisation (numero,adresse) VALUES
(6840,'942 Cabrespines, 65300 Lutilhous'),
(6841,'267bis Les Hauts De Breguieres H-I-J, 16700 Condac');

INSERT INTO Organisation (numero,adresse) VALUES
(6842,'979 La Croix de Soulagnet, 52150 Nijon'),
(6843,'157 Le Couderc, 60620 Villers-Saint-Genest');

INSERT INTO Organisation (numero,adresse) VALUES
(6844,'2 La Rode Haute, 28170 Saint-Maixme-Hauterive'),
(6845,'356bis Bouviala le Bas, 29250 Plougoulm');

INSERT INTO Organisation (numero,adresse) VALUES
(6846,'689 La Chave et les Rouveyres, 29510 Briec'),
(6847,'298 Les Chez, 60220 Quincampoix-Fleuzy');

INSERT INTO Organisation (numero,adresse) VALUES
(6848,'759 Saint Pardoux, 25680 Bonnal'),
(6849,'222 Gilet le Neuf, 60850 Lalandelle');

INSERT INTO Organisation (numero,adresse) VALUES
(6850,'332bis Les Doges A-B-C-D-E-F-G, 41100 Selommes'),
(6851,'34 Alayrac, 49070 Beaucouzé');

INSERT INTO Organisation (numero,adresse) VALUES
(6852,'451 Au Moulin de Coulet, 68570 Osenbach'),
(6853,'430bis Chapot, 38530 Saint-Maximin');

INSERT INTO Organisation (numero,adresse) VALUES
(6854,'791bis Garquier-Les-Roures, 46210 Montet-et-Bouxal'),
(6855,'715 Le Champ du Voisin, 19360 Cosnac');

INSERT INTO Organisation (numero,adresse) VALUES
(6856,'916bis Square Paul Gordeaux, 12850 Onet-le-Château'),
(6857,'425 Route de Blissy, 12200 Le Bas Ségala');

INSERT INTO Organisation (numero,adresse) VALUES
(6858,'713bis La Boubène, 46400 Saint-Vincent-du-Pendit'),
(6859,'961 La Gleyzette, 60680 Grandfresnoy');

INSERT INTO Organisation (numero,adresse) VALUES
(6860,'461 Ecole maternelle Pasteur, 33540 Mesterrieux'),
(6861,'780 Bretandières, 02250 Housset');

INSERT INTO Organisation (numero,adresse) VALUES
(6862,'839 Champ Cornu, 21420 Savigny-lès-Beaune'),
(6863,'146 Saint Cyrice, 33490 Saint-Martial');

INSERT INTO Organisation (numero,adresse) VALUES
(6864,'188 Lotissement Chauret 1, 14310 Villy-Bocage'),
(6865,'980 "Lotissement ""LES JULIENS""", 17770 Juicq');

INSERT INTO Organisation (numero,adresse) VALUES
(6866,'20bis Res La Roseraie, 16200 Mainxe'),
(6867,'643 Balastel, 65460 Bazet');

INSERT INTO Organisation (numero,adresse) VALUES
(6868,'166 Petit Cammazou, 22110 Mellionnec'),
(6869,'598 Rue des Crayats, 50800 La Lande-d''Airou');

INSERT INTO Organisation (numero,adresse) VALUES
(6870,'472 Salvaute, 65260 Villelongue'),
(6871,'232 Passage Louis Gassin, 05700 Nossage-et-Bénévent');

INSERT INTO Organisation (numero,adresse) VALUES
(6872,'143 Bouriou, 04270 Saint-Jeannet'),
(6873,'472 Le Reve De Jean Pierre, 15270 Trémouille');

INSERT INTO Organisation (numero,adresse) VALUES
(6874,'405 Résidence Le solea, 59229 Téteghem-Coudekerque-Village'),
(6875,'423 Maison Brulee, 63340 Charbonnier-les-Mines');

INSERT INTO Organisation (numero,adresse) VALUES
(6876,'262bis Marchère, 48200 Blavignac'),
(6877,'254 Les Mottes, 07120 Saint-Alban-Auriolles');

INSERT INTO Organisation (numero,adresse) VALUES
(6878,'586bis La Burelle, 47170 Sainte-Maure-de-Peyriac'),
(6879,'789 Traverse de Bonvillars, 30360 Ners');

INSERT INTO Organisation (numero,adresse) VALUES
(6880,'71bis Cap de Front Entrée 3, 39360 Rogna'),
(6881,'820 La Montee Perdrix, 58250 Lanty');

INSERT INTO Organisation (numero,adresse) VALUES
(6882,'508 Pessengue-Haut, 31110 Saccourvielle'),
(6883,'822 Les Vieux Moines, 80200 Biaches');

INSERT INTO Organisation (numero,adresse) VALUES
(6884,'702 Le Fidji Bat B, 33820 Saint-Ciers-sur-Gironde'),
(6885,'753bis Alyandre, 67170 Krautwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(6886,'638 Les Cardenas, 52130 Sommancourt'),
(6887,'272 Res De La Baie B4, 69380 Les Chères');

INSERT INTO Organisation (numero,adresse) VALUES
(6888,'585 Avenue Nicolas II prolongée, 76590 Manéhouville'),
(6889,'353 La Salieire, 65400 Artalens-Souin');

INSERT INTO Organisation (numero,adresse) VALUES
(6890,'64 Fontaine des Parmagnes, 24650 Chancelade'),
(6891,'0 Terrons et Courtial Bas, 20276 Asco');

INSERT INTO Organisation (numero,adresse) VALUES
(6892,'462 Mas De Puech, 63810 Cros'),
(6893,'282 Le Moulin Dudot, 54300 Jolivet');

INSERT INTO Organisation (numero,adresse) VALUES
(6894,'804 Font Sorillat, 08130 Saint-Loup-Terrier'),
(6895,'546 La Bessarede, 48160 Saint-Julien-des-Points');

INSERT INTO Organisation (numero,adresse) VALUES
(6896,'560 Impasse de la Sorbonne, 71880 Châtenoy-le-Royal'),
(6897,'575 Frontenat, 01370 Saint-Étienne-du-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(6898,'993 Pitché, 41800 Saint-Rimay'),
(6899,'988 Chezelle, 56920 Noyal-Pontivy');

INSERT INTO Organisation (numero,adresse) VALUES
(6900,'309 Villa Sequoia, 51300 Les Rivières-Henruel'),
(6901,'127 Les Pres-Ginies, 53230 Courbeveille');

INSERT INTO Organisation (numero,adresse) VALUES
(6902,'587 Résidence La Grande Bleue Bât 2, 77650 Saint-Loup-de-Naud'),
(6903,'346 Château de Lassalle, 66340 Palau-de-Cerdagne');

INSERT INTO Organisation (numero,adresse) VALUES
(6904,'354 Longecombe - Hauteville-Lompnes, 57865 Amanvillers'),
(6905,'629 Saint Reverien, 11580 Véraza');

INSERT INTO Organisation (numero,adresse) VALUES
(6906,'312 Lacam, 77510 Saint-Léger'),
(6907,'530 Le Truel, 72190 Saint-Pavace');

INSERT INTO Organisation (numero,adresse) VALUES
(6908,'500 La Verniere Haute, 52330 Vaudrémont'),
(6909,'520bis Res Les Aubepines, 31260 Escoulis');

INSERT INTO Organisation (numero,adresse) VALUES
(6910,'212 Co de Bié, 14600 Équemauville'),
(6911,'353 Souleilhac, 39210 Arlay');

INSERT INTO Organisation (numero,adresse) VALUES
(6912,'423 Les Cazals, 47370 Tournon-d''Agenais'),
(6913,'532bis La Tronque-Basse, 36500 La Chapelle-Orthemale');

INSERT INTO Organisation (numero,adresse) VALUES
(6914,'293bis La Nacelle, 44640 Cheix-en-Retz'),
(6915,'707bis La Bastisse de Menay, 76280 Villainville');

INSERT INTO Organisation (numero,adresse) VALUES
(6916,'618bis Arghis, 47360 Saint-Sardos'),
(6917,'566 Le Chemin Vert, 67930 Beinheim');

INSERT INTO Organisation (numero,adresse) VALUES
(6918,'999 Les Petites Roches, 38730 Panissage'),
(6919,'582 Saint Julien, 57660 Altrippe');

INSERT INTO Organisation (numero,adresse) VALUES
(6920,'176 La Burgayrole, 55300 Ranzières'),
(6921,'707 La Cambonnie, 53290 Bouessay');

INSERT INTO Organisation (numero,adresse) VALUES
(6922,'695 Les Bouscaillous, 76340 Pierrecourt'),
(6923,'7 Touscat, 15290 Omps');

INSERT INTO Organisation (numero,adresse) VALUES
(6924,'200bis Esplanade Léopold Sédar Senghor, 02120 Bernot'),
(6925,'241bis L''Etang Gorgeas, 36350 La Pérouille');

INSERT INTO Organisation (numero,adresse) VALUES
(6926,'451 Le Biquet, 51260 Esclavolles-Lurey'),
(6927,'762 Douviou, 07110 Rocles');

INSERT INTO Organisation (numero,adresse) VALUES
(6928,'581 Les_crozardais, 04250 Nibles'),
(6929,'523 Champ Vieux Bas, 62127 Marquay');

INSERT INTO Organisation (numero,adresse) VALUES
(6930,'607 Le Cebie, 70130 Vy-le-Ferroux'),
(6931,'861 La Vignola, 33460 Lamarque');

INSERT INTO Organisation (numero,adresse) VALUES
(6932,'109 Pado, 45700 Vimory'),
(6933,'0 Rue la Promenade, 74300 Cluses');

INSERT INTO Organisation (numero,adresse) VALUES
(6934,'400 Méra, 14810 Gonneville-en-Auge'),
(6935,'493 La Côte de l''Epinette, 55110 Vilosnes-Haraumont');

INSERT INTO Organisation (numero,adresse) VALUES
(6936,'861 La Croix Bonne Dame, 60250 Heilles'),
(6937,'684 Saint Grégoire, 28120 Bailleau-le-Pin');

INSERT INTO Organisation (numero,adresse) VALUES
(6938,'604bis Cornillon, 71510 Charrecey'),
(6939,'38 Prads, 69230 Saint-Genis-Laval');

INSERT INTO Organisation (numero,adresse) VALUES
(6940,'234 Mondalazac, 43490 Vielprat'),
(6941,'100 Bergerie la Asso, 42140 Fontanès');

INSERT INTO Organisation (numero,adresse) VALUES
(6942,'471 Coulzonne, 58600 Garchizy'),
(6943,'14 Bourret, 66230 Serralongue');

INSERT INTO Organisation (numero,adresse) VALUES
(6944,'33 Ferme les ozias, 46220 Prayssac'),
(6945,'301 La Butte des Gaulmes, 21510 Échalot');

INSERT INTO Organisation (numero,adresse) VALUES
(6946,'519 Les Buissieres, 40320 Urgons'),
(6947,'250bis La Nedouze, 14700 Eraines');

INSERT INTO Organisation (numero,adresse) VALUES
(6948,'182 Grand Paquis, 25500 Le Bélieu'),
(6949,'276 mainphy, 62223 Feuchy');

INSERT INTO Organisation (numero,adresse) VALUES
(6950,'240 Promenade Jean Gismondi, 54120 Reherrey'),
(6951,'206bis Rue du Présbytère, 36320 Villedieu-sur-Indre');

INSERT INTO Organisation (numero,adresse) VALUES
(6952,'904 Rec Del Prue, 24500 Singleyrac'),
(6953,'430 Le Mas Sainte Therese, 64110 Laroin');

INSERT INTO Organisation (numero,adresse) VALUES
(6954,'279 Impasse Mal Foch, 02250 Thiernu'),
(6955,'848bis Lebret, 27800 Brionne');

INSERT INTO Organisation (numero,adresse) VALUES
(6956,'659 Cluos, 10110 Buxières-sur-Arce'),
(6957,'369 Rocher Dessus, 59740 Choisies');

INSERT INTO Organisation (numero,adresse) VALUES
(6958,'146 La Capelle Bleys, 25240 Petite-Chaux'),
(6959,'892bis l''Arenie, 59420 Mouvaux');

INSERT INTO Organisation (numero,adresse) VALUES
(6960,'235 Olea D-E, 54290 Saint-Germain'),
(6961,'0bis Saison Percee, 57980 Metzing');

INSERT INTO Organisation (numero,adresse) VALUES
(6962,'997bis Grange de la Lebouse, 64470 Tardets-Sorholus'),
(6963,'56 Chemin des Petits Pres, 64310 Sare');

INSERT INTO Organisation (numero,adresse) VALUES
(6964,'86bis Peyres Crousades, 08240 Imécourt'),
(6965,'858 Délaissé Route Métropolitaine 2565, 62390 Haravesnes');

INSERT INTO Organisation (numero,adresse) VALUES
(6966,'814bis Étang Cardon, 73800 La Chavanne'),
(6967,'233 Ancienne D117, 24600 Villetoureix');

INSERT INTO Organisation (numero,adresse) VALUES
(6968,'881bis Vernay Bouillon, 17370 Le Grand-Village-Plage'),
(6969,'811 La Grand Haye, 02820 Saint-Erme-Outre-et-Ramecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(6970,'113 Domaine de la Jasse, 02130 Ronchères'),
(6971,'275bis Boulevard Henri Savy, 34480 Fouzilhon');

INSERT INTO Organisation (numero,adresse) VALUES
(6972,'681bis Clos d''Éguine Ouest, 25160 Montperreux'),
(6973,'168bis Plat de Mount, 60890 Varinfroy');

INSERT INTO Organisation (numero,adresse) VALUES
(6974,'195 Avenue Sainte-Philomène, 57535 Marange-Silvange'),
(6975,'100bis Codepeire, 17520 Germignac');

INSERT INTO Organisation (numero,adresse) VALUES
(6976,'187 Chateau de Malvaux, 38350 Saint-Arey'),
(6977,'838 Domaine Salot, 31370 Savères');

INSERT INTO Organisation (numero,adresse) VALUES
(6978,'90 Bâtiment Le basilic Entrée 4, 62580 Arleux-en-Gohelle'),
(6979,'777 Les 4 vents, 35190 Tinténiac');

INSERT INTO Organisation (numero,adresse) VALUES
(6980,'684 Brosse Neuf, 55600 Flassigny'),
(6981,'595 Le Foreston, 68150 Ribeauvillé');

INSERT INTO Organisation (numero,adresse) VALUES
(6982,'266 Le Champ du Voisin, 52310 Viéville'),
(6983,'702 Rond point de Provence, 71460 Saint-Ythaire');

INSERT INTO Organisation (numero,adresse) VALUES
(6984,'521bis Signefon, 67210 Niedernai'),
(6985,'698 Lavaldieu, 52140 Val-de-Meuse');

INSERT INTO Organisation (numero,adresse) VALUES
(6986,'881bis Veyries de Bas, 06470 Daluis'),
(6987,'545bis Les Jalliberts, 39290 Mutigney');

INSERT INTO Organisation (numero,adresse) VALUES
(6988,'591 Lusclade, 05150 Montjay'),
(6989,'306 Sous-Beal, 60380 Fontenay-Torcy');

INSERT INTO Organisation (numero,adresse) VALUES
(6990,'491 Rancurel, 57690 Marange-Zondrange'),
(6991,'959bis Sarraou, 21540 Aubigny-lès-Sombernon');

INSERT INTO Organisation (numero,adresse) VALUES
(6992,'42 La Pièce à la Saulx, 54830 Vallois'),
(6993,'182 Au Dessus des Effalizes, 07460 Berrias-et-Casteljau');

INSERT INTO Organisation (numero,adresse) VALUES
(6994,'765 Les Arables, 65350 Jacque'),
(6995,'364 Place Cros, 54113 Mont-le-Vignoble');

INSERT INTO Organisation (numero,adresse) VALUES
(6996,'456 Le Chariot, 23200 Néoux'),
(6997,'181 """ Les Quillets """, 34190 Ganges');

INSERT INTO Organisation (numero,adresse) VALUES
(6998,'661 quartier Celestrera, 62170 Montcavrel'),
(6999,'126bis Les Rouquilles, 42130 Leigneux');

INSERT INTO Organisation (numero,adresse) VALUES
(7000,'167bis Chemin de St Martin, 08700 Neufmanil'),
(7001,'187 Domaine de Ficelle, 44590 Saint-Vincent-des-Landes');

INSERT INTO Organisation (numero,adresse) VALUES
(7002,'975 Sentier de la Source, 68410 Ammerschwihr'),
(7003,'265 Cialancias, 29100 Douarnenez');

INSERT INTO Organisation (numero,adresse) VALUES
(7004,'594 Montée Stalingrad, 76110 Houquetot'),
(7005,'670 Grande Neuve, 29180 Plogonnec');

INSERT INTO Organisation (numero,adresse) VALUES
(7006,'288bis Dko Casa, 53170 Saint-Charles-la-Forêt'),
(7007,'403 Metairie des Perdraux, 28200 Villemaury');

INSERT INTO Organisation (numero,adresse) VALUES
(7008,'335bis le Coullet, 27180 Caugé'),
(7009,'785bis Allée des Acacias, 08310 Juniville');

INSERT INTO Organisation (numero,adresse) VALUES
(7010,'838 Bretelle Entrée Comboul - Mathis (Chaussée sud), 71330 Bouhans'),
(7011,'849 Résidence Le Canigou, 41500 Mulsans');

INSERT INTO Organisation (numero,adresse) VALUES
(7012,'571bis Le Puech de Lavernhe, 55230 Vaudoncourt'),
(7013,'698 La Grand Vigne, 31310 Montesquieu-Volvestre');

INSERT INTO Organisation (numero,adresse) VALUES
(7014,'910 Haute-Serve, 76210 Saint-Eustache-la-Forêt'),
(7015,'631 Route de la Drobie, 65350 Collongues');

INSERT INTO Organisation (numero,adresse) VALUES
(7016,'779 Res Du Vieux Cagnes Bat B, 28410 Bû'),
(7017,'455 Jardin Saint Jacques, 27450 Saint-Martin-Saint-Firmin');

INSERT INTO Organisation (numero,adresse) VALUES
(7018,'171 Les 2 Chateaux, 50170 Beauvoir'),
(7019,'659 La Besse, 31350 Lespugue');

INSERT INTO Organisation (numero,adresse) VALUES
(7020,'747 Les Tendes, 72130 Saint-Victeur'),
(7021,'532 Rue du 19 Mars 1962 Recoules, 61190 Tourouvre au Perche');

INSERT INTO Organisation (numero,adresse) VALUES
(7022,'156 Pre de la Blonde, 25580 Lavans-Vuillafans'),
(7023,'522bis Mas de Patule, 36210 Anjouin');

INSERT INTO Organisation (numero,adresse) VALUES
(7024,'986 Pouzadouire, 10110 Polisy'),
(7025,'782 Maison de Secours, 17290 Virson');

INSERT INTO Organisation (numero,adresse) VALUES
(7026,'46 """ Foret de Messarges """, 35250 Saint-Aubin-d''Aubigné'),
(7027,'112 Jacquette, 54800 Mouaville');

INSERT INTO Organisation (numero,adresse) VALUES
(7028,'740 Les Roures B, 07600 Labastide-sur-Bésorgues'),
(7029,'610 La Chanteraie, 11340 Comus');

INSERT INTO Organisation (numero,adresse) VALUES
(7030,'77 Impasse des Muriers, 17870 Breuil-Magné'),
(7031,'731bis Les Gâteaux, 07160 Le Cheylard');

INSERT INTO Organisation (numero,adresse) VALUES
(7032,'701 Les Grands Près, 38230 Charvieu-Chavagneux'),
(7033,'525 Parking du Microsite, 03120 Billezois');

INSERT INTO Organisation (numero,adresse) VALUES
(7034,'326bis Chemin de la Haute Couture, 72270 Bousse'),
(7035,'568 La Girviere, 33370 Yvrac');

INSERT INTO Organisation (numero,adresse) VALUES
(7036,'723 Les Coutals, 39300 Cize'),
(7037,'780bis Le Grand Guet, 50750 Dangy');

INSERT INTO Organisation (numero,adresse) VALUES
(7038,'582 Les Judas, 02370 Condé-sur-Aisne'),
(7039,'19 Les Regnauds, 01990 Chaneins');

INSERT INTO Organisation (numero,adresse) VALUES
(7040,'996 Poulentines, 12370 Mounes-Prohencoux'),
(7041,'620 Les Asquies de Rieupeyroux, 56200 La Gacilly');

INSERT INTO Organisation (numero,adresse) VALUES
(7042,'667 Puech Frech, 30960 Saint-Jean-de-Valériscle'),
(7043,'490 La Lande de Celles, 14190 Soignolles');

INSERT INTO Organisation (numero,adresse) VALUES
(7044,'363 Cabrières Chateau, 25500 Les Fins'),
(7045,'763 La Pendarie, 51220 Cauroy-lès-Hermonville');

INSERT INTO Organisation (numero,adresse) VALUES
(7046,'74 Chazallet, 10290 Avon-la-Pèze'),
(7047,'554 Le Poticaire, 78910 Flexanville');

INSERT INTO Organisation (numero,adresse) VALUES
(7048,'430 La Ferraye, 64560 Larrau'),
(7049,'109 Avenue Jean Marguerite, 19520 Mansac');

INSERT INTO Organisation (numero,adresse) VALUES
(7050,'983 Escalier de l''Église de La Pointe, 04000 Digne-les-Bains'),
(7051,'751 """ Prieur """, 63230 Mazaye');

INSERT INTO Organisation (numero,adresse) VALUES
(7052,'345 13ème Bis, 55190 Marson-sur-Barboure'),
(7053,'687 La Haie, 02160 Vendresse-Beaulne');

INSERT INTO Organisation (numero,adresse) VALUES
(7054,'207 Berdou, 54850 Méréville'),
(7055,'679 Plan de Braut, 03600 La Celle');

INSERT INTO Organisation (numero,adresse) VALUES
(7056,'51bis Truquet, 02420 Villeret'),
(7057,'438 Les Fayolles, 25210 Saint-Julien-lès-Russey');

INSERT INTO Organisation (numero,adresse) VALUES
(7058,'439 Place de La Matinière, 13200 Arles'),
(7059,'630 Champ Coillod, 52400 Guyonvelle');

INSERT INTO Organisation (numero,adresse) VALUES
(7060,'920 Riou Colombier, 47440 Casseneuil'),
(7061,'855 Place Barthèlèmy Domèrègo, 15800 Vic-sur-Cère');

INSERT INTO Organisation (numero,adresse) VALUES
(7062,'197 Villas Gourmettes, 61190 Tourouvre au Perche'),
(7063,'610 Ferme du Bas Quesnoy, 62130 Humerœuille');

INSERT INTO Organisation (numero,adresse) VALUES
(7064,'4bis Cos, 25120 Cernay-l''Église'),
(7065,'231 Le Moulin d''Aussalesses, 69970 Chaponnay');

INSERT INTO Organisation (numero,adresse) VALUES
(7066,'766 Domaine de La Soulette, 59110 La Madeleine'),
(7067,'280 Bastide Lou Plantier, 30360 Ners');

INSERT INTO Organisation (numero,adresse) VALUES
(7068,'54 Les Aubrettes, 74460 Marnaz'),
(7069,'675 Chantilly, 60170 Pimprez');

INSERT INTO Organisation (numero,adresse) VALUES
(7070,'749 Place du jeu de Battoir, 36290 Mézières-en-Brenne'),
(7071,'204 La Plaine du Pont, 01200 Châtillon-en-Michaille');

INSERT INTO Organisation (numero,adresse) VALUES
(7072,'921 Beque des Bois, 74800 Saint-Pierre-en-Faucigny'),
(7073,'985 La Noirée, 29980 Île-Tudy');

INSERT INTO Organisation (numero,adresse) VALUES
(7074,'946bis Bouscau Haut, 59145 Berlaimont'),
(7075,'796 Carrefour des Diables Bleus, 12390 Belcastel');

INSERT INTO Organisation (numero,adresse) VALUES
(7076,'43 Le Chemin du Cimetière, 52000 Foulain'),
(7077,'733 """ Simpert """, 62820 Libercourt');

INSERT INTO Organisation (numero,adresse) VALUES
(7078,'359bis Le Grand Etang, 55500 Stainville'),
(7079,'261 Villa Poe, 12170 Saint-Jean-Delnous');

INSERT INTO Organisation (numero,adresse) VALUES
(7080,'689bis Aire de Jeux et de Pique Nique, 22590 Pordic'),
(7081,'604 Le Moulin d''Arcy, 46220 Lagardelle');

INSERT INTO Organisation (numero,adresse) VALUES
(7082,'451 À la Grange Silan, 02330 Vallées en Champagne'),
(7083,'379 Serre des Faures, 39300 Le Larderet');

INSERT INTO Organisation (numero,adresse) VALUES
(7084,'672 La Buissière, 27130 Les Barils'),
(7085,'251bis Villa Elisabeth, 67250 Kutzenhausen');

INSERT INTO Organisation (numero,adresse) VALUES
(7086,'314 Les Basses Certelles, 21310 Blagny-sur-Vingeanne'),
(7087,'684 Pignols, 68730 Michelbach-le-Bas');

INSERT INTO Organisation (numero,adresse) VALUES
(7088,'757bis Bourdalis, 37600 Saint-Senoch'),
(7089,'631bis La Commanderie Nord, 54630 Richardménil');

INSERT INTO Organisation (numero,adresse) VALUES
(7090,'850 Hlm le Plessis Bat I3, 39700 Vriange'),
(7091,'173 Impasse de Ladoux, 26470 La Charce');

INSERT INTO Organisation (numero,adresse) VALUES
(7092,'749bis Lavernhe, 59138 Pont-sur-Sambre'),
(7093,'93 Le Fond de Corbeny, 65190 Bégole');

INSERT INTO Organisation (numero,adresse) VALUES
(7094,'623bis Saint Hubert, 73200 Mercury'),
(7095,'554 À la Croix d''Ain, 27390 Saint-Agnan-de-Cernières');

INSERT INTO Organisation (numero,adresse) VALUES
(7096,'829 Le Haut Montvillers, 51700 Festigny'),
(7097,'18 Boulardot, 23220 Bonnat');

INSERT INTO Organisation (numero,adresse) VALUES
(7098,'431 Chemin du Rosaire, 61200 Juvigny-sur-Orne'),
(7099,'425 """ La Bruyère """, 79120 Saint-Coutant');

INSERT INTO Organisation (numero,adresse) VALUES
(7100,'105 """ Salles """, 26400 Montclar-sur-Gervanne'),
(7101,'300bis Villa Antonia, 02220 Augy');

INSERT INTO Organisation (numero,adresse) VALUES
(7102,'621 Garbet, 29510 Landudal'),
(7103,'54 Le Caylaret, 07130 Toulaud');

INSERT INTO Organisation (numero,adresse) VALUES
(7104,'96 Impasse de la Forêt, 59750 Feignies'),
(7105,'591 Foullade, 35480 Guipry-Messac');

INSERT INTO Organisation (numero,adresse) VALUES
(7106,'273 Caramaurel, 34700 Soubès'),
(7107,'560 La Font des Clappiers, 21170 Saint-Symphorien-sur-Saône');

INSERT INTO Organisation (numero,adresse) VALUES
(7108,'133 Place rue Maurice Maccario, 51270 Orbais-l''Abbaye'),
(7109,'784 Le Central Plaza Bat A, 17600 Médis');

INSERT INTO Organisation (numero,adresse) VALUES
(7110,'901bis Le Petit Courdin, 08250 Chevières'),
(7111,'81 Moulo de Bidaou, 03420 Mazirat');

INSERT INTO Organisation (numero,adresse) VALUES
(7112,'846 Le Cros D''Azur, 59115 Leers'),
(7113,'883bis Les Jugathes, 49680 Vivy');

INSERT INTO Organisation (numero,adresse) VALUES
(7114,'712bis Puech d''Orlhaguet, 02140 Gercy'),
(7115,'873 Le Patus, 20112 Olmiccia');

INSERT INTO Organisation (numero,adresse) VALUES
(7116,'944 Les coins, 72700 Étival-lès-le-Mans'),
(7117,'864 La Crotte d''Oie, 37530 Saint-Règle');

INSERT INTO Organisation (numero,adresse) VALUES
(7118,'311 Semiramis 73, 51240 Coupéville'),
(7119,'635 Tortues Roies de Juzancour, 53160 Saint-Martin-de-Connée');

INSERT INTO Organisation (numero,adresse) VALUES
(7120,'88 Résidence du Stade, 30630 Goudargues'),
(7121,'769 Le Buis, 42620 Saint-Pierre-Laval');

INSERT INTO Organisation (numero,adresse) VALUES
(7122,'646 Bâtiment Le géranium, 77370 Nangis'),
(7123,'836bis L’Austal, 41130 Châtillon-sur-Cher');

INSERT INTO Organisation (numero,adresse) VALUES
(7124,'211 Les Sentes à Pieds, 45720 Coullons'),
(7125,'500bis Les Cousties Hautes, 27400 Crasville');

INSERT INTO Organisation (numero,adresse) VALUES
(7126,'490 Baillard, 21200 Levernois'),
(7127,'891 les Tartes, 46100 Cambes');

INSERT INTO Organisation (numero,adresse) VALUES
(7128,'622 Les Mondons, 35000 Rennes'),
(7129,'527 Les Vignes Hautes, 40700 Bassercles');

INSERT INTO Organisation (numero,adresse) VALUES
(7130,'688 Pobusca, 48210 Mas-Saint-Chély'),
(7131,'331bis La croix des bois, 02290 Saint-Christophe-à-Berry');

INSERT INTO Organisation (numero,adresse) VALUES
(7132,'862 Vielmont, 54290 Borville'),
(7133,'829 Courtiol Haut, 62161 Marœuil');

INSERT INTO Organisation (numero,adresse) VALUES
(7134,'334 Jardin de la Légion d''Honneur, 24510 Saint-Félix-de-Villadeix'),
(7135,'129 Jaleyres, 78200 Perdreauville');

INSERT INTO Organisation (numero,adresse) VALUES
(7136,'271bis Parc Carol de Roumanie, 42630 Pradines'),
(7137,'613 Quai d''Accueil, 14620 Morteaux-Coulibœuf');

INSERT INTO Organisation (numero,adresse) VALUES
(7138,'785 Villa Heaven, 02680 Dallon'),
(7139,'340 Le Ray Noir, 17700 Saint-Germain-de-Marencennes');

INSERT INTO Organisation (numero,adresse) VALUES
(7140,'848 Madières, 24440 Naussannes'),
(7141,'91 La Ferme de Fayet, 10210 Vallières');

INSERT INTO Organisation (numero,adresse) VALUES
(7142,'301bis Les Petites Landes, 73170 Saint-Jean-de-Chevelu'),
(7143,'575 Sinhalac, 41500 Lestiou');

INSERT INTO Organisation (numero,adresse) VALUES
(7144,'884bis Le Mas de Poumet, 14270 Le Mesnil-Mauger'),
(7145,'124 Palais de Justice, 49330 Sœurdres');

INSERT INTO Organisation (numero,adresse) VALUES
(7146,'367 Pre des Chevres, 46200 Souillac'),
(7147,'23bis Blancard, 62370 Offekerque');

INSERT INTO Organisation (numero,adresse) VALUES
(7148,'913 Hameau de Malvaux, 38660 Saint-Vincent-de-Mercuze'),
(7149,'470 Breillet, 11270 Cazalrenoux');

INSERT INTO Organisation (numero,adresse) VALUES
(7150,'332 Rue de la Ferme, 20600 Bastia'),
(7151,'90 Cabanettes, 09310 Les Cabannes');

INSERT INTO Organisation (numero,adresse) VALUES
(7152,'796 L''Acajadou, 63450 Tallende'),
(7153,'28 Rue des Métiers, 15100 Roffiac');

INSERT INTO Organisation (numero,adresse) VALUES
(7154,'658bis Combe de Veyle Nord, 09140 Seix'),
(7155,'181 chemin rural dit des Bouvottes, 75003 Paris 03');

INSERT INTO Organisation (numero,adresse) VALUES
(7156,'58 Allée des Coquelicots, 07230 Planzolles'),
(7157,'21bis Lieu-dit Le Marais de Longchamp, 77410 Gressy');

INSERT INTO Organisation (numero,adresse) VALUES
(7158,'398 Jardin Adeline Bailet, 18350 Flavigny'),
(7159,'413 Lieu dit Pradals, 14710 Écrammeville');

INSERT INTO Organisation (numero,adresse) VALUES
(7160,'440bis Le Seuillet, 62170 Aix-en-Issart'),
(7161,'236bis La Côte du Moulinet, 65350 Peyriguère');

INSERT INTO Organisation (numero,adresse) VALUES
(7162,'907 Pre de Villars, 55600 Iré-le-Sec'),
(7163,'790 Co de Cheylan, 24380 Chalagnac');

INSERT INTO Organisation (numero,adresse) VALUES
(7164,'307 Planal de Villemajou, 72440 Bouloire'),
(7165,'208bis Tuilerie Barillere, 17500 Agudelle');

INSERT INTO Organisation (numero,adresse) VALUES
(7166,'25bis Quart En Reserve, 61320 La Lande-de-Goult'),
(7167,'221 Salle Municipale Dieter Trennheuser - ERP, 39300 Loulle');

INSERT INTO Organisation (numero,adresse) VALUES
(7168,'200 La Rotonde, 27400 Heudebouville'),
(7169,'997 Gamas, 64410 Arget');

INSERT INTO Organisation (numero,adresse) VALUES
(7170,'850 La Tarrinie, 07160 Saint-Barthélemy-le-Meil'),
(7171,'697bis Le Palencas, 64190 Bastanès');

INSERT INTO Organisation (numero,adresse) VALUES
(7172,'707 La Terre à l''Argent, 57390 Audun-le-Tiche'),
(7173,'368bis Résidence Le Manoir, 63470 Verneugheol');

INSERT INTO Organisation (numero,adresse) VALUES
(7174,'461 Les Terres du Chateau, 56220 Pluherlin'),
(7175,'533 Bouscau Haut, 21490 Bretigny');

INSERT INTO Organisation (numero,adresse) VALUES
(7176,'19bis """ Rouinaire """, 54260 Villers-le-Rond'),
(7177,'270 Soleil D''Azur, 63970 Aydat');

INSERT INTO Organisation (numero,adresse) VALUES
(7178,'550 Les Blaches Ouest, 09300 L''Aiguillon'),
(7179,'623 Amplaing, 71600 Hautefond');

INSERT INTO Organisation (numero,adresse) VALUES
(7180,'99 Serayol, 78790 Hargeville'),
(7181,'781bis Le Puech des Hems, 11400 Tréville');

INSERT INTO Organisation (numero,adresse) VALUES
(7182,'747 Chemin du Relais T.d.f., 55500 Chanteraine'),
(7183,'75 Les Jardins de la Valmasque, 06650 Opio');

INSERT INTO Organisation (numero,adresse) VALUES
(7184,'866 ancienne école, 61210 Montreuil-au-Houlme'),
(7185,'120 Bâtiment Le basilic Entrée 3, 69870 Poule-les-Écharmeaux');

INSERT INTO Organisation (numero,adresse) VALUES
(7186,'560 Casas, 33480 Avensan'),
(7187,'999 Bois Bonnot, 32320 Riguepeu');

INSERT INTO Organisation (numero,adresse) VALUES
(7188,'43 Le Puech-Baguet, 28120 Charonville'),
(7189,'830bis Lieu-dit Roc Saint Martin, 80250 Quiry-le-Sec');

INSERT INTO Organisation (numero,adresse) VALUES
(7190,'250 Lieu dit Le Caillaou, 29740 Plobannalec-Lesconil'),
(7191,'447 La Raviere, 77520 Vimpelles');

INSERT INTO Organisation (numero,adresse) VALUES
(7192,'732 Place Pierre Magnan, 54385 Noviant-aux-Prés'),
(7193,'787bis Renaud, 43430 Les Vastres');

INSERT INTO Organisation (numero,adresse) VALUES
(7194,'455 Les Bessades, 48150 Hures-la-Parade'),
(7195,'130bis Valauris, 40130 Capbreton');

INSERT INTO Organisation (numero,adresse) VALUES
(7196,'194 Poste de distribution électrique Mairie, 14950 Saint-Pierre-Azif'),
(7197,'843 Pontier, 51120 Fontaine-Denis-Nuisy');

INSERT INTO Organisation (numero,adresse) VALUES
(7198,'524 Le Mas de Connes, 24120 Coly'),
(7199,'891 Romeveille, 29600 Sainte-Sève');

INSERT INTO Organisation (numero,adresse) VALUES
(7200,'865 Couchet, 16230 Puyréaux'),
(7201,'150bis Residence les Muguets, 54450 Blâmont');

INSERT INTO Organisation (numero,adresse) VALUES
(7202,'836 Moulin de l''Espine, 02360 Rouvroy-sur-Serre'),
(7203,'423bis Montolin, 64320 Sendets');

INSERT INTO Organisation (numero,adresse) VALUES
(7204,'696bis Le Fortuna, 64190 Ogenne-Camptort'),
(7205,'22 Brigade motorisée de Gendarmerie, 41160 Saint-Jean-Froidmentel');

INSERT INTO Organisation (numero,adresse) VALUES
(7206,'214 Les Barbillies, 67250 Hoffen'),
(7207,'284 Liaison Chemin de la Paillos - Chemin du Malgarach sud, 03220 Chavroches');

INSERT INTO Organisation (numero,adresse) VALUES
(7208,'539bis Bidous, 14250 Ellon'),
(7209,'729 Manaut de Devant, 44480 Donges');

INSERT INTO Organisation (numero,adresse) VALUES
(7210,'863 La Mignonette, 20151 Sari-d''Orcino'),
(7211,'767 Le Moulin à Vent, 31430 Saint-Élix-le-Château');

INSERT INTO Organisation (numero,adresse) VALUES
(7212,'950 Les Plaines de Lafon, 39230 Monay'),
(7213,'437 Rioube, 60250 Mouchy-le-Châtel');

INSERT INTO Organisation (numero,adresse) VALUES
(7214,'690bis L’Abeille, 33123 Le Verdon-sur-Mer'),
(7215,'684 Les Geneyries, 25250 La Prétière');

INSERT INTO Organisation (numero,adresse) VALUES
(7216,'816 Villa Mia Nevia, 21580 Bussières'),
(7217,'453 Soules, 71220 Chiddes');

INSERT INTO Organisation (numero,adresse) VALUES
(7218,'183 Birkadem, 33230 Coutras'),
(7219,'618 Allée du Bois, 54330 Vitrey');

INSERT INTO Organisation (numero,adresse) VALUES
(7220,'916bis La Jeannette, 27460 Alizay'),
(7221,'872 Lacombe Basse, 58190 Saint-Aubin-des-Chaumes');

INSERT INTO Organisation (numero,adresse) VALUES
(7222,'880bis En Brochalin, 17170 Ferrières'),
(7223,'787 Les Sagnasses, 59390 Sailly-lez-Lannoy');

INSERT INTO Organisation (numero,adresse) VALUES
(7224,'16 Le-trou-des-anes, 04250 Melve'),
(7225,'890 Valtan, 67490 Gottesheim');

INSERT INTO Organisation (numero,adresse) VALUES
(7226,'700bis Res De La Baie A1, 62580 Fresnoy-en-Gohelle'),
(7227,'143 Riou Pesqué, 34360 Saint-Chinian');

INSERT INTO Organisation (numero,adresse) VALUES
(7228,'41 Plan de Phazy, 33500 Lalande-de-Pomerol'),
(7229,'216bis Dournets, 19120 Queyssac-les-Vignes');

INSERT INTO Organisation (numero,adresse) VALUES
(7230,'736bis Quartier des Lioures, 30210 Saint-Hilaire-d''Ozilhan'),
(7231,'697 Le Mont de Coyant, 30330 La Bastide-d''Engras');

INSERT INTO Organisation (numero,adresse) VALUES
(7232,'252 En Record, 08110 Williers'),
(7233,'15bis la Vinties, 72600 Marollette');

INSERT INTO Organisation (numero,adresse) VALUES
(7234,'879 Clot de Gueinier, 36500 Palluau-sur-Indre'),
(7235,'614 La Bastide Des Remparts, 78640 Neauphle-le-Château');

INSERT INTO Organisation (numero,adresse) VALUES
(7236,'566bis Route de Vaudreuille, 56550 Belz'),
(7237,'996 Mille Hommes, 41190 Saint-Cyr-du-Gault');

INSERT INTO Organisation (numero,adresse) VALUES
(7238,'696 Chabriol Le Bas, 77330 Ozoir-la-Ferrière'),
(7239,'621 Champ Gauthier, 57480 Kerling-lès-Sierck');

INSERT INTO Organisation (numero,adresse) VALUES
(7240,'660 Volognat, 60340 Villers-sous-Saint-Leu'),
(7241,'213bis Les Arnauds, 01510 Saint-Martin-de-Bavel');

INSERT INTO Organisation (numero,adresse) VALUES
(7242,'208bis Champ des Vignots, 33760 Cantois'),
(7243,'480 Combe du Notaire, 77183 Croissy-Beaubourg');

INSERT INTO Organisation (numero,adresse) VALUES
(7244,'754bis Le Puits Trouve, 77520 Cessoy-en-Montois'),
(7245,'918 Lotissement Clos Louis, 17170 Courçon');

INSERT INTO Organisation (numero,adresse) VALUES
(7246,'763 Le Mas Saphir, 77390 Verneuil-l''Étang'),
(7247,'711 Mondevis, 45160 Ardon');

INSERT INTO Organisation (numero,adresse) VALUES
(7248,'863 Hameau de Pelat, 26410 Saint-Roman'),
(7249,'971 Les Mounets, 40400 Meilhan');

INSERT INTO Organisation (numero,adresse) VALUES
(7250,'662bis Les Tieules, 51320 Soudron'),
(7251,'829bis La Compagnie, 35240 Retiers');

INSERT INTO Organisation (numero,adresse) VALUES
(7252,'662 la Dreccia, 06730 Saint-André-de-la-Roche'),
(7253,'323 Les Terrasses du Levant - La Dôle, 27120 Croisy-sur-Eure');

INSERT INTO Organisation (numero,adresse) VALUES
(7254,'191 Les Fournaches, 20290 Borgo'),
(7255,'760 Escalier Route du Bord de Mer/Rue Paul Lantelme, 15190 Saint-Saturnin');

INSERT INTO Organisation (numero,adresse) VALUES
(7256,'45 ZAE du Fongeri, 02880 Margival'),
(7257,'722 Berri, 07110 Largentière');

INSERT INTO Organisation (numero,adresse) VALUES
(7258,'778bis Larlan, 65320 Séron'),
(7259,'389bis Les Pagats, 67430 Lorentzen');

INSERT INTO Organisation (numero,adresse) VALUES
(7260,'66 La Marinie, 55220 Senoncourt-les-Maujouy'),
(7261,'965 Le Vieux Mazert, 27310 Honguemare-Guenouville');

INSERT INTO Organisation (numero,adresse) VALUES
(7262,'29 Les Grandes Grèves, 45220 Saint-Germain-des-Prés'),
(7263,'200 Lesbros, 23600 Saint-Pierre-le-Bost');

INSERT INTO Organisation (numero,adresse) VALUES
(7264,'648bis Puech de Fontaneilles, 04250 Bellaffaire'),
(7265,'538 Les Trois Sapins, 72130 Saint-Paul-le-Gaultier');

INSERT INTO Organisation (numero,adresse) VALUES
(7266,'579 Labussiere Foret, 64450 Thèze'),
(7267,'294 Villaret, 08130 Coulommes-et-Marqueny');

INSERT INTO Organisation (numero,adresse) VALUES
(7268,'301 Jaunac, 25300 Granges-Narboz'),
(7269,'468 Les Canebiers, 04230 Ongles');

INSERT INTO Organisation (numero,adresse) VALUES
(7270,'44 Marsagues, 47140 Trémons'),
(7271,'102 Pre de 14 Jours, 71620 Montcoy');

INSERT INTO Organisation (numero,adresse) VALUES
(7272,'133 Allée Laura Borla, 31570 Préserville'),
(7273,'130bis Neurière, 46230 Laburgade');

INSERT INTO Organisation (numero,adresse) VALUES
(7274,'418 La Joupa, 17430 Saint-Coutant-le-Grand'),
(7275,'91 Rey, 34400 Lunel');

INSERT INTO Organisation (numero,adresse) VALUES
(7276,'495bis La Babiole, 39130 Soucia'),
(7277,'864 Le Louvier, 62550 Bours');

INSERT INTO Organisation (numero,adresse) VALUES
(7278,'100 Les Amourals, 70000 Charmoille'),
(7279,'715 Résidence La Pommeraie, 47180 Castelnau-sur-Gupie');

INSERT INTO Organisation (numero,adresse) VALUES
(7280,'759 Allée Dizzy Gillespi, 76690 Fontaine-le-Bourg'),
(7281,'850 Pre du Tour, 76280 Anglesqueville-l''Esneval');

INSERT INTO Organisation (numero,adresse) VALUES
(7282,'367 Le Fond de la Bouloie, 43150 Moudeyres'),
(7283,'194bis Lotissement du Château, 46110 Carennac');

INSERT INTO Organisation (numero,adresse) VALUES
(7284,'265 L''Oustalet, 50480 Vierville'),
(7285,'359 Le Haut Moulin, 11500 Saint-Martin-Lys');

INSERT INTO Organisation (numero,adresse) VALUES
(7286,'551 Bregous, 79600 Saint-Loup-Lamairé'),
(7287,'158 Ferme de Martinpré, 09140 Ustou');

INSERT INTO Organisation (numero,adresse) VALUES
(7288,'36 Saint Germain, 52250 Baissey'),
(7289,'228 Terrain de tennis, 38490 Les Abrets en Dauphiné');

INSERT INTO Organisation (numero,adresse) VALUES
(7290,'289 La Jeannette, 19600 Chasteaux'),
(7291,'427bis Séguret, 45220 Saint-Germain-des-Prés');

INSERT INTO Organisation (numero,adresse) VALUES
(7292,'19 L''Esperance, 73300 Le Châtel'),
(7293,'36bis Le Prignolet, 17600 Corme-Royal');

INSERT INTO Organisation (numero,adresse) VALUES
(7294,'3bis Pres Raviers, 25640 Val-de-Roulans'),
(7295,'960bis Puechségat, 67340 Menchhoffen');

INSERT INTO Organisation (numero,adresse) VALUES
(7296,'500bis Les Pinquies, 10500 Crespy-le-Neuf'),
(7297,'661bis Le Bois de Chantraine, 70170 Chaux-lès-Port');

INSERT INTO Organisation (numero,adresse) VALUES
(7298,'73 Mas de Miquel, 55200 Lérouville'),
(7299,'792 Vieux Pont de La Pointe, 71170 Chauffailles');

INSERT INTO Organisation (numero,adresse) VALUES
(7300,'420 Les Ermes, 57970 Stuckange'),
(7301,'381 La Ferriere de la Prade, 37110 Neuville-sur-Brenne');

INSERT INTO Organisation (numero,adresse) VALUES
(7302,'624bis Impasse Capron, 10240 Longsols'),
(7303,'288 Le Bois Saint Menge, 39570 Saint-Didier');

INSERT INTO Organisation (numero,adresse) VALUES
(7304,'480 Camp Del Rey, 11110 Armissan'),
(7305,'192 Le Quartier Neuf, 30570 Saint-André-de-Majencoules');

INSERT INTO Organisation (numero,adresse) VALUES
(7306,'398 Le Bocage Saint Veran, 07510 Cros-de-Géorand'),
(7307,'390 """ Les Fontibiers """, 43700 Chaspinhac');

INSERT INTO Organisation (numero,adresse) VALUES
(7308,'925 Le Bournhou, 80360 Hardecourt-aux-Bois'),
(7309,'987 Nauriol Bas, 61390 Courtomer');

INSERT INTO Organisation (numero,adresse) VALUES
(7310,'71 Bruscatel, 54370 Bezange-la-Grande'),
(7311,'255 Mas Edouard, 11110 Vinassan');

INSERT INTO Organisation (numero,adresse) VALUES
(7312,'24bis Le Chantillty A, 16480 Passirac'),
(7313,'803bis Potachet Est, 41330 Saint-Bohaire');

INSERT INTO Organisation (numero,adresse) VALUES
(7314,'665bis Le Campet, 56320 Lanvénégen'),
(7315,'272 Lieu Dit Rouzat, 60380 Grémévillers');

INSERT INTO Organisation (numero,adresse) VALUES
(7316,'246 Chemin Alessandrini, 70100 Velesmes-Échevanne'),
(7317,'693 Janery, 33370 Pompignac');

INSERT INTO Organisation (numero,adresse) VALUES
(7318,'560 Passage Marco Grilli, 79300 Argentonnay'),
(7319,'541 Le Martinet, 24130 Laveyssière');

INSERT INTO Organisation (numero,adresse) VALUES
(7320,'275 Varambon, 62760 Thièvres'),
(7321,'582 Voie liaison Chemin de la Ginestière - Chemin de Crémat - Rue Benoît Aonzo, 24400 Mussidan');

INSERT INTO Organisation (numero,adresse) VALUES
(7322,'369 Point Eau Incendie n° 1004 (borne d''incendie), 39230 Sellières'),
(7323,'819 Ricalet, 21310 Noiron-sur-Bèze');

INSERT INTO Organisation (numero,adresse) VALUES
(7324,'654 Hameau de Rosy, 20217 Nonza'),
(7325,'139bis Le Creux Sale, 08430 Hagnicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(7326,'794bis Pépissou, 17150 Saint-Thomas-de-Conac'),
(7327,'537bis Le bas Serre, 67920 Sundhouse');

INSERT INTO Organisation (numero,adresse) VALUES
(7328,'98 lieu-dit Le Marrou, 24330 Saint-Crépin-d''Auberoche'),
(7329,'26 À la Croix d''Ain, 08400 Grivy-Loisy');

INSERT INTO Organisation (numero,adresse) VALUES
(7330,'727 La-cullee-damameline, 40250 Hauriet'),
(7331,'898 Chemin de l''Abbaye, 14570 Saint-Rémy');

INSERT INTO Organisation (numero,adresse) VALUES
(7332,'141 Jourda, 70200 Moffans-et-Vacheresse'),
(7333,'143bis Les Lauriers Roses A-B-C, 73310 Motz');

INSERT INTO Organisation (numero,adresse) VALUES
(7334,'37 Etang de Fabre, 15300 Ussel'),
(7335,'507 Ferme d''Artois, 16700 Londigny');

INSERT INTO Organisation (numero,adresse) VALUES
(7336,'148 Le Fustié, 77370 Fontains'),
(7337,'807bis Moulin de lembaurat, 61160 Fel');

INSERT INTO Organisation (numero,adresse) VALUES
(7338,'746 Foyer de vie, 51110 Lavannes'),
(7339,'707bis Derrière Saint-Jean Est, 02200 Buzancy');

INSERT INTO Organisation (numero,adresse) VALUES
(7340,'28bis Le Louage Tixier, 50420 Saint-Vigor-des-Monts'),
(7341,'463bis Cantafau de Cirou, 32140 Lourties-Monbrun');

INSERT INTO Organisation (numero,adresse) VALUES
(7342,'43 Pré François, 62450 Bapaume'),
(7343,'125 La Goellette, 80410 Cayeux-sur-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(7344,'874bis Le Mas Rouget, 02130 Fère-en-Tardenois'),
(7345,'468 La Maroune, 36210 Saint-Christophe-en-Bazelle');

INSERT INTO Organisation (numero,adresse) VALUES
(7346,'459bis Combe Chastel, 49130 Saint-Jean-de-la-Croix'),
(7347,'622bis Les Teilles, 62450 Avesnes-lès-Bapaume');

INSERT INTO Organisation (numero,adresse) VALUES
(7348,'355 Pres du Pont, 77320 La Chapelle-Moutils'),
(7349,'963bis Trastet, 33220 Port-Sainte-Foy-et-Ponchapt');

INSERT INTO Organisation (numero,adresse) VALUES
(7350,'353 La Grande Fortelle, 60420 Léglantiers'),
(7351,'468bis Allée du S/l''Francois d''Orleans, 37290 Bossay-sur-Claise');

INSERT INTO Organisation (numero,adresse) VALUES
(7352,'979 Sous-Murat, 47340 Saint-Robert'),
(7353,'193 Merre, 63520 Trézioux');

INSERT INTO Organisation (numero,adresse) VALUES
(7354,'154 """ Brossiere """, 10190 Vauchassis'),
(7355,'892 Chemin de Chemin de Brucelles, 60480 Montreuil-sur-Brêche');

INSERT INTO Organisation (numero,adresse) VALUES
(7356,'721bis Piece Brulee, 50310 Fresville'),
(7357,'916bis Voie de service Autoroute A8 dite la Provencale, 24540 Vergt-de-Biron');

INSERT INTO Organisation (numero,adresse) VALUES
(7358,'538 Route de Cantarel, 59158 Maulde'),
(7359,'491 Bialès, 03500 Louchy-Montfand');

INSERT INTO Organisation (numero,adresse) VALUES
(7360,'656bis Jonction Boulevard Durandy - Pr Maurice Rouvier, 47270 Saint-Maurin'),
(7361,'112 L''Aparté, 65250 Bazus-Neste');

INSERT INTO Organisation (numero,adresse) VALUES
(7362,'910 L''Arrete Poulet, 66320 Rigarda'),
(7363,'941 Traverse Flandres-Dunkerque 1940, 56140 Saint-Marcel');

INSERT INTO Organisation (numero,adresse) VALUES
(7364,'983 Domaine Derriers, 70110 Montjustin-et-Velotte'),
(7365,'233bis villa le Milou, 61570 Boissei-la-Lande');

INSERT INTO Organisation (numero,adresse) VALUES
(7366,'420 Pourret, 21320 Chazilly'),
(7367,'552 Saint-Andeol, 62690 Villers-Châtel');

INSERT INTO Organisation (numero,adresse) VALUES
(7368,'193 Le Pre-saint-juvin, 74150 Crempigny-Bonneguête'),
(7369,'918 Puech du Gridou, 76750 Estouteville-Écalles');

INSERT INTO Organisation (numero,adresse) VALUES
(7370,'600bis bussac, 21150 Gissey-sous-Flavigny'),
(7371,'600bis Le Champ Tibier, 59190 Hondeghem');

INSERT INTO Organisation (numero,adresse) VALUES
(7372,'788 Bagot, 19360 Malemort'),
(7373,'236 Le Cabanou, 76440 Fontaine-en-Bray');

INSERT INTO Organisation (numero,adresse) VALUES
(7374,'383 Chemin rural n°3 de Maranwez à Saint-Jean-aux-Bois, 64120 Orsanco'),
(7375,'419 Lieu-dit Le Castelet, 77730 Nanteuil-sur-Marne');

INSERT INTO Organisation (numero,adresse) VALUES
(7376,'829 Colombe, 40250 Saint-Aubin'),
(7377,'558bis Pont de Grandfuel, 02000 Laon');

INSERT INTO Organisation (numero,adresse) VALUES
(7378,'815 Domaine du Bois d''Arreux, 60240 Vaudancourt'),
(7379,'806bis Le Vernay, 35133 Beaucé');

INSERT INTO Organisation (numero,adresse) VALUES
(7380,'809 Lotissement du Belvédère, 69400 Arnas'),
(7381,'650 Cougnas et jonquier, 32190 Cazaux-d''Anglès');

INSERT INTO Organisation (numero,adresse) VALUES
(7382,'300 Le Moulin Pacaud, 61310 Gouffern en Auge'),
(7383,'501 Voiles Blanches Bât A, 32480 La Romieu');

INSERT INTO Organisation (numero,adresse) VALUES
(7384,'901 Le Grand Terment, 77120 Marolles-en-Brie'),
(7385,'542bis Les Coumanines, 23190 Saint-Domet');

INSERT INTO Organisation (numero,adresse) VALUES
(7386,'476 Foyer Rural, 54620 Joppécourt'),
(7387,'670 Hameau de Chaudon, 63320 Saint-Diéry');

INSERT INTO Organisation (numero,adresse) VALUES
(7388,'205 quartier Gaudarrena, 80220 Bouttencourt'),
(7389,'77 Lapasse, 02160 Roucy');

INSERT INTO Organisation (numero,adresse) VALUES
(7390,'67 Prachazet, 31140 Montberon'),
(7391,'614bis Bordeau, 20212 Mazzola');

INSERT INTO Organisation (numero,adresse) VALUES
(7392,'696bis Roquenoire, 77150 Lésigny'),
(7393,'558bis Le Cote D''Azur, 27370 Le Bec-Thomas');

INSERT INTO Organisation (numero,adresse) VALUES
(7394,'990bis Le Temple, 17540 Le Gué-d''Alleré'),
(7395,'713bis La Croix, 14490 Planquery');

INSERT INTO Organisation (numero,adresse) VALUES
(7396,'929 Bonne Terre, 57830 Barchain'),
(7397,'293bis Lacroux de Quins, 19120 Sioniac');

INSERT INTO Organisation (numero,adresse) VALUES
(7398,'139bis Les Chaumes Blanches, 66320 Valmanya'),
(7399,'213 Freychet, 02120 Hauteville');

INSERT INTO Organisation (numero,adresse) VALUES
(7400,'63 Les Feuilles, 02140 Dagny-Lambercy'),
(7401,'471bis Magnans et Bellarots, 22340 Treffrin');

INSERT INTO Organisation (numero,adresse) VALUES
(7402,'558 Blanches Terres, 44860 Pont-Saint-Martin'),
(7403,'95 Chez Guerinot, 27290 Glos-sur-Risle');

INSERT INTO Organisation (numero,adresse) VALUES
(7404,'493bis Brienne, 73800 Saint-Pierre-de-Soucy'),
(7405,'714 Champ de la Couilleure, 57910 Hambach');

INSERT INTO Organisation (numero,adresse) VALUES
(7406,'461 Ferme de la Nouette, 20246 Piève'),
(7407,'163bis Lou Mas Flouri, 62890 Muncq-Nieurlet');

INSERT INTO Organisation (numero,adresse) VALUES
(7408,'873 Chemin Privé de la Cité Lyautey Franchet d''Esperey, 51190 Avize'),
(7409,'249 Chemin de la Gane, 43100 Brioude');

INSERT INTO Organisation (numero,adresse) VALUES
(7410,'404 Villa Cadia, 57320 Chémery-les-Deux'),
(7411,'615bis La Croix Du Sud, 38380 Saint-Christophe-sur-Guiers');

INSERT INTO Organisation (numero,adresse) VALUES
(7412,'360 Le Castel Des Arts, 51300 Bignicourt-sur-Marne'),
(7413,'394 Pratmau, 54113 Crézilles');

INSERT INTO Organisation (numero,adresse) VALUES
(7414,'768 Cazomaury, 46800 Lascabanes'),
(7415,'199 Palais de Justice, 70240 Genevrey');

INSERT INTO Organisation (numero,adresse) VALUES
(7416,'23 Villa Lys, 80400 Eppeville'),
(7417,'35 Lieu Dit Borde Crémade, 77260 Reuil-en-Brie');

INSERT INTO Organisation (numero,adresse) VALUES
(7418,'239 La Petite Angeniere, 50490 La Ronde-Haye'),
(7419,'481 Castellet Saint Cassien, 14480 Colombiers-sur-Seulles');

INSERT INTO Organisation (numero,adresse) VALUES
(7420,'91 La Calmesie, 41320 Saint-Loup'),
(7421,'800bis Le Rozet, 51170 Unchair');

INSERT INTO Organisation (numero,adresse) VALUES
(7422,'285 Les Hauts De Caucours, 58110 Brinay'),
(7423,'234 Villa Tym, 10500 Lassicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(7424,'433bis Gour de Bade, 42990 Saint-Georges-en-Couzan'),
(7425,'846 Les Mourinqs, 69970 Chaponnay');

INSERT INTO Organisation (numero,adresse) VALUES
(7426,'103bis Fond de Lavaux, 09240 Allières'),
(7427,'542 Pre Carre, 34360 Cébazan');

INSERT INTO Organisation (numero,adresse) VALUES
(7428,'733 Saint-Foujasse, 28270 Les Châtelets'),
(7429,'34 Puech de Lande Raze, 47290 Monviel');

INSERT INTO Organisation (numero,adresse) VALUES
(7430,'331 Le Moulon Souchon, 38620 Saint-Sulpice-des-Rivoires'),
(7431,'819 Le Presbytère, 57910 Neufgrange');

INSERT INTO Organisation (numero,adresse) VALUES
(7432,'278 Serre Souteyrol, 24240 Saussignac'),
(7433,'641 Charbonneau, 73000 Bassens');

INSERT INTO Organisation (numero,adresse) VALUES
(7434,'525 Chemin de la Grange Volet, 80132 Grand-Laviers'),
(7435,'54bis Allee Bugatti, 54730 Ville-Houdlémont');

INSERT INTO Organisation (numero,adresse) VALUES
(7436,'591 Monument des Sténographes, 60190 Gournay-sur-Aronde'),
(7437,'609bis La Casita, 71210 Saint-Julien-sur-Dheune');

INSERT INTO Organisation (numero,adresse) VALUES
(7438,'411 Champ de Chassignole, 50290 Bréhal'),
(7439,'915 Lescure Fangel, 18210 Thaumiers');

INSERT INTO Organisation (numero,adresse) VALUES
(7440,'758 Volada, 29460 Irvillac'),
(7441,'485bis Bel Air Nord, 16300 Saint-Médard');

INSERT INTO Organisation (numero,adresse) VALUES
(7442,'57 Chemin Départemental N°19, 73100 Grésy-sur-Aix'),
(7443,'144 Pomballet, 54420 Cerville');

INSERT INTO Organisation (numero,adresse) VALUES
(7444,'528 Chemin Voyeux des Vaches, 15500 Celoux'),
(7445,'908 L''Islet Bas, 32290 Pouydraguin');

INSERT INTO Organisation (numero,adresse) VALUES
(7446,'125 Abietta de Salomon, 54810 Longlaville'),
(7447,'122bis Croix de la Besse, 57140 Woippy');

INSERT INTO Organisation (numero,adresse) VALUES
(7448,'634bis Montginou, 59270 Godewaersvelde'),
(7449,'849 Niquel, 14220 Espins');

INSERT INTO Organisation (numero,adresse) VALUES
(7450,'810 Le Peyrol, 37270 Montlouis-sur-Loire'),
(7451,'885 Lieu-dit Espies, 52500 Poinson-lès-Fayl');

INSERT INTO Organisation (numero,adresse) VALUES
(7452,'665 Domaine de Chez Laire, 09300 Raissac'),
(7453,'259bis Terre des Saules, 21440 Pellerey');

INSERT INTO Organisation (numero,adresse) VALUES
(7454,'560 Armoire opérateurs téléphonniques Parking Mairie, 17410 Saint-Martin-de-Ré'),
(7455,'911bis La Lazerte, 42380 Estivareilles');

INSERT INTO Organisation (numero,adresse) VALUES
(7456,'386 Hameau de Caffelle, 21120 Crécey-sur-Tille'),
(7457,'382 Font de la Vergne, 60150 Mélicocq');

INSERT INTO Organisation (numero,adresse) VALUES
(7458,'849 Baraillé, 04340 Le Lauzet-Ubaye'),
(7459,'221 Ruelle du Rouillard, 18350 Saint-Hilaire-de-Gondilly');

INSERT INTO Organisation (numero,adresse) VALUES
(7460,'378 La Galopinière, 67350 Ringeldorf'),
(7461,'864 Les Bichons, 03220 Varennes-sur-Tèche');

INSERT INTO Organisation (numero,adresse) VALUES
(7462,'828 Restouil, 55210 Thillot'),
(7463,'699 Le Roudié, 46200 Saint-Sozy');

INSERT INTO Organisation (numero,adresse) VALUES
(7464,'821 Les Fontanes, 57925 Distroff'),
(7465,'604bis Bâtiment la Durance Entrée 5, 18130 Lantan');

INSERT INTO Organisation (numero,adresse) VALUES
(7466,'102 le Costal, 12350 Prévinquières'),
(7467,'734 Route de la Lauvette, 35380 Saint-Péran');

INSERT INTO Organisation (numero,adresse) VALUES
(7468,'370 Foillier, 54260 Othe'),
(7469,'329 Quai du Commerce, 64500 Ciboure');

INSERT INTO Organisation (numero,adresse) VALUES
(7470,'603 Gare de l''Estagnol, 30330 Gaujac'),
(7471,'773 1 écluse du Fresquel Pont Rouge Est, 80340 Cappy');

INSERT INTO Organisation (numero,adresse) VALUES
(7472,'468 Hameau de Terrefête, 62830 Doudeauville'),
(7473,'674 """ Foret de Messarges """, 25150 Villars-sous-Écot');

INSERT INTO Organisation (numero,adresse) VALUES
(7474,'680 Jardin Des Abondances, 77810 Thomery'),
(7475,'419bis Puausson, 60153 Rethondes');

INSERT INTO Organisation (numero,adresse) VALUES
(7476,'298 Bretelle Sortie N°56 A8 - Monaco (Provenance Cannes), 52120 Aizanville'),
(7477,'366 Le Chambonnet, 76220 Montroty');

INSERT INTO Organisation (numero,adresse) VALUES
(7478,'506 Les Clauzes Lapanouse, 47400 Lagruère'),
(7479,'62 Le Caupy, 44700 Orvault');

INSERT INTO Organisation (numero,adresse) VALUES
(7480,'183 Chemin de Dion Bouton, 08300 Doux'),
(7481,'929bis Sylvanjer, 09100 Saint-Martin-d''Oydes');

INSERT INTO Organisation (numero,adresse) VALUES
(7482,'791bis Roquebiliére, 61570 Almenêches'),
(7483,'442 Les Fossés, 74230 Manigod');

INSERT INTO Organisation (numero,adresse) VALUES
(7484,'145 Col de Garde, 65190 Orieux'),
(7485,'168bis Moulin de Bernard, 21690 Champrenault');

INSERT INTO Organisation (numero,adresse) VALUES
(7486,'260 Montée de Malignon, 32230 Cazaux-Villecomtal'),
(7487,'437 Lonnagou, 14420 Potigny');

INSERT INTO Organisation (numero,adresse) VALUES
(7488,'541bis Derrière Saint Jean Ouest, 11240 Mazerolles-du-Razès'),
(7489,'344 Maite, 14220 Saint-Laurent-de-Condel');

INSERT INTO Organisation (numero,adresse) VALUES
(7490,'365bis """ Les Reverets """, 51120 Péas'),
(7491,'308bis La Reginie, 25113 Sainte-Marie');

INSERT INTO Organisation (numero,adresse) VALUES
(7492,'384 Les Ziebles, 19430 Sexcles'),
(7493,'494 Travers de Miquelou, 77470 Trilport');

INSERT INTO Organisation (numero,adresse) VALUES
(7494,'303bis Residence Suffren, 72600 Panon'),
(7495,'875 Prés Marie, 28700 Umpeau');

INSERT INTO Organisation (numero,adresse) VALUES
(7496,'446bis La Pièce des Eaux, 25190 Feule'),
(7497,'536 La Garenne à Jean Margot, 31410 Mauzac');

INSERT INTO Organisation (numero,adresse) VALUES
(7498,'655bis Mirande, 39800 Abergement-le-Petit'),
(7499,'232 Lieu-dit La Douay, 38150 Bougé-Chambalud');

INSERT INTO Organisation (numero,adresse) VALUES
(7500,'46 Espinous, 55800 Noyers-Auzécourt'),
(7501,'818 1291 Route de l''Arbitelle, 59580 Aniche');

INSERT INTO Organisation (numero,adresse) VALUES
(7502,'635bis L’Horte, 08430 Champigneul-sur-Vence'),
(7503,'991 Campagnac, 76460 Ingouville');

INSERT INTO Organisation (numero,adresse) VALUES
(7504,'523 La croix du soldat, 71320 La Boulaye'),
(7505,'528bis Mairie Service Urbanisme Droit des Sols, 09230 Sainte-Croix-Volvestre');

INSERT INTO Organisation (numero,adresse) VALUES
(7506,'871 Le Palais Du Soleil, 29770 Plogoff'),
(7507,'767bis Prats de Rillo, 40270 Bordères-et-Lamensans');

INSERT INTO Organisation (numero,adresse) VALUES
(7508,'652bis Le Champ Louvia, 73230 Thoiry'),
(7509,'713 Logis-neuf, 46100 Camboulit');

INSERT INTO Organisation (numero,adresse) VALUES
(7510,'281 Rue du Tranchat, 63890 Grandval'),
(7511,'115 Seveyrac-Haut, 20118 Coggia');

INSERT INTO Organisation (numero,adresse) VALUES
(7512,'188bis Impasse du Carretier, 14600 Honfleur'),
(7513,'217 Saint Simon, 05800 Saint-Firmin');

INSERT INTO Organisation (numero,adresse) VALUES
(7514,'317bis La Grangasse, 01430 Outriaz'),
(7515,'944 "Lotissement ""LES JULIENS""", 68380 Breitenbach-Haut-Rhin');

INSERT INTO Organisation (numero,adresse) VALUES
(7516,'513 Baus de Mars, 56220 Rochefort-en-Terre'),
(7517,'165 Les Carbonnels, 70100 Beaujeu-Saint-Vallier-Pierrejux-et-Quitteur');

INSERT INTO Organisation (numero,adresse) VALUES
(7518,'985 Lieu-dit Mourouet, 63570 Saint-Jean-Saint-Gervais'),
(7519,'140 Le tremblay, 66730 Sournia');

INSERT INTO Organisation (numero,adresse) VALUES
(7520,'416bis Les Chaillots, 19320 Marcillac-la-Croisille'),
(7521,'443 Les Chaises, 34270 Cazevieille');

INSERT INTO Organisation (numero,adresse) VALUES
(7522,'17 La Chatelle, 18210 Bannegon'),
(7523,'364 Bourgogne Haut, 35130 Arbrissel');

INSERT INTO Organisation (numero,adresse) VALUES
(7524,'966 Mardalon, 39130 Saint-Maurice-Crillat'),
(7525,'334 Ancien couvent des Cordeliers, 49320 Gennes');

INSERT INTO Organisation (numero,adresse) VALUES
(7526,'586 Aire Camping cars, 62158 La Herlière'),
(7527,'908 Ruelle du Cornet, 69440 Saint-André-la-Côte');

INSERT INTO Organisation (numero,adresse) VALUES
(7528,'136 Col de Paluel, 08150 Harcy'),
(7529,'149 Hounal, 59173 Sercus');

INSERT INTO Organisation (numero,adresse) VALUES
(7530,'554 Les Horts, 46270 Felzins'),
(7531,'570bis La Gastounette, 39290 Montmirey-la-Ville');

INSERT INTO Organisation (numero,adresse) VALUES
(7532,'371 Pre Du Nez, 65670 Monlong'),
(7533,'252 Colognac, 70110 Senargent-Mignafans');

INSERT INTO Organisation (numero,adresse) VALUES
(7534,'413 Balade, 25410 Villars-Saint-Georges'),
(7535,'667 Le Gros Poirier, 63840 Sauvessanges');

INSERT INTO Organisation (numero,adresse) VALUES
(7536,'140bis La Jasso, 59288 Preux-au-Bois'),
(7537,'455bis Voie de l''Ecole du Bois de Boulogne ouest, 70700 Angirey');

INSERT INTO Organisation (numero,adresse) VALUES
(7538,'768bis La Ruelle Ébaine, 50390 Golleville'),
(7539,'747bis Pres l''Abattoir, 58190 Saizy');

INSERT INTO Organisation (numero,adresse) VALUES
(7540,'343 Le Lotissement, 11170 Moussoulens'),
(7541,'357 Sainte-Margueritte, 38260 Champier');

INSERT INTO Organisation (numero,adresse) VALUES
(7542,'49 Le Gros Pre, 70270 Saint-Barthélemy'),
(7543,'536 La Pesquie, 42460 Sevelinges');

INSERT INTO Organisation (numero,adresse) VALUES
(7544,'402 La Guillauderie, 76190 Carville-la-Folletière'),
(7545,'123bis Chemin d''exploitation n°1, 27330 La Vieille-Lyre');

INSERT INTO Organisation (numero,adresse) VALUES
(7546,'756 Champ Layssard, 61500 Bursard'),
(7547,'719 Bayle, 15100 Alleuze');

INSERT INTO Organisation (numero,adresse) VALUES
(7548,'59 Champ Besson, 55220 Saint-André-en-Barrois'),
(7549,'732bis Garenne de Combernon, 31510 Sauveterre-de-Comminges');

INSERT INTO Organisation (numero,adresse) VALUES
(7550,'639 Matefan, 73300 Hermillon'),
(7551,'812 Les Vabres, 25640 Blarians');

INSERT INTO Organisation (numero,adresse) VALUES
(7552,'229bis Poète, 42800 Saint-Romain-en-Jarez'),
(7553,'318 Ribière, 63390 Espinasse');

INSERT INTO Organisation (numero,adresse) VALUES
(7554,'174 Coulet Goudin, 34310 Montady'),
(7555,'949 Connes, 32230 Troncens');

INSERT INTO Organisation (numero,adresse) VALUES
(7556,'646bis Gué de Sioule et les Rathi, 53370 Boulay-les-Ifs'),
(7557,'95 Chante au vent, 10430 Rosières-près-Troyes');

INSERT INTO Organisation (numero,adresse) VALUES
(7558,'814 Landry, 59530 Villereau'),
(7559,'127 Le Poirier Gourmaux, 69690 Courzieu');

INSERT INTO Organisation (numero,adresse) VALUES
(7560,'411 Bâtiment Le cyste Entrée 10, 08430 Jandun'),
(7561,'851 Les Graniols, 38260 Champier');

INSERT INTO Organisation (numero,adresse) VALUES
(7562,'933 Champ d''Abrard, 66760 Angoustrine-Villeneuve-des-Escaldes'),
(7563,'846 Salle Municipale Dieter Trennheuser - ERP, 23300 Saint-Priest-la-Feuille');

INSERT INTO Organisation (numero,adresse) VALUES
(7564,'865 Le Puech de Lagriffoul, 13700 Saint-Victoret'),
(7565,'343 Hlm le Plessis Bat I4, 47000 Agen');

INSERT INTO Organisation (numero,adresse) VALUES
(7566,'535 Fourcadelle, 39330 Mouchard'),
(7567,'360 Rue des Maires, 27210 Saint-Pierre-du-Val');

INSERT INTO Organisation (numero,adresse) VALUES
(7568,'69 Le Mas de Frayssinhes, 21500 Champ-d''Oiseau'),
(7569,'168 Les Fabres, 72260 Dissé-sous-Ballon');

INSERT INTO Organisation (numero,adresse) VALUES
(7570,'970 Montcalmet, 14700 Villy-lez-Falaise'),
(7571,'153 Le Village de Chemery, 09800 Sor');

INSERT INTO Organisation (numero,adresse) VALUES
(7572,'891bis Closures mauvaises, 21140 Souhey'),
(7573,'11 Voie Communale Rouette des Chataigniers, 77111 Soignolles-en-Brie');

INSERT INTO Organisation (numero,adresse) VALUES
(7574,'946 Olmet, 27520 Theillement'),
(7575,'191 Les Tinettes, 15000 Aurillac');

INSERT INTO Organisation (numero,adresse) VALUES
(7576,'42 Chante Merle Nord, 35630 Saint-Brieuc-des-Iffs'),
(7577,'357bis Le Crouzet Est, 12210 Cassuéjouls');

INSERT INTO Organisation (numero,adresse) VALUES
(7578,'476 Cap d''Ase, 39270 La Chailleuse'),
(7579,'559 Les Glaires, 53360 Saint-Sulpice');

INSERT INTO Organisation (numero,adresse) VALUES
(7580,'229 Rue Honoré Sauvan, 64330 Aydie'),
(7581,'507bis La Maison Bompart, 02380 Verneuil-sous-Coucy');

INSERT INTO Organisation (numero,adresse) VALUES
(7582,'822 Bretelle Sortie Avenue des Sapeurs Pompiers de Nice - Pont de la Première Division Française Libre, 25170 Chevigney-sur-l''Ognon'),
(7583,'13 Parc des Chênes Verts, 27350 Hauville');

INSERT INTO Organisation (numero,adresse) VALUES
(7584,'731 Impasse de l''Eau Fraîche, 02400 Belleau'),
(7585,'451bis La Peyriere, 45210 Rozoy-le-Vieil');

INSERT INTO Organisation (numero,adresse) VALUES
(7586,'204 Lotissement Peyrot, 61390 Saint-Germain-le-Vieux'),
(7587,'623 Voie Communale La Pouge, 76400 Contremoulins');

INSERT INTO Organisation (numero,adresse) VALUES
(7588,'175 Grande Paroisse, 58190 Metz-le-Comte'),
(7589,'185 Ancien chemin de Valbonne, 70400 Granges-le-Bourg');

INSERT INTO Organisation (numero,adresse) VALUES
(7590,'123 Lieu-dit Touchis, 25110 Lomont-sur-Crête'),
(7591,'90 Le Nid des Leups, 11120 Ginestas');

INSERT INTO Organisation (numero,adresse) VALUES
(7592,'255 La Brande de Viplaix, 27930 Sassey'),
(7593,'586 Les Boltes, 71310 La Chapelle-Saint-Sauveur');

INSERT INTO Organisation (numero,adresse) VALUES
(7594,'161 Place de la Pétanque, 69840 Juliénas'),
(7595,'82 Miquels, 50800 Fleury');

INSERT INTO Organisation (numero,adresse) VALUES
(7596,'744 Sus Carriere, 54290 Crévéchamps'),
(7597,'499bis Vigne Maillet, 80370 Heuzecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(7598,'371bis Square Victoria, 14540 Soliers'),
(7599,'93 Cammazou-haut, 24600 Segonzac');

INSERT INTO Organisation (numero,adresse) VALUES
(7600,'831 Chemin de Coude, 42920 Chalmazel-Jeansagnière'),
(7601,'73 Domaine du Bois Joli, 35650 Le Rheu');

INSERT INTO Organisation (numero,adresse) VALUES
(7602,'612 En Saumont, 53220 Pontmain'),
(7603,'544bis Therondels, 40410 Liposthey');

INSERT INTO Organisation (numero,adresse) VALUES
(7604,'512 Le Moulin Dudot, 23170 Lépaud'),
(7605,'81 Liaison Avenue Emile Henriot - Rue Louis de Coppet, 26170 Plaisians');

INSERT INTO Organisation (numero,adresse) VALUES
(7606,'108 Le Bas des Bordes, 55190 Villeroy-sur-Méholle'),
(7607,'103bis Au Carteron, 76740 Le Bourg-Dun');

INSERT INTO Organisation (numero,adresse) VALUES
(7608,'394 Château Capitoul, 56930 Pluméliau'),
(7609,'96 Sainte-Scolastique, 62185 Saint-Tricat');

INSERT INTO Organisation (numero,adresse) VALUES
(7610,'613 Avenue Jean Marguerite, 59152 Chéreng'),
(7611,'792bis Champ de Rame haut, 80250 Chaussoy-Epagny');

INSERT INTO Organisation (numero,adresse) VALUES
(7612,'313 Jardin Boulevard Henri Sappia, 11700 Capendu'),
(7613,'204bis Lubac, 10140 Briel-sur-Barse');

INSERT INTO Organisation (numero,adresse) VALUES
(7614,'902 Meljac, 33710 Tauriac'),
(7615,'303bis Mas Saint Esprit, 57170 Gerbécourt');

INSERT INTO Organisation (numero,adresse) VALUES
(7616,'673bis Grange Ballet, 64220 Lasse'),
(7617,'249bis Dessus la Fontaine Saint-Martin, 72160 Thorigné-sur-Dué');

INSERT INTO Organisation (numero,adresse) VALUES
(7618,'243 Le Fajaou, 59554 Bantigny'),
(7619,'946 Pirly, 68130 Franken');

INSERT INTO Organisation (numero,adresse) VALUES
(7620,'768 Biolet, 58150 Saint-Quentin-sur-Nohain'),
(7621,'779 Les Tartès et Cabessades, 11700 Saint-Couat-d''Aude');

INSERT INTO Organisation (numero,adresse) VALUES
(7622,'346 Parc Castel des Deux Rois, 80135 Millencourt-en-Ponthieu'),
(7623,'590 Le Coustaras, 32130 Nizas');

INSERT INTO Organisation (numero,adresse) VALUES
(7624,'420 Dardenne d''En Haut, 65170 Vignec'),
(7625,'297 Chemin de Bonnaud, 24600 Bourg-du-Bost');

INSERT INTO Organisation (numero,adresse) VALUES
(7626,'607bis Chaupine de dessous, 15140 Fontanges'),
(7627,'376 Chalet Saint Ange, 18260 Thou');

INSERT INTO Organisation (numero,adresse) VALUES
(7628,'760 Passage du Paulin, 26120 Combovin'),
(7629,'896 Vallon, 42380 Saint-Nizier-de-Fornas');

INSERT INTO Organisation (numero,adresse) VALUES
(7630,'55 Route de saint Pourçain, 68320 Grussenheim'),
(7631,'964 La Roucayrie, 38140 Izeaux');

INSERT INTO Organisation (numero,adresse) VALUES
(7632,'410bis Res De La Baie A1, 45190 Beaugency'),
(7633,'115 Résidence Les Maisons de Leucate, 60300 Baron');

INSERT INTO Organisation (numero,adresse) VALUES
(7634,'64 Ville Haute, 39160 Saint-Amour'),
(7635,'247 Plaine de Meyre, 52360 Changey');

INSERT INTO Organisation (numero,adresse) VALUES
(7636,'959bis Le Bois, 21210 Champeau-en-Morvan'),
(7637,'512bis Les Salets, 62370 Polincove');

INSERT INTO Organisation (numero,adresse) VALUES
(7638,'134 Les Dahlias, 31190 Grépiac'),
(7639,'832 baudinotte, 54450 Frémonville');

INSERT INTO Organisation (numero,adresse) VALUES
(7640,'675 Allée du Rond-Point, 55270 Vauquois'),
(7641,'749 Le Village - Promenade de Lure, 39570 La Chailleuse');

INSERT INTO Organisation (numero,adresse) VALUES
(7642,'767 La Bézonie, 76660 Fresnoy-Folny'),
(7643,'210 Le Champ de Carlies, 03320 Couleuvre');

INSERT INTO Organisation (numero,adresse) VALUES
(7644,'525 Racouneau, 55190 Broussey-en-Blois'),
(7645,'997 La Roseraie, 68870 Bartenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(7646,'15bis Le Bois des Haies, 64350 Lannecaube'),
(7647,'10 Contree de l''Etang Gouyat, 09500 Camon');

INSERT INTO Organisation (numero,adresse) VALUES
(7648,'809bis Carratieres Basses, 65350 Jacque'),
(7649,'655 Fontaine de la Vernéa, 16700 Villegats');

INSERT INTO Organisation (numero,adresse) VALUES
(7650,'659 Maisons Neuves, 66220 Fosse'),
(7651,'479bis Montbrun, 70240 Varogne');

INSERT INTO Organisation (numero,adresse) VALUES
(7652,'179bis Villa Eden, 54470 Essey-et-Maizerais'),
(7653,'359 Gardivol, 11360 Cascastel-des-Corbières');

INSERT INTO Organisation (numero,adresse) VALUES
(7654,'385 Bourrelle, 29180 Quéménéven'),
(7655,'188bis ZI les Pivoisons, 35320 Pancé');

INSERT INTO Organisation (numero,adresse) VALUES
(7656,'890bis Castelarou, 48340 Les Hermaux'),
(7657,'394 Clairefontaine, 71250 Chérizet');

INSERT INTO Organisation (numero,adresse) VALUES
(7658,'637 Revol, 21390 Normier'),
(7659,'750 Cart Cigale, 70400 Vyans-le-Val');

INSERT INTO Organisation (numero,adresse) VALUES
(7660,'665 Moyenne Cairosina, 16190 Deviat'),
(7661,'246 Serre de Mouréou, 27400 La Vacherie');

INSERT INTO Organisation (numero,adresse) VALUES
(7662,'189 Champ du Cros, 07340 Charnas'),
(7663,'763 Prat de Jacquou, 51240 La Chaussée-sur-Marne');

INSERT INTO Organisation (numero,adresse) VALUES
(7664,'790 Rue des Chèvres, 26330 Ratières'),
(7665,'238bis Cercy, 04240 Le Fugeret');

INSERT INTO Organisation (numero,adresse) VALUES
(7666,'461 Les Costes et les Cledes, 20252 Lento'),
(7667,'56bis la Carbonniere, 21440 Bligny-le-Sec');

INSERT INTO Organisation (numero,adresse) VALUES
(7668,'982bis la Vigne, 14400 Saint-Martin-des-Entrées'),
(7669,'248bis Les Placettes, 52300 Vaux-sur-Saint-Urbain');

INSERT INTO Organisation (numero,adresse) VALUES
(7670,'162bis Lieu dit Onzo, 80140 Fontaine-le-Sec'),
(7671,'938 Station Gdf, 79190 Sauzé-Vaussais');

INSERT INTO Organisation (numero,adresse) VALUES
(7672,'638bis la Brousse, 33710 Pugnac'),
(7673,'26 Les Grillons 3, 47120 Auriac-sur-Dropt');

INSERT INTO Organisation (numero,adresse) VALUES
(7674,'842 Les Montants, 60380 Buicourt'),
(7675,'373 La Bernadasse, 47170 Réaup-Lisse');

INSERT INTO Organisation (numero,adresse) VALUES
(7676,'387bis Grange Grise, 31510 Labroquère'),
(7677,'64bis Cours des Colles et Regagnade, 48250 Luc');

INSERT INTO Organisation (numero,adresse) VALUES
(7678,'529 La Barbotte, 79370 Fressines'),
(7679,'158 Sénepjac, 32350 Mirannes');

INSERT INTO Organisation (numero,adresse) VALUES
(7680,'121bis Etang Pochon, 10400 Barbuise'),
(7681,'847 Saint Rocq, 54190 Bréhain-la-Ville');

INSERT INTO Organisation (numero,adresse) VALUES
(7682,'52 Campan, 51800 Sivry-Ante'),
(7683,'780 Roc de BELVIS, 64150 Lagor');

INSERT INTO Organisation (numero,adresse) VALUES
(7684,'927 Domaine de Bela Bisto, 46320 Issepts'),
(7685,'796bis La Mandre, 12310 Laissac-Sévérac l''Église');

INSERT INTO Organisation (numero,adresse) VALUES
(7686,'609 Falgayroles Bas, 69620 Chamelet'),
(7687,'210 Gorry, 01570 Feillens');

INSERT INTO Organisation (numero,adresse) VALUES
(7688,'416 Puech Blanc, 50500 Catz'),
(7689,'588bis Les Pussalons, 79190 Caunay');

INSERT INTO Organisation (numero,adresse) VALUES
(7690,'621 La Maure, 52140 Avrecourt'),
(7691,'533 Le Triage d''Harcy, 32380 Gaudonville');

INSERT INTO Organisation (numero,adresse) VALUES
(7692,'211bis Lasbros, 23160 La Chapelle-Baloue'),
(7693,'725bis Julia, 60129 Orrouy');

INSERT INTO Organisation (numero,adresse) VALUES
(7694,'675bis Impasse des Ecoliers, 29120 Combrit'),
(7695,'284bis Born, 39130 Largillay-Marsonnay');

INSERT INTO Organisation (numero,adresse) VALUES
(7696,'723 Rieusset, 69840 Cenves'),
(7697,'850 Villa Benji, 57710 Aumetz');

INSERT INTO Organisation (numero,adresse) VALUES
(7698,'634 L’Armandes, 33390 Eyrans'),
(7699,'530 Peyssonnieres, 12700 Causse-et-Diège');

INSERT INTO Organisation (numero,adresse) VALUES
(7700,'566bis Le Domaine Buisson, 03310 Durdat-Larequille'),
(7701,'466bis Le Serre des Rands, 09460 Mijanès');

INSERT INTO Organisation (numero,adresse) VALUES
(7702,'791 Lotissement les Côteaux de la Treille II, 02490 Vendelles'),
(7703,'748bis Rives Sud, 62126 Conteville-lès-Boulogne');

INSERT INTO Organisation (numero,adresse) VALUES
(7704,'33 Chez Pometot, 76660 Bailleul-Neuville'),
(7705,'104 Filagne, 21130 Flammerans');

INSERT INTO Organisation (numero,adresse) VALUES
(7706,'670 TIRECOUI- La Rouede, 49122 Bégrolles-en-Mauges'),
(7707,'841 Rue de la Scierie, 22630 Saint-Juvat');

INSERT INTO Organisation (numero,adresse) VALUES
(7708,'113 Le Grand Limon, 27630 Heubécourt-Haricourt'),
(7709,'347bis Cap de Roumany, 39160 Thoissia');

INSERT INTO Organisation (numero,adresse) VALUES
(7710,'812 Pre Menard, 39130 Pont-de-Poitte'),
(7711,'843 Amen, 25550 Raynans');

INSERT INTO Organisation (numero,adresse) VALUES
(7712,'363 Lieu-dit Les Oches, 58340 Saint-Gratien-Savigny'),
(7713,'999 Croix de Fer, 42470 Fourneaux');

INSERT INTO Organisation (numero,adresse) VALUES
(7714,'559bis Laleuf, 48600 Auroux'),
(7715,'642 Villemagne, 31180 Saint-Geniès-Bellevue');

INSERT INTO Organisation (numero,adresse) VALUES
(7716,'996 L''Ibac, 35250 Andouillé-Neuville'),
(7717,'570 Ginebres, 34800 Ceyras');

INSERT INTO Organisation (numero,adresse) VALUES
(7718,'619bis Arbas, 06590 Théoule-sur-Mer'),
(7719,'449 Jardin des Moulins, 73250 Fréterive');

INSERT INTO Organisation (numero,adresse) VALUES
(7720,'752bis L''Hippocampe, 71290 Loisy'),
(7721,'287 Terrain de Tennis, 65370 Esbareich');

INSERT INTO Organisation (numero,adresse) VALUES
(7722,'693 Les Amaryllis, 63210 Orcival'),
(7723,'518bis Rome le Vieux, 41100 Selommes');

INSERT INTO Organisation (numero,adresse) VALUES
(7724,'382 Bâtiment Le basilic Entrée 2, 50490 Vaudrimesnil'),
(7725,'740 Albinet, 77460 Souppes-sur-Loing');

INSERT INTO Organisation (numero,adresse) VALUES
(7726,'347 Le Roudilhou, 16120 Viville'),
(7727,'621 Le Contour, 67700 Monswiller');

INSERT INTO Organisation (numero,adresse) VALUES
(7728,'961 Chignaux Vieux, 20237 Quercitello'),
(7729,'663 Les Petits Regains, 70240 Mollans');

INSERT INTO Organisation (numero,adresse) VALUES
(7730,'257 Res Lafayette B, 43390 Auzon'),
(7731,'996bis Le Cocas, 07160 Saint-Cierge-sous-le-Cheylard');

INSERT INTO Organisation (numero,adresse) VALUES
(7732,'231 Voie de liaison Ruelle des Prés - Rue Rancher, 74330 Sillingy'),
(7733,'340 Village de la Caille, 42160 Bonson');

INSERT INTO Organisation (numero,adresse) VALUES
(7734,'157 Les Corbes, 02160 Beaurieux'),
(7735,'56 Carrou, 60190 Estrées-Saint-Denis');

INSERT INTO Organisation (numero,adresse) VALUES
(7736,'613 Le Grand Mazeau, 25190 Liebvillers'),
(7737,'928 Chemin du Domaine de la Bauma, 63850 La Godivelle');

INSERT INTO Organisation (numero,adresse) VALUES
(7738,'387bis Vaysse, 77220 Liverdy-en-Brie'),
(7739,'174 Lieu Bourgeois Les Rougeards, 76500 Elbeuf');

INSERT INTO Organisation (numero,adresse) VALUES
(7740,'225bis Le Pre le Pretre, 43490 Costaros'),
(7741,'792bis Biolet, 68800 Rammersmatt');

INSERT INTO Organisation (numero,adresse) VALUES
(7742,'0 Lavilatte, 62450 Frémicourt'),
(7743,'90bis Impasse Lou Colombier, 51170 Faverolles-et-Coëmy');

INSERT INTO Organisation (numero,adresse) VALUES
(7744,'285bis Route du Donjon, 50510 Saint-Sauveur-la-Pommeraye'),
(7745,'57 Pont Loup, 08190 Sault-Saint-Remy');

INSERT INTO Organisation (numero,adresse) VALUES
(7746,'546 Ramade, 19300 Moustier-Ventadour'),
(7747,'625bis Le Bois de la Dame, 30129 Redessan');

INSERT INTO Organisation (numero,adresse) VALUES
(7748,'369 Saint Symphorien, 26150 Laval-d''Aix'),
(7749,'856 Les Allées des Ormeaux, 22340 Treffrin');

INSERT INTO Organisation (numero,adresse) VALUES
(7750,'317bis La Fabrèguerie, 39120 Neublans-Abergement'),
(7751,'465 Pouchole, 71390 Moroges');

INSERT INTO Organisation (numero,adresse) VALUES
(7752,'113 Les Aiguiers, 42800 Saint-Martin-la-Plaine'),
(7753,'435 Mairie Musée Numérique - Serv. Economique, 57460 Bousbach');

INSERT INTO Organisation (numero,adresse) VALUES
(7754,'222 La Raynaldiere, 24570 Condat-sur-Vézère'),
(7755,'31bis Les Traverses, 77111 Soignolles-en-Brie');

INSERT INTO Organisation (numero,adresse) VALUES
(7756,'698 Hotel L''Empreinte, 13920 Saint-Mitre-les-Remparts'),
(7757,'5 Villa Edith, 27150 Étrépagny');

INSERT INTO Organisation (numero,adresse) VALUES
(7758,'107 Bosc, 07340 Vinzieux'),
(7759,'568 L''Escayre d''en bas, 41120 Monthou-sur-Bièvre');

INSERT INTO Organisation (numero,adresse) VALUES
(7760,'256 Rabaute, 32380 Saint-Léonard'),
(7761,'85 Roque Bernade, 72170 Juillé');

INSERT INTO Organisation (numero,adresse) VALUES
(7762,'161bis Croix Jobert, 08170 Fépin'),
(7763,'480 les Bouteux, 64410 Mialos');

INSERT INTO Organisation (numero,adresse) VALUES
(7764,'194bis Col Del Four, 64410 Vignes'),
(7765,'815 Le Muret, 08090 Tournes');

INSERT INTO Organisation (numero,adresse) VALUES
(7766,'627 Le Temps Retrouve, 38840 Saint-Hilaire-du-Rosier'),
(7767,'421 Le Castelleras, 55190 Reffroy');

INSERT INTO Organisation (numero,adresse) VALUES
(7768,'363 Rond-Point  Daniel Labit, 36500 Neuillay-les-Bois'),
(7769,'904 Pont de la Pierre, 42380 La Tourette');

INSERT INTO Organisation (numero,adresse) VALUES
(7770,'360bis Escalier Olivetto - George V, 36290 Saulnay'),
(7771,'699 Les Granges Communes, 31370 Sajas');

INSERT INTO Organisation (numero,adresse) VALUES
(7772,'473 Combe de Veyle Nord, 77390 Chaumes-en-Brie'),
(7773,'805 Passage de la Caravelle, 80150 Le Boisle');

INSERT INTO Organisation (numero,adresse) VALUES
(7774,'925bis Les Pelottes, 33540 Landerrouet-sur-Ségur'),
(7775,'225 Rue Passade des Bains, 02320 Brancourt-en-Laonnois');

INSERT INTO Organisation (numero,adresse) VALUES
(7776,'641bis Le Chemin de Clermont, 63270 Saint-Maurice'),
(7777,'964bis Les Sentes à Pieds, 53700 Saint-Germain-de-Coulamer');

INSERT INTO Organisation (numero,adresse) VALUES
(7778,'150 Moun Oustal, 07190 Saint-Étienne-de-Serre'),
(7779,'57 Coudène, 44760 Les Moutiers-en-Retz');

INSERT INTO Organisation (numero,adresse) VALUES
(7780,'568 Gardin, 17260 Saint-Simon-de-Pellouaille'),
(7781,'832 Fontrebo, 71390 Saules');

INSERT INTO Organisation (numero,adresse) VALUES
(7782,'536 Le Chateau de Mont, 50490 Vaudrimesnil'),
(7783,'819bis Coumbe d''Aze, 59490 Somain');

INSERT INTO Organisation (numero,adresse) VALUES
(7784,'787bis Chemin du Grand Poenat, 38160 Saint-Sauveur'),
(7785,'976 Les Perles, 65130 Bulan');

INSERT INTO Organisation (numero,adresse) VALUES
(7786,'577 Quins, 53200 Prée-d''Anjou'),
(7787,'634 La Vigne du Grand Clos, 46300 Le Vigan');

INSERT INTO Organisation (numero,adresse) VALUES
(7788,'375 Aire de service Autoroute 51, 78190 Trappes'),
(7789,'695 Place La Clef des Champs, 03120 Arfeuilles');

INSERT INTO Organisation (numero,adresse) VALUES
(7790,'557 La Cayrede, 50220 Poilley'),
(7791,'915bis Les Andaines, 16160 Gond-Pontouvre');

INSERT INTO Organisation (numero,adresse) VALUES
(7792,'592bis Résidence Le Hameau, 32190 Caillavet'),
(7793,'60 Le Petit Méchatin, 02220 Mont-Notre-Dame');

INSERT INTO Organisation (numero,adresse) VALUES
(7794,'481 Route des Sablons, 53160 Jublains'),
(7795,'309bis Pre Lagoutte, 10140 Juvanzé');

INSERT INTO Organisation (numero,adresse) VALUES
(7796,'741bis La Couture, 59151 Bugnicourt'),
(7797,'835 La Tortiere, 09400 Cazenave-Serres-et-Allens');

INSERT INTO Organisation (numero,adresse) VALUES
(7798,'339bis Le Peyssel, 70190 Grandvelle-et-le-Perrenot'),
(7799,'403 Voie de liaison de Gaulle - Rainier III, 26110 Aubres');

INSERT INTO Organisation (numero,adresse) VALUES
(7800,'265 la Condamine, 35135 Chantepie'),
(7801,'978 La Burelle, 54300 Bonviller');

INSERT INTO Organisation (numero,adresse) VALUES
(7802,'727 Le Ventavon, 43320 Le Vernet'),
(7803,'442 Res Primavera C, 26400 Suze');

INSERT INTO Organisation (numero,adresse) VALUES
(7804,'74 L''Estang-bigou, 57420 Foville'),
(7805,'332bis Les Roussettes, 12200 Le Bas Ségala');

INSERT INTO Organisation (numero,adresse) VALUES
(7806,'491 Pivernet, 71260 Bissy-la-Mâconnaise'),
(7807,'809 Les Zodiaques 2, 32360 Saint-Lary');

INSERT INTO Organisation (numero,adresse) VALUES
(7808,'646bis Domaine Boudet, 27330 Champignolles'),
(7809,'895 Les Gouttes Larges, 32800 Noulens');

INSERT INTO Organisation (numero,adresse) VALUES
(7810,'971 Carrefour du 28 Août 1944, 56220 Peillac'),
(7811,'499 Le Trap, 55110 Mont-devant-Sassey');

INSERT INTO Organisation (numero,adresse) VALUES
(7812,'576 Le Roualdesq, 09200 Alos'),
(7813,'673 Les Moussets, 52230 Thonnance-les-Moulins');

INSERT INTO Organisation (numero,adresse) VALUES
(7814,'180 Rond-Point de la Bastide Neuve, 73390 Chamousset'),
(7815,'69 Lourtel, 12560 Campagnac');

INSERT INTO Organisation (numero,adresse) VALUES
(7816,'758bis Piste de la Fraccia, 60480 Thieux'),
(7817,'86bis Aubin, 41170 Arville');

INSERT INTO Organisation (numero,adresse) VALUES
(7818,'356 Mousset Bas, 27110 Épégard'),
(7819,'349bis Antenne Relais, 02000 Monampteuil');

INSERT INTO Organisation (numero,adresse) VALUES
(7820,'165 Chrismarc, 07360 Saint-Vincent-de-Durfort'),
(7821,'986 quartier Pont de Caramagne, 34210 Oupia');

INSERT INTO Organisation (numero,adresse) VALUES
(7822,'831 Lou Luc, 16200 Houlette'),
(7823,'992 Le Merle, 55250 Èvres');

INSERT INTO Organisation (numero,adresse) VALUES
(7824,'953 Route Métropolitaine 56, 20221 Sant''Andréa-di-Cotone'),
(7825,'532 Le Soulacre Bas, 43150 Moudeyres');

INSERT INTO Organisation (numero,adresse) VALUES
(7826,'587 Bach, 54610 Clémery'),
(7827,'42 Chemin des Contamines, 60860 Pisseleu');

INSERT INTO Organisation (numero,adresse) VALUES
(7828,'321 Pre Henquau, 54180 Heillecourt'),
(7829,'41 La ferme de Taux, 66500 Clara-Villerach');

INSERT INTO Organisation (numero,adresse) VALUES
(7830,'892bis Les Grands Navoirs Ouest, 62630 Widehem'),
(7831,'562 Couli, 37220 Rilly-sur-Vienne');

INSERT INTO Organisation (numero,adresse) VALUES
(7832,'609 Adelisa, 22460 Saint-Thélo'),
(7833,'92 Parking de la Pointe des Douaniers, 36170 Chazelet');

INSERT INTO Organisation (numero,adresse) VALUES
(7834,'87 Artignac, 59217 Carnières'),
(7835,'730bis L''Astarelle, 44115 Basse-Goulaine');

INSERT INTO Organisation (numero,adresse) VALUES
(7836,'549 Le Tarroux, 57420 Goin'),
(7837,'547bis Allée du Carimai, 47210 Doudrac');

INSERT INTO Organisation (numero,adresse) VALUES
(7838,'66 Lindrevie Moulin, 60950 Montagny-Sainte-Félicité'),
(7839,'634 Hameau des blanchons, 35520 Melesse');

INSERT INTO Organisation (numero,adresse) VALUES
(7840,'819 La Grosse Ribe, 19240 Allassac'),
(7841,'260 Le Bayard, 56230 Larré');

INSERT INTO Organisation (numero,adresse) VALUES
(7842,'145 Boulbennes de Tapio, 40500 Eyres-Moncube'),
(7843,'741 Malportel, 39800 Chamole');

INSERT INTO Organisation (numero,adresse) VALUES
(7844,'376bis Mas de Davet, 03200 Vichy'),
(7845,'555bis Lieu dit Le Par, 57160 Scy-Chazelles');

INSERT INTO Organisation (numero,adresse) VALUES
(7846,'618 Columbarium, 80430 Saint-Aubin-Rivière'),
(7847,'8 Villa Les Orchidees, 76280 Fongueusemare');

INSERT INTO Organisation (numero,adresse) VALUES
(7848,'10 La Grange de Puaux, 31230 Mirambeau'),
(7849,'940 Combrieres, 80120 Saint-Quentin-en-Tourmont');

INSERT INTO Organisation (numero,adresse) VALUES
(7850,'465 Le Bois Chevalier Ouest, 70230 Chassey-lès-Montbozon'),
(7851,'274 Le Cantou, 14350 Saint-Jean-des-Essartiers');

INSERT INTO Organisation (numero,adresse) VALUES
(7852,'820 Cami de la Roque, 39300 Chapois'),
(7853,'54bis Prarie, 58210 Saint-Germain-des-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(7854,'299 Sagna Colas, 33250 Cissac-Médoc'),
(7855,'590 Camp Del Rey, 58400 La Marche');

INSERT INTO Organisation (numero,adresse) VALUES
(7856,'627 La Rode Basse, 73170 La Chapelle-Saint-Martin'),
(7857,'678 Villa Gabrielle, 53940 Ahuillé');

INSERT INTO Organisation (numero,adresse) VALUES
(7858,'846bis Brune, 55600 Remoiville'),
(7859,'241 La Paouloune, 39150 Lac-des-Rouges-Truites');

INSERT INTO Organisation (numero,adresse) VALUES
(7860,'454 Les Champs d''Oeillette, 51800 Gizaucourt'),
(7861,'911bis Charrière du bois, 45410 Lion-en-Beauce');

INSERT INTO Organisation (numero,adresse) VALUES
(7862,'654 Le Miralda, 57330 Escherange'),
(7863,'689 Rec d''Alby, 67350 Mulhausen');

INSERT INTO Organisation (numero,adresse) VALUES
(7864,'841bis Chamonal Nord, 76640 Sainte-Marguerite-sur-Fauville'),
(7865,'423bis Le Murano C, 17150 Consac');

INSERT INTO Organisation (numero,adresse) VALUES
(7866,'344 Moulin de lembaurat, 44540 Bonnœuvre'),
(7867,'123 Cérarges Tupin - Hauteville-Lompnes, 62380 Dohem');

INSERT INTO Organisation (numero,adresse) VALUES
(7868,'648 La Longe, 78910 Orvilliers'),
(7869,'164bis Le Grand Chemin, 42270 Saint-Priest-en-Jarez');

INSERT INTO Organisation (numero,adresse) VALUES
(7870,'250 Domaine de Saint Angel, 39160 Les Trois Châteaux'),
(7871,'28 Le Mas du Ruisseau, 73340 Le Noyer');

INSERT INTO Organisation (numero,adresse) VALUES
(7872,'146bis Volpilliaire, 38840 Saint-Bonnet-de-Chavagne'),
(7873,'538 Petret Ferme, 57920 Buding');

INSERT INTO Organisation (numero,adresse) VALUES
(7874,'272 Prat Del Mas, 07460 Beaulieu'),
(7875,'344 Route Verte, 64190 Gurs');

INSERT INTO Organisation (numero,adresse) VALUES
(7876,'722bis Roumegous-Haut, 03400 Saint-Ennemond'),
(7877,'957bis Bas d''Ane, 27950 Mercey');

INSERT INTO Organisation (numero,adresse) VALUES
(7878,'448 L''Ambry, 29300 Baye'),
(7879,'733 St Antonin, 70190 La Malachère');

INSERT INTO Organisation (numero,adresse) VALUES
(7880,'294 La Gamasse et la Sibadiere, 31370 Sabonnères'),
(7881,'484 Bouteou, 48320 Quézac');

INSERT INTO Organisation (numero,adresse) VALUES
(7882,'502 Immeuble le Grand Puy, 66390 Baixas'),
(7883,'967 Le Taous, 59330 Boussières-sur-Sambre');

INSERT INTO Organisation (numero,adresse) VALUES
(7884,'91 Le Pont de Moulinas, 17100 Saintes'),
(7885,'611 Mas du Serre, 13650 Meyrargues');

INSERT INTO Organisation (numero,adresse) VALUES
(7886,'559bis Le Petit Perron, 62185 Saint-Tricat'),
(7887,'36bis Allée des Arbousiers, 06910 Pierrefeu');

INSERT INTO Organisation (numero,adresse) VALUES
(7888,'63bis La Cabanette, 40170 Lévignacq'),
(7889,'440 Square du Chanoine Pierre-Marie Boulat, 54300 Sionviller');

INSERT INTO Organisation (numero,adresse) VALUES
(7890,'625 Lieu-dit Gayon, 17460 Colombiers'),
(7891,'697 La Croix du Tet, 05500 Buissard');

INSERT INTO Organisation (numero,adresse) VALUES
(7892,'892 Rocher Dessus, 54790 Mancieulles'),
(7893,'622 Sambule, 39270 Augisey');

INSERT INTO Organisation (numero,adresse) VALUES
(7894,'760bis Voie Parc des Baumettes, 08300 Sorbon'),
(7895,'882bis Gouleyres et Moulin de Fau, 23190 Bellegarde-en-Marche');

INSERT INTO Organisation (numero,adresse) VALUES
(7896,'482bis Les Peltes, 43580 Esplantas-Vazeilles'),
(7897,'916 Monteillas, 13920 Saint-Mitre-les-Remparts');

INSERT INTO Organisation (numero,adresse) VALUES
(7898,'330 Saint Walfroy, 40250 Larbey'),
(7899,'413bis La Pradelarie, 65400 Ouzous');

INSERT INTO Organisation (numero,adresse) VALUES
(7900,'589bis Aubert, 51310 Saint-Bon'),
(7901,'589 Le Bézi, 23600 Toulx-Sainte-Croix');

INSERT INTO Organisation (numero,adresse) VALUES
(7902,'947 Belinguié, 51310 Neuvy'),
(7903,'551 La-noue-jacquet, 53200 Châtelain');

INSERT INTO Organisation (numero,adresse) VALUES
(7904,'145 Bergerie de Nalquier, 09310 Larcat'),
(7905,'368 Hameau Les Gourniers, 61120 Le Renouard');

INSERT INTO Organisation (numero,adresse) VALUES
(7906,'256bis Sentier de la Florette, 76290 Saint-Martin-du-Manoir'),
(7907,'868 Ginoux d''en bas, 30580 Fontarèches');

INSERT INTO Organisation (numero,adresse) VALUES
(7908,'365 Le Viala, 11350 Padern'),
(7909,'521bis Santouen Est, 69840 Jullié');

INSERT INTO Organisation (numero,adresse) VALUES
(7910,'807 Camp de la Bordo, 38840 Saint-Lattier'),
(7911,'266bis Le Bois de la Dame, 60000 Beauvais');

INSERT INTO Organisation (numero,adresse) VALUES
(7912,'364 Terres de Lyon, 62170 La Madelaine-sous-Montreuil'),
(7913,'893 Parking Stade du Mont Gros, 39240 Valzin en Petite Montagne');

INSERT INTO Organisation (numero,adresse) VALUES
(7914,'836 L''Oratoire de Saint Julien, 57640 Argancy'),
(7915,'454bis Masset, 38250 Corrençon-en-Vercors');

INSERT INTO Organisation (numero,adresse) VALUES
(7916,'964 Parking Massa, 20125 Soccia'),
(7917,'833 Les Bois Plantes, 02340 Noircourt');

INSERT INTO Organisation (numero,adresse) VALUES
(7918,'517 Le Bottin, 63170 Aubière'),
(7919,'892 Teranga, 46160 Saint-Sulpice');

INSERT INTO Organisation (numero,adresse) VALUES
(7920,'779 Chateau Blanc, 76440 Fontaine-en-Bray'),
(7921,'227 lieu-dit Auriac les Bels, 64190 Bugnein');

INSERT INTO Organisation (numero,adresse) VALUES
(7922,'830 Le Plot de la Laonne, 62130 Herlincourt'),
(7923,'738 Route du Pont de Clans, 25170 Émagny');

INSERT INTO Organisation (numero,adresse) VALUES
(7924,'388bis Brieu, 62131 Vaudricourt'),
(7925,'582 Saint-barthelemy, 73540 La Bâthie');

INSERT INTO Organisation (numero,adresse) VALUES
(7926,'580bis Sentier reliant l''Impasse Victor Lavagna - Voie du lotissement Château Rosemont, 46130 Puybrun'),
(7927,'164bis Les Côtes du Chochard, 39130 Mesnois');

INSERT INTO Organisation (numero,adresse) VALUES
(7928,'285 Viarouge, 79200 Lageon'),
(7929,'977 La Riviere de Sanhes, 50480 Vierville');

INSERT INTO Organisation (numero,adresse) VALUES
(7930,'181 Les Bleuets A, 10190 Estissac'),
(7931,'928bis Domaine des Vallées, 37500 Chinon');

INSERT INTO Organisation (numero,adresse) VALUES
(7932,'890 quartier Le Petit Bois, 47160 Buzet-sur-Baïse'),
(7933,'0bis Fayet Bas, 09300 L''Aiguillon');

INSERT INTO Organisation (numero,adresse) VALUES
(7934,'757 La Martinarie, 54380 Dieulouard'),
(7935,'995bis Lou Puont, 25650 La Chaux');

INSERT INTO Organisation (numero,adresse) VALUES
(7936,'34bis Rue  Charles Pizzala, 12230 L''Hospitalet-du-Larzac'),
(7937,'464bis Fontlebeau et Costebelle, 08250 Beffu-et-le-Morthomme');

INSERT INTO Organisation (numero,adresse) VALUES
(7938,'930 À l''Hopital, 51140 Breuil'),
(7939,'873 Pont de Soleils, 76200 Dieppe');

INSERT INTO Organisation (numero,adresse) VALUES
(7940,'57 Le Clos des Vignes, 25240 Gellin'),
(7941,'422 La Cancelade-Basse, 46300 Gourdon');

INSERT INTO Organisation (numero,adresse) VALUES
(7942,'296bis La Borie de Cabessieres, 70140 La Résie-Saint-Martin'),
(7943,'936 La Colline d''Haybes, 21200 Meursanges');

INSERT INTO Organisation (numero,adresse) VALUES
(7944,'203 Place de la Plaine, 47410 Lauzun'),
(7945,'111 Lieu-Dit Les Garcins, 80240 Hancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(7946,'372 Blancaria, 76850 Cottévrard'),
(7947,'829 Badel, 14260 Bauquay');

INSERT INTO Organisation (numero,adresse) VALUES
(7948,'190 Escalier Avenue Val Marie - Avenue du Rond-Point, 51210 Fromentières'),
(7949,'128bis Combuejouls, 54113 Gye');

INSERT INTO Organisation (numero,adresse) VALUES
(7950,'772 Bretelle Sortie N°52 A8 - Mercantour (Provenance Vintimille), 77760 Rumont'),
(7951,'180 Impasse des Lavandières, 70100 Cresancey');

INSERT INTO Organisation (numero,adresse) VALUES
(7952,'528 Caylus, 26160 La Bâtie-Rolland'),
(7953,'983 La Gredo, 32300 Saint-Michel');

INSERT INTO Organisation (numero,adresse) VALUES
(7954,'292 La Tete aux Chevaux, 70000 Comberjon'),
(7955,'923 La Lave, 72130 Saint-Ouen-de-Mimbré');

INSERT INTO Organisation (numero,adresse) VALUES
(7956,'156 Peuroir Ouest, 77840 Crouy-sur-Ourcq'),
(7957,'504 La Ribeyre de Bois, 12550 Coupiac');

INSERT INTO Organisation (numero,adresse) VALUES
(7958,'249bis Deveze Migiere, 46090 Aujols'),
(7959,'95 Hoyeau Maillet, 21121 Daix');

INSERT INTO Organisation (numero,adresse) VALUES
(7960,'232bis Puech Baguet, 30133 Les Angles'),
(7961,'319 Mont Vireux, 62124 Haplincourt');

INSERT INTO Organisation (numero,adresse) VALUES
(7962,'33 La Caborge, 72230 Mulsanne'),
(7963,'228 Saint Victor et Genouillet, 33710 Gauriac');

INSERT INTO Organisation (numero,adresse) VALUES
(7964,'305 Le Moulin de Loupeigne, 67650 Dieffenthal'),
(7965,'107bis Garage 4, 24190 Saint-Germain-du-Salembre');

INSERT INTO Organisation (numero,adresse) VALUES
(7966,'48 Bonnard-Est, 09250 Caychax'),
(7967,'920 Les Vieux Prés, 60190 Cernoy');

INSERT INTO Organisation (numero,adresse) VALUES
(7968,'564 Au-dessus du Village, 50490 La Ronde-Haye'),
(7969,'0 Le Gros Chêne, 80132 Quesnoy-le-Montant');

INSERT INTO Organisation (numero,adresse) VALUES
(7970,'196 Les Girards, 46250 Marminiac'),
(7971,'919 Le Grand Méchatin, 25210 Les Fontenelles');

INSERT INTO Organisation (numero,adresse) VALUES
(7972,'781 Chemin du Fanc, 47360 Frégimont'),
(7973,'140 Pisse Co, 53170 Le Bignon-du-Maine');

INSERT INTO Organisation (numero,adresse) VALUES
(7974,'817 Pla d''El Castel, 08300 Sorbon'),
(7975,'536 Parking de la Gare Routière, 16380 Souffrignac');

INSERT INTO Organisation (numero,adresse) VALUES
(7976,'563 Lacon, 62152 Neufchâtel-Hardelot'),
(7977,'314 Bois Rigaud, 32400 Verlus');

INSERT INTO Organisation (numero,adresse) VALUES
(7978,'940 Moulin d''Icart, 14470 Reviers'),
(7979,'117 Baldrac, 49500 Louvaines');

INSERT INTO Organisation (numero,adresse) VALUES
(7980,'521 Villa La Thebaide, 27250 Chambord'),
(7981,'208 Hameau de Barret le Haut, 17350 Annepont');

INSERT INTO Organisation (numero,adresse) VALUES
(7982,'459bis Voie s''amorçant au Chemin du Vallon de Terron, 67320 Thal-Drulingen'),
(7983,'766 Cours du Palais, 66320 Valmanya');

INSERT INTO Organisation (numero,adresse) VALUES
(7984,'294 Mas Vialaret, 51120 Saudoy'),
(7985,'652bis L''Emeraude, 57250 Moyeuvre-Petite');

INSERT INTO Organisation (numero,adresse) VALUES
(7986,'146 Les Mures Est, 02870 Cerny-lès-Bucy'),
(7987,'46 Chemin Chauveau, 57600 Forbach');

INSERT INTO Organisation (numero,adresse) VALUES
(7988,'717 Allée de la Filiole, 25300 Doubs'),
(7989,'794 Le Vergnas, 32420 Meilhan');

INSERT INTO Organisation (numero,adresse) VALUES
(7990,'599 Chemin de la Colle, 51340 Scrupt'),
(7991,'3 Allée des Arbousiers, 26300 Bourg-de-Péage');

INSERT INTO Organisation (numero,adresse) VALUES
(7992,'76 Gros Prefaissal, 55200 Pont-sur-Meuse'),
(7993,'119 Majoulet, 76320 Caudebec-lès-Elbeuf');

INSERT INTO Organisation (numero,adresse) VALUES
(7994,'486bis Monteillas, 32720 Gée-Rivière'),
(7995,'105 La Péguille, 39210 Plasne');

INSERT INTO Organisation (numero,adresse) VALUES
(7996,'48 La Bouyssière, 42740 La Terrasse-sur-Dorlay'),
(7997,'320bis Les Mas Du Leouve, 02880 Clamecy');

INSERT INTO Organisation (numero,adresse) VALUES
(7998,'956bis La Mignone, 42520 Lupé'),
(7999,'886 Aupiac, 55600 Bazeilles-sur-Othain');

INSERT INTO Organisation (numero,adresse) VALUES
(8000,'254bis Lotissement les Carillons - Avrissieu le Bas, 38210 La Rivière'),
(8001,'922 Clos Pervenche, 59670 Wemaers-Cappel');

INSERT INTO Organisation (numero,adresse) VALUES
(8002,'423bis Coste de Rome, 27120 Rouvray'),
(8003,'567 A Goraty, 16600 Magnac-sur-Touvre');

INSERT INTO Organisation (numero,adresse) VALUES
(8004,'291 Le Gaudet, 76133 Épouville'),
(8005,'314 La Condomine, 31160 Rouède');

INSERT INTO Organisation (numero,adresse) VALUES
(8006,'739 Le Misserou, 54112 Vannes-le-Châtel'),
(8007,'392 Font-Patine, 27800 Boisney');

INSERT INTO Organisation (numero,adresse) VALUES
(8008,'196 Square Roger Boyer, 33340 Blaignan'),
(8009,'678 Saint-Dalmas-de-Tende, 74400 Chamonix-Mont-Blanc');

INSERT INTO Organisation (numero,adresse) VALUES
(8010,'678 Ruols, 64640 Lantabat'),
(8011,'647 Les Jardins D''Auguste, 39120 Pleure');

INSERT INTO Organisation (numero,adresse) VALUES
(8012,'709bis Domaine de la Basse-cour, 34650 Brenas'),
(8013,'481 Résidence Wind Surf 2, 80132 Buigny-Saint-Maclou');

INSERT INTO Organisation (numero,adresse) VALUES
(8014,'180 Cayraguet-Haut, 73100 Aix-les-Bains'),
(8015,'904 La Graverie, 16370 Cherves-Richemont');

INSERT INTO Organisation (numero,adresse) VALUES
(8016,'829 Rue de Ladevèze, 64410 Arzacq-Arraziguet'),
(8017,'410 Rougnac, 72320 Saint-Maixent');

INSERT INTO Organisation (numero,adresse) VALUES
(8018,'762 Allée  Antoine Canova, 64120 Bunus'),
(8019,'666 Allée de la Cressonnière, 32200 Maurens');

INSERT INTO Organisation (numero,adresse) VALUES
(8020,'55 """ La Vernelle """, 60650 Espaubourg'),
(8021,'165 Le Causse Palat, 76640 Yébleron');

INSERT INTO Organisation (numero,adresse) VALUES
(8022,'534bis Champs des Chaumes, 21370 Pasques'),
(8023,'447 Chemin de Belvédère à La Madone des Fenêstre, 39140 Larnaud');

INSERT INTO Organisation (numero,adresse) VALUES
(8024,'802 Les Gouilles, 71170 Anglure-sous-Dun'),
(8025,'783bis Les Basses, 32600 L''Isle-Jourdain');

INSERT INTO Organisation (numero,adresse) VALUES
(8026,'676 Pechcarbou, 08370 Signy-Montlibert'),
(8027,'119 Le Moulin d''Auzène, 33350 Pujols');

INSERT INTO Organisation (numero,adresse) VALUES
(8028,'409 Les Hauts de Savignac, 47410 Bourgougnague'),
(8029,'349 Bois Blanc, 57690 Marange-Zondrange');

INSERT INTO Organisation (numero,adresse) VALUES
(8030,'849 Cité l''Aiguille les Platanes, 31440 Esténos'),
(8031,'221bis Gare, 69640 Rivolet');

INSERT INTO Organisation (numero,adresse) VALUES
(8032,'322 La Plane Del Turq, 62510 Arques'),
(8033,'637 Square de Baton rouge, 45340 Gaubertin');

INSERT INTO Organisation (numero,adresse) VALUES
(8034,'211bis Rond-Point  François de Saboulin Bollena, 35130 Arbrissel'),
(8035,'375 Fourteau, 32230 Juillac');

INSERT INTO Organisation (numero,adresse) VALUES
(8036,'338 L''Aiglette Nord, 37600 Sennevières'),
(8037,'658 Les Péricards, 03210 Souvigny');

INSERT INTO Organisation (numero,adresse) VALUES
(8038,'662bis Vignoble du Terrefort, 80340 Suzanne'),
(8039,'297bis Dardennes, 37340 Rillé');

INSERT INTO Organisation (numero,adresse) VALUES
(8040,'86 Pirochon, 40330 Brassempouy'),
(8041,'147 Bassinet, 70100 Arc-lès-Gray');

INSERT INTO Organisation (numero,adresse) VALUES
(8042,'720 Le Milieu, 35270 Meillac'),
(8043,'745 Le Soulacre Bas, 53140 La Pallu');

INSERT INTO Organisation (numero,adresse) VALUES
(8044,'970 Le Guerat, 72380 La Guierche'),
(8045,'659 Rue Saint-Jean-Baptiste, 25260 Longevelle-sur-Doubs');

INSERT INTO Organisation (numero,adresse) VALUES
(8046,'69 Villa Castel, 59188 Saint-Vaast-en-Cambrésis'),
(8047,'924 Aubuc, 57970 Kuntzig');

INSERT INTO Organisation (numero,adresse) VALUES
(8048,'117bis Le grand pré, 78790 Montchauvet'),
(8049,'433 Les Adrechs, 31230 Puymaurin');

INSERT INTO Organisation (numero,adresse) VALUES
(8050,'507bis Riou d''Orgeas, 54720 Laix'),
(8051,'110 Le Rank-Sud, 63160 Chas');

INSERT INTO Organisation (numero,adresse) VALUES
(8052,'922 Laguillou, 27410 Mesnil-en-Ouche'),
(8053,'25 Pomballet, 07120 Saint-Alban-Auriolles');

INSERT INTO Organisation (numero,adresse) VALUES
(8054,'653 Font Couverte, 78720 Dampierre-en-Yvelines'),
(8055,'221 Domaine de Romilhac, 39700 Vriange');

INSERT INTO Organisation (numero,adresse) VALUES
(8056,'928bis Lieu-dit Dessous le mont, 07800 Beauchastel'),
(8057,'793 Les Violettes Bat A, 32300 L''Isle-de-Noé');

INSERT INTO Organisation (numero,adresse) VALUES
(8058,'203 Résidence Le Ségovent 5, 42590 Pinay'),
(8059,'598 La Grosse Borne, 77520 Donnemarie-Dontilly');

INSERT INTO Organisation (numero,adresse) VALUES
(8060,'834bis Riveneuve du Bosc, 80150 Le Boisle'),
(8061,'604bis Domaine de la Cote, 38520 La Garde');

INSERT INTO Organisation (numero,adresse) VALUES
(8062,'327bis Domaine de la Grande Peche, 20117 Cauro'),
(8063,'717bis Fonteilles, 10700 Saint-Étienne-sous-Barbuise');

INSERT INTO Organisation (numero,adresse) VALUES
(8064,'518bis Res Les Aubepines, 47220 Marmont-Pachas'),
(8065,'88 Sacré Cœur, 59149 Cousolre');

INSERT INTO Organisation (numero,adresse) VALUES
(8066,'696bis Bât E les Deux Moulins, 32140 Sère'),
(8067,'904bis Chemin de la Jonction, 56530 Gestel');

INSERT INTO Organisation (numero,adresse) VALUES
(8068,'905 Le Petit Tanvol, 10350 Saint-Lupien'),
(8069,'347 Résidence de l''Etang, 74420 Habère-Poche');

INSERT INTO Organisation (numero,adresse) VALUES
(8070,'955 Le Planas, 60350 Trosly-Breuil'),
(8071,'579 Joug, 25470 Courtefontaine');

INSERT INTO Organisation (numero,adresse) VALUES
(8072,'752 Brantigny, 02650 Crézancy'),
(8073,'897 Château du Monceau, 40110 Arengosse');

INSERT INTO Organisation (numero,adresse) VALUES
(8074,'899 Res Romana, 44660 Ruffigné'),
(8075,'669 Place des Illustres, 63320 Tourzel-Ronzières');

INSERT INTO Organisation (numero,adresse) VALUES
(8076,'824 Iris du Colombier, 64270 Auterrive'),
(8077,'918 Les Deux Ponts, 30210 Saint-Bonnet-du-Gard');

INSERT INTO Organisation (numero,adresse) VALUES
(8078,'496bis Allée Emile Zola, 60240 Fresne-Léguillon'),
(8079,'152bis Pré Cousin, 11230 Courtauly');

INSERT INTO Organisation (numero,adresse) VALUES
(8080,'678 Impasse du Collet, 10500 Blaincourt-sur-Aube'),
(8081,'433 Côte de la Poudrière, 27150 Boisemont');

INSERT INTO Organisation (numero,adresse) VALUES
(8082,'516 Maillebiau-Nord, 08800 Monthermé'),
(8083,'172bis Pre Jeantet, 54370 Laneuveville-aux-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(8084,'303 Grand Bicetre, 06750 Caille'),
(8085,'319 Les Mauguins, 02220 Serches');

INSERT INTO Organisation (numero,adresse) VALUES
(8086,'862bis Pierres de Chalay, 27400 Houetteville'),
(8087,'884 Rue des Pradals, 10200 Engente');

INSERT INTO Organisation (numero,adresse) VALUES
(8088,'671 Domaine des Fleurs, 21500 Étais'),
(8089,'787 La Campristinie, 17210 Bran');

INSERT INTO Organisation (numero,adresse) VALUES
(8090,'970bis Lidane, 15110 Fridefont'),
(8091,'334 La Fontaine Sainte Croix, 74230 Thônes');

INSERT INTO Organisation (numero,adresse) VALUES
(8092,'613bis Jardin de l''École de la Vernéa, 67320 Asswiller'),
(8093,'259bis Marty le Vieux, 54450 Bénaménil');

INSERT INTO Organisation (numero,adresse) VALUES
(8094,'526bis Vieux Chemin de Saint-Antoine raccourci n°3, 47160 Buzet-sur-Baïse'),
(8095,'934bis Les Arènes entrée B, 16190 Saint-Laurent-de-Belzagot');

INSERT INTO Organisation (numero,adresse) VALUES
(8096,'364 Lauthier le Haut, 64300 Loubieng'),
(8097,'221 Le pont du Jugnon, 40700 Poudenx');

INSERT INTO Organisation (numero,adresse) VALUES
(8098,'246 Passage Jean-Jacques Rousseau, 59380 West-Cappel'),
(8099,'714bis La Petite Cabanette, 63250 Chabreloche');

INSERT INTO Organisation (numero,adresse) VALUES
(8100,'746 Lotissement la Roseraie, 76460 Gueutteville-les-Grès'),
(8101,'557 Failloué Bas, 24370 Sainte-Mondane');

INSERT INTO Organisation (numero,adresse) VALUES
(8102,'520 La Roucarie Haute, 27480 Bézu-la-Forêt'),
(8103,'31 Le Bois de Plan, 54870 Cons-la-Grandville');

INSERT INTO Organisation (numero,adresse) VALUES
(8104,'412 Résidence du Rocher Bâtiment grenat, 07000 Privas'),
(8105,'871 Les Mithiers, 02340 Berlise');

INSERT INTO Organisation (numero,adresse) VALUES
(8106,'888 Résidence Plein Soleil, 52800 Thivet'),
(8107,'281 Splans Ouest, 60480 Lachaussée-du-Bois-d''Écu');

INSERT INTO Organisation (numero,adresse) VALUES
(8108,'23bis Résidence Anglade Bat Montbéas - Salau, 10250 Courteron'),
(8109,'666bis Les Camps Bous, 38300 Crachier');

INSERT INTO Organisation (numero,adresse) VALUES
(8110,'827 Les Iris, 41170 Saint-Agil'),
(8111,'614 Le Bois de la Tombe, 21520 Louesme');

INSERT INTO Organisation (numero,adresse) VALUES
(8112,'496 Bois de Bonac, 21320 Rouvres-sous-Meilly'),
(8113,'819bis Hameau de Banchin, 01450 Cerdon');

INSERT INTO Organisation (numero,adresse) VALUES
(8114,'391 La Palice, 57340 Marthille'),
(8115,'411 Les Albies-est, 59285 Arnèke');

INSERT INTO Organisation (numero,adresse) VALUES
(8116,'716 Serieysol, 79500 Saint-Vincent-la-Châtre'),
(8117,'989 domaine d''Arnauteille, 08150 Harcy');

INSERT INTO Organisation (numero,adresse) VALUES
(8118,'992 Les Combes et le Remesou, 64190 Navarrenx'),
(8119,'764 Traverse Malraux, 10800 Saint-Julien-les-Villas');

INSERT INTO Organisation (numero,adresse) VALUES
(8120,'552 La Pesse Longue, 32720 Vergoignan'),
(8121,'478 Salars, 04120 Demandolx');

INSERT INTO Organisation (numero,adresse) VALUES
(8122,'811 Las Touzeilles, 50300 La Gohannière'),
(8123,'887 La Freyssinie, 03430 Cosne-d''Allier');

INSERT INTO Organisation (numero,adresse) VALUES
(8124,'960bis Gours, 10500 Maizières-lès-Brienne'),
(8125,'28bis Résidence Les Dauphins, 39290 Frasne-les-Meulières');

INSERT INTO Organisation (numero,adresse) VALUES
(8126,'582bis Gaillou du bas, 70600 Écuelle'),
(8127,'664 L''Arche, 64360 Cuqueron');

INSERT INTO Organisation (numero,adresse) VALUES
(8128,'75bis Fouasse, 47120 Baleyssagues'),
(8129,'210 L’Escaillon, 15260 Oradour');

INSERT INTO Organisation (numero,adresse) VALUES
(8130,'998 Allee Bugatti, 73500 Aussois'),
(8131,'597 Grisardes, 42440 Saint-Julien-la-Vêtre');

INSERT INTO Organisation (numero,adresse) VALUES
(8132,'612 Le Mas d’Entraygues, 76780 Croisy-sur-Andelle'),
(8133,'463 Lande du Puech, 30190 Sauzet');

INSERT INTO Organisation (numero,adresse) VALUES
(8134,'190 Passage souterrain Michel Genty, 26300 Châteauneuf-sur-Isère'),
(8135,'211 L’Abriq, 22400 Coëtmieux');

INSERT INTO Organisation (numero,adresse) VALUES
(8136,'817bis Compregnac, 51300 Vauclerc'),
(8137,'247bis Avenue d''Oran, 63310 Randan');

INSERT INTO Organisation (numero,adresse) VALUES
(8138,'517 Hameau de Pelat, 20229 Carpineto'),
(8139,'607 Combe Del Pous, 21120 Courtivron');

INSERT INTO Organisation (numero,adresse) VALUES
(8140,'783bis Loreley, 68510 Kappelen'),
(8141,'615 À la Grange Silan, 68310 Wittelsheim');

INSERT INTO Organisation (numero,adresse) VALUES
(8142,'432 Ile du Gravié, 45230 Adon'),
(8143,'405 Collettes Cottages, 65400 Ayzac-Ost');

INSERT INTO Organisation (numero,adresse) VALUES
(8144,'555bis """ Les Durants """, 30260 Corconne'),
(8145,'765 La Planette, 60510 Litz');

INSERT INTO Organisation (numero,adresse) VALUES
(8146,'266 Aumières Hautes (les), 71330 Sens-sur-Seille'),
(8147,'154 Reserve incendie, 62580 Neuville-Saint-Vaast');

INSERT INTO Organisation (numero,adresse) VALUES
(8148,'146 Les Cerisiers, 08400 Sainte-Marie'),
(8149,'212bis Baraque d’Isidore, 42130 Marcilly-le-Châtel');

INSERT INTO Organisation (numero,adresse) VALUES
(8150,'179 Bâtiment L''églantier, 73130 Saint-Colomban-des-Villards'),
(8151,'885bis Bois des Foix, 24270 Payzac');

INSERT INTO Organisation (numero,adresse) VALUES
(8152,'553 Lieu-dit La Blachille, 47210 Doudrac'),
(8153,'275 Beun Ourizount, 22550 Ruca');

INSERT INTO Organisation (numero,adresse) VALUES
(8154,'629 Le Moulin de Mandy, 22290 Lannebert'),
(8155,'817 Bonde de Mairisette, 10150 Creney-près-Troyes');

INSERT INTO Organisation (numero,adresse) VALUES
(8156,'397 Riou du Merle, 67117 Ittenheim'),
(8157,'85 La Pujolle, 21570 Thoires');

INSERT INTO Organisation (numero,adresse) VALUES
(8158,'95 Ranc Chabrier, 61150 Avoine'),
(8159,'3bis Le Champ Bonamy, 62550 Tangry');

INSERT INTO Organisation (numero,adresse) VALUES
(8160,'170 Res Du Cros A, 64130 Moncayolle-Larrory-Mendibieu'),
(8161,'233 La Mairie, 80250 Chirmont');

INSERT INTO Organisation (numero,adresse) VALUES
(8162,'782 Domaine du Pérou, 45230 Sainte-Geneviève-des-Bois'),
(8163,'114 Le Couzi, 51600 Saint-Jean-sur-Tourbe');

INSERT INTO Organisation (numero,adresse) VALUES
(8164,'487 Passage Guet du Latou, 14490 La Bazoque'),
(8165,'779 Les Bourgnounets, 35580 Saint-Senoux');

INSERT INTO Organisation (numero,adresse) VALUES
(8166,'869 Brasserie, 17250 Plassay'),
(8167,'680 Le Vergnet Bas, 71400 Tavernay');

INSERT INTO Organisation (numero,adresse) VALUES
(8168,'487 CC- Pont des Lônes, 54290 Loromontzey'),
(8169,'968 Hameau du Courtal, 80480 Bacouel-sur-Selle');

INSERT INTO Organisation (numero,adresse) VALUES
(8170,'924bis Trescases, 68420 Vœgtlinshoffen'),
(8171,'973 Peyrator, 02410 Saint-Nicolas-aux-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(8172,'624bis Ruelle du Château, 03360 Lételon'),
(8173,'941 Saint-Michel, 65130 Tilhouse');

INSERT INTO Organisation (numero,adresse) VALUES
(8174,'445 La Grifoulette, 28330 Chapelle-Guillaume'),
(8175,'548bis Viarouge, 53300 La Haie-Traversaine');

INSERT INTO Organisation (numero,adresse) VALUES
(8176,'607 Fourques d''en bas, 40630 Luglon'),
(8177,'984 Lieu-dit Bellevue, 60680 Jonquières');

INSERT INTO Organisation (numero,adresse) VALUES
(8178,'511 Pré Courtin, 24120 Beauregard-de-Terrasson'),
(8179,'427 Les Scaldayries, 51220 Hermonville');

INSERT INTO Organisation (numero,adresse) VALUES
(8180,'345 L’Herm, 33350 Castillon-la-Bataille'),
(8181,'164bis Domaine d''Aussières, 47350 Lachapelle');

INSERT INTO Organisation (numero,adresse) VALUES
(8182,'558 Villa Larlan, 17340 Châtelaillon-Plage'),
(8183,'342bis Fromentals, 28360 Dammarie');

INSERT INTO Organisation (numero,adresse) VALUES
(8184,'195 Le Haut Plan d''Estine, 60120 Fléchy'),
(8185,'888bis La Borie de Pagax, 05100 Briançon');

INSERT INTO Organisation (numero,adresse) VALUES
(8186,'792bis Lairaud, 59670 Ochtezeele'),
(8187,'684 Le Bosc Redon, 68720 Hochstatt');

INSERT INTO Organisation (numero,adresse) VALUES
(8188,'906 Résidence Les Dunes, 01160 Neuville-sur-Ain'),
(8189,'608bis La Cloterie, 19430 Camps-Saint-Mathurin-Léobazel');

INSERT INTO Organisation (numero,adresse) VALUES
(8190,'201 Serre-court, 54470 Xammes'),
(8191,'975 Evieu-Ouest, 67420 Bourg-Bruche');

INSERT INTO Organisation (numero,adresse) VALUES
(8192,'635bis La Sardanne, 49700 Dénezé-sous-Doué'),
(8193,'233 Rigail, 21410 Gergueil');

INSERT INTO Organisation (numero,adresse) VALUES
(8194,'271 """ Les Bauzets """, 03350 Le Brethon'),
(8195,'591 Le Petit Bosquet, 67130 Wisches');

INSERT INTO Organisation (numero,adresse) VALUES
(8196,'122bis Casino, 50310 Éroudeville'),
(8197,'912bis Cercy, 62490 Quiéry-la-Motte');

INSERT INTO Organisation (numero,adresse) VALUES
(8198,'158 Moulin des Tempes, 40200 Mimizan'),
(8199,'999 Le Babinas, 27910 Letteguives');

INSERT INTO Organisation (numero,adresse) VALUES
(8200,'638 La borde de Loze, 17500 Allas-Champagne'),
(8201,'210 La_vialle, 77154 Villeneuve-les-Bordes');

INSERT INTO Organisation (numero,adresse) VALUES
(8202,'475 Virjalais, 02240 Brissy-Hamégicourt'),
(8203,'172bis Les Jardins Des Colettes, 73570 Brides-les-Bains');

INSERT INTO Organisation (numero,adresse) VALUES
(8204,'298 Les Amaryllis, 59320 Emmerin'),
(8205,'588bis Repiou, 51800 Minaucourt-le-Mesnil-lès-Hurlus');

INSERT INTO Organisation (numero,adresse) VALUES
(8206,'236 La croix des bois, 37350 Chaumussay'),
(8207,'373 Seguret, 33620 Laruscade');

INSERT INTO Organisation (numero,adresse) VALUES
(8208,'404 Les Valettes Sud, 55400 Damloup'),
(8209,'884 Route d''Eclassan, 25310 Villars-lès-Blamont');

INSERT INTO Organisation (numero,adresse) VALUES
(8210,'493bis L''Estanque, 27120 Houlbec-Cocherel'),
(8211,'557bis Lieudit Marty, 74370 Villaz');

INSERT INTO Organisation (numero,adresse) VALUES
(8212,'298 Sillignieu, 74500 Vinzier'),
(8213,'22bis Le Petit Chenois, 41270 Le Poislay');

INSERT INTO Organisation (numero,adresse) VALUES
(8214,'731 Appt. 2, 12490 Saint-Rome-de-Cernon'),
(8215,'161 Crachet, 08240 Fossé');

INSERT INTO Organisation (numero,adresse) VALUES
(8216,'927 Les fournils, 74250 Bogève'),
(8217,'494bis Cagnes Provencal C, 60360 Viefvillers');

INSERT INTO Organisation (numero,adresse) VALUES
(8218,'900 Place  Jean Montpellaz, 39570 Pannessières'),
(8219,'47 Ribaumes, 07000 Lyas');

INSERT INTO Organisation (numero,adresse) VALUES
(8220,'240 Domaine du Fleich, 55500 Maulan'),
(8221,'771bis Le Fond du Ham, 54870 Montigny-sur-Chiers');

INSERT INTO Organisation (numero,adresse) VALUES
(8222,'500bis Castagnou, 08170 Fumay'),
(8223,'908 Agence Postale Communale et Distributeur Billets, 63310 Saint-André-le-Coq');

INSERT INTO Organisation (numero,adresse) VALUES
(8224,'220 Chemin des Grands Pins, 70230 Thiénans'),
(8225,'153bis Moulin de Bonneval, 15300 Laveissière');

INSERT INTO Organisation (numero,adresse) VALUES
(8226,'297bis La Marseillaise, 80340 Cappy'),
(8227,'589 Mauras, 77780 Bourron-Marlotte');

INSERT INTO Organisation (numero,adresse) VALUES
(8228,'503 moulin, 20167 Alata'),
(8229,'806 Mourtis, 54610 Sivry');

INSERT INTO Organisation (numero,adresse) VALUES
(8230,'191 Antenne téléphonie, 59530 Hecq'),
(8231,'726 Vic le Haut, 27550 Fontaine-la-Soret');

INSERT INTO Organisation (numero,adresse) VALUES
(8232,'790bis Ponton - P, 25510 Laviron'),
(8233,'149 Lotissement le Grand Pré, 72380 Souillé');

INSERT INTO Organisation (numero,adresse) VALUES
(8234,'307bis Villagre, 23130 Le Chauchet'),
(8235,'765 Le Gros Moreau, 55210 Beney-en-Woëvre');

INSERT INTO Organisation (numero,adresse) VALUES
(8236,'789bis Bouchet Ravaux, 68210 Hagenbach'),
(8237,'964 Edelweiss, 40360 Pomarez');

INSERT INTO Organisation (numero,adresse) VALUES
(8238,'403 Impasse Madona, 30770 Arrigas'),
(8239,'670bis Courriaut, 76540 Sassetot-le-Mauconduit');

INSERT INTO Organisation (numero,adresse) VALUES
(8240,'698 Résidence du stade Bâtiment C, 69590 Pomeys'),
(8241,'409 Tacard, 56120 Guégon');

INSERT INTO Organisation (numero,adresse) VALUES
(8242,'347bis Villerous, 47190 Nicole'),
(8243,'103 Colletta Soubrana, 47310 Moncaut');

INSERT INTO Organisation (numero,adresse) VALUES
(8244,'755 Derrière l''Hôtesse, 58240 Toury-sur-Jour'),
(8245,'496 Le Grand Terne, 51800 Malmy');

INSERT INTO Organisation (numero,adresse) VALUES
(8246,'833 La Paire, 24340 Léguillac-de-Cercles'),
(8247,'437bis La Tarrinie, 24330 Blis-et-Born');

INSERT INTO Organisation (numero,adresse) VALUES
(8248,'35 Puech Marty, 16450 Le Grand-Madieu'),
(8249,'502 Les Baumes, 45320 Ervauville');

INSERT INTO Organisation (numero,adresse) VALUES
(8250,'89 Grosjeanne Ouest, 05000 La Bâtie-Vieille'),
(8251,'468bis Parc Logistique de l''Aube, 42600 Précieux');

INSERT INTO Organisation (numero,adresse) VALUES
(8252,'384 Villa Zagara, 63910 Vertaizon'),
(8253,'288bis La Repeyrade, 64230 Momas');

INSERT INTO Organisation (numero,adresse) VALUES
(8254,'896 Valcros, 51400 Baconnes'),
(8255,'362 Ile de Faux, 30460 Colognac');

INSERT INTO Organisation (numero,adresse) VALUES
(8256,'911bis Boulbennes de Lissac, 61160 Louvières-en-Auge'),
(8257,'403bis Magalassou, 03130 Liernolles');

INSERT INTO Organisation (numero,adresse) VALUES
(8258,'996 Les Culleries, 71460 Santilly'),
(8259,'132 Le Gleyzat, 62500 Saint-Martin-lez-Tatinghem');

INSERT INTO Organisation (numero,adresse) VALUES
(8260,'149 Nescoulac, 10120 Saint-Germain'),
(8261,'404 Boulevard Lamerette, 25690 Avoudrey');

INSERT INTO Organisation (numero,adresse) VALUES
(8262,'569 En Benevy, 32300 Aujan-Mournède'),
(8263,'422 Passage du Fret, 55170 Brauvilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(8264,'926 Frache, 77144 Chalifert'),
(8265,'729bis Voie liaison traverse Adolphe Isnard - Serrat Avenue Emile Henriot, 11380 Mas-Cabardès');

INSERT INTO Organisation (numero,adresse) VALUES
(8266,'21 La Côte de Braux, 06430 La Brigue'),
(8267,'78bis Le Bois Maireau, 80140 Fresnoy-Andainville');

INSERT INTO Organisation (numero,adresse) VALUES
(8268,'81 L''Eglise, 40320 Urgons'),
(8269,'13 Panissal, 60530 Crouy-en-Thelle');

INSERT INTO Organisation (numero,adresse) VALUES
(8270,'84bis Au Dessus de Daigny, 52110 Beurville'),
(8271,'769bis le Plos, 80310 Yzeux');

INSERT INTO Organisation (numero,adresse) VALUES
(8272,'474 Ferme de la Pardonne, 12390 Mayran'),
(8273,'503 Fontborne, 10200 Fuligny');

INSERT INTO Organisation (numero,adresse) VALUES
(8274,'675 Le Causse de Valette, 40190 Pujo-le-Plan'),
(8275,'627 Les Champs de la Plaine, 20246 Sorio');

INSERT INTO Organisation (numero,adresse) VALUES
(8276,'701 Bon-pommier, 59266 Banteux'),
(8277,'995 Residence St Maurice Bat B, 12430 Alrance');

INSERT INTO Organisation (numero,adresse) VALUES
(8278,'464 Lieu-dit Portet Las Rives, 10700 Salon'),
(8279,'194 Beau Bouchard, 57330 Volmerange-les-Mines');

INSERT INTO Organisation (numero,adresse) VALUES
(8280,'504 Devant Sévigny, 41800 Villavard'),
(8281,'622 Horizon Bleu, 60390 Le Vauroux');

INSERT INTO Organisation (numero,adresse) VALUES
(8282,'727 La Bouissona, 78125 Vieille-Église-en-Yvelines'),
(8283,'738 Lotissement Le Clos de Cassagne, 76390 Richemont');

INSERT INTO Organisation (numero,adresse) VALUES
(8284,'88bis Le Cavaignal, 36160 La Motte-Feuilly'),
(8285,'565 Route Départementale 6098, 76730 Omonville');

INSERT INTO Organisation (numero,adresse) VALUES
(8286,'221 """ Bouquetterie """, 58500 Rix'),
(8287,'129 Pujaout, 28210 Le Boullay-Mivoye');

INSERT INTO Organisation (numero,adresse) VALUES
(8288,'458 Monieri Ouest, 16210 Bellon'),
(8289,'694 Borde Neuve Nord, 12310 Bertholène');

INSERT INTO Organisation (numero,adresse) VALUES
(8290,'968 Les Grandes Gouilles, 22300 Lannion'),
(8291,'316 Ranc Courbier, 01140 Garnerans');

INSERT INTO Organisation (numero,adresse) VALUES
(8292,'43bis Le Saut de la Dame, 22210 Saint-Étienne-du-Gué-de-l''Isle'),
(8293,'116 La Rocase, 02130 Cramaille');

INSERT INTO Organisation (numero,adresse) VALUES
(8294,'429 Les Jonchiers, 02210 Armentières-sur-Ourcq'),
(8295,'648 Voie Alphonse et Odette Grebel, 05700 Étoile-Saint-Cyrice');

INSERT INTO Organisation (numero,adresse) VALUES
(8296,'32bis Bosquet du Maréchal, 17380 Annezay'),
(8297,'126bis Avenue du Stade Hlm Artois, 70160 Amance');

INSERT INTO Organisation (numero,adresse) VALUES
(8298,'983bis Giffon, 77440 Armentières-en-Brie'),
(8299,'905 Ginières, 59200 Tourcoing');

INSERT INTO Organisation (numero,adresse) VALUES
(8300,'694 las escallos, 54610 Abaucourt'),
(8301,'679 Les Pres de Colombies, 52120 Lanty-sur-Aube');

INSERT INTO Organisation (numero,adresse) VALUES
(8302,'413bis Le Lac Sud, 58000 Saint-Éloi'),
(8303,'228 L’Aspic, 28300 Challet');

INSERT INTO Organisation (numero,adresse) VALUES
(8304,'250bis Grande Borde, 40190 Hontanx'),
(8305,'574 Le Camp Del Bosc, 72220 Marigné-Laillé');

INSERT INTO Organisation (numero,adresse) VALUES
(8306,'612 Chalet Saint Ange, 54700 Norroy-lès-Pont-à-Mousson'),
(8307,'920 Rue de la Roque, 59620 Aulnoye-Aymeries');

INSERT INTO Organisation (numero,adresse) VALUES
(8308,'656 Mourteiron, 80120 Arry'),
(8309,'463 Bâtiment Le bleuet, 30870 Saint-Côme-et-Maruéjols');

INSERT INTO Organisation (numero,adresse) VALUES
(8310,'528 Hameau de Rébaillou, 16360 Le Tâtre'),
(8311,'760 Bâtiment Le coquelicot, 03150 Boucé');

INSERT INTO Organisation (numero,adresse) VALUES
(8312,'87 Mélan, 71800 Vareilles'),
(8313,'799 Chemin du Belvédère, 51260 Marcilly-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(8314,'182 Au Dessus du Fond de Manil, 60390 Beaumont-les-Nonains'),
(8315,'185 Chez Say, 11570 Palaja');

INSERT INTO Organisation (numero,adresse) VALUES
(8316,'338 Les Ourtrigous, 51350 Cormontreuil'),
(8317,'780bis Taillade, 30450 Génolhac');

INSERT INTO Organisation (numero,adresse) VALUES
(8318,'379 Verduc, 71440 Savigny-sur-Seille'),
(8319,'770 Bâtiment C2, 39400 Les Rousses');

INSERT INTO Organisation (numero,adresse) VALUES
(8320,'615bis La Roche de la Cime, 17470 Dampierre-sur-Boutonne'),
(8321,'433bis Passelaygue, 59213 Escarmain');

INSERT INTO Organisation (numero,adresse) VALUES
(8322,'885 La Réserve des Placiers, 50870 Chavoy'),
(8323,'701bis La Vessana, 37190 Neuil');

INSERT INTO Organisation (numero,adresse) VALUES
(8324,'171 Villa Luce, 57260 Bassing'),
(8325,'885 La Croix de la Faboulie, 06670 Saint-Martin-du-Var');

INSERT INTO Organisation (numero,adresse) VALUES
(8326,'905 La Coulangerie, 13250 Saint-Chamas'),
(8327,'194bis Voie liaison Chemin de la Madonette de Terron Chemin de l''Archet, 28230 Épernon');

INSERT INTO Organisation (numero,adresse) VALUES
(8328,'627bis Chateau de la Rochefoucauld, 01310 Saint-Rémy'),
(8329,'284 Les Choupis, 34390 Saint-Vincent-d''Olargues');

INSERT INTO Organisation (numero,adresse) VALUES
(8330,'99 Roc du DEVEZ, 38710 Cornillon-en-Trièves'),
(8331,'804 Combelade, 48400 Vebron');

INSERT INTO Organisation (numero,adresse) VALUES
(8332,'612 Route de Belpech, 27170 Perriers-la-Campagne'),
(8333,'138 Grandes Terres des Viaires, 31290 Villefranche-de-Lauragais');

INSERT INTO Organisation (numero,adresse) VALUES
(8334,'992 Petit Paris Hameau, 11620 Villemoustaussou'),
(8335,'841 Notre Dame de la Route, 60240 Serans');

INSERT INTO Organisation (numero,adresse) VALUES
(8336,'475 Les Marges, 74200 Anthy-sur-Léman'),
(8337,'334bis Villasaintroman, 27150 Bouchevilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(8338,'757 Chemin de la Lècque, 45260 Montereau'),
(8339,'309bis Chemin du Chateau, 63450 Le Crest');

INSERT INTO Organisation (numero,adresse) VALUES
(8340,'604 Ruelle du Verger, 47290 Moulinet'),
(8341,'845 Domaine de Jonquières, 47160 Caubeyres');

INSERT INTO Organisation (numero,adresse) VALUES
(8342,'856 Résidence les Hauts de Cadirac, 78930 Guerville'),
(8343,'694bis Moulin d''Aval, 14600 Genneville');

INSERT INTO Organisation (numero,adresse) VALUES
(8344,'766bis Le Sérieys, 33230 Abzac'),
(8345,'674 De Ruelle Lambercy, 32160 Couloumé-Mondebat');

INSERT INTO Organisation (numero,adresse) VALUES
(8346,'590bis Place  Jean Boyer, 68250 Westhalten'),
(8347,'369 Le Champ de Saule, 67350 Ringeldorf');

INSERT INTO Organisation (numero,adresse) VALUES
(8348,'420 Rue Cd No 946, 25480 Miserey-Salines'),
(8349,'643bis La Mal Amendee, 25410 Saint-Vit');

INSERT INTO Organisation (numero,adresse) VALUES
(8350,'970 Métairie du Château, 59270 Merris'),
(8351,'611 Hameau du Bassin, 47370 Tournon-d''Agenais');

INSERT INTO Organisation (numero,adresse) VALUES
(8352,'365 Place des Colombes, 64640 Lantabat'),
(8353,'798 Mouline-Ribiere, 02000 Vaucelles-et-Beffecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(8354,'812 Pain Blanc, 33750 Beychac-et-Caillau'),
(8355,'312bis Puech Del Bez, 67440 Lochwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(8356,'52 Logements communaux, 31620 Saint-Rustice'),
(8357,'655bis Croix Champillon, 59242 Genech');

INSERT INTO Organisation (numero,adresse) VALUES
(8358,'830bis Peyre Bruni, 22240 Fréhel'),
(8359,'389 Résidence Antoine Blondin - Bâtiment B, 21220 Détain-et-Bruant');

INSERT INTO Organisation (numero,adresse) VALUES
(8360,'695bis Les Galets Escalier 1, 36300 Douadic'),
(8361,'378bis Village de Banogne, 02160 Beaurieux');

INSERT INTO Organisation (numero,adresse) VALUES
(8362,'199bis La Grande Voie, 08220 Saint-Quentin-le-Petit'),
(8363,'337 Ferme du Parc, 27310 Honguemare-Guenouville');

INSERT INTO Organisation (numero,adresse) VALUES
(8364,'819 Le Marais du Mesnil, 46130 Estal'),
(8365,'334bis Les Grand Routes, 25310 Thulay');

INSERT INTO Organisation (numero,adresse) VALUES
(8366,'955bis Calvaire Saint Laurent, 37220 Rilly-sur-Vienne'),
(8367,'166 Les Cimetières, 74410 La Chapelle-Saint-Maurice');

INSERT INTO Organisation (numero,adresse) VALUES
(8368,'437 Les Cavalis, 39250 Esserval-Tartre'),
(8369,'960 Calcines, 51700 Baslieux-sous-Châtillon');

INSERT INTO Organisation (numero,adresse) VALUES
(8370,'248 La Lande de Fonbelle, 57130 Vernéville'),
(8371,'588 Rue Edouard Herriot, 19160 Chirac-Bellevue');

INSERT INTO Organisation (numero,adresse) VALUES
(8372,'530bis Clot de Rasigade, 33760 Targon'),
(8373,'547bis Le St Saens A, 77118 Gravon');

INSERT INTO Organisation (numero,adresse) VALUES
(8374,'354bis lotissement le Clos David, 02220 Ville-Savoye'),
(8375,'790 Roucayrol, 62860 Rumaucourt');

INSERT INTO Organisation (numero,adresse) VALUES
(8376,'294bis Place de Le Vernière, 01160 Neuville-sur-Ain'),
(8377,'957 Mazars, 31310 Latrape');

INSERT INTO Organisation (numero,adresse) VALUES
(8378,'551 Malvies, 68290 Sewen'),
(8379,'82 Clos Perrot, 67440 Dimbsthal');

INSERT INTO Organisation (numero,adresse) VALUES
(8380,'784 Pre Rachet, 46700 Cassagnes'),
(8381,'332bis Broussettes, 01630 Péron');

INSERT INTO Organisation (numero,adresse) VALUES
(8382,'130 Le Grand Pont, 55230 Amel-sur-l''Étang'),
(8383,'445bis La Borie du Colombie, 27400 Terres de Bord');

INSERT INTO Organisation (numero,adresse) VALUES
(8384,'227 Monquiers, 02870 Crépy'),
(8385,'267 La Matte, 29260 Ploudaniel');

INSERT INTO Organisation (numero,adresse) VALUES
(8386,'651 Bâtiment Le lavandin Entrée 18, 21430 Villiers-en-Morvan'),
(8387,'475 Salonzet, 78640 Saint-Germain-de-la-Grange');

INSERT INTO Organisation (numero,adresse) VALUES
(8388,'670 Les Carrons, 32600 L''Isle-Jourdain'),
(8389,'601bis Combe Gagiere, 18210 Thaumiers');

INSERT INTO Organisation (numero,adresse) VALUES
(8390,'108bis La Mal Amendee, 70100 Le Tremblois'),
(8391,'26bis Les Sauteaux, 43390 Azérat');

INSERT INTO Organisation (numero,adresse) VALUES
(8392,'988 Impasse Saint Exupéry, 40190 Le Frêche'),
(8393,'354 Le Chatillon, 77130 Varennes-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(8394,'420 Le Barrugat, 28700 Roinville'),
(8395,'62 Le Moulin de la Cammazie, 62123 Noyellette');

INSERT INTO Organisation (numero,adresse) VALUES
(8396,'835 Taches Derrière le Mont, 27230 Bazoques'),
(8397,'675 Place de la Gare, 54385 Avrainville');

INSERT INTO Organisation (numero,adresse) VALUES
(8398,'904 Le Pla de Cautirac, 14130 Le Breuil-en-Auge'),
(8399,'533 Bois des Cornillards, 59380 Quaëdypre');

INSERT INTO Organisation (numero,adresse) VALUES
(8400,'120bis Le Frayssinet Haut, 14123 Cormelles-le-Royal'),
(8401,'858bis la Bourdette, 02360 Cuiry-lès-Iviers');

INSERT INTO Organisation (numero,adresse) VALUES
(8402,'220 Al Pla-ouest, 50210 Guéhébert'),
(8403,'84 Le Grand Mont, 61140 Rives d''Andaine');

INSERT INTO Organisation (numero,adresse) VALUES
(8404,'952 Le Mondelet, 50700 Saint-Joseph'),
(8405,'282 Lou Mazet, 68300 Saint-Louis');

INSERT INTO Organisation (numero,adresse) VALUES
(8406,'389 Les Coués, 67480 Rœschwoog'),
(8407,'375 Lieu-dit Bastide, 57200 Frauenberg');

INSERT INTO Organisation (numero,adresse) VALUES
(8408,'656bis Route de la première division de la France libre, 61230 La Trinité-des-Laitiers'),
(8409,'594bis Montmouth, 65190 Orieux');

INSERT INTO Organisation (numero,adresse) VALUES
(8410,'200 La Broussiere, 21690 Villotte-Saint-Seine'),
(8411,'652 Pré du Gros, 71700 Ozenay');

INSERT INTO Organisation (numero,adresse) VALUES
(8412,'948 La Penne, 30610 Saint-Nazaire-des-Gardies'),
(8413,'21 Bât A3 les hauts de Septèmes sud, 64170 Serres-Sainte-Marie');

INSERT INTO Organisation (numero,adresse) VALUES
(8414,'227 Villa Le Nid, 21420 Bouilland'),
(8415,'600 Domaine d''Altou, 48300 Pierrefiche');

INSERT INTO Organisation (numero,adresse) VALUES
(8416,'419 Place de l''Eglise St Amans, 72310 Cogners'),
(8417,'482bis Lotissement la Parau, 76660 Londinières');

INSERT INTO Organisation (numero,adresse) VALUES
(8418,'771 Pont du Petit Tournon, 51330 Charmont'),
(8419,'751 Les jas, 51700 Vincelles');

INSERT INTO Organisation (numero,adresse) VALUES
(8420,'776 Hameau LES GOURBELS, 60380 Thérines'),
(8421,'901bis Réserve souple Incendie, 65230 Hachan');

INSERT INTO Organisation (numero,adresse) VALUES
(8422,'108 La Bouleste Haute, 43300 Chazelles'),
(8423,'431 Chemin de la Blanchere, 77120 Giremoutiers');

INSERT INTO Organisation (numero,adresse) VALUES
(8424,'258 Salgues, 15160 Allanche'),
(8425,'619bis """ Les Jacquets """, 39800 Grozon');

INSERT INTO Organisation (numero,adresse) VALUES
(8426,'899bis Bouyssiere, 62116 Ayette'),
(8427,'540 Les Monts Rouvets, 54114 Jeandelaincourt');

INSERT INTO Organisation (numero,adresse) VALUES
(8428,'412 Les Amiers, 57380 Boustroff'),
(8429,'873 Lotissement les Vieilles Vignes, 56920 Noyal-Pontivy');

INSERT INTO Organisation (numero,adresse) VALUES
(8430,'973 Ham de Charoué, 61600 La Chaux'),
(8431,'733 Rue du Château d''eau, 67270 Zœbersdorf');

INSERT INTO Organisation (numero,adresse) VALUES
(8432,'276 Hameau de Jouandou, 77151 Montceaux-lès-Provins'),
(8433,'741 Pre de Gautie, 70140 Malans');

INSERT INTO Organisation (numero,adresse) VALUES
(8434,'272 ZA du Troncas, 62128 Saint-Léger'),
(8435,'356 Les Scoubidous, 14380 Noues de Sienne');

INSERT INTO Organisation (numero,adresse) VALUES
(8436,'855 Rond-Point  Jean Boulitreau, 08230 Taillette'),
(8437,'458 Malpel, 42310 Urbise');

INSERT INTO Organisation (numero,adresse) VALUES
(8438,'561 Pesse Blanque, 76540 Thérouldeville'),
(8439,'241 Vers les Nez, 51330 Noirlieu');

INSERT INTO Organisation (numero,adresse) VALUES
(8440,'370 Le Verger, 53700 Saint-Germain-de-Coulamer'),
(8441,'991 Guilholma, 80110 Aubvillers');

INSERT INTO Organisation (numero,adresse) VALUES
(8442,'907bis La Forêt et les Champs Frais, 47340 Laroque-Timbaut'),
(8443,'871 Les Donhes Hautes, 62860 Palluel');

INSERT INTO Organisation (numero,adresse) VALUES
(8444,'898bis Parking des Oches, 62147 Graincourt-lès-Havrincourt'),
(8445,'888bis Tanayssou, 71580 Flacey-en-Bresse');

INSERT INTO Organisation (numero,adresse) VALUES
(8446,'862 Le Champ à Perdrix, 80170 Caix'),
(8447,'868 Pas de l''Estradelle, 02130 Saponay');

INSERT INTO Organisation (numero,adresse) VALUES
(8448,'459 Prés des Tets, 34550 Bessan'),
(8449,'154 L’Estoupe, 08430 Villers-le-Tourneur');

INSERT INTO Organisation (numero,adresse) VALUES
(8450,'540 Réserve Incendie Louvry, 80140 Neuville-au-Bois'),
(8451,'700 Voie accès Lycée René Goscinny, 41000 Villebarou');

INSERT INTO Organisation (numero,adresse) VALUES
(8452,'356 Bouchalas, 33370 Sallebœuf'),
(8453,'266 Les Garines, 65380 Azereix');

INSERT INTO Organisation (numero,adresse) VALUES
(8454,'428 Aire de Repos, 59127 Walincourt-Selvigny'),
(8455,'397bis Villa Sabaodia, 27120 Hardencourt-Cocherel');

INSERT INTO Organisation (numero,adresse) VALUES
(8456,'720 Bettay, 41330 Marolles'),
(8457,'885 Corbou, 69620 Légny');

INSERT INTO Organisation (numero,adresse) VALUES
(8458,'234 Barraque du Puech, 66690 Sorède'),
(8459,'332 Allée du Père Bahier, 59144 Amfroipret');

INSERT INTO Organisation (numero,adresse) VALUES
(8460,'766bis La Foret-Viau la Foret-Viau, 53230 Méral'),
(8461,'336bis Chemin Clérissi, 55270 Boureuilles');

INSERT INTO Organisation (numero,adresse) VALUES
(8462,'532bis Parc Léonor, 62850 Herbinghen'),
(8463,'325bis Haut de la Perthe, 07560 Le Roux');

INSERT INTO Organisation (numero,adresse) VALUES
(8464,'889 Petit Ravataux, 74130 Brizon'),
(8465,'785bis Clot de Bousquet, 32300 Saint-Ost');

INSERT INTO Organisation (numero,adresse) VALUES
(8466,'774 Pradines, 60750 Choisy-au-Bac'),
(8467,'430bis Voie Georges Meygret, 19340 Couffy-sur-Sarsonne');

INSERT INTO Organisation (numero,adresse) VALUES
(8468,'991 La Borie de Belly, 74930 Scientrier'),
(8469,'20 "Buvette "" L''Ecume des jours """, 16300 Saint-Médard');

INSERT INTO Organisation (numero,adresse) VALUES
(8470,'5 Hameau de la Ferme d''Anjou, 67420 Ranrupt'),
(8471,'948 Cuilleré, 27630 Vexin-sur-Epte');

INSERT INTO Organisation (numero,adresse) VALUES
(8472,'421 St Jean des Sapinettes, 56450 Le Hézo'),
(8473,'93 Mascammeau, 14250 Bucéels');

INSERT INTO Organisation (numero,adresse) VALUES
(8474,'271 Sautins, 24590 Jayac'),
(8475,'299bis Chateau de Ronnet, 21420 Pernand-Vergelesses');

INSERT INTO Organisation (numero,adresse) VALUES
(8476,'152bis Les Hauches de Tourton, 62130 Monts-en-Ternois'),
(8477,'875bis La Borde de Bas, 51140 Chenay');

INSERT INTO Organisation (numero,adresse) VALUES
(8478,'937 Tieulet, 34700 Le Puech'),
(8479,'41 La Courbaisse Haute, 39570 Trenal');

INSERT INTO Organisation (numero,adresse) VALUES
(8480,'333 Allée Emile Zola, 51300 Dompremy'),
(8481,'690 Les Preis, 03140 Monestier');

INSERT INTO Organisation (numero,adresse) VALUES
(8482,'326 Les Bords de Loire, 76310 Sainte-Adresse'),
(8483,'114 Bois Messire Jean, 33720 Saint-Michel-de-Rieufret');

INSERT INTO Organisation (numero,adresse) VALUES
(8484,'393bis Les Aubepines, 35230 Noyal-Châtillon-sur-Seiche'),
(8485,'336 Le Travers du Tamas, 39600 Mathenay');

INSERT INTO Organisation (numero,adresse) VALUES
(8486,'205 Monatgne de Bassibie, 76430 La Cerlangue'),
(8487,'252 Allée privée dite chemin du Parc Springland, 30360 Saint-Maurice-de-Cazevieille');

INSERT INTO Organisation (numero,adresse) VALUES
(8488,'896 La Basse Gréyère, 41300 Orçay'),
(8489,'328bis Marais de Sergy, 31440 Argut-Dessous');

INSERT INTO Organisation (numero,adresse) VALUES
(8490,'795bis Daulou, 08400 Vouziers'),
(8491,'996 Fergue, 61210 Sainte-Honorine-la-Guillaume');

INSERT INTO Organisation (numero,adresse) VALUES
(8492,'649 Champ de Seyne, 16130 Verrières'),
(8493,'8 Chemin de la Garenne, 69100 Villeurbanne');

INSERT INTO Organisation (numero,adresse) VALUES
(8494,'947 Parc Logistique de l''Aube, 60800 Feigneux'),
(8495,'871 Résidence Anglade Bat Fonta C1 - Salau, 17700 Puyravault');

INSERT INTO Organisation (numero,adresse) VALUES
(8496,'943bis Devant Ville, 05130 Sigoyer'),
(8497,'934 Ventelon, 67490 Dettwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(8498,'629 Cribas le Bas, 02320 Allemant'),
(8499,'401 Grillères, 57570 Mondorff');

INSERT INTO Organisation (numero,adresse) VALUES
(8500,'344bis Les Maisons de la Mer 1, 12490 Saint-Rome-de-Tarn'),
(8501,'910 Bretelle Sortie N°50 A8 - Mercantour (Provenance Cannes) sud, 12440 Lescure-Jaoul');

INSERT INTO Organisation (numero,adresse) VALUES
(8502,'91bis Careille, 04250 Bellaffaire'),
(8503,'824bis Flaugiere, 54122 Chenevières');

INSERT INTO Organisation (numero,adresse) VALUES
(8504,'794 Alidieres, 70200 Froideterre'),
(8505,'845bis La Plaine de Presles, 50190 Gonfreville');

INSERT INTO Organisation (numero,adresse) VALUES
(8506,'196 Puech-Long, 76780 Nolléval'),
(8507,'496 L'' Ardillier, 04250 Faucon-du-Caire');

INSERT INTO Organisation (numero,adresse) VALUES
(8508,'928 Bellevue, 31260 Montsaunès'),
(8509,'160bis Le Serret Sud, 11500 Quillan');

INSERT INTO Organisation (numero,adresse) VALUES
(8510,'53 Chemin des Chassaings, 02870 Bucy-lès-Cerny'),
(8511,'215 Traverse Record, 58500 Pousseaux');

INSERT INTO Organisation (numero,adresse) VALUES
(8512,'24 Terre Blanche, 37460 Montrésor'),
(8513,'36 Les Genevrieres, 07120 Pradons');

INSERT INTO Organisation (numero,adresse) VALUES
(8514,'497 Bois Canot, 77140 Darvault'),
(8515,'322 Aux Granges Peclet, 11160 Rieux-Minervois');

INSERT INTO Organisation (numero,adresse) VALUES
(8516,'174bis Le Concorde Bat 1 Esc 1, 65240 Estarvielle'),
(8517,'822 Loulier, 04320 Entrevaux');

INSERT INTO Organisation (numero,adresse) VALUES
(8518,'575 Jardin D''Azur B, 62120 Linghem'),
(8519,'789bis Le Champ Del Mas, 68480 Lutter');

INSERT INTO Organisation (numero,adresse) VALUES
(8520,'537 Derriere les Fosses, 16330 Xambes'),
(8521,'356 Barde, 24260 Journiac');

INSERT INTO Organisation (numero,adresse) VALUES
(8522,'484 Chemin du Collet de Grisella, 03460 Trévol'),
(8523,'326 La Galante, 44430 La Remaudière');

INSERT INTO Organisation (numero,adresse) VALUES
(8524,'581 Espious et Blanco, 29380 Saint-Thurien'),
(8525,'601 Camp de la Bordo, 47360 Frégimont');

INSERT INTO Organisation (numero,adresse) VALUES
(8526,'356 Carmentran, 14230 Neuilly-la-Forêt'),
(8527,'929 Allée Netanya, 77120 Beautheil');

INSERT INTO Organisation (numero,adresse) VALUES
(8528,'726 Cadravals Bas, 32140 Esclassan-Labastide'),
(8529,'596bis Eglise Notre Dame de Nazareth, 42460 Coutouvre');

INSERT INTO Organisation (numero,adresse) VALUES
(8530,'900 Magreou, 14330 Saon'),
(8531,'60 La Coute, 27400 Crasville');

INSERT INTO Organisation (numero,adresse) VALUES
(8532,'667 La Croix Philippe, 60119 Hénonville'),
(8533,'305 au verger, 55150 Saint-Laurent-sur-Othain');

INSERT INTO Organisation (numero,adresse) VALUES
(8534,'186 Les Cousteilles, 09230 Fabas'),
(8535,'660 Les Lauriers Roses, 23160 Bazelat');

INSERT INTO Organisation (numero,adresse) VALUES
(8536,'239 Courbaud d’En Bas, 24540 Saint-Marcory'),
(8537,'421 La Combe du Ray, 43200 Saint-Maurice-de-Lignon');

INSERT INTO Organisation (numero,adresse) VALUES
(8538,'50 Les Sapins, 07800 Charmes-sur-Rhône'),
(8539,'790bis Les Ondines, 80130 Bourseville');

INSERT INTO Organisation (numero,adresse) VALUES
(8540,'744 Au Bois du Til, 52200 Peigney'),
(8541,'453 Guerre, 63470 Verneugheol');

INSERT INTO Organisation (numero,adresse) VALUES
(8542,'346bis Ranc du Prieur les Repanti, 31420 Bachas'),
(8543,'182 Mouciera Inferieure, 36500 Vendœuvres');

INSERT INTO Organisation (numero,adresse) VALUES
(8544,'51 Le Pouret, 80210 Valines'),
(8545,'135 Route Saint-Sébastien, 36160 Sainte-Sévère-sur-Indre');

INSERT INTO Organisation (numero,adresse) VALUES
(8546,'189bis La Hajelette, 48700 Estables'),
(8547,'882bis Hameau de Vorages d’En Haut, 32300 Clermont-Pouyguillès');

INSERT INTO Organisation (numero,adresse) VALUES
(8548,'917 Voie liaison Avenue du Bois de Cythère - Chemin de la Petite Source, 51290 Lignon'),
(8549,'670 Le Rivet du Pied, 65260 Adast');

INSERT INTO Organisation (numero,adresse) VALUES
(8550,'371 Prés Marie, 55300 Lamorville'),
(8551,'566 Cavurne, 49520 Le Bourg-d''Iré');

INSERT INTO Organisation (numero,adresse) VALUES
(8552,'627 Les Petites Champagnes, 48230 Chanac'),
(8553,'449 Le Moulin d’Arneau, 66130 Saint-Michel-de-Llotes');

INSERT INTO Organisation (numero,adresse) VALUES
(8554,'134bis Audura, 20290 Ortiporio'),
(8555,'880 Chouris, 64260 Bescat');

INSERT INTO Organisation (numero,adresse) VALUES
(8556,'778 Cros, 14540 Poussy-la-Campagne'),
(8557,'755 Plan de l''Orme, 80240 Aizecourt-le-Bas');

INSERT INTO Organisation (numero,adresse) VALUES
(8558,'357 La Jonna, 45230 Adon'),
(8559,'293 Piene Haute, 11250 Saint-Hilaire');

INSERT INTO Organisation (numero,adresse) VALUES
(8560,'686 Vesvre, 72330 Cérans-Foulletourte'),
(8561,'483bis Pesacyrol, 54760 Moivrons');

INSERT INTO Organisation (numero,adresse) VALUES
(8562,'261 Lieu Dit Lasserre, 53110 Lassay-les-Châteaux'),
(8563,'969 Le Perier, 72360 Mayet');

INSERT INTO Organisation (numero,adresse) VALUES
(8564,'942 Les Négrats, 58230 Moux-en-Morvan'),
(8565,'381 Le Gros Bonnet, 78910 Boissets');

INSERT INTO Organisation (numero,adresse) VALUES
(8566,'426 Résidence La Pommeraie, 40260 Linxe'),
(8567,'18 Sammissieu, 80210 Acheux-en-Vimeu');

INSERT INTO Organisation (numero,adresse) VALUES
(8568,'277bis Lotissement Val de Tourame II, 71250 Blanot'),
(8569,'998bis Murasson, 21510 Aignay-le-Duc');

INSERT INTO Organisation (numero,adresse) VALUES
(8570,'433 le Cheminot, 16410 Dignac'),
(8571,'973bis Résidence Port Plaisance, 64350 Simacourbe');

INSERT INTO Organisation (numero,adresse) VALUES
(8572,'586 Pla des Arques, 41190 Chambon-sur-Cisse'),
(8573,'396bis École Maternelle de la Pinède, 66730 Rabouillet');

INSERT INTO Organisation (numero,adresse) VALUES
(8574,'416 Parvis des Mosaïques, 74380 Arthaz-Pont-Notre-Dame'),
(8575,'734 La Basse Troliere, 39270 Onoz');

INSERT INTO Organisation (numero,adresse) VALUES
(8576,'168 La Catonne, 22240 Fréhel'),
(8577,'394 Sourret, 33540 Blasimon');

INSERT INTO Organisation (numero,adresse) VALUES
(8578,'3bis Coste Rouge, 23400 Saint-Priest-Palus'),
(8579,'355 Camefort, 79200 Lageon');

INSERT INTO Organisation (numero,adresse) VALUES
(8580,'373 Les Pieces Nobles, 62380 Acquin-Westbécourt'),
(8581,'287 Camin Louis Michel, 02310 Bézu-le-Guéry');

INSERT INTO Organisation (numero,adresse) VALUES
(8582,'495bis Le Vieux Port, 14550 Blainville-sur-Orne'),
(8583,'144bis """ Les Peillereaux """, 23240 Le Grand-Bourg');

INSERT INTO Organisation (numero,adresse) VALUES
(8584,'918 Villa Alexandra, 55210 Saint-Maurice-sous-les-Côtes'),
(8585,'246 Moulin de Biac, 25720 Larnod');

INSERT INTO Organisation (numero,adresse) VALUES
(8586,'650 Rue du Vieux Four, 11800 Trèbes'),
(8587,'756bis Four de Perry, 29150 Châteaulin');

INSERT INTO Organisation (numero,adresse) VALUES
(8588,'760bis Les Régnauds, 53360 Houssay'),
(8589,'414 La Boutonnette, 38300 Domarin');

INSERT INTO Organisation (numero,adresse) VALUES
(8590,'88 Les Bringues, 32290 Saint-Pierre-d''Aubézies'),
(8591,'57 As Jasses-sud, 38930 Chichilianne');

INSERT INTO Organisation (numero,adresse) VALUES
(8592,'111 Champ de Bief, 55210 Chaillon'),
(8593,'3 Les Hameaux d''Oraison, 43160 Berbezit');

INSERT INTO Organisation (numero,adresse) VALUES
(8594,'79 La Petite Locaterie, 76440 Sainte-Geneviève'),
(8595,'687 Les Vergers Villa 6, 18240 Sainte-Gemme-en-Sancerrois');

INSERT INTO Organisation (numero,adresse) VALUES
(8596,'690 Pigautier, 07190 Saint-Étienne-de-Serre'),
(8597,'82 Chemin du Prugnon, 32310 Lagardère');

INSERT INTO Organisation (numero,adresse) VALUES
(8598,'411 Rue de l''Enclos, 60590 Villers-sur-Trie'),
(8599,'457bis Les Matriots, 51270 Mareuil-en-Brie');

INSERT INTO Organisation (numero,adresse) VALUES
(8600,'125 Trassoulas, 60120 Beauvoir'),
(8601,'521bis La Besse Noits, 02260 Froidestrées');

INSERT INTO Organisation (numero,adresse) VALUES
(8602,'713bis Chemin de la Canague, 62360 Isques'),
(8603,'837bis Domaine Plaine de Sie, 24120 Villac');

INSERT INTO Organisation (numero,adresse) VALUES
(8604,'204 Cayzac, 02840 Parfondru'),
(8605,'699bis La Bartasse, 44680 Saint-Mars-de-Coutais');

INSERT INTO Organisation (numero,adresse) VALUES
(8606,'399 École élémentaire Ampère - ERP, 20230 San-Giuliano'),
(8607,'199 Combe Lange, 49420 Armaillé');

INSERT INTO Organisation (numero,adresse) VALUES
(8608,'589 Le Puech de la Poujade, 21250 Corberon'),
(8609,'527bis Pescayret, 21540 Aubigny-lès-Sombernon');

INSERT INTO Organisation (numero,adresse) VALUES
(8610,'73 La Rouge, 51130 Givry-lès-Loisy'),
(8611,'533 lieu dit Lacoste, 56540 Le Croisty');

INSERT INTO Organisation (numero,adresse) VALUES
(8612,'294 Le Champ d''Orcy, 30340 Saint-Privat-des-Vieux'),
(8613,'616 le Mollard, 77230 Saint-Mard');

INSERT INTO Organisation (numero,adresse) VALUES
(8614,'316 Les Baumes et les Cresses, 63160 Espirat'),
(8615,'84bis Fond de Bussy, 59239 Thumeries');

INSERT INTO Organisation (numero,adresse) VALUES
(8616,'394 Le Puech et Zigounets, 39240 Valfin-sur-Valouse'),
(8617,'461 Dangou, 77400 Pomponne');

INSERT INTO Organisation (numero,adresse) VALUES
(8618,'630bis Carlas, 24560 Sainte-Radegonde'),
(8619,'208bis Résidence Le Clos de l''Etang, 73440 Les Belleville');

INSERT INTO Organisation (numero,adresse) VALUES
(8620,'743 Les Gaudres, 62124 Ruyaulcourt'),
(8621,'522bis Lieu dit le Bois du Four, 18000 Bourges');

INSERT INTO Organisation (numero,adresse) VALUES
(8622,'916 Grandvaux, 21580 Busserotte-et-Montenaille'),
(8623,'247bis Las Carrières, 61300 L''Aigle');

INSERT INTO Organisation (numero,adresse) VALUES
(8624,'986 Le Grand Mont, 54113 Moutrot'),
(8625,'100 Le pleidieu, 32230 Scieurac-et-Flourès');

INSERT INTO Organisation (numero,adresse) VALUES
(8626,'185 moulin, 54740 Crantenoy'),
(8627,'774 Bourge, 77690 La Genevraye');

INSERT INTO Organisation (numero,adresse) VALUES
(8628,'895 Ristolas, 70180 Roche-et-Raucourt'),
(8629,'585 Chambrançon, 14230 Osmanville');

INSERT INTO Organisation (numero,adresse) VALUES
(8630,'508bis Badassou, 30530 La Vernarède'),
(8631,'537 Chemin de Pré Long, 65400 Ouzous');

INSERT INTO Organisation (numero,adresse) VALUES
(8632,'301 Bois Thivon, 63440 Lisseuil'),
(8633,'164 Hameau du Villaret, 12220 Galgan');

INSERT INTO Organisation (numero,adresse) VALUES
(8634,'794 Allée des Chênes, 30450 Génolhac'),
(8635,'478 Chez Rolland, 14130 Le Torquesne');

INSERT INTO Organisation (numero,adresse) VALUES
(8636,'584 Le Château de Brugheas, 23400 Saint-Junien-la-Bregère'),
(8637,'540bis Mottin Ferme, 12200 Saint-Rémy');

INSERT INTO Organisation (numero,adresse) VALUES
(8638,'663 Les Guérins, 62580 Willerval'),
(8639,'137 Antenne téléphonie, 39570 Courbouzon');

INSERT INTO Organisation (numero,adresse) VALUES
(8640,'68 Brule_biasse, 77133 Machault'),
(8641,'708bis Mayumbe, 20218 Morosaglia');

INSERT INTO Organisation (numero,adresse) VALUES
(8642,'768bis Ambert, 02810 Hautevesnes'),
(8643,'976bis Résidence Cres de la Ginestelle, 18330 Vouzeron');

INSERT INTO Organisation (numero,adresse) VALUES
(8644,'663 La Burguiere Basse, 31530 Bellegarde-Sainte-Marie'),
(8645,'835 Allée Colonel Beltrame, 70000 Dampvalley-lès-Colombe');

INSERT INTO Organisation (numero,adresse) VALUES
(8646,'435 Aux closures Berthelon, 02540 Montfaucon'),
(8647,'944bis """ La Meschine """, 56460 Val d''Oust');

INSERT INTO Organisation (numero,adresse) VALUES
(8648,'806bis Château Des Millets, 02650 Fossoy'),
(8649,'269 Ferme de la Grange des Prés, 07310 La Rochette');

INSERT INTO Organisation (numero,adresse) VALUES
(8650,'212 Aux Cotes, 17500 Guitinières'),
(8651,'333bis Aux Eguets, 25360 Passavant');

INSERT INTO Organisation (numero,adresse) VALUES
(8652,'15 Les Poulards, 50250 Picauville'),
(8653,'23 Résidence St Vincent, 40320 Philondenx');

INSERT INTO Organisation (numero,adresse) VALUES
(8654,'208bis Rond-Point  Pierre Tchernia, 52800 Mandres-la-Côte'),
(8655,'190bis Villa Solea Bat B, 60490 Marquéglise');

INSERT INTO Organisation (numero,adresse) VALUES
(8656,'525 Cadepau, 68210 Eteimbes'),
(8657,'719 Le Rouchat, 45300 Givraines');

INSERT INTO Organisation (numero,adresse) VALUES
(8658,'485bis Borde Neuve Nord, 21140 Magny-la-Ville'),
(8659,'789 L''Orée de La Lombardière, 78120 Clairefontaine-en-Yvelines');

INSERT INTO Organisation (numero,adresse) VALUES
(8660,'310 Puech Mouly, 10510 Maizières-la-Grande-Paroisse'),
(8661,'832bis Place du 19 Mars 1962, 44760 La Bernerie-en-Retz');

INSERT INTO Organisation (numero,adresse) VALUES
(8662,'623 Quartier la Bastide, 70210 Melincourt'),
(8663,'818 les Maisonnettes, 37800 Pouzay');

INSERT INTO Organisation (numero,adresse) VALUES
(8664,'22 Verseille, 10160 Maraye-en-Othe'),
(8665,'105 Blâches-Gombert, 65380 Ossun');

INSERT INTO Organisation (numero,adresse) VALUES
(8666,'508 Square Dominique Durandy, 39190 Grusse'),
(8667,'920 Plô Marty, 18340 Vorly');

INSERT INTO Organisation (numero,adresse) VALUES
(8668,'476bis Le Bois des Haies, 16410 Garat'),
(8669,'861 Les Chanels, 73630 La Compôte');

INSERT INTO Organisation (numero,adresse) VALUES
(8670,'576 Champ Beau, 08700 Joigny-sur-Meuse'),
(8671,'108 Mezeyrac, 79170 Brioux-sur-Boutonne');

INSERT INTO Organisation (numero,adresse) VALUES
(8672,'124 La Capelle de Lardeyrolles, 36160 Champillet'),
(8673,'115 Les Nereides, 51360 Val-de-Vesle');

INSERT INTO Organisation (numero,adresse) VALUES
(8674,'456 Le Maresol, 13740 Le Rove'),
(8675,'244 Rue des Acacias, 31110 Caubous');

INSERT INTO Organisation (numero,adresse) VALUES
(8676,'234 Les Priourets, 67400 Illkirch-Graffenstaden'),
(8677,'887 Le Village St Julien, 02210 Breny');

INSERT INTO Organisation (numero,adresse) VALUES
(8678,'754bis L’Albarede, 37310 Chambourg-sur-Indre'),
(8679,'285 La-Blacheyrette, 71710 Les Bizots');

INSERT INTO Organisation (numero,adresse) VALUES
(8680,'908 Escalier Olivetto - Ménard, 31220 Le Plan'),
(8681,'846 Résidence Les Pinèdes du Golf, 72270 Courcelles-la-Forêt');

INSERT INTO Organisation (numero,adresse) VALUES
(8682,'994bis Blancard, 32100 Blaziert'),
(8683,'924 Les Amandiers, 21110 Marliens');

INSERT INTO Organisation (numero,adresse) VALUES
(8684,'792 Allée Casal, 08350 Bosseval-et-Briancourt'),
(8685,'325 Les Emoutouses, 51240 Vitry-la-Ville');

INSERT INTO Organisation (numero,adresse) VALUES
(8686,'102bis melac, 01600 Misérieux'),
(8687,'445 Bretelle Sortie N°49 A8 - Saint-Laurent-du-Var (Provenance Cannes), 17400 Saint-Jean-d''Angély');

INSERT INTO Organisation (numero,adresse) VALUES
(8688,'17 La Coutarie-Haute, 28300 Poisvilliers'),
(8689,'34 Flies, 19140 Condat-sur-Ganaveix');

INSERT INTO Organisation (numero,adresse) VALUES
(8690,'346 La Plaire, 20239 Rutali'),
(8691,'526 Ressouvaou, 79100 Oiron');

INSERT INTO Organisation (numero,adresse) VALUES
(8692,'917 Lourou, 64800 Nay'),
(8693,'232bis Domaine de Bela Bisto, 63114 Coudes');

INSERT INTO Organisation (numero,adresse) VALUES
(8694,'355 Mas des Fonts, 64350 Lannecaube'),
(8695,'91 Les Mouilles, 21350 Vitteaux');

INSERT INTO Organisation (numero,adresse) VALUES
(8696,'809 Pouech, 58350 Nannay'),
(8697,'54 Les Gouttes, 30760 Aiguèze');

INSERT INTO Organisation (numero,adresse) VALUES
(8698,'759bis Mairie annexe de La Pointe de Contes, 52600 Heuilley-le-Grand'),
(8699,'490bis Faubourg d''En Bas, 19130 Voutezac');

INSERT INTO Organisation (numero,adresse) VALUES
(8700,'401 Sauvage, 64330 Taron-Sadirac-Viellenave'),
(8701,'72bis Lotissement le Rancure, 14480 Cully');

INSERT INTO Organisation (numero,adresse) VALUES
(8702,'506 Le Terne Jean Servais, 59159 Noyelles-sur-Escaut'),
(8703,'904bis Avignas, 67190 Gresswiller');

INSERT INTO Organisation (numero,adresse) VALUES
(8704,'740 Château Dollet, 57860 Roncourt'),
(8705,'691 Le Bois Madame, 54820 Marbache');

INSERT INTO Organisation (numero,adresse) VALUES
(8706,'505bis Le Potier, 33730 Villandraut'),
(8707,'666 Tré Charavu - Cormaranche-en-Bugey, 72450 Montfort-le-Gesnois');

INSERT INTO Organisation (numero,adresse) VALUES
(8708,'758 Pre Henquau, 62450 Riencourt-lès-Bapaume'),
(8709,'716bis Rascassies, 58380 Lucenay-lès-Aix');

INSERT INTO Organisation (numero,adresse) VALUES
(8710,'106 Lotissement Les Graviers II, 43510 Saint-Jean-Lachalm'),
(8711,'900bis Le Portail Ferrier, 16700 La Faye');

INSERT INTO Organisation (numero,adresse) VALUES
(8712,'451 Avenue Santos - Dumont, 39170 Ravilloles'),
(8713,'136bis Les Fourniols, 60150 Chevincourt');

INSERT INTO Organisation (numero,adresse) VALUES
(8714,'113bis Santa Barbara, 30770 Vissec'),
(8715,'307 Route de Richebourg, 40500 Audignon');

INSERT INTO Organisation (numero,adresse) VALUES
(8716,'594 Lieu-dit Combe Levas, 27350 Valletot'),
(8717,'140bis Aygues Negres, 62760 Mondicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(8718,'428 Le Verger, 77410 Précy-sur-Marne'),
(8719,'806 Le Potet, 70800 Magnoncourt');

INSERT INTO Organisation (numero,adresse) VALUES
(8720,'678bis Les Grandes Soulières, 10160 Bérulle'),
(8721,'222 Saint Mayard, 57720 Erching');

INSERT INTO Organisation (numero,adresse) VALUES
(8722,'135 Grand Corvey, 13008 Marseille 08'),
(8723,'312 Fontmichelle, 62127 Maizières');

INSERT INTO Organisation (numero,adresse) VALUES
(8724,'237 La Castelloise, 78550 Dannemarie'),
(8725,'265bis Las Souquos, 16460 Chenommet');

INSERT INTO Organisation (numero,adresse) VALUES
(8726,'72 La Greppe, 55260 Baudrémont'),
(8727,'454 Rue des Figuiers, 77111 Solers');

INSERT INTO Organisation (numero,adresse) VALUES
(8728,'412 Le Barrugat, 49540 Aubigné-sur-Layon'),
(8729,'420 En Biasse, 01990 Chaneins');

INSERT INTO Organisation (numero,adresse) VALUES
(8730,'915 Les Courtoirades, 26750 Geyssans'),
(8731,'982 Rond-Point  Roger Fert, 73670 Entremont-le-Vieux');

INSERT INTO Organisation (numero,adresse) VALUES
(8732,'808 l''Albarea, 14220 Grimbosq'),
(8733,'883bis Les Foulons, 10100 Pars-lès-Romilly');

INSERT INTO Organisation (numero,adresse) VALUES
(8734,'589 La Trille Vieux, 10320 Assenay'),
(8735,'85bis Gensac-Haut, 64780 Suhescun');

INSERT INTO Organisation (numero,adresse) VALUES
(8736,'902 Pré de Monsieur, 60250 Ansacq'),
(8737,'611 Les Pres la Chenet, 53170 La Bazouge-de-Chemeré');

INSERT INTO Organisation (numero,adresse) VALUES
(8738,'51 le Verger, 30190 La Calmette'),
(8739,'32 Trabiet de dessus, 52220 Laneuville-à-Rémy');

INSERT INTO Organisation (numero,adresse) VALUES
(8740,'218bis Bois Communaux de Deville, 16200 Sainte-Sévère'),
(8741,'729 Bec de Jun Sud, 13870 Rognonas');

INSERT INTO Organisation (numero,adresse) VALUES
(8742,'395 Route Métropolitaine 31, 62560 Coyecques'),
(8743,'115bis Mas de la Girard, 24350 Grand-Brassac');

INSERT INTO Organisation (numero,adresse) VALUES
(8744,'419 Les Perrières, 31150 Gratentour'),
(8745,'315 """ La Rochelle """, 63380 Saint-Étienne-des-Champs');

INSERT INTO Organisation (numero,adresse) VALUES
(8746,'938bis Le Teron Haut 1, 55250 Waly'),
(8747,'508 La Citronelle, 67790 Steinbourg');

INSERT INTO Organisation (numero,adresse) VALUES
(8748,'636 Bellegarde, 25170 Moncley'),
(8749,'108 Le Mont Madame, 26150 Saint-Julien-en-Quint');

INSERT INTO Organisation (numero,adresse) VALUES
(8750,'860bis Les Tracols, 77710 Saint-Ange-le-Viel'),
(8751,'831 Pieces Longues, 50600 Lapenty');

INSERT INTO Organisation (numero,adresse) VALUES
(8752,'28bis Domaine de Rigou, 15800 Thiézac'),
(8753,'227 le Langousty, 21120 Saulx-le-Duc');

INSERT INTO Organisation (numero,adresse) VALUES
(8754,'454bis Le Plan Saint Leger, 41120 Feings'),
(8755,'706 Parc Castel des Deux Rois, 06670 Saint-Blaise');

INSERT INTO Organisation (numero,adresse) VALUES
(8756,'486 La Mera, 53410 La Gravelle'),
(8757,'572 Saint Mayeul, 80190 Nesle');

INSERT INTO Organisation (numero,adresse) VALUES
(8758,'141 Cayrac le Haut, 76410 Tourville-la-Rivière'),
(8759,'930 Le San Luca, 31150 Lespinasse');

INSERT INTO Organisation (numero,adresse) VALUES
(8760,'48bis Place Cour Toulouse, 60870 Brenouille'),
(8761,'148 Loze, 04330 Clumanc');

INSERT INTO Organisation (numero,adresse) VALUES
(8762,'575 Villa Caprice, 07230 Lablachère'),
(8763,'491 étang D, 10330 Villeret');

INSERT INTO Organisation (numero,adresse) VALUES
(8764,'983 Château de Durfort, 21270 Heuilley-sur-Saône'),
(8765,'472bis Quartier Vazeille, 02290 Berny-Rivière');

INSERT INTO Organisation (numero,adresse) VALUES
(8766,'193bis Le Gazanas, 67330 Bouxwiller'),
(8767,'979 """ Les Frelingants """, 57220 Mégange');

INSERT INTO Organisation (numero,adresse) VALUES
(8768,'360 Les_bizets, 49730 Parnay'),
(8769,'53 Les Lévêques, 64120 Arbouet-Sussaute');

INSERT INTO Organisation (numero,adresse) VALUES
(8770,'695 Les Alars, 41190 Saint-Cyr-du-Gault'),
(8771,'135 Les Souliers, 21120 Courtivron');

INSERT INTO Organisation (numero,adresse) VALUES
(8772,'136 Les Cougnas, 07160 Saint-Andéol-de-Fourchades'),
(8773,'872 En Record, 54470 Xammes');

INSERT INTO Organisation (numero,adresse) VALUES
(8774,'222 Fongouze, 60175 Villeneuve-les-Sablons'),
(8775,'491bis Sur les Vieux Prés, 76530 Mauny');

INSERT INTO Organisation (numero,adresse) VALUES
(8776,'796 Les Rivals, 06460 Saint-Vallier-de-Thiey'),
(8777,'327 Chateau de Loulieres, 31160 Ganties');

INSERT INTO Organisation (numero,adresse) VALUES
(8778,'835 Le Bousquet Detestet, 62270 Boubers-sur-Canche'),
(8779,'621 Le Pic, 05700 Étoile-Saint-Cyrice');

INSERT INTO Organisation (numero,adresse) VALUES
(8780,'672 Lieu-dit La Calmette, 80250 Remiencourt'),
(8781,'709 L’Hubac, 37120 Richelieu');

INSERT INTO Organisation (numero,adresse) VALUES
(8782,'228 Rond point de la Mer, 47190 Nicole'),
(8783,'850 Mas Marie-Pierre, 03140 Saint-Germain-de-Salles');

INSERT INTO Organisation (numero,adresse) VALUES
(8784,'51 Chanas, 47130 Clermont-Dessous'),
(8785,'225 """ La Petite Matray """, 09460 Rouze');

INSERT INTO Organisation (numero,adresse) VALUES
(8786,'205 Lo Bordur, 64230 Momas'),
(8787,'502 """ Les Coquets """, 57640 Charly-Oradour');

INSERT INTO Organisation (numero,adresse) VALUES
(8788,'416bis Montels-Cance, 62610 Autingues'),
(8789,'95bis Hlm les Gâteaux Bat C2, 39800 Villers-les-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(8790,'700 Lieu Dit Las Planes, 17100 Les Gonds'),
(8791,'79bis La Medecine, 21270 Cirey-lès-Pontailler');

INSERT INTO Organisation (numero,adresse) VALUES
(8792,'6 L’Iscloun, 20270 Casevecchie'),
(8793,'412 Lieu-dit Lascombes, 61190 Moussonvilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(8794,'109 Square Vincent Bourrel, 34380 Rouet'),
(8795,'273 Voie Communale du Canal, 47150 Lacaussade');

INSERT INTO Organisation (numero,adresse) VALUES
(8796,'912 Le Grand Viala, 07230 Faugères'),
(8797,'245 Roses Garden-Sonia B, 18120 Méreau');

INSERT INTO Organisation (numero,adresse) VALUES
(8798,'686 La Balmayrie Haute, 33420 Cabara'),
(8799,'378bis La Jeannette, 16370 Bréville');

INSERT INTO Organisation (numero,adresse) VALUES
(8800,'868 Pech Del Miey, 21170 Saint-Usage'),
(8801,'959bis Chemin Terre Longue Ou Pertuis, 36100 Neuvy-Pailloux');

INSERT INTO Organisation (numero,adresse) VALUES
(8802,'339 Boulouis, 29300 Quimperlé'),
(8803,'71bis L''Ouchette, 45270 Beauchamps-sur-Huillard');

INSERT INTO Organisation (numero,adresse) VALUES
(8804,'727 Verger Pirson, 39370 Les Bouchoux'),
(8805,'320bis Fournies, 36300 Ciron');

INSERT INTO Organisation (numero,adresse) VALUES
(8806,'721 Le Long-champ, 71130 Neuvy-Grandchamp'),
(8807,'589 Lieu-Dit Le Grangeon, 77120 Coulommiers');

INSERT INTO Organisation (numero,adresse) VALUES
(8808,'870 Vigne Basse, 51250 Cheminon'),
(8809,'580 Petit Berlie, 60220 Lannoy-Cuillère');

INSERT INTO Organisation (numero,adresse) VALUES
(8810,'174bis La Chave, 20169 Bonifacio'),
(8811,'672bis Talou, 72240 Lavardin');

INSERT INTO Organisation (numero,adresse) VALUES
(8812,'221 La Jaubernie, 39140 Nance'),
(8813,'351 Les Galets, 38380 Miribel-les-Échelles');

INSERT INTO Organisation (numero,adresse) VALUES
(8814,'670 Ocreval, 20217 Olcani'),
(8815,'653 Peira Grossa, 02860 Martigny-Courpierre');

INSERT INTO Organisation (numero,adresse) VALUES
(8816,'731 Bois des Bartres, 22100 Calorguen'),
(8817,'392 L''Ubac de Birou, 50270 Surtainville');

INSERT INTO Organisation (numero,adresse) VALUES
(8818,'758 Bâtiment Le kermes, 50320 Folligny'),
(8819,'27 Villa Mamy, 30770 Alzon');

INSERT INTO Organisation (numero,adresse) VALUES
(8820,'548 Noussols, 36300 Rosnay'),
(8821,'779 Serve Vallet, 72800 La Chapelle-aux-Choux');

INSERT INTO Organisation (numero,adresse) VALUES
(8822,'348 Chp Fromentot, 71480 Joudes'),
(8823,'229bis Monternoz, 27680 Marais-Vernier');

INSERT INTO Organisation (numero,adresse) VALUES
(8824,'732 La Quinaude, 02880 Braye'),
(8825,'157 Ferme des Comtesses, 28700 Garancières-en-Beauce');

INSERT INTO Organisation (numero,adresse) VALUES
(8826,'420 La Croix Roumier, 68780 Sternenberg'),
(8827,'424 Venras, 80120 Vercourt');

INSERT INTO Organisation (numero,adresse) VALUES
(8828,'577bis Le Clos Est, 57670 Insviller'),
(8829,'684bis Le Moulin D''Olive, 70190 Bourguignon-lès-la-Charité');

INSERT INTO Organisation (numero,adresse) VALUES
(8830,'668bis La Cassanie, 27120 Ménilles'),
(8831,'610 La Culee Saint Martin, 10110 Éguilly-sous-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(8832,'176 Maury Haut, 60280 Venette'),
(8833,'507 Lotissement Montolive, 64340 Boucau');

INSERT INTO Organisation (numero,adresse) VALUES
(8834,'816 Les Escurnaillers, 35130 La Guerche-de-Bretagne'),
(8835,'632 Prats de Termech, 24520 Lamonzie-Montastruc');

INSERT INTO Organisation (numero,adresse) VALUES
(8836,'743bis Charezy, 33650 La Brède'),
(8837,'785 Recollets, 65190 Tournay');

INSERT INTO Organisation (numero,adresse) VALUES
(8838,'261bis Le Pre Dore, 62870 Roussent'),
(8839,'431 Place Damase Arbaud, 07220 Larnas');

INSERT INTO Organisation (numero,adresse) VALUES
(8840,'89 Le Puech de Labit, 77124 Villenoy'),
(8841,'785bis Ruelle Dautel, 11700 Puichéric');

INSERT INTO Organisation (numero,adresse) VALUES
(8842,'89bis Planal de Villemajou, 45190 Cravant'),
(8843,'755 L''Etang Croisette, 12600 Thérondels');

INSERT INTO Organisation (numero,adresse) VALUES
(8844,'267 Lotissement Les Cymes d''Argent, 60120 Ansauvillers'),
(8845,'978 Ligounet, 52330 Montheries');

INSERT INTO Organisation (numero,adresse) VALUES
(8846,'552bis Rue du Chemin de fer, 41500 Mulsans'),
(8847,'802bis Résidence Le Pré de l''Aube, 28300 Mainvilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(8848,'588 Résidence les Hauts de Cadirac, 25380 La Grange'),
(8849,'440 Blache du Boisson, 72260 Nouans');

INSERT INTO Organisation (numero,adresse) VALUES
(8850,'712 Le Theomar, 28140 Dambron'),
(8851,'72 Mazies, 70180 Achey');

INSERT INTO Organisation (numero,adresse) VALUES
(8852,'96bis Terres des Prés, 54470 Thiaucourt-Regniéville'),
(8853,'800 Peyrousse, 47430 Calonges');

INSERT INTO Organisation (numero,adresse) VALUES
(8854,'989 Allée des Rosiers, 51310 Réveillon'),
(8855,'939 Villa Emeraude, 34120 Lézignan-la-Cèbe');

INSERT INTO Organisation (numero,adresse) VALUES
(8856,'515bis Fontcroze, 19120 Bilhac'),
(8857,'560 Concas Haut, 11200 Ornaisons');

INSERT INTO Organisation (numero,adresse) VALUES
(8858,'108bis Le Village de Blégiers, 72610 Béthon'),
(8859,'504 Montmayoux Haut, 18330 Saint-Laurent');

INSERT INTO Organisation (numero,adresse) VALUES
(8860,'732bis Le Mas Berthier, 07600 Labastide-sur-Bésorgues'),
(8861,'427bis Costecalde, 27620 Giverny');

INSERT INTO Organisation (numero,adresse) VALUES
(8862,'43bis L''Hippodrome A1, 08380 Neuville-lez-Beaulieu'),
(8863,'699bis Le Pont du Bost, 19430 Mercœur');

INSERT INTO Organisation (numero,adresse) VALUES
(8864,'502 Gentillac, 07200 Saint-Didier-sous-Aubenas'),
(8865,'408 Chez Gaille, 15240 Auzers');

INSERT INTO Organisation (numero,adresse) VALUES
(8866,'262bis Fustiés, 21460 Thoste'),
(8867,'611 Villardy, 21540 Montoillot');

INSERT INTO Organisation (numero,adresse) VALUES
(8868,'703 Le Fiou, 70200 La Côte'),
(8869,'674bis Dunieres, 02390 Neuvillette');

INSERT INTO Organisation (numero,adresse) VALUES
(8870,'211 L''Obit, 73000 Bassens'),
(8871,'114bis Bast du Chateau Saint-Martin, 06260 Saint-Antonin');

INSERT INTO Organisation (numero,adresse) VALUES
(8872,'972bis Magnans et Bellarots, 16150 Chassenon'),
(8873,'120 Les Coufins, 67770 Sessenheim');

INSERT INTO Organisation (numero,adresse) VALUES
(8874,'949bis La Rue Creuse, 18600 Givardon'),
(8875,'895 Impasse du Pre, 45230 Aillant-sur-Milleron');

INSERT INTO Organisation (numero,adresse) VALUES
(8876,'794 Le Combart, 62217 Tilloy-lès-Mofflaines'),
(8877,'766bis Résidence Les Maisons de Leucate, 16270 Suris');

INSERT INTO Organisation (numero,adresse) VALUES
(8878,'244 Le Clos Super Leucate, 71800 Vareilles'),
(8879,'623 Couberchy, 59131 Rousies');

INSERT INTO Organisation (numero,adresse) VALUES
(8880,'606 La Baraque du Pouget, 58330 Sainte-Marie'),
(8881,'777 Les Mamons, 31260 Mazères-sur-Salat');

INSERT INTO Organisation (numero,adresse) VALUES
(8882,'434 Le Vabre Jeune, 51240 La Chaussée-sur-Marne'),
(8883,'199 Le Chaporier, 79400 Saint-Martin-de-Saint-Maixent');

INSERT INTO Organisation (numero,adresse) VALUES
(8884,'813 Lotissement les Graviers I, 32100 Blaziert'),
(8885,'103bis Route de Pugieu, 57070 Chieulles');

INSERT INTO Organisation (numero,adresse) VALUES
(8886,'455 Quartier La Fonde, 64160 Buros'),
(8887,'3 Aco d’Isnard, 22320 Le Haut-Corlay');

INSERT INTO Organisation (numero,adresse) VALUES
(8888,'572 Chemin de Sainte-Claire, 60480 Campremy'),
(8889,'795bis Bois de Cuet, 28800 Montboissier');

INSERT INTO Organisation (numero,adresse) VALUES
(8890,'541 La Croix des Ormes, 09100 Pamiers'),
(8891,'537bis La Cantaloubie, 77167 Poligny');

INSERT INTO Organisation (numero,adresse) VALUES
(8892,'127 le Purgatoire, 24380 Fouleix'),
(8893,'188bis Cité l''Aiguille, 65330 Castelbajac');

INSERT INTO Organisation (numero,adresse) VALUES
(8894,'411bis Croix Colin Nord, 21700 Nuits-Saint-Georges'),
(8895,'742 Amarande Bat C, 24140 Saint-Martin-des-Combes');

INSERT INTO Organisation (numero,adresse) VALUES
(8896,'133 Impasse des Chênes, 25170 Audeux'),
(8897,'301 Bouche Incendie, 63800 Cournon-d''Auvergne');

INSERT INTO Organisation (numero,adresse) VALUES
(8898,'813 Les Cannebiers, 27240 Mesnils-sur-Iton'),
(8899,'102bis Le Petit Papillon, 17430 Saint-Coutant-le-Grand');

INSERT INTO Organisation (numero,adresse) VALUES
(8900,'825 Bage, 71850 Charnay-lès-Mâcon'),
(8901,'933bis Les Barrieres Vitrac-en, 30440 Saint-Bresson');

INSERT INTO Organisation (numero,adresse) VALUES
(8902,'169 Le Vieux Pressoir, 64510 Narcastet'),
(8903,'198 Résidence Suffren, 58400 Mesves-sur-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(8904,'273 Allée des Roses, 23150 Saint-Martial-le-Mont'),
(8905,'760 Locaterie Roubaud, 13360 Roquevaire');

INSERT INTO Organisation (numero,adresse) VALUES
(8906,'123 Le Mas de Bessiere, 62500 Saint-Martin-lez-Tatinghem'),
(8907,'421 Le Petit Cormont, 67280 Oberhaslach');

INSERT INTO Organisation (numero,adresse) VALUES
(8908,'554bis Moulin de Pampier, 53100 Parigné-sur-Braye'),
(8909,'659 Météline, 34200 Sète');

INSERT INTO Organisation (numero,adresse) VALUES
(8910,'880 Bouque de Biau Ouest, 76450 Hautot-l''Auvray'),
(8911,'142 Square Marcel Kirchner, 71270 Lays-sur-le-Doubs');

INSERT INTO Organisation (numero,adresse) VALUES
(8912,'769 La Fontaine aux Pretres, 39210 Nevy-sur-Seille'),
(8913,'348 Les Guigard, 20239 Murato');

INSERT INTO Organisation (numero,adresse) VALUES
(8914,'830 Résidence Cap de Front, 69560 Sainte-Colombe'),
(8915,'967 La Vallee Evrard, 38480 Saint-Martin-de-Vaulserre');

INSERT INTO Organisation (numero,adresse) VALUES
(8916,'219bis Sole Mio, 58120 Montigny-en-Morvan'),
(8917,'862 Icart, 44140 Remouillé');

INSERT INTO Organisation (numero,adresse) VALUES
(8918,'649 Gazou, 01430 Condamine'),
(8919,'980 Champaigue, 52500 Farincourt');

INSERT INTO Organisation (numero,adresse) VALUES
(8920,'421 Chemin du Béal, 54470 Charey'),
(8921,'575 Domaine de la Masseu, 24380 Saint-Amand-de-Vergt');

INSERT INTO Organisation (numero,adresse) VALUES
(8922,'87 La Petite Vigne, 73730 Cevins'),
(8923,'619 Cardine, 01570 Manziat');

INSERT INTO Organisation (numero,adresse) VALUES
(8924,'516 Sainte-Juliette, 25320 Boussières'),
(8925,'373 Jardin Joseph Kessel, 53120 Brecé');

INSERT INTO Organisation (numero,adresse) VALUES
(8926,'140 Le Gros Faux, 25690 Longemaison'),
(8927,'761 les Gageres, 02490 Le Verguier');

INSERT INTO Organisation (numero,adresse) VALUES
(8928,'284 Lotissement le Pas du Cayla, 31600 Lamasquère'),
(8929,'900 La Barre, 76540 Saint-Martin-aux-Buneaux');

INSERT INTO Organisation (numero,adresse) VALUES
(8930,'69 Puech de Cassos, 15310 Saint-Cernin'),
(8931,'362 Bély, 70700 Frasne-le-Château');

INSERT INTO Organisation (numero,adresse) VALUES
(8932,'628bis Les Grands Debrits, 41300 Selles-Saint-Denis'),
(8933,'737 Bruquets, 04270 Estoublon');

INSERT INTO Organisation (numero,adresse) VALUES
(8934,'808 Mas de Rapine, 79110 Couture-d''Argenson'),
(8935,'476 Tiecs superieur, 60400 Varesnes');

INSERT INTO Organisation (numero,adresse) VALUES
(8936,'975bis Montmayoux Haut, 21250 Tichey'),
(8937,'649 Jean Vallet, 24520 Cours-de-Pile');

INSERT INTO Organisation (numero,adresse) VALUES
(8938,'209bis Bourdette, 60800 Rocquemont'),
(8939,'123 La Tanella Sud, 67250 Stundwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(8940,'299bis Fourès, 25510 Villers-la-Combe'),
(8941,'833 Les Petits Saulsoirs, 51190 Oger');

INSERT INTO Organisation (numero,adresse) VALUES
(8942,'62 Le roux, 12390 Goutrens'),
(8943,'686 Bésséat Sud, 57480 Sierck-les-Bains');

INSERT INTO Organisation (numero,adresse) VALUES
(8944,'597 Parking de la Baignoire, 54490 Piennes'),
(8945,'327 Moulin de l''Espine, 60810 Brasseuse');

INSERT INTO Organisation (numero,adresse) VALUES
(8946,'499bis Impasse sans nom 2, 57220 Velving'),
(8947,'703 Mal Bouisset et Pas du Veire, 05260 Saint-Léger-les-Mélèzes');

INSERT INTO Organisation (numero,adresse) VALUES
(8948,'298 Latour, 50410 Villebaudon'),
(8949,'254 Le Quier, 31530 Montaigut-sur-Save');

INSERT INTO Organisation (numero,adresse) VALUES
(8950,'173 L’Ile, 62260 Amettes'),
(8951,'430 Feneyrols, 23340 Faux-la-Montagne');

INSERT INTO Organisation (numero,adresse) VALUES
(8952,'279 Beauménil Bas, 75015 Paris 15'),
(8953,'309 Fossieu, 17139 Dompierre-sur-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(8954,'882bis Sous la Baise, 72350 Chevillé'),
(8955,'542 la Fage, 14140 Prêtreville');

INSERT INTO Organisation (numero,adresse) VALUES
(8956,'113 Lavinol, 12430 Le Truel'),
(8957,'696bis Capfourquet, 80110 Beaucourt-en-Santerre');

INSERT INTO Organisation (numero,adresse) VALUES
(8958,'134 L''Enclos de Bizet, 62240 Lottinghen'),
(8959,'853 Rio Muny, 25110 Fontenotte');

INSERT INTO Organisation (numero,adresse) VALUES
(8960,'477 """ Les Cantes """, 31330 Le Burgaud'),
(8961,'380bis La Noyeraie, 71220 Pressy-sous-Dondin');

INSERT INTO Organisation (numero,adresse) VALUES
(8962,'166 Salvaza le Bas, 26310 Valdrôme'),
(8963,'255bis Le Clos Saint Michel Villas 6 A 12, 08300 Nanteuil-sur-Aisne');

INSERT INTO Organisation (numero,adresse) VALUES
(8964,'95 Les Grandes Terres, 57570 Mondorff'),
(8965,'262 Ravourier - La Combe, 32400 Projan');

INSERT INTO Organisation (numero,adresse) VALUES
(8966,'192 Les Amphores, 76380 Val-de-la-Haye'),
(8967,'738 Centre de Loisirs, 76220 Doudeauville');

INSERT INTO Organisation (numero,adresse) VALUES
(8968,'830bis Croux de Mourgues, 10170 Méry-sur-Seine'),
(8969,'963 Barodière, 44880 Sautron');

INSERT INTO Organisation (numero,adresse) VALUES
(8970,'113bis Le Mas Del Puech, 53400 Niafles'),
(8971,'331 Font Trompette et Valon Ca, 25300 La Cluse-et-Mijoux');

INSERT INTO Organisation (numero,adresse) VALUES
(8972,'781 Mairie CCAS, 65170 Tramezaïgues'),
(8973,'464bis Esplanade  Georges Roth, 77940 Blennes');

INSERT INTO Organisation (numero,adresse) VALUES
(8974,'692 Pinaud, 80340 Chuignolles'),
(8975,'814 Les Valliers, 66170 Saint-Féliu-d''Amont');

INSERT INTO Organisation (numero,adresse) VALUES
(8976,'74bis Villa Clos De Marie, 19130 Objat'),
(8977,'659 Le Moulin de la Roche, 16310 Massignac');

INSERT INTO Organisation (numero,adresse) VALUES
(8978,'40 Port Camille Rayon, 44270 La Marne'),
(8979,'433 La Saussette, 48400 Bassurels');

INSERT INTO Organisation (numero,adresse) VALUES
(8980,'35bis Planquelongue, 04500 Montagnac-Montpezat'),
(8981,'223 Les Peyronnies, 42430 Champoly');

INSERT INTO Organisation (numero,adresse) VALUES
(8982,'162 Maison Monard, 49390 Mouliherne'),
(8983,'913 Sente de la Sablonnière, 77650 Sainte-Colombe');

INSERT INTO Organisation (numero,adresse) VALUES
(8984,'435 Milla, 54540 Veney'),
(8985,'939 Figeagols, 28170 Serazereux');

INSERT INTO Organisation (numero,adresse) VALUES
(8986,'294 Le Planet Haut, 50200 Brainville'),
(8987,'866 Moulin de Vilban, 10320 Javernant');

INSERT INTO Organisation (numero,adresse) VALUES
(8988,'208 Res Felicita Aa/Ab/B, 66800 Llo'),
(8989,'563bis Cargaut, 17520 Saint-Eugène');

INSERT INTO Organisation (numero,adresse) VALUES
(8990,'225bis Le Cros Esc 4, 14480 Saint-Gabriel-Brécy'),
(8991,'42 Res Helios A/B, 62760 Orville');

INSERT INTO Organisation (numero,adresse) VALUES
(8992,'926bis Rue des Carratieres, 24320 Champagne-et-Fontaine'),
(8993,'916 Sales, 71260 Cruzille');

INSERT INTO Organisation (numero,adresse) VALUES
(8994,'473 Passage des Oudaias, 22160 La Chapelle-Neuve'),
(8995,'805bis Buscansoles, 50190 Feugères');

INSERT INTO Organisation (numero,adresse) VALUES
(8996,'980 Le Musée Départemental de l''Ecole Publique, 38830 Crêts en Belledonne'),
(8997,'219 Suquairie, 54260 Saint-Jean-lès-Longuyon');

INSERT INTO Organisation (numero,adresse) VALUES
(8998,'994bis La Terre de Maltiere, 19110 Sarroux Saint Julien'),
(8999,'81bis La Baraque du Banquier, 07380 Chirols');

INSERT INTO Organisation (numero,adresse) VALUES
(9000,'822 Route de Loupeigne, 71530 Virey-le-Grand'),
(9001,'878 Le Central Plaza Bat A, 14130 Coquainvilliers');

INSERT INTO Organisation (numero,adresse) VALUES
(9002,'433bis La Guillone, 76440 Haucourt'),
(9003,'603bis Grande Becnee, 77320 Sancy-lès-Provins');

INSERT INTO Organisation (numero,adresse) VALUES
(9004,'984bis Petites Longues Royes, 17360 La Genétouze'),
(9005,'264 Route de Revin, 65270 Peyrouse');

INSERT INTO Organisation (numero,adresse) VALUES
(9006,'604 Alseroques, 03350 Le Vilhain'),
(9007,'88bis Les Barchauds, 09400 Tarascon-sur-Ariège');

INSERT INTO Organisation (numero,adresse) VALUES
(9008,'185bis Vernades, 18120 Cerbois'),
(9009,'520bis Peyrignac, 64490 Aydius');

INSERT INTO Organisation (numero,adresse) VALUES
(9010,'127 Chemin Rural Lachut, 76160 La Vieux-Rue'),
(9011,'252 Les Perrières, 59820 Saint-Georges-sur-l''Aa');

INSERT INTO Organisation (numero,adresse) VALUES
(9012,'180 Chateau de Ferrals, 14230 Vouilly'),
(9013,'946 Traverse des Pastoureaux, 16000 Angoulême');

INSERT INTO Organisation (numero,adresse) VALUES
(9014,'984 Esquein, 74430 Saint-Jean-d''Aulps'),
(9015,'756 Chemin du Cellier, 40300 Saint-Étienne-d''Orthe');

INSERT INTO Organisation (numero,adresse) VALUES
(9016,'103 Bec de Jun, 62310 Verchin'),
(9017,'643 Trunel, 80150 Yvrencheux');

INSERT INTO Organisation (numero,adresse) VALUES
(9018,'691 Descente du Lavoir, 35133 La Selle-en-Luitré'),
(9019,'151bis Lilou, 57580 Adaincourt');

INSERT INTO Organisation (numero,adresse) VALUES
(9020,'15 Miolas, 32390 Puységur'),
(9021,'688bis Vergnedes, 42170 Saint-Just-Saint-Rambert');

INSERT INTO Organisation (numero,adresse) VALUES
(9022,'549 Les Bonniers de Tenieres, 80170 Bayonvillers'),
(9023,'656bis La Butte de Canard, 24380 Salon');

INSERT INTO Organisation (numero,adresse) VALUES
(9024,'153 Pré d''Amont, 10130 Vosnon'),
(9025,'454 Bois Gaillard, 20100 Grossa');

INSERT INTO Organisation (numero,adresse) VALUES
(9026,'588 """ Les Talots """, 43170 Saugues'),
(9027,'572 Castelviel, 09100 Saint-Jean-du-Falga');

INSERT INTO Organisation (numero,adresse) VALUES
(9028,'266 Chemin de Ternis, 69700 Beauvallon'),
(9029,'18 Can du Pic, 02510 Étreux');

INSERT INTO Organisation (numero,adresse) VALUES
(9030,'44bis Tournemire, 25490 Badevel'),
(9031,'298 La Tuilerie de Ferrals, 73350 Champagny-en-Vanoise');

INSERT INTO Organisation (numero,adresse) VALUES
(9032,'471 En Gourgan, 53270 Sainte-Suzanne-et-Chammes'),
(9033,'106 Villa Pagnol, 33540 Saint-Félix-de-Foncaude');

INSERT INTO Organisation (numero,adresse) VALUES
(9034,'306 Direction Départementale des Territoires (DDT), 19170 Gourdon-Murat'),
(9035,'733bis Mas de Sabde, 52700 Andelot-Blancheville');

INSERT INTO Organisation (numero,adresse) VALUES
(9036,'892 Le jas du coeur, 36210 Anjouin'),
(9037,'873 Lieu dit Junca, 33460 Margaux-Cantenac');

INSERT INTO Organisation (numero,adresse) VALUES
(9038,'932bis Cai Est, 64230 Denguin'),
(9039,'66bis Les Salonnes, 24190 Neuvic');

INSERT INTO Organisation (numero,adresse) VALUES
(9040,'448 Ephad Mariposa, 53950 La Chapelle-Anthenaise'),
(9041,'854 Las Taïchounièros, 71420 Génelard');

INSERT INTO Organisation (numero,adresse) VALUES
(9042,'591 Le Gres, 35160 Le Verger'),
(9043,'183 Bretelle Sortie N°50 A8 - Mercantour (Provenance Cannes) sud, 25800 Valdahon');

INSERT INTO Organisation (numero,adresse) VALUES
(9044,'486bis Garage 1, 69720 Saint-Bonnet-de-Mure'),
(9045,'365 Passage Marco Grilli, 54580 Moineville');

INSERT INTO Organisation (numero,adresse) VALUES
(9046,'238 Domaine de Sannes, 31370 Lahage'),
(9047,'985bis La Martiniè de Lebous, 51250 Sermaize-les-Bains');

INSERT INTO Organisation (numero,adresse) VALUES
(9048,'268 Promenade du rattachement de Tourrette à la France, 28250 Digny'),
(9049,'595bis Villefranche, 34700 Fozières');

INSERT INTO Organisation (numero,adresse) VALUES
(9050,'441 Les Infruts, 79330 Coulonges-Thouarsais'),
(9051,'957 Chamounières, 52410 Roches-sur-Marne');

INSERT INTO Organisation (numero,adresse) VALUES
(9052,'56bis Le Moustier, 66420 Le Barcarès'),
(9053,'477 Piogiero de Boiri, 16450 Beaulieu-sur-Sonnette');

INSERT INTO Organisation (numero,adresse) VALUES
(9054,'242 Tre le Rocher, 63380 Landogne'),
(9055,'255 les Bioux, 47420 Boussès');

INSERT INTO Organisation (numero,adresse) VALUES
(9056,'141 Villa Emilie A, 70400 Échenans-sous-Mont-Vaudois'),
(9057,'936 Les Eucalyptus, 11590 Sallèles-d''Aude');

INSERT INTO Organisation (numero,adresse) VALUES
(9058,'416 Couret Mauri Rouze, 52240 Millières'),
(9059,'885 Chez Moulin, 35420 Villamée');

INSERT INTO Organisation (numero,adresse) VALUES
(9060,'705 La Petite Prugne, 72110 Bonnétable'),
(9061,'602 Rue de la Piscine, 70300 Esboz-Brest');

INSERT INTO Organisation (numero,adresse) VALUES
(9062,'479 Les Fréaux, 60150 Janville'),
(9063,'947 Foyer Municipal, 21120 Moloy');

INSERT INTO Organisation (numero,adresse) VALUES
(9064,'992 La Couvelie Haute, 25360 Nancray'),
(9065,'55 la Valliera, 50200 Gratot');

INSERT INTO Organisation (numero,adresse) VALUES
(9066,'101bis Les Étiennes, 76390 Landes-Vieilles-et-Neuves'),
(9067,'279 La Boutonnette, 02130 Coulonges-Cohan');

INSERT INTO Organisation (numero,adresse) VALUES
(9068,'793bis Villa Les Alizes, 50200 Gouville sur Mer'),
(9069,'3 Pamplemousse, 80140 Villeroy');

INSERT INTO Organisation (numero,adresse) VALUES
(9070,'814bis Bretelle Entrée Trachel - Mathis (Chaussée nord), 62270 Ligny-sur-Canche'),
(9071,'542bis La Gaspare, 09130 Lanoux');

INSERT INTO Organisation (numero,adresse) VALUES
(9072,'848 Villefranche, 42260 Dancé'),
(9073,'69 Maison de Retraite l''Eclaircie, 59173 Ebblinghem');

INSERT INTO Organisation (numero,adresse) VALUES
(9074,'799 Fondivia, 42660 Tarentaise'),
(9075,'324 Sous le Roc, 07340 Peyraud');

INSERT INTO Organisation (numero,adresse) VALUES
(9076,'937bis Les Petites Mûres, 20259 Vallica'),
(9077,'657 L''Ermitage, 16130 Angeac-Champagne');

INSERT INTO Organisation (numero,adresse) VALUES
(9078,'830bis Le Molard de Lorge, 33790 Pellegrue'),
(9079,'927bis Combebelle Domaine de le Bas, 03210 Chemilly');

INSERT INTO Organisation (numero,adresse) VALUES
(9080,'219 Rue du Barry Marzials, 30770 Blandas'),
(9081,'508 Girman-Bas, 71230 Pouilloux');

INSERT INTO Organisation (numero,adresse) VALUES
(9082,'911 La Falière, 62270 Canettemont'),
(9083,'76 Pelissières, 57640 Vry');

INSERT INTO Organisation (numero,adresse) VALUES
(9084,'545 Rue de la Parra, 14950 Saint-Pierre-Azif'),
(9085,'876bis Bérot, 40990 Saint-Vincent-de-Paul');

INSERT INTO Organisation (numero,adresse) VALUES
(9086,'904 Lieu-Dit La Bonne Terre, 04150 L''Hospitalet'),
(9087,'631 Sentier de la Rouette, 31350 Nénigan');

INSERT INTO Organisation (numero,adresse) VALUES
(9088,'641 Les Pessonnets, 53120 Carelles'),
(9089,'772 Prades de Souyri, 71530 Crissey');

INSERT INTO Organisation (numero,adresse) VALUES
(9090,'325 Le Bois Jacot, 05140 Montbrand'),
(9091,'534 Voie de liaison Ruelle des Prés - Rue Rancher, 28260 Anet');

INSERT INTO Organisation (numero,adresse) VALUES
(9092,'48 Ecluse de Chavignon, 51140 Châlons-sur-Vesle'),
(9093,'147 Ferme de Beaufait, 34980 Saint-Gély-du-Fesc');

INSERT INTO Organisation (numero,adresse) VALUES
(9094,'435 Station d''Épuration de Saint-Julien-Vocance, 80370 Le Meillard'),
(9095,'821 Résidence Les Portes du Soleil, 62390 Quœux-Haut-Maînil');

INSERT INTO Organisation (numero,adresse) VALUES
(9096,'907 Domaine Rambaud, 74270 Menthonnex-sous-Clermont'),
(9097,'900 Passage du Patrimoine, 72300 Juigné-sur-Sarthe');

INSERT INTO Organisation (numero,adresse) VALUES
(9098,'416bis Bernardon, 55230 Arrancy-sur-Crusne'),
(9099,'570 Escalier Avenue Val Marie - Avenue du Rond-Point, 76480 Le Mesnil-sous-Jumièges');

INSERT INTO Organisation (numero,adresse) VALUES
(9100,'135 Vers Cua, 52160 Rouelles'),
(9101,'598 Grange Neuve, 67430 Ratzwiller');

INSERT INTO Organisation (numero,adresse) VALUES
(9102,'848 Passage Passaour, 38860 Les Deux Alpes'),
(9103,'842 La Borie Basse, 29420 Mespaul');

INSERT INTO Organisation (numero,adresse) VALUES
(9104,'137 Le Bois des Seigneurs, 68210 Magny'),
(9105,'877 Chemin de Quirielle, 41360 Fortan');

INSERT INTO Organisation (numero,adresse) VALUES
(9106,'657bis Barbet, 59176 Écaillon'),
(9107,'698 Péré, 64500 Saint-Jean-de-Luz');

INSERT INTO Organisation (numero,adresse) VALUES
(9108,'285bis Baudoin, 21410 Baulme-la-Roche'),
(9109,'766 Le Pre Champ Mort, 02680 Fontaine-lès-Clercs');

INSERT INTO Organisation (numero,adresse) VALUES
(9110,'359 Espine, 48700 Fontans'),
(9111,'142 Le Lavoir, 52700 Mareilles');

INSERT INTO Organisation (numero,adresse) VALUES
(9112,'170 Hlm les Gâteaux Bat A2, 69005 Lyon 05'),
(9113,'791 Le Gleyzal, 56190 Ambon');

INSERT INTO Organisation (numero,adresse) VALUES
(9114,'239 Mas de Bousquel, 25170 Ruffey-le-Château'),
(9115,'836 Le Chabret, 55160 Maizeray');

INSERT INTO Organisation (numero,adresse) VALUES
(9116,'3 Moulin de Cazottes, 33650 Saucats'),
(9117,'59bis Le Saule Bayer côté du rond-pré, 59177 Ramousies');

INSERT INTO Organisation (numero,adresse) VALUES
(9118,'903 Pas del Roc, 26770 Le Pègue'),
(9119,'112 Las Es Combos, 41210 Saint-Viâtre');

INSERT INTO Organisation (numero,adresse) VALUES
(9120,'639bis Maison Neuve du Chem Soiss, 27720 Dangu'),
(9121,'905 Villa Soblay, 63440 Pouzol');

INSERT INTO Organisation (numero,adresse) VALUES
(9122,'147 La Lazerte, 31510 Antichan-de-Frontignes'),
(9123,'80 Le Cros Pouthier, 51110 Boult-sur-Suippe');

INSERT INTO Organisation (numero,adresse) VALUES
(9124,'281bis Les Carrés, 76270 Callengeville'),
(9125,'596 Chambonnet Haut, 74950 Le Reposoir');

INSERT INTO Organisation (numero,adresse) VALUES
(9126,'513 Route Departementale 119, 55200 Broussey-Raulecourt'),
(9127,'249 Macia Fava, 26420 Saint-Agnan-en-Vercors');

INSERT INTO Organisation (numero,adresse) VALUES
(9128,'199 Poirier Jean Oudot, 46210 Gorses'),
(9129,'355 Le Vialaret Lapanouse, 57580 Thimonville');

INSERT INTO Organisation (numero,adresse) VALUES
(9130,'157 Les Meles, 68800 Vieux-Thann'),
(9131,'631 Champ des Louvettes, 14130 Le Theil-en-Auge');

INSERT INTO Organisation (numero,adresse) VALUES
(9132,'438 La Pature du Bois, 49320 Coutures'),
(9133,'66bis Prats de Termech, 21140 Millery');

INSERT INTO Organisation (numero,adresse) VALUES
(9134,'172bis Las Peyros, 33830 Belin-Béliet'),
(9135,'760 La Castié Basse, 63450 Cournols');

INSERT INTO Organisation (numero,adresse) VALUES
(9136,'299 Résidence Mykonos, 57580 Arriance'),
(9137,'454bis Louage Richard, 47170 Lannes');

INSERT INTO Organisation (numero,adresse) VALUES
(9138,'764bis La Jawiflotine, 44320 Saint-Père-en-Retz'),
(9139,'864 Les Grosses Terres, 23290 Fursac');

INSERT INTO Organisation (numero,adresse) VALUES
(9140,'283 Le Patureau Jaune, 74420 Villard'),
(9141,'101 Cap de l’Homme, 42410 La Chapelle-Villars');

INSERT INTO Organisation (numero,adresse) VALUES
(9142,'193 Le Claou, 28220 Montigny-le-Gannelon'),
(9143,'422 Pibayen, 06520 Grasse');

INSERT INTO Organisation (numero,adresse) VALUES
(9144,'874 """ Le Breu """, 67430 Mackwiller'),
(9145,'386 Essart Ravot, 80360 Équancourt');

INSERT INTO Organisation (numero,adresse) VALUES
(9146,'792bis Le Grand Bigut, 05100 Puy-Saint-Pierre'),
(9147,'797 Coste de Figeac, 24520 Liorac-sur-Louyre');

INSERT INTO Organisation (numero,adresse) VALUES
(9148,'415 Puech La Mole, 50480 Boutteville'),
(9149,'740bis Sansot, 07630 Le Béage');

INSERT INTO Organisation (numero,adresse) VALUES
(9150,'375 Terrebache, 07320 Devesset'),
(9151,'490 Suc de Passeros, 58240 Chantenay-Saint-Imbert');

INSERT INTO Organisation (numero,adresse) VALUES
(9152,'653 Impasse de la Garenne, 02300 Neuflieux'),
(9153,'278 Le Rouillon Adele, 05300 Saint-Pierre-Avez');

INSERT INTO Organisation (numero,adresse) VALUES
(9154,'554bis Square Richard Wagner, 07330 Astet'),
(9155,'83 Ibac de Rivet, 76360 Villers-Écalles');

INSERT INTO Organisation (numero,adresse) VALUES
(9156,'923bis Serre-Lagarde, 77710 Nanteau-sur-Lunain'),
(9157,'127 Montrozier, 57320 Chémery-les-Deux');

INSERT INTO Organisation (numero,adresse) VALUES
(9158,'79 Labeau, 17000 La Rochelle'),
(9159,'789 Res De La Baie B1, 52320 Mirbel');

INSERT INTO Organisation (numero,adresse) VALUES
(9160,'388 Sintineddi, 14190 Urville'),
(9161,'595 Guillou, 14430 Angerville');

INSERT INTO Organisation (numero,adresse) VALUES
(9162,'154 Grande Becnee, 07440 Champis'),
(9163,'556 """ Les Dalins """, 33113 Cazalis');

INSERT INTO Organisation (numero,adresse) VALUES
(9164,'454 Gare SNCF du Cros-de-Cagnes, 38250 Corrençon-en-Vercors'),
(9165,'351 Riou Laval, 34120 Cazouls-d''Hérault');

INSERT INTO Organisation (numero,adresse) VALUES
(9166,'152 La Pernade, 11200 Canet'),
(9167,'854 Pistes Hautes, 16700 Taizé-Aizie');

INSERT INTO Organisation (numero,adresse) VALUES
(9168,'86 Ban de la Morteau, 01160 Varambon'),
(9169,'976 La Fontaine et Saint-Pansier, 10440 La Rivière-de-Corps');

INSERT INTO Organisation (numero,adresse) VALUES
(9170,'487bis Les Barrieres Vitrac-en, 39570 Villeneuve-sous-Pymont'),
(9171,'152bis les Calderies, 19150 Cornil');

INSERT INTO Organisation (numero,adresse) VALUES
(9172,'681 Prayssac, 26190 Bouvante'),
(9173,'372 Les Jonchiers, 67230 Kertzfeld');

INSERT INTO Organisation (numero,adresse) VALUES
(9174,'468 La Sapie, 22460 Merléac'),
(9175,'94 Saint-Lazare, 15140 Saint-Martin-Cantalès');

INSERT INTO Organisation (numero,adresse) VALUES
(9176,'84 Lavergne, 27830 Neaufles-Saint-Martin'),
(9177,'238 Pélissier, 16300 Brie-sous-Barbezieux');

INSERT INTO Organisation (numero,adresse) VALUES
(9178,'170bis La Pascaline, 51700 Leuvrigny'),
(9179,'518bis Petit Simandre, 28340 La Ferté-Vidame');

INSERT INTO Organisation (numero,adresse) VALUES
(9180,'531 Les Pres du Canal, 58190 Metz-le-Comte'),
(9181,'557 Le Caigno Bat C, 71130 Neuvy-Grandchamp');

INSERT INTO Organisation (numero,adresse) VALUES
(9182,'688 Castelbou, 69170 Joux'),
(9183,'325 Le Village - Place du Château, 60340 Villers-sous-Saint-Leu');

INSERT INTO Organisation (numero,adresse) VALUES
(9184,'901 Le Villeneuve B, 60880 Armancourt'),
(9185,'301 Delta, 80131 Vauvillers');

INSERT INTO Organisation (numero,adresse) VALUES
(9186,'378bis Pre Coulomb, 57340 Bermering'),
(9187,'871 La Grange de Rouretord, 15110 Saint-Rémy-de-Chaudes-Aigues');

INSERT INTO Organisation (numero,adresse) VALUES
(9188,'189 Le Village-nord, 58230 Saint-Brisson'),
(9189,'683 Voie liaison Route Pessicart - Avenue du Super Righi, 72380 Sainte-Sabine-sur-Longève');

INSERT INTO Organisation (numero,adresse) VALUES
(9190,'270 Les Pernins, 10600 Mergey'),
(9191,'2 Grange de Prele, 37340 Continvoir');

INSERT INTO Organisation (numero,adresse) VALUES
(9192,'922 La Vrable, 62310 Coupelle-Neuve'),
(9193,'28 Chrismarc, 51460 Tilloy-et-Bellay');

INSERT INTO Organisation (numero,adresse) VALUES
(9194,'312 Irague, 65460 Bours'),
(9195,'139bis Grandval, 38460 Leyrieu');

INSERT INTO Organisation (numero,adresse) VALUES
(9196,'167 Salle Municipale Pierre Mendès France - ERP, 25410 Velesmes-Essarts'),
(9197,'629 Camp Del Fraysse, 56140 Malestroit');

INSERT INTO Organisation (numero,adresse) VALUES
(9198,'390 Ruelle des Fonds de Thémois, 10200 Rouvres-les-Vignes'),
(9199,'454 Salignac, 25650 Maisons-du-Bois-Lièvremont');

INSERT INTO Organisation (numero,adresse) VALUES
(9200,'250 Ham de Gros Loup, 68210 Mertzen'),
(9201,'388 Bourgaille, 39110 Lemuy');

INSERT INTO Organisation (numero,adresse) VALUES
(9202,'196 Les Charmettes, 08800 Les Hautes-Rivières'),
(9203,'121 La_valette, 33540 Caumont');

INSERT INTO Organisation (numero,adresse) VALUES
(9204,'464bis Cité de la Campagne, 32170 Bazugues'),
(9205,'756bis L’Estoupe, 25580 Les Premiers Sapins');

INSERT INTO Organisation (numero,adresse) VALUES
(9206,'551bis Hameau de Côte Courbe, 66730 Felluns'),
(9207,'720 Le Trou des Vaches, 57410 Rahling');

INSERT INTO Organisation (numero,adresse) VALUES
(9208,'782 Hameau de Voltaire, 28190 Dangers'),
(9209,'756bis Résidence les Jardins d''Aude, 38260 Thodure');

INSERT INTO Organisation (numero,adresse) VALUES
(9210,'509 Favols, 35490 Gahard'),
(9211,'25 Guignicourt, 51310 Villeneuve-la-Lionne');

INSERT INTO Organisation (numero,adresse) VALUES
(9212,'337bis Chemin de Mont - Sens, 62170 La Calotterie'),
(9213,'224bis Cayrac-Haut, 32350 Ordan-Larroque');

INSERT INTO Organisation (numero,adresse) VALUES
(9214,'978 Chalet Des Cigales, 16490 Alloue'),
(9215,'945 Castelline, 31220 Montberaud');

INSERT INTO Organisation (numero,adresse) VALUES
(9216,'670 Molénat, 39160 Balanod'),
(9217,'453 Patry, 66820 Vernet-les-Bains');

INSERT INTO Organisation (numero,adresse) VALUES
(9218,'524bis Les Orangers, 57670 Bénestroff'),
(9219,'469bis Le Pouget et Terrons, 02210 Launoy');

INSERT INTO Organisation (numero,adresse) VALUES
(9220,'601 La Borde Mondy, 11700 Pépieux'),
(9221,'672bis Moulin-Voire, 72400 Dehault');

INSERT INTO Organisation (numero,adresse) VALUES
(9222,'455bis Les Berenguiers, 77560 Courtacon'),
(9223,'681 Chemin du Vallon, 50310 Montebourg');

INSERT INTO Organisation (numero,adresse) VALUES
(9224,'89 Hlm le Plessis bat. J2, 33880 Baurech'),
(9225,'366 La Glau, 24380 Creyssensac-et-Pissot');

INSERT INTO Organisation (numero,adresse) VALUES
(9226,'0bis Puech de Leguo, 52300 Guindrecourt-aux-Ormes'),
(9227,'170 Les Muriers, 09240 Montseron');

INSERT INTO Organisation (numero,adresse) VALUES
(9228,'329bis Lieu Dit Villette, 09240 Montels'),
(9229,'612bis Chemin de la Canague, 21320 Bellenot-sous-Pouilly');

INSERT INTO Organisation (numero,adresse) VALUES
(9230,'789bis Fontaine de Caumels, 71330 Le Tartre'),
(9231,'351bis Colombie, 71960 Fuissé');

INSERT INTO Organisation (numero,adresse) VALUES
(9232,'543bis Au Hameau du Trève d''Ars, 20234 Novale'),
(9233,'864 Le Grand Broux, 69960 Corbas');

INSERT INTO Organisation (numero,adresse) VALUES
(9234,'26 Al Riou, 70300 Brotte-lès-Luxeuil'),
(9235,'562 Château d''Eau, 53380 Juvigné');

INSERT INTO Organisation (numero,adresse) VALUES
(9236,'384 Impasse des Gerles, 17100 La Chapelle-des-Pots'),
(9237,'661bis Muselet, 14370 Chicheboville');

INSERT INTO Organisation (numero,adresse) VALUES
(9238,'44bis Articaut, 50600 Lapenty'),
(9239,'91bis Le Buisson Sainte Geneviev, 30920 Codognan');

INSERT INTO Organisation (numero,adresse) VALUES
(9240,'721 Les Bressous, 70140 Chaumercenne'),
(9241,'650bis Bretelle Sortie N°50 A8 - Mercantour (Provenance Cannes) sud, 09200 Montjoie-en-Couserans');

INSERT INTO Organisation (numero,adresse) VALUES
(9242,'945 Le Bourg Neuf, 04420 Prads-Haute-Bléone'),
(9243,'181bis Allée  Jean de la Fontaine, 65130 Castillon');

INSERT INTO Organisation (numero,adresse) VALUES
(9244,'351bis Le Bas Vernet, 64410 Mialos'),
(9245,'915bis Etang communal Le Potant, 68510 Magstatt-le-Bas');

INSERT INTO Organisation (numero,adresse) VALUES
(9246,'77 Bois du Fay, 48000 Mende'),
(9247,'142 Moulin Murat, 31450 Fourquevaux');

INSERT INTO Organisation (numero,adresse) VALUES
(9248,'407bis Les Rollates, 21350 Saffres'),
(9249,'605bis Petit Cerisier, 68780 Diefmatten');

INSERT INTO Organisation (numero,adresse) VALUES
(9250,'822 Refuge des Bans, 53420 Chailland'),
(9251,'203bis Lieu-dit La Pargade, 25320 Vorges-les-Pins');

INSERT INTO Organisation (numero,adresse) VALUES
(9252,'142 les Guillemots, 25450 Damprichard'),
(9253,'805 Garampy, 76330 Port-Jérôme-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(9254,'0 Piste de l''Ubac, 21530 Saint-Germain-de-Modéon'),
(9255,'384 Hameau de Liffart, 62179 Escalles');

INSERT INTO Organisation (numero,adresse) VALUES
(9256,'872 En Cunière, 09200 Moulis'),
(9257,'785 Le Moulin des Brasses, 38160 Saint Antoine l''Abbaye');

INSERT INTO Organisation (numero,adresse) VALUES
(9258,'584 Les Usages, 77190 Villiers-en-Bière'),
(9259,'747 Artigues, 08190 Aire');

INSERT INTO Organisation (numero,adresse) VALUES
(9260,'692 Réserve de Magny, 71100 La Charmée'),
(9261,'940 Sénepjac, 33620 Laruscade');

INSERT INTO Organisation (numero,adresse) VALUES
(9262,'948 Avenue Chomérac, 79420 Clavé'),
(9263,'872 Sous-Beal, 62130 Guinecourt');

INSERT INTO Organisation (numero,adresse) VALUES
(9264,'181bis Bederet, 13119 Saint-Savournin'),
(9265,'581 Le Riage, 51120 Barbonne-Fayel');

INSERT INTO Organisation (numero,adresse) VALUES
(9266,'344 Petit Port, 30120 Pommiers'),
(9267,'805 Le Moulin Prard, 54110 Courbesseaux');

INSERT INTO Organisation (numero,adresse) VALUES
(9268,'426 Les Granges, 59840 Pérenchies'),
(9269,'568 La Plaine de Laumiere, 57320 Alzing');

INSERT INTO Organisation (numero,adresse) VALUES
(9270,'850 Le Pou, 02110 Brancourt-le-Grand'),
(9271,'535 Cote Jardin, 80200 Villers-Carbonnel');

INSERT INTO Organisation (numero,adresse) VALUES
(9272,'654bis Moulin de Sannes, 77390 Courquetaine'),
(9273,'330 Camp Belle Idee, 31410 Longages');

INSERT INTO Organisation (numero,adresse) VALUES
(9274,'310 Longpré, 80400 Quivières'),
(9275,'242 Route Métropolitaine 19, 62129 Herbelles');

INSERT INTO Organisation (numero,adresse) VALUES
(9276,'791 La Tourette, 67270 Scherlenheim'),
(9277,'576bis Champ Signon, 47220 Cuq');

INSERT INTO Organisation (numero,adresse) VALUES
(9278,'889 La Grande Bessaie, 41290 Sainte-Gemmes'),
(9279,'476 Fond de la Cense, 43590 Beauzac');

INSERT INTO Organisation (numero,adresse) VALUES
(9280,'634 Le Coumel, 05000 Neffes'),
(9281,'7bis Domaine de la Cote, 28140 Poupry');

INSERT INTO Organisation (numero,adresse) VALUES
(9282,'177bis Font-dou-teoule, 01190 Chavannes-sur-Reyssouze'),
(9283,'634 Le Syrina A, 60190 Cernoy');

INSERT INTO Organisation (numero,adresse) VALUES
(9284,'564 Chateau Gadin, 18300 Couargues'),
(9285,'260 Puech Meja, 23190 La Serre-Bussière-Vieille');

INSERT INTO Organisation (numero,adresse) VALUES
(9286,'274 Martinou, 39230 La Chaux-en-Bresse'),
(9287,'440 Les Prats, 62860 Épinoy');

INSERT INTO Organisation (numero,adresse) VALUES
(9288,'25bis Square des Santons, 67340 Sparsbach'),
(9289,'461bis ZI de l''Omois, 32460 Le Houga');

INSERT INTO Organisation (numero,adresse) VALUES
(9290,'666 Les Gallais, 31600 Eaunes'),
(9291,'892 Lieu-dit Campounac, 16300 Montmérac');

INSERT INTO Organisation (numero,adresse) VALUES
(9292,'240 Lancelot Nord, 57170 Wuisse'),
(9293,'325 Route de Decazeville, 36310 Tilly');

INSERT INTO Organisation (numero,adresse) VALUES
(9294,'5 Les Canals, 72170 Moitron-sur-Sarthe'),
(9295,'43 La Pradette, 54210 Saint-Nicolas-de-Port');

INSERT INTO Organisation (numero,adresse) VALUES
(9296,'684 Le Ranche, 53220 Pontmain'),
(9297,'483 Perget, 70700 Vellemoz');

INSERT INTO Organisation (numero,adresse) VALUES
(9298,'520 Chaunac, 02270 Assis-sur-Serre'),
(9299,'873bis Résidence Les Patios 3, 16360 Chantillac');

INSERT INTO Organisation (numero,adresse) VALUES
(9300,'340 Encaoulade, 80400 Ercheu'),
(9301,'115bis Buret, 10600 Mergey');

INSERT INTO Organisation (numero,adresse) VALUES
(9302,'569bis Les-Mitres, 56480 Sainte-Brigitte'),
(9303,'844 L''Ubac d''Étoile, 28190 Billancelles');

INSERT INTO Organisation (numero,adresse) VALUES
(9304,'563bis Roussolles, 52400 Serqueux'),
(9305,'738 Petit Beron, 47120 Lévignac-de-Guyenne');

INSERT INTO Organisation (numero,adresse) VALUES
(9306,'276 Roc de BELVIS, 62880 Pont-à-Vendin'),
(9307,'304 Le Cebie, 17490 Saint-Ouen-la-Thène');

INSERT INTO Organisation (numero,adresse) VALUES
(9308,'943 Lieu Dit Lasserre, 70190 Montarlot-lès-Rioz'),
(9309,'613 La Foulie, 60600 Étouy');

INSERT INTO Organisation (numero,adresse) VALUES
(9310,'14bis Les Fouquetis, 44480 Donges'),
(9311,'507 La Tour, 49150 Baugé-en-Anjou');

INSERT INTO Organisation (numero,adresse) VALUES
(9312,'101 La Baraque de Cussan, 76730 Gonnetot'),
(9313,'529 La Bessierette, 44420 La Turballe');

INSERT INTO Organisation (numero,adresse) VALUES
(9314,'957 Vincent, 30150 Montfaucon'),
(9315,'322 le Pouget, 08310 Saint-Clément-à-Arnes');

INSERT INTO Organisation (numero,adresse) VALUES
(9316,'618 Les Buffets, 69970 Chaponnay'),
(9317,'212bis Le comte, 13930 Aureille');

INSERT INTO Organisation (numero,adresse) VALUES
(9318,'413bis La Banlaurière, 14710 Russy'),
(9319,'641 Rue du Moulin, 32190 Séailles');

INSERT INTO Organisation (numero,adresse) VALUES
(9320,'531 Fontaine de Marty, 55700 Laneuville-sur-Meuse'),
(9321,'337bis Quezac, 31120 Roquettes');

INSERT INTO Organisation (numero,adresse) VALUES
(9322,'148 Clot de Pech, 32320 Montesquiou'),
(9323,'935 Telot, 14160 Grangues');

INSERT INTO Organisation (numero,adresse) VALUES
(9324,'957 Côte de la Poudrière, 38760 Saint-Paul-de-Varces'),
(9325,'711 Les Forges, 51330 Givry-en-Argonne');

INSERT INTO Organisation (numero,adresse) VALUES
(9326,'558 Les Sorbelettes, 15150 Arnac'),
(9327,'958 La Roucanelle, 25170 Champvans-les-Moulins');

INSERT INTO Organisation (numero,adresse) VALUES
(9328,'804 Coste Calde Haute, 57420 Pouilly'),
(9329,'514 Hameau de Saint-Estève, 02290 Montigny-Lengrain');

INSERT INTO Organisation (numero,adresse) VALUES
(9330,'921 Angel Berg, 35120 Mont-Dol'),
(9331,'862 Rue du Colonel Polidori, 03340 La Ferté-Hauterive');

INSERT INTO Organisation (numero,adresse) VALUES
(9332,'879 La Prairie de Tavaux, 04000 Entrages'),
(9333,'15 Les Avertis, 62117 Brebières');

INSERT INTO Organisation (numero,adresse) VALUES
(9334,'336bis Plein Soleil, 02240 Séry-lès-Mézières'),
(9335,'577 Mairie annexe de La Pointe de Contes, 14240 Caumont-sur-Aure');

INSERT INTO Organisation (numero,adresse) VALUES
(9336,'969 Le Glacis du Moulin, 68120 Pfastatt'),
(9337,'819 Les Sagnolles, 70400 Mignavillers');

INSERT INTO Organisation (numero,adresse) VALUES
(9338,'675 En Percheron, 71800 Saint-Racho'),
(9339,'159bis Les Grandes Blaches, 71140 Chalmoux');

INSERT INTO Organisation (numero,adresse) VALUES
(9340,'257 Le Poustel, 76133 Manéglise'),
(9341,'740bis Bretelle Entrée N°51 Digue des Français - A8 (Direction Cannes), 57590 Delme');

INSERT INTO Organisation (numero,adresse) VALUES
(9342,'356 Les Abaures, 14170 Vaudeloges'),
(9343,'795bis Rue Antoine de Saint Exupery, 24240 Mescoules');

INSERT INTO Organisation (numero,adresse) VALUES
(9344,'562 Impasse les Trois Sabots, 74210 Saint-Ferréol'),
(9345,'653bis Pres des Crouès, 58150 Saint-Quentin-sur-Nohain');

INSERT INTO Organisation (numero,adresse) VALUES
(9346,'762 Marfaing d''en haut, 16230 Val-de-Bonnieure'),
(9347,'59 Salvage, 14400 Crouay');

INSERT INTO Organisation (numero,adresse) VALUES
(9348,'522 La Teppe, 26400 Eygluy-Escoulin'),
(9349,'605 Domaine Saint-Basile, 68290 Dolleren');

INSERT INTO Organisation (numero,adresse) VALUES
(9350,'18 Complexe Sportif, 66360 Jujols'),
(9351,'548 Crouzet, 29690 La Feuillée');

INSERT INTO Organisation (numero,adresse) VALUES
(9352,'374 Payre Fabre, 49260 Saint-Cyr-en-Bourg'),
(9353,'591 Bretelle Entrée N°55 Turin - A8 (Direction Vintimille), 54300 Rehainviller');

INSERT INTO Organisation (numero,adresse) VALUES
(9354,'863bis En Brochalin, 42300 Villerest'),
(9355,'434 Chez Lallias, 62130 Huclier');

INSERT INTO Organisation (numero,adresse) VALUES
(9356,'131bis Villa Riviera, 25220 Amagney'),
(9357,'506 Ponganières, 14130 Saint-Julien-sur-Calonne');

INSERT INTO Organisation (numero,adresse) VALUES
(9358,'745 Point Eau Incendie n° 1004 (borne d''incendie), 24800 Eyzerac'),
(9359,'643 Stade de rugby Jean Salobert, 40500 Coudures');

INSERT INTO Organisation (numero,adresse) VALUES
(9360,'526 Hameau de Galié, 27430 Connelles'),
(9361,'82bis Candy, 25230 Dasle');

INSERT INTO Organisation (numero,adresse) VALUES
(9362,'682 Fontiaud, 03450 Nades'),
(9363,'563 Le Bois des Courtys, 80370 Maizicourt');

INSERT INTO Organisation (numero,adresse) VALUES
(9364,'795 Les Olives, 71120 Ozolles'),
(9365,'444 Font-Patine, 68127 Biltzheim');

INSERT INTO Organisation (numero,adresse) VALUES
(9366,'753bis Zone Artisanale, 54160 Pierreville'),
(9367,'296 La Roseya, 18520 Bengy-sur-Craon');

INSERT INTO Organisation (numero,adresse) VALUES
(9368,'89 Carretier, 57530 Maizeroy'),
(9369,'982 Stamura, 55130 Demange-aux-Eaux');

INSERT INTO Organisation (numero,adresse) VALUES
(9370,'643 Le Mas d’Entraygues, 71190 Laizy'),
(9371,'367 Fouent de Magne Bas, 52000 Buxières-lès-Villiers');

INSERT INTO Organisation (numero,adresse) VALUES
(9372,'251 Les Decharty, 02220 Jouaignes'),
(9373,'131bis Lieu-dit Riou de las Barguéros, 55210 Thillot');

INSERT INTO Organisation (numero,adresse) VALUES
(9374,'747 Barthes, 71150 Sampigny-lès-Maranges'),
(9375,'900 Prague, 34150 Saint-Guilhem-le-Désert');

INSERT INTO Organisation (numero,adresse) VALUES
(9376,'231bis Casot, 80340 Suzanne'),
(9377,'554 Chemin Dit de Leffincourt, 09800 Sor');

INSERT INTO Organisation (numero,adresse) VALUES
(9378,'728bis Impasse des Anges, 80140 Cannessières'),
(9379,'173 Domaine des Chênes, 57790 Lorquin');

INSERT INTO Organisation (numero,adresse) VALUES
(9380,'795bis Les Quatre Buissons, 46140 Luzech'),
(9381,'614bis Laugere, 55220 Lemmes');

INSERT INTO Organisation (numero,adresse) VALUES
(9382,'223 La Roulie, 80140 Neuville-au-Bois'),
(9383,'719 Le Causse de la Glene, 36240 Gehée');

INSERT INTO Organisation (numero,adresse) VALUES
(9384,'842 La Croix Jacob - Place, 50240 Saint-Laurent-de-Terregatte'),
(9385,'166bis Le Sanhas Mort, 38570 La Pierre');

INSERT INTO Organisation (numero,adresse) VALUES
(9386,'484 Le presbytère de Bajou, 21400 Étrochey'),
(9387,'182bis Derrière la Tour, 62650 Bourthes');

INSERT INTO Organisation (numero,adresse) VALUES
(9388,'210 Etang David, 14380 Pont-Bellanger'),
(9389,'654bis La Tirasse, 30121 Mus');

INSERT INTO Organisation (numero,adresse) VALUES
(9390,'700 Les Andrauds, 62650 Enquin-sur-Baillons'),
(9391,'424bis Traverse de Bonvillars, 01250 Hautecourt-Romanèche');

INSERT INTO Organisation (numero,adresse) VALUES
(9392,'832 Le Moulin de Lissart, 50580 Denneville'),
(9393,'899 Col Del Besal, 74140 Machilly');

INSERT INTO Organisation (numero,adresse) VALUES
(9394,'405 Route de l''Aire Saint-Michel, 35450 Mecé'),
(9395,'538bis Le Savé, 64300 Sallespisse');

INSERT INTO Organisation (numero,adresse) VALUES
(9396,'304 Escalier de l''Ancien Chemin de l''Abadie, 43410 Léotoing'),
(9397,'579bis Foulbanne, 57160 Lessy');

INSERT INTO Organisation (numero,adresse) VALUES
(9398,'955 Gardette, 79140 Le Pin'),
(9399,'328bis Parc Mérovingien, 24100 Lembras');

INSERT INTO Organisation (numero,adresse) VALUES
(9400,'441 La Cote de la Louberie, 11200 Montséret'),
(9401,'937 En Barre, 10140 La Villeneuve-au-Chêne');

INSERT INTO Organisation (numero,adresse) VALUES
(9402,'547bis "Usine de méthanisation, D820", 22300 Caouënnec-Lanvézéac'),
(9403,'488 Mas de Roux, 10250 Courteron');

INSERT INTO Organisation (numero,adresse) VALUES
(9404,'679 Villa Erisand, 16110 Yvrac-et-Malleyrand'),
(9405,'964bis Pachins, 72510 Pontvallain');

INSERT INTO Organisation (numero,adresse) VALUES
(9406,'323 Les Guillaumesses, 22650 Beaussais-sur-Mer'),
(9407,'382 L’Argailler, 61700 Dompierre');

INSERT INTO Organisation (numero,adresse) VALUES
(9408,'630 Pré Poirier, 17470 Contré'),
(9409,'639 Les Petites Champagnes, 02260 Papleux');

INSERT INTO Organisation (numero,adresse) VALUES
(9410,'992 Bâtiment A5, 26570 Montbrun-les-Bains'),
(9411,'457 Chassat, 37380 Neuillé-le-Lierre');

INSERT INTO Organisation (numero,adresse) VALUES
(9412,'188 La Bouloie, 50290 Bréhal'),
(9413,'185bis Domov, 64430 Urepel');

INSERT INTO Organisation (numero,adresse) VALUES
(9414,'397 Gabet, 14710 Rubercy'),
(9415,'483 Gravelines, 34210 Minerve');

INSERT INTO Organisation (numero,adresse) VALUES
(9416,'383 Les Plaintiers, 59149 Bousignies-sur-Roc'),
(9417,'238bis Les Pradeaux, 10700 Villette-sur-Aube');

INSERT INTO Organisation (numero,adresse) VALUES
(9418,'841 Les Pres de Nogent, 10330 Donnement'),
(9419,'508bis La Croix rouge, 77410 Précy-sur-Marne');

INSERT INTO Organisation (numero,adresse) VALUES
(9420,'482 Le Besset, 08090 Sury'),
(9421,'331 Périolle, 40120 Maillères');

INSERT INTO Organisation (numero,adresse) VALUES
(9422,'257bis Castex, 14320 Fontenay-le-Marmion'),
(9423,'863 Le Puech Roux, 52220 Frampas');

INSERT INTO Organisation (numero,adresse) VALUES
(9424,'243 Passage souterrain Michel Genty, 38590 Brézins'),
(9425,'373bis Chemin du Pilon du Roy, 18320 Marseilles-lès-Aubigny');

INSERT INTO Organisation (numero,adresse) VALUES
(9426,'456 Résidence Les vignettes Bâtiment D2, 07200 Fons'),
(9427,'346bis Cap de Tete, 20114 Figari');

INSERT INTO Organisation (numero,adresse) VALUES
(9428,'695 Crématorium, 77320 Jouy-sur-Morin'),
(9429,'362 Le Roc de Saint Jean, 39300 Valempoulières');

INSERT INTO Organisation (numero,adresse) VALUES
(9430,'310bis Chemin de La Collette, 51400 Saint-Hilaire-au-Temple'),
(9431,'697 Domaine de Souillard, 09310 Pech');

INSERT INTO Organisation (numero,adresse) VALUES
(9432,'10 Palot, 17380 Torxé'),
(9433,'861bis Le Pont de Puech Bayssac, 45130 Meung-sur-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(9434,'757bis Mas des Contes, 43100 Paulhac'),
(9435,'82 Brunel, 16130 Verrières');

INSERT INTO Organisation (numero,adresse) VALUES
(9436,'291bis le Château, 32140 Panassac'),
(9437,'413 Le Poultre, 60310 Candor');

INSERT INTO Organisation (numero,adresse) VALUES
(9438,'220bis Amarande Bat B, 62650 Clenleu'),
(9439,'802bis Les Salettes, 04150 Banon');

INSERT INTO Organisation (numero,adresse) VALUES
(9440,'742 Le Grauzel, 43300 Saint-Arcons-d''Allier'),
(9441,'854bis La Rodo, 60390 La Neuville-Garnier');

INSERT INTO Organisation (numero,adresse) VALUES
(9442,'384 Village Vivarois III, 55320 Sommedieue'),
(9443,'237 Prairie du Bosquet de Jean, 18360 La Celette');

INSERT INTO Organisation (numero,adresse) VALUES
(9444,'687 Le Champ de la Chévre, 35430 Saint-Jouan-des-Guérets'),
(9445,'725 Mont Long, 50800 Bourguenolles');

INSERT INTO Organisation (numero,adresse) VALUES
(9446,'140 le Cheminot, 68630 Mittelwihr'),
(9447,'865 Chez Carte, 03150 Sanssat');

INSERT INTO Organisation (numero,adresse) VALUES
(9448,'284bis La Plagnole, 77590 Bois-le-Roi'),
(9449,'983bis Plaine de Calais, 69640 Rivolet');

INSERT INTO Organisation (numero,adresse) VALUES
(9450,'304 Point Ordures Ménagères - Déchets verts, 54540 Raon-lès-Leau'),
(9451,'202 La Garenne-Sud, 08300 Hauteville');

INSERT INTO Organisation (numero,adresse) VALUES
(9452,'163 Route de la Cave- Le Rougié, 08130 Semuy'),
(9453,'481 La Pierre, 64300 Laà-Mondrans');

INSERT INTO Organisation (numero,adresse) VALUES
(9454,'318bis Le Tremblais, 76210 Beuzeville-la-Grenier'),
(9455,'518bis Béret, 04230 Fontienne');

INSERT INTO Organisation (numero,adresse) VALUES
(9456,'743 Rue  Saint-Thomas de Villeneuve, 79170 Juillé'),
(9457,'449bis Les Bois du Chaillot, 32420 Sarcos');

INSERT INTO Organisation (numero,adresse) VALUES
(9458,'973 Escalier Square Alunni, 41290 Boisseau'),
(9459,'546bis La Petite Ferrage, 01190 Boissey');

INSERT INTO Organisation (numero,adresse) VALUES
(9460,'182 Bobignieux, 21230 Antigny-la-Ville'),
(9461,'970 Le Crêt d''Eau, 46200 Saint-Sozy');

INSERT INTO Organisation (numero,adresse) VALUES
(9462,'185 Impasse des Genêts, 80340 La Neuville-lès-Bray'),
(9463,'731 Gondoux, 39210 Domblans');

INSERT INTO Organisation (numero,adresse) VALUES
(9464,'549bis Grand Matrignat Est, 72130 Saint-Aubin-de-Locquenay'),
(9465,'163 Le Plessis, 16100 Javrezac');

INSERT INTO Organisation (numero,adresse) VALUES
(9466,'640 L’Ardillier, 16410 Garat'),
(9467,'709 Mergabes-Bas, 47700 Poussignac');

INSERT INTO Organisation (numero,adresse) VALUES
(9468,'305 La Benechie, 57510 Puttelange-aux-Lacs'),
(9469,'424bis Le bout du Monde, 31150 Gagnac-sur-Garonne');

INSERT INTO Organisation (numero,adresse) VALUES
(9470,'38 Malpago, 76760 Saint-Martin-aux-Arbres'),
(9471,'950bis Les Ayguas, 08220 Remaucourt');

INSERT INTO Organisation (numero,adresse) VALUES
(9472,'318 Quarton, 79380 La Forêt-sur-Sèvre'),
(9473,'909 étang F1, 39250 Doye');

INSERT INTO Organisation (numero,adresse) VALUES
(9474,'809 Guille de Long, 46140 Carnac-Rouffiac'),
(9475,'306 Casterino, 60190 Sacy-le-Petit');

INSERT INTO Organisation (numero,adresse) VALUES
(9476,'43bis Sarbaute, 11230 Peyrefitte-du-Razès'),
(9477,'946 La Paouloune, 22160 Saint-Nicodème');

INSERT INTO Organisation (numero,adresse) VALUES
(9478,'125bis Le Portail Ferrier, 51290 Isle-sur-Marne'),
(9479,'191 Sentier du Hameau Wors, 09140 Couflens');

INSERT INTO Organisation (numero,adresse) VALUES
(9480,'763bis Serre Blanc, 31850 Beaupuy'),
(9481,'345 Locaterie des Sapins, 78500 Sartrouville');

INSERT INTO Organisation (numero,adresse) VALUES
(9482,'775bis Falgayroles Bas, 27800 Berthouville'),
(9483,'826bis Caton, 73300 Hermillon');

INSERT INTO Organisation (numero,adresse) VALUES
(9484,'5 Les provens, 16170 Mareuil'),
(9485,'280bis La Clairierre, 50320 Saint-Jean-des-Champs');

INSERT INTO Organisation (numero,adresse) VALUES
(9486,'485 Bâtiment Le lavandin Entrée 18, 54560 Audun-le-Roman'),
(9487,'183 La Mauvaise Femme, 10320 Saint-Jean-de-Bonneval');

INSERT INTO Organisation (numero,adresse) VALUES
(9488,'84bis Cellier de Najac, 14400 Cottun'),
(9489,'69bis Chemin Daniel, 62128 Guémappe');

INSERT INTO Organisation (numero,adresse) VALUES
(9490,'91 Le Clos Quennesson, 20151 Sari-d''Orcino'),
(9491,'932 Saint-isidore, 76560 Sommesnil');

INSERT INTO Organisation (numero,adresse) VALUES
(9492,'286 Rue des Amoureux, 29630 Saint-Jean-du-Doigt'),
(9493,'347 Les Alouettes, 11290 Arzens');

INSERT INTO Organisation (numero,adresse) VALUES
(9494,'718bis Prat de Madame, 59144 Jenlain'),
(9495,'990bis Peyremoula, 14000 Caen');

INSERT INTO Organisation (numero,adresse) VALUES
(9496,'40 Boissandroux, 24350 Mensignac'),
(9497,'321 Pouillas, 26350 Montchenu');

INSERT INTO Organisation (numero,adresse) VALUES
(9498,'332 Place la de Victoire, 62690 Camblain-l''Abbé'),
(9499,'929 Bois Tréteau, 02140 Prisces');

INSERT INTO Organisation (numero,adresse) VALUES
(9500,'471 nouzet, 07120 Chauzon'),
(9501,'939bis Les Agoustes, 08310 Saint-Étienne-à-Arnes');

INSERT INTO Organisation (numero,adresse) VALUES
(9502,'913 Chateau de Lagoual, 26330 Châteauneuf-de-Galaure'),
(9503,'155bis Hauterives, 52210 Villiers-sur-Suize');

INSERT INTO Organisation (numero,adresse) VALUES
(9504,'112bis Pierre Avons, 53100 Parigné-sur-Braye'),
(9505,'446 Le Champ de Boncourt, 44670 Juigné-des-Moutiers');

INSERT INTO Organisation (numero,adresse) VALUES
(9506,'635bis Le Segala Sud, 39300 Le Larderet'),
(9507,'224 Resquens, 62470 Camblain-Châtelain');

INSERT INTO Organisation (numero,adresse) VALUES
(9508,'8 Suech, 57050 Longeville-lès-Metz'),
(9509,'23 Saint-Estève, 06830 Gilette');

INSERT INTO Organisation (numero,adresse) VALUES
(9510,'414 Le Trein, 71140 Cronat'),
(9511,'22 Le Talieyrou, 28150 Réclainville');

INSERT INTO Organisation (numero,adresse) VALUES
(9512,'571bis Malakoff, 77480 Baby'),
(9513,'500bis La Chave et les Rouveyres, 59234 Fressain');

INSERT INTO Organisation (numero,adresse) VALUES
(9514,'855 Les Tourniaires, 59213 Capelle'),
(9515,'706 Le Brouguet, 20121 Rezza');

INSERT INTO Organisation (numero,adresse) VALUES
(9516,'760 Castel Fleuri, 31360 Castillon-de-Saint-Martory'),
(9517,'672 Les Jonquieres, 06500 Gorbio');

INSERT INTO Organisation (numero,adresse) VALUES
(9518,'892 Cacaraing, 62760 Mondicourt'),
(9519,'185 Le Champ Fagots, 47150 Saint-Aubin');

INSERT INTO Organisation (numero,adresse) VALUES
(9520,'18bis La Carnicousie, 80320 Ablaincourt-Pressoir'),
(9521,'410 Le Poulinet, 49070 Beaucouzé');

INSERT INTO Organisation (numero,adresse) VALUES
(9522,'641 Le Clediol, 61500 Le Cercueil'),
(9523,'599bis Maisonneuve, 63890 Grandval');

INSERT INTO Organisation (numero,adresse) VALUES
(9524,'223 Chateau des Bordes, 27500 Selles'),
(9525,'670 La Grande Garenne, 41160 Brévainville');

INSERT INTO Organisation (numero,adresse) VALUES
(9526,'508 Plein Soleil, 20100 Sartène'),
(9527,'33 Les Terres de Champagne, 71120 Ozolles');

INSERT INTO Organisation (numero,adresse) VALUES
(9528,'236 Sorbier, 27330 La Neuve-Lyre'),
(9529,'976bis Pres le Cimetiere, 18250 Montigny');

INSERT INTO Organisation (numero,adresse) VALUES
(9530,'201 Les Persières, 64640 Lantabat'),
(9531,'534 La Moulasse, 28700 Maisons');

INSERT INTO Organisation (numero,adresse) VALUES
(9532,'310bis Ferries d''En Haut, 50440 Herqueville'),
(9533,'136bis Residence les Orchidees, 15200 Jaleyrac');

INSERT INTO Organisation (numero,adresse) VALUES
(9534,'445 La Baraque de la Besse, 30210 Saint-Bonnet-du-Gard'),
(9535,'209 Lavaux d''En Haut, 32700 Terraube');

INSERT INTO Organisation (numero,adresse) VALUES
(9536,'338 Groupe Scolaire Francine Claret Mateos, 35390 Saint-Sulpice-des-Landes'),
(9537,'176 Don, 14210 Val d''Arry');

INSERT INTO Organisation (numero,adresse) VALUES
(9538,'462 Avenue Henry Guillaumet, 79270 La Rochénard'),
(9539,'319bis Cap de Prats, 10240 Avant-lès-Ramerupt');

INSERT INTO Organisation (numero,adresse) VALUES
(9540,'797 """ La Gueze """, 07610 Sécheras'),
(9541,'366 Ferme de Camparol, 26340 Aucelon');

INSERT INTO Organisation (numero,adresse) VALUES
(9542,'912 Village Merlin, 22240 Plévenon'),
(9543,'919 Les Tupinieres, 44410 La Chapelle-des-Marais');

INSERT INTO Organisation (numero,adresse) VALUES
(9544,'228 La Petite Arrouaise, 60310 Margny-aux-Cerises'),
(9545,'392 Landeserre, 27640 Villiers-en-Désœuvre');

INSERT INTO Organisation (numero,adresse) VALUES
(9546,'913 Lieu-dit Le Tronc, 24480 Bouillac'),
(9547,'636 Roumenty-Haut, 61400 Comblot');

INSERT INTO Organisation (numero,adresse) VALUES
(9548,'180 La Rouine, 58170 Fléty'),
(9549,'833 Saint-Cyprien, 47110 Sainte-Livrade-sur-Lot');

INSERT INTO Organisation (numero,adresse) VALUES
(9550,'909 Peyroutou, 69440 Chabanière'),
(9551,'315 La Cluse, 11290 Montréal');

INSERT INTO Organisation (numero,adresse) VALUES
(9552,'761 Roustanies, 45340 Boiscommun'),
(9553,'648bis Au-dessus de l''Eglise, 07140 Montselgues');

INSERT INTO Organisation (numero,adresse) VALUES
(9554,'529bis Le Bois des Macons, 52260 Marac'),
(9555,'802bis Carrefour Armance Royer, 27190 Sainte-Marthe');

INSERT INTO Organisation (numero,adresse) VALUES
(9556,'745 Les Lazes, 16320 Ronsenac'),
(9557,'113 Forêt Royale Darmaca, 73220 Montsapey');

INSERT INTO Organisation (numero,adresse) VALUES
(9558,'691 Les Estèves, 05100 Briançon'),
(9559,'422 Côte de Neyva, 38660 Saint-Hilaire');

INSERT INTO Organisation (numero,adresse) VALUES
(9560,'890 Les Cotes de Gis, 04410 Puimoisson'),
(9561,'73 Pied la Vigne, 11120 Marcorignan');

INSERT INTO Organisation (numero,adresse) VALUES
(9562,'615 Les Ourtalous, 64300 Biron'),
(9563,'852 Rioupelles, 24540 Saint-Avit-Rivière');

INSERT INTO Organisation (numero,adresse) VALUES
(9564,'807 Les Amouroux, 19500 Ligneyrac'),
(9565,'189 Lieu Sebeau, 69380 Alix');

INSERT INTO Organisation (numero,adresse) VALUES
(9566,'538 Square Louis Maccagno, 52320 Vouécourt'),
(9567,'440 La Rue Mulot, 18410 Blancafort');

INSERT INTO Organisation (numero,adresse) VALUES
(9568,'286 La Fantaisie, 36100 La Champenoise'),
(9569,'274 Valence, 52300 Paroy-sur-Saulx');

INSERT INTO Organisation (numero,adresse) VALUES
(9570,'426 La Roucayrie, 50370 Les Cresnays'),
(9571,'616 Les Plantiers-Nord, 42640 Saint-Forgeux-Lespinasse');

INSERT INTO Organisation (numero,adresse) VALUES
(9572,'700bis Roubreau, 31450 Pouze'),
(9573,'454 Soudon, 21170 Montot');

INSERT INTO Organisation (numero,adresse) VALUES
(9574,'988 Résidence Les Bastides d''ÉLI, 18340 Soye-en-Septaine'),
(9575,'672bis Chemin de la Jonction, 35320 La Bosse-de-Bretagne');

INSERT INTO Organisation (numero,adresse) VALUES
(9576,'950 Bezentou, 58130 Guérigny'),
(9577,'196 Pramejo, 10110 Magnant');

INSERT INTO Organisation (numero,adresse) VALUES
(9578,'315 En Barvier, 49520 Noyant-la-Gravoyère'),
(9579,'406bis Cazals d''Arnaud, 24610 Montpeyroux');

INSERT INTO Organisation (numero,adresse) VALUES
(9580,'17 Lieu dit Le Triangle, 14190 Ouilly-le-Tesson'),
(9581,'707 Marty le Vieux, 24340 Monsec');

INSERT INTO Organisation (numero,adresse) VALUES
(9582,'902 Villa Auguste, 34420 Cers'),
(9583,'135 Hameau du Villard, 52200 Perrancey-les-Vieux-Moulins');

INSERT INTO Organisation (numero,adresse) VALUES
(9584,'833 Cité Scolaire Internationale de Ferney-Voltaire, 62217 Neuville-Vitasse'),
(9585,'959bis Linrésie, 47500 Saint-Vite');

INSERT INTO Organisation (numero,adresse) VALUES
(9586,'122 Le Grand Hubac, 27160 Bémécourt'),
(9587,'407bis Peloutier, 24640 Chourgnac');

INSERT INTO Organisation (numero,adresse) VALUES
(9588,'373 Résidence du stade Bâtiment C, 73730 Cevins'),
(9589,'621 Allée Laura Borla, 55500 Nantois');

INSERT INTO Organisation (numero,adresse) VALUES
(9590,'635 La Bastisse de Menay, 61400 Comblot'),
(9591,'948 Le Puech de Garde, 54580 Saint-Ail');

INSERT INTO Organisation (numero,adresse) VALUES
(9592,'984 Bournac, 41700 Oisly'),
(9593,'322bis Lieu-dit Carol, 27370 La Saussaye');

INSERT INTO Organisation (numero,adresse) VALUES
(9594,'174 Hameau Renoir, 23500 La Nouaille'),
(9595,'675 Cours d''Artos, 51500 Sacy');

INSERT INTO Organisation (numero,adresse) VALUES
(9596,'712bis Les Mines, 80240 Driencourt'),
(9597,'276bis Lotissement Chante Claude 1, 37120 Lémeré');

INSERT INTO Organisation (numero,adresse) VALUES
(9598,'24bis Le Peyssel, 51300 Courdemanges'),
(9599,'640 Etang Girard, 64450 Argelos');

INSERT INTO Organisation (numero,adresse) VALUES
(9600,'939 Le Séminaire, 55160 Bonzée'),
(9601,'686 Pigeonnier Communal, 16420 Brigueuil');

INSERT INTO Organisation (numero,adresse) VALUES
(9602,'663 Clot de Brouilh, 62450 Beugnâtre'),
(9603,'209 Place René de Lucinge, 60480 Bucamps');

INSERT INTO Organisation (numero,adresse) VALUES
(9604,'932 Avenue Denis Delahaye, 50190 Nay'),
(9605,'927 Le Petit Larris, 09800 Argein');

INSERT INTO Organisation (numero,adresse) VALUES
(9606,'8 Coumo Caoudo, 23000 Saint-Sulpice-le-Guérétois'),
(9607,'610 Col de l''Horte, 65190 Bernadets-Dessus');

INSERT INTO Organisation (numero,adresse) VALUES
(9608,'489 Terrain multi-jeux / Stade (Foot...), 69620 Chamelet'),
(9609,'858 Lou Plan, 26150 Sainte-Croix');

INSERT INTO Organisation (numero,adresse) VALUES
(9610,'199 Tiebaghi, 08250 Chevières'),
(9611,'113 Arques, 50580 Canville-la-Rocque');

INSERT INTO Organisation (numero,adresse) VALUES
(9612,'486 Les Plaines de la Colange, 62132 Caffiers'),
(9613,'702 Le Pas du Ranc, 44310 Saint-Colomban');

INSERT INTO Organisation (numero,adresse) VALUES
(9614,'9bis Les Seringas, 77120 Saints'),
(9615,'971 Granges de Valaura, 62380 Bléquin');

INSERT INTO Organisation (numero,adresse) VALUES
(9616,'986 Le Pain au Vin, 59570 Obies'),
(9617,'55 Champ de Faire, 24320 Chapdeuil');

INSERT INTO Organisation (numero,adresse) VALUES
(9618,'19bis Pré de la Tourrette, 31570 Saint-Pierre-de-Lages'),
(9619,'437 Croux d''Al Sarrat, 38270 Saint-Barthélemy');

INSERT INTO Organisation (numero,adresse) VALUES
(9620,'89 Granges Besson, 50260 Breuville'),
(9621,'370 Avenue  Joseph Rigaud, 79130 Secondigny');

INSERT INTO Organisation (numero,adresse) VALUES
(9622,'939 Dessous la Casinière, 64230 Beyrie-en-Béarn'),
(9623,'939 Las Crambes, 16360 Condéon');

INSERT INTO Organisation (numero,adresse) VALUES
(9624,'39 Route de Chagny, 56450 Surzur'),
(9625,'133bis Prunhac, 08090 This');

INSERT INTO Organisation (numero,adresse) VALUES
(9626,'782 Plan du Soleil, 59940 Neuf-Berquin'),
(9627,'330 Le Cammas Blanc, 06830 Gilette');

INSERT INTO Organisation (numero,adresse) VALUES
(9628,'11bis Village de Saint Laurent, 76270 Neufchâtel-en-Bray'),
(9629,'107bis Les Tracols, 15800 Jou-sous-Monjou');

INSERT INTO Organisation (numero,adresse) VALUES
(9630,'807 Peyrousse, 65190 Peyraube'),
(9631,'369 Jardin Rue Genari - Boulevard Braille, 77570 La Madeleine-sur-Loing');

INSERT INTO Organisation (numero,adresse) VALUES
(9632,'280bis Les Savoyes, 08300 Perthes'),
(9633,'819bis Belinguié, 11140 Joucou');

INSERT INTO Organisation (numero,adresse) VALUES
(9634,'6 Pra Poumel, 08110 Carignan'),
(9635,'123 Cave Terre, 46800 Saux');

INSERT INTO Organisation (numero,adresse) VALUES
(9636,'244 Langlade, 57580 Rémilly'),
(9637,'496 Les Grands Debrits, 17500 Léoville');

INSERT INTO Organisation (numero,adresse) VALUES
(9638,'341bis Trabaou, 76140 Le Petit-Quevilly'),
(9639,'294 Basse Chaumont, 38134 La Sure en Chartreuse');

INSERT INTO Organisation (numero,adresse) VALUES
(9640,'364 Petite Paroisse, 24210 Peyrignac'),
(9641,'553 Clos des Trois Noyers, 17260 Saint-Simon-de-Pellouaille');

INSERT INTO Organisation (numero,adresse) VALUES
(9642,'931 Résidence L''Oustal, 29790 Confort-Meilars'),
(9643,'550 La Pièce des Eaux, 33840 Goualade');

INSERT INTO Organisation (numero,adresse) VALUES
(9644,'341 Le Pas du Ranc, 46100 Cambes'),
(9645,'530bis La Roquerie, 47260 Castelmoron-sur-Lot');

INSERT INTO Organisation (numero,adresse) VALUES
(9646,'60 Thumet Devant, 80140 Frettecuisse'),
(9647,'617 Villa Saint Veran, 31230 Goudex');

INSERT INTO Organisation (numero,adresse) VALUES
(9648,'204 La Font Vineuse, 33210 Bommes'),
(9649,'112 Résidence Hawaï 3, 41290 Conan');

INSERT INTO Organisation (numero,adresse) VALUES
(9650,'358bis Chemin du San-Peyre, 27180 Saint-Sébastien-de-Morsent'),
(9651,'451bis Le Buc, 51490 Saint-Hilaire-le-Petit');

INSERT INTO Organisation (numero,adresse) VALUES
(9652,'646bis Parent, 14130 Le Breuil-en-Auge'),
(9653,'305 Ichart, 14270 Magny-la-Campagne');

INSERT INTO Organisation (numero,adresse) VALUES
(9654,'509 Rue du Maréchal, 60290 Cauffry'),
(9655,'187bis Domaine Des Sables, 68230 Niedermorschwihr');

INSERT INTO Organisation (numero,adresse) VALUES
(9656,'40bis Bourgougnon, 49330 Cherré'),
(9657,'680 Sente de la Ruelle des Bois, 55800 Villers-aux-Vents');

INSERT INTO Organisation (numero,adresse) VALUES
(9658,'807bis Chemin de la Cascade de Gairaut, 57370 Metting'),
(9659,'611bis Parrouquet, 38160 Saint-Appolinard');

INSERT INTO Organisation (numero,adresse) VALUES
(9660,'454 Lombray, 04250 Faucon-du-Caire'),
(9661,'92bis Terres Rouges, 27150 Mesnil-sous-Vienne');

INSERT INTO Organisation (numero,adresse) VALUES
(9662,'255bis Moulin d’Angles, 63780 Queuille'),
(9663,'187bis Le Mauvais Pas, 37350 Barrou');

INSERT INTO Organisation (numero,adresse) VALUES
(9664,'63 Les Peyres Blanches, 62390 Quœux-Haut-Maînil'),
(9665,'384bis Les Saouves, 58230 Saint-Agnan');

INSERT INTO Organisation (numero,adresse) VALUES
(9666,'357 Vazenton, 02190 Amifontaine'),
(9667,'454 La Borie Graissac, 59570 Bellignies');

INSERT INTO Organisation (numero,adresse) VALUES
(9668,'390 Lotissement de la Clorisse, 60120 Villers-Vicomte'),
(9669,'339 Chemin de la Bigue, 62196 Hesdigneul-lès-Béthune');

INSERT INTO Organisation (numero,adresse) VALUES
(9670,'355bis Chemin de Carcassonne, 61160 Saint-Lambert-sur-Dive'),
(9671,'514 La Chaumine, 09350 Fornex');

INSERT INTO Organisation (numero,adresse) VALUES
(9672,'793 Eglise Saint Michel, 73500 Bramans'),
(9673,'457 L''Esquinade, 02200 Ploisy');

INSERT INTO Organisation (numero,adresse) VALUES
(9674,'880 Centre Loisirs Jeunesse, 70200 Arpenans'),
(9675,'507 La Belle Foret, 46140 Sauzet');

INSERT INTO Organisation (numero,adresse) VALUES
(9676,'869bis Rez des Bessies, 41370 Saint-Léonard-en-Beauce'),
(9677,'599 La Grande Vestide, 54113 Gye');

INSERT INTO Organisation (numero,adresse) VALUES
(9678,'961 Le Bournhou, 02540 Viffort'),
(9679,'399 Lareyat, 16110 Pranzac');

INSERT INTO Organisation (numero,adresse) VALUES
(9680,'239 Le Ratous, 66500 Los Masos'),
(9681,'538 Maison de Secours, 40380 Nousse');

INSERT INTO Organisation (numero,adresse) VALUES
(9682,'506 Montgazon, 55100 Brabant-sur-Meuse'),
(9683,'779 Les 4 Vents, 40170 Bias');

INSERT INTO Organisation (numero,adresse) VALUES
(9684,'260 Sourrières, 55600 Breux'),
(9685,'600 Fédac, 36240 Jeu-Maloches');

INSERT INTO Organisation (numero,adresse) VALUES
(9686,'944 Calvaire, 03170 Saint-Angel'),
(9687,'251 Le Plo de la Besse, 34600 Le Poujol-sur-Orb');

INSERT INTO Organisation (numero,adresse) VALUES
(9688,'969 Lotissement Le Clos de la Reine, 20138 Coti-Chiavari'),
(9689,'676 La Pauzette, 27330 Mesnil-en-Ouche');

INSERT INTO Organisation (numero,adresse) VALUES
(9690,'849bis Lagardie, 55160 Hennemont'),
(9691,'845 Domaine Nesme, 43320 Fix-Saint-Geneys');

INSERT INTO Organisation (numero,adresse) VALUES
(9692,'27 Pré Gris, 31220 Lavelanet-de-Comminges'),
(9693,'941 Creux d''Arsac, 13100 Aix-en-Provence');

INSERT INTO Organisation (numero,adresse) VALUES
(9694,'969 Vers les Nez, 02800 Courbes'),
(9695,'422 Quartier le Villard, 01430 Vieu-d''Izenave');

INSERT INTO Organisation (numero,adresse) VALUES
(9696,'270 Domaine de la Fontaine, 59247 Hem-Lenglet'),
(9697,'559 Les Taboutes, 15300 Ségur-les-Villas');

INSERT INTO Organisation (numero,adresse) VALUES
(9698,'85bis Hameau de la Benague, 10510 Origny-le-Sec'),
(9699,'226bis Roya, 80500 Ayencourt');

INSERT INTO Organisation (numero,adresse) VALUES
(9700,'121 Saint-Gérier, 59247 Hem-Lenglet'),
(9701,'631 Plan d''eau d''Eygliers, 08130 Neuville-Day');

INSERT INTO Organisation (numero,adresse) VALUES
(9702,'187 Chemin Balmas, 18240 Savigny-en-Sancerre'),
(9703,'831bis Naucelle, 45300 Pithiviers-le-Vieil');

INSERT INTO Organisation (numero,adresse) VALUES
(9704,'527 L''Ancienne Chapelle, 66600 Rivesaltes'),
(9705,'514 Le Mazi, 08090 Haudrecy');

INSERT INTO Organisation (numero,adresse) VALUES
(9706,'183 le Burgas, 16380 Saint-Germain-de-Montbron'),
(9707,'82 Chemin des Pyrénées, 60350 Bitry');

INSERT INTO Organisation (numero,adresse) VALUES
(9708,'518 Les 2 Chenes, 56290 Port-Louis'),
(9709,'621 Le Glandou, 01510 Ordonnaz');

INSERT INTO Organisation (numero,adresse) VALUES
(9710,'78 La Vallee du Charmier, 52500 Champsevraine'),
(9711,'343 Les Baraques du Peyron, 76590 Lintot-les-Bois');

INSERT INTO Organisation (numero,adresse) VALUES
(9712,'76bis Saint Cloud, 02210 Saint-Rémy-Blanzy'),
(9713,'46 Bouriou, 43320 Chaspuzac');

INSERT INTO Organisation (numero,adresse) VALUES
(9714,'830 La Iucci Louise, 70230 Ormenans'),
(9715,'212bis Hameau de MONTCAMP, 70110 Longevelle');

INSERT INTO Organisation (numero,adresse) VALUES
(9716,'220 Jardin de la Batterie du Cimetière Russe, 11230 Puivert'),
(9717,'432bis Les Dezard, 09800 Galey');

INSERT INTO Organisation (numero,adresse) VALUES
(9718,'380 Chemin de la Croix, 24300 Le Bourdeix'),
(9719,'461 Vazeille, 55220 Souilly');

INSERT INTO Organisation (numero,adresse) VALUES
(9720,'579 Villa La Pinede, 54610 Mailly-sur-Seille'),
(9721,'530 Domaine des Vallieres, 28200 Lutz-en-Dunois');

INSERT INTO Organisation (numero,adresse) VALUES
(9722,'275 Laguille, 14600 Genneville'),
(9723,'824 Froideau, 02160 Bourg-et-Comin');

INSERT INTO Organisation (numero,adresse) VALUES
(9724,'248 Le Grand Vernay, 71000 Mâcon'),
(9725,'296bis Garrou, 72600 Aillières-Beauvoir');

INSERT INTO Organisation (numero,adresse) VALUES
(9726,'83bis Lotissement les Erables, 07310 La Rochette'),
(9727,'98 Le bas de Morot, 36230 Fougerolles');

INSERT INTO Organisation (numero,adresse) VALUES
(9728,'423 Le Mas Des Bartavelles, 73200 Monthion'),
(9729,'750 Donnemorte, 65100 Lourdes');

INSERT INTO Organisation (numero,adresse) VALUES
(9730,'558 Laune Supérieure, 70110 Mélecey'),
(9731,'767 Le Landass, 16460 Couture');

INSERT INTO Organisation (numero,adresse) VALUES
(9732,'421bis L''Ensoleillado, 55300 Maizey'),
(9733,'316bis felips, 34130 Mudaison');

INSERT INTO Organisation (numero,adresse) VALUES
(9734,'203 Gorry, 66150 Montferrer'),
(9735,'805 Biac, 42290 Sorbiers');

INSERT INTO Organisation (numero,adresse) VALUES
(9736,'318 Rue du Barry Marzials, 01560 Saint-Trivier-de-Courtes'),
(9737,'900bis Rue Docteur Lanchier, 53190 Fougerolles-du-Plessis');

INSERT INTO Organisation (numero,adresse) VALUES
(9738,'670 Cabet, 62760 Orville'),
(9739,'297 Le Louvier, 61290 Les Menus');

INSERT INTO Organisation (numero,adresse) VALUES
(9740,'40 Lieu Meslier, 02640 Tugny-et-Pont'),
(9741,'4bis Col de la Saulce, 79420 Clavé');

INSERT INTO Organisation (numero,adresse) VALUES
(9742,'781 Arcadie, 21320 Semarey'),
(9743,'775 Camigrand, 38460 Leyrieu');

INSERT INTO Organisation (numero,adresse) VALUES
(9744,'233 La Fayette, 80430 Liomer'),
(9745,'42 Le Sabatier, 67340 Lichtenberg');

INSERT INTO Organisation (numero,adresse) VALUES
(9746,'700 Moliere-nord, 45530 Combreux'),
(9747,'309 Pres des Gouilles, 45260 Presnoy');

INSERT INTO Organisation (numero,adresse) VALUES
(9748,'740 Ecole Primaire, 48120 Sainte-Eulalie'),
(9749,'513bis Blue Bay, 34290 Alignan-du-Vent');

INSERT INTO Organisation (numero,adresse) VALUES
(9750,'184 La Bastidie Basse, 74150 Massingy'),
(9751,'608 Soubie le Vieux, 26510 Saint-May');

INSERT INTO Organisation (numero,adresse) VALUES
(9752,'623bis Borio de Baille, 67420 Saales'),
(9753,'184 Ham des Sauzeries Basses, 77580 Vaucourtois');

INSERT INTO Organisation (numero,adresse) VALUES
(9754,'991 Lieu Dit Rieuprégon, 60110 Corbeil-Cerf'),
(9755,'108 Piece Longue, 61170 Coulonges-sur-Sarthe');

INSERT INTO Organisation (numero,adresse) VALUES
(9756,'103 Le Moulin Brûle, 54116 Tantonville'),
(9757,'635bis Les Agoustes, 71460 Chissey-lès-Mâcon');

INSERT INTO Organisation (numero,adresse) VALUES
(9758,'966bis Chemin de Saint-vallier, 34120 Pézenas'),
(9759,'311 La Sanguinieres, 39570 Montaigu');

INSERT INTO Organisation (numero,adresse) VALUES
(9760,'505bis Le Chateau du Creux, 34160 Saint-Bauzille-de-Montmel'),
(9761,'671 Logement communal, 71160 Gilly-sur-Loire');

INSERT INTO Organisation (numero,adresse) VALUES
(9762,'376 Moulin de la Barriere, 64410 Séby'),
(9763,'870 Les Florentines, 01250 Ramasse');

INSERT INTO Organisation (numero,adresse) VALUES
(9764,'41bis Lou Fraysse, 50500 Catz'),
(9765,'337 Cussac, 02130 Villers-Agron-Aiguizy');

INSERT INTO Organisation (numero,adresse) VALUES
(9766,'4 La Vallée à Jarre, 12150 Sévérac d''Aveyron'),
(9767,'765 Le Bois Quelin, 63560 Menat');

INSERT INTO Organisation (numero,adresse) VALUES
(9768,'918 Rayret, 41170 Baillou'),
(9769,'559 St Antonin, 72290 Mézières-sur-Ponthouin');

INSERT INTO Organisation (numero,adresse) VALUES
(9770,'247 Ciernat, 16350 Turgon'),
(9771,'714bis Camp de Las Peyros, 30360 Ners');

INSERT INTO Organisation (numero,adresse) VALUES
(9772,'955bis Château Bon, 55160 Harville'),
(9773,'692 Versols, 64240 Bonloc');

INSERT INTO Organisation (numero,adresse) VALUES
(9774,'436 La Petite Graou, 34400 Saint-Nazaire-de-Pézan'),
(9775,'257 Marie Charlotte, 39230 La Charme');

INSERT INTO Organisation (numero,adresse) VALUES
(9776,'927 Collège du Baou, 62730 Marck'),
(9777,'239 """ Les Rois """, 60480 Reuil-sur-Brêche');

INSERT INTO Organisation (numero,adresse) VALUES
(9778,'19 Route de Frans, 11390 Laprade'),
(9779,'632bis Montcel, 20225 Cateri');

INSERT INTO Organisation (numero,adresse) VALUES
(9780,'573bis Les Mecoues, 78700 Conflans-Sainte-Honorine'),
(9781,'252 Chemin du Raouaste, 54700 Blénod-lès-Pont-à-Mousson');

INSERT INTO Organisation (numero,adresse) VALUES
(9782,'958bis Les 3 Horloges, 43250 Sainte-Florine'),
(9783,'252 Puech Montard, 14910 Benerville-sur-Mer');

INSERT INTO Organisation (numero,adresse) VALUES
(9784,'83 Testas, 67860 Rhinau'),
(9785,'815 Res Les Collines De Cagnes, 39370 La Pesse');

INSERT INTO Organisation (numero,adresse) VALUES
(9786,'596 Les Rivieres Anglaises, 67510 Obersteinbach'),
(9787,'257 Villa La Mouette, 36340 Malicornay');

INSERT INTO Organisation (numero,adresse) VALUES
(9788,'574 Les Eaux, 52150 Levécourt'),
(9789,'367bis Plan de Becouze, 30270 Saint-Jean-du-Gard');

INSERT INTO Organisation (numero,adresse) VALUES
(9790,'986 Serre des Eymards, 49610 Les Garennes sur Loire'),
(9791,'85bis Pahy Mahy, 72240 Conlie');

INSERT INTO Organisation (numero,adresse) VALUES
(9792,'267 Rue du Riez Prolongée, 19510 Benayes'),
(9793,'497 la Calquière, 56250 Saint-Nolff');

INSERT INTO Organisation (numero,adresse) VALUES
(9794,'443bis Le Vas, 36160 Sazeray'),
(9795,'861bis Berduc, 22720 Saint-Fiacre');

INSERT INTO Organisation (numero,adresse) VALUES
(9796,'967bis Longue Peyssolle, 41290 Conan'),
(9797,'336 Pierre Creuse, 16230 Juillé');

INSERT INTO Organisation (numero,adresse) VALUES
(9798,'726 Véraz, 54450 Blâmont'),
(9799,'733 Villard les bois, 14260 Bauquay');

INSERT INTO Organisation (numero,adresse) VALUES
(9800,'79bis Les Chadeaux, 24530 Quinsac'),
(9801,'667 Saint-Amans-de-Lizertet, 19230 Beyssac');

INSERT INTO Organisation (numero,adresse) VALUES
(9802,'280 Le Gorp du Pont, 72260 Nauvay'),
(9803,'659 Les Terrisses, 27850 Ménesqueville');

INSERT INTO Organisation (numero,adresse) VALUES
(9804,'247bis Vergnes, 42310 La Pacaudière'),
(9805,'629 Mont-joie, 60220 Formerie');

INSERT INTO Organisation (numero,adresse) VALUES
(9806,'181bis Pain Blanc Ouest, 57420 Liéhon'),
(9807,'348 Le Mas de Vinaigre, 62112 Gouy-sous-Bellonne');

INSERT INTO Organisation (numero,adresse) VALUES
(9808,'678bis Champ-Pointu, 30350 Domessargues'),
(9809,'813 Moulin de Laumet, 38330 Saint-Nazaire-les-Eymes');

INSERT INTO Organisation (numero,adresse) VALUES
(9810,'850 Traverse du Grand Pin, 16130 Ars'),
(9811,'740 Les Petits Gâteliers, 59620 Monceau-Saint-Waast');

INSERT INTO Organisation (numero,adresse) VALUES
(9812,'471 Riou Bas, 33113 Origne'),
(9813,'823bis La Mouriere, 02630 Mennevret');

INSERT INTO Organisation (numero,adresse) VALUES
(9814,'837 Moulin d''Aval, 48270 Prinsuéjols-Malbouzon'),
(9815,'721 Foyer Municipal, 78550 Gressey');

INSERT INTO Organisation (numero,adresse) VALUES
(9816,'480bis Theraube, 57140 Saulny'),
(9817,'368 Festes, 12460 Montézic');

INSERT INTO Organisation (numero,adresse) VALUES
(9818,'458 Le Goya, 03800 Saint-Priest-d''Andelot'),
(9819,'831bis Carrière des Roux, 70200 Saint-Germain');

INSERT INTO Organisation (numero,adresse) VALUES
(9820,'183bis Bestes, 67370 Pfulgriesheim'),
(9821,'669 Le Charpinet, 49140 La Chapelle-Saint-Laud');

INSERT INTO Organisation (numero,adresse) VALUES
(9822,'511 Caprice, 04280 Céreste'),
(9823,'748 Crau de Chauvin, 40120 Sarbazan');

INSERT INTO Organisation (numero,adresse) VALUES
(9824,'695 Le Petit Chavon, 28150 Les Villages Vovéens'),
(9825,'171bis Chemin d''Ullion, 33240 Peujard');

INSERT INTO Organisation (numero,adresse) VALUES
(9826,'359 Les Hostes, 24370 Simeyrols'),
(9827,'301 Chemin des Cistes, 57990 Nousseviller-Saint-Nabor');

INSERT INTO Organisation (numero,adresse) VALUES
(9828,'718 Mouiroues, 35120 Saint-Broladre'),
(9829,'792bis Ladreyt de la Ribeyre, 12620 Castelnau-Pégayrols');

INSERT INTO Organisation (numero,adresse) VALUES
(9830,'738 Lotissement le Bel horizon, 68210 Ballersdorf'),
(9831,'806bis Le Queyrelin, 30150 Roquemaure');

INSERT INTO Organisation (numero,adresse) VALUES
(9832,'16 la Cruyatte, 32290 Loussous-Débat'),
(9833,'399 Ruelle du Treillard, 63820 Saint-Julien-Puy-Lavèze');

INSERT INTO Organisation (numero,adresse) VALUES
(9834,'370 Petite Nantille, 39260 Moirans-en-Montagne'),
(9835,'693 Les Savoyes, 35290 Gaël');

INSERT INTO Organisation (numero,adresse) VALUES
(9836,'668bis Prat-Long, 53390 Saint-Erblon'),
(9837,'991 Pescayret, 02200 Saconin-et-Breuil');

INSERT INTO Organisation (numero,adresse) VALUES
(9838,'846bis La Petite Jarry, 44740 Batz-sur-Mer'),
(9839,'607bis Gibalaux le Haut, 06530 Cabris');

INSERT INTO Organisation (numero,adresse) VALUES
(9840,'470 Hameau des Ecureuils, 62360 Hesdin-l''Abbé'),
(9841,'940 Le Colombier, 24360 Busserolles');

INSERT INTO Organisation (numero,adresse) VALUES
(9842,'867bis L’Esclavissac, 17210 Bran'),
(9843,'192bis Le Logis, 62760 Orville');

INSERT INTO Organisation (numero,adresse) VALUES
(9844,'186 Oasis, 66800 Eyne'),
(9845,'939 Ranc Cristiane, 70400 Villers-sur-Saulnot');

INSERT INTO Organisation (numero,adresse) VALUES
(9846,'957 Combe des Allignols, 50300 Le Val-Saint-Père'),
(9847,'38 Le Courret, 42990 Saint-Georges-en-Couzan');

INSERT INTO Organisation (numero,adresse) VALUES
(9848,'31 Route de la Chartreuse, 27220 Chavigny-Bailleul'),
(9849,'785bis Le Girbon, 19250 Maussac');

INSERT INTO Organisation (numero,adresse) VALUES
(9850,'945 Lafont, 68760 Willer-sur-Thur'),
(9851,'622 Hlm Ave St Jean, 65500 Villenave-près-Marsac');

INSERT INTO Organisation (numero,adresse) VALUES
(9852,'144 Quartier le Point Nodal, 29460 Hanvec'),
(9853,'483bis Les Jujubiers / Villa La Bastide, 62760 Halloy');

INSERT INTO Organisation (numero,adresse) VALUES
(9854,'677 Hlm les Chartreux Bat F2, 32720 Barcelonne-du-Gers'),
(9855,'860 Les Baraques Perier, 78810 Davron');

INSERT INTO Organisation (numero,adresse) VALUES
(9856,'771 Chemin du cimetière de Saint-Martin, 63470 Herment'),
(9857,'103 Les Campillous, 31220 Sana');

INSERT INTO Organisation (numero,adresse) VALUES
(9858,'493bis Le Grand Villers, 67370 Schnersheim'),
(9859,'982 La Coussane, 06910 Cuébris');

INSERT INTO Organisation (numero,adresse) VALUES
(9860,'509 Les Regards, 31420 Peyrouzet'),
(9861,'113 Jardin Jean Gilletta, 16300 Angeduc');

INSERT INTO Organisation (numero,adresse) VALUES
(9862,'174 La Colombe, 25410 Velesmes-Essarts'),
(9863,'777 Les Diezes, 15130 Ytrac');

INSERT INTO Organisation (numero,adresse) VALUES
(9864,'251 Chemin de la Papière, 67150 Limersheim'),
(9865,'701bis Le Perdut, 73730 Saint-Paul-sur-Isère');

INSERT INTO Organisation (numero,adresse) VALUES
(9866,'422 Les Tourniès, 33126 La Rivière'),
(9867,'609bis L''Artigue, 34210 La Livinière');

INSERT INTO Organisation (numero,adresse) VALUES
(9868,'202 Le Déversoir, 02000 Chaillevois'),
(9869,'954 Grands Charands, 77760 Recloses');

INSERT INTO Organisation (numero,adresse) VALUES
(9870,'105 Le Bois Fistère, 39700 Rans'),
(9871,'596 Sarabelle, 16480 Châtignac');

INSERT INTO Organisation (numero,adresse) VALUES
(9872,'287 Sinhalaguet, 02110 Fontaine-Uterte'),
(9873,'796 la Pradas, 38440 Royas');

INSERT INTO Organisation (numero,adresse) VALUES
(9874,'669 Ruelle Eleup, 57680 Novéant-sur-Moselle'),
(9875,'550 Chouplat d''En Haut, 15240 Saignes');

INSERT INTO Organisation (numero,adresse) VALUES
(9876,'703 L''Ille, 25680 Tressandans'),
(9877,'776 Champ Branche, 35740 Pacé');

INSERT INTO Organisation (numero,adresse) VALUES
(9878,'918 La Bessierette, 07270 Boucieu-le-Roi'),
(9879,'533 Pré Bas Séverac, 46130 Cahus');

INSERT INTO Organisation (numero,adresse) VALUES
(9880,'254 Moulin Miguet - Hauteville-Lompnes, 65150 Tuzaguet'),
(9881,'476 Le Sucol, 77410 Gressy');

INSERT INTO Organisation (numero,adresse) VALUES
(9882,'193 Le Cussol, 62830 Halinghen'),
(9883,'726bis Place Guyemer, 03110 Saint-Pont');

INSERT INTO Organisation (numero,adresse) VALUES
(9884,'747 Rond-Point  Lieutenant-colonel Jeanpierre, 12620 Castelnau-Pégayrols'),
(9885,'755bis lieu-dit Prédès, 23260 Crocq');

INSERT INTO Organisation (numero,adresse) VALUES
(9886,'852 Résidence L''iléo Bâtiment A, 09200 Saint-Girons'),
(9887,'981 La Villette, 14310 Amayé-sur-Seulles');

INSERT INTO Organisation (numero,adresse) VALUES
(9888,'785bis Notre Dame d’Aures, 51260 Esclavolles-Lurey'),
(9889,'236 Escaliers de la Brèche, 66500 Ria-Sirach');

INSERT INTO Organisation (numero,adresse) VALUES
(9890,'979 Rue de l''Écaille, 55210 Nonsard-Lamarche'),
(9891,'464 Gamarus, 15130 Ytrac');

INSERT INTO Organisation (numero,adresse) VALUES
(9892,'862 Pont Loup, 31110 Cazeaux-de-Larboust'),
(9893,'242bis Malac, 48160 Saint-Martin-de-Boubaux');

INSERT INTO Organisation (numero,adresse) VALUES
(9894,'635bis La Puech de la Penterie, 39700 Orchamps'),
(9895,'436 Ile Olive, 29620 Guimaëc');

INSERT INTO Organisation (numero,adresse) VALUES
(9896,'535 Bois Cordier, 54450 Nonhigny'),
(9897,'516 Les Heures Claires Bat 3, 69420 Ampuis');

INSERT INTO Organisation (numero,adresse) VALUES
(9898,'34 Derriere l''Enclos, 17330 Saint-Martial'),
(9899,'965 SCI la Réunion, 04500 Montagnac-Montpezat');

INSERT INTO Organisation (numero,adresse) VALUES
(9900,'601bis La Fourniere-ouest, 59294 Haussy'),
(9901,'694bis Port Galand, 65240 Germ');

INSERT INTO Organisation (numero,adresse) VALUES
(9902,'789 Escalier Avenue Stephen Liegeard - Chemin Frédéric Mistral, 05110 Curbans'),
(9903,'105 La Piece du Moulin, 69003 Lyon 03');

INSERT INTO Organisation (numero,adresse) VALUES
(9904,'417 Le Monnet, 11800 Villedubert'),
(9905,'325 Moulin Vidot, 24130 Le Fleix');

INSERT INTO Organisation (numero,adresse) VALUES
(9906,'623 Le Vert Logis, 16500 Brillac'),
(9907,'373bis Saint Barnabe, 55700 Beauclair');

INSERT INTO Organisation (numero,adresse) VALUES
(9908,'772bis Chaudebry, 65200 Antist'),
(9909,'743bis Les-terres-des-gaizes, 77165 Le Plessis-l''Évêque');

INSERT INTO Organisation (numero,adresse) VALUES
(9910,'855bis Chemin du San-Peyre, 50420 Moyon Villages'),
(9911,'765 Pré Rond, 65350 Collongues');

INSERT INTO Organisation (numero,adresse) VALUES
(9912,'902 Les Marsals, 16150 Chabanais'),
(9913,'383bis La Breteline, 55800 Couvonges');

INSERT INTO Organisation (numero,adresse) VALUES
(9914,'570bis Princess Riviera, 27400 Heudreville-sur-Eure'),
(9915,'935 Les Cimetières, 26150 Romeyer');

INSERT INTO Organisation (numero,adresse) VALUES
(9916,'206bis Les Cayres, 21200 Vignoles'),
(9917,'659bis Tour Camargue, 25340 Uzelle');

INSERT INTO Organisation (numero,adresse) VALUES
(9918,'636 Le Revaut, 57590 Prévocourt'),
(9919,'903 Le Lausset, 62720 Rety');

INSERT INTO Organisation (numero,adresse) VALUES
(9920,'951 Le Central Plaza Bat B-C-D, 62175 Boisleux-au-Mont'),
(9921,'281 Le Fond Renauld Jacques, 04140 Verdaches');

INSERT INTO Organisation (numero,adresse) VALUES
(9922,'186 Le Mas del Rieu, 20130 Cargèse'),
(9923,'308 Champ de la Vigne, 61130 Origny-le-Roux');

INSERT INTO Organisation (numero,adresse) VALUES
(9924,'528 la Mathiverie, 33710 Samonac'),
(9925,'357bis Gourgueil, 46350 Calès');

INSERT INTO Organisation (numero,adresse) VALUES
(9926,'490 La Trille Vieux, 74360 Abondance'),
(9927,'880 Villa Lou Parpaiouns, 57320 Menskirch');

INSERT INTO Organisation (numero,adresse) VALUES
(9928,'84 Masclat, 64410 Fichous-Riumayou'),
(9929,'252 Les Crouis, 70360 Ferrières-lès-Scey');

INSERT INTO Organisation (numero,adresse) VALUES
(9930,'576 Roubreau, 31290 Lagarde'),
(9931,'91 Le Fossé St-martin, 11300 La Digne-d''Aval');

INSERT INTO Organisation (numero,adresse) VALUES
(9932,'617 Fazendes, 59270 Saint-Jans-Cappel'),
(9933,'923 """ Les Jacquets """, 67340 Rothbach');

INSERT INTO Organisation (numero,adresse) VALUES
(9934,'33 Cervagn, 62830 Verlincthun'),
(9935,'696bis La Vidadie, 69870 Grandris');

INSERT INTO Organisation (numero,adresse) VALUES
(9936,'308 Chambonnet Haut, 10500 Braux'),
(9937,'703 Rue de l''Est, 78250 Meulan-en-Yvelines');

INSERT INTO Organisation (numero,adresse) VALUES
(9938,'99 Mer Et Soleil, 17600 Nancras'),
(9939,'452 Le Village de Terron, 01300 Andert-et-Condon');

INSERT INTO Organisation (numero,adresse) VALUES
(9940,'378 Ciabanetta Est, 32700 Terraube'),
(9941,'550 Villa Casablanca, 60134 Villers-Saint-Sépulcre');

INSERT INTO Organisation (numero,adresse) VALUES
(9942,'370 Lieu-dit Clairefontaine, 51330 Saint-Jean-devant-Possesse'),
(9943,'294bis Quartier Champ Rey, 11300 Villelongue-d''Aude');

INSERT INTO Organisation (numero,adresse) VALUES
(9944,'192 Le Suc, 33750 Baron'),
(9945,'683 Escalier Cyrnos, 49360 Yzernay');

INSERT INTO Organisation (numero,adresse) VALUES
(9946,'444 La Viole, 01430 Condamine'),
(9947,'41bis Cambon-Bas, 31230 Castelgaillard');

INSERT INTO Organisation (numero,adresse) VALUES
(9948,'506 Bassieu, 54770 Dommartin-sous-Amance'),
(9949,'373 Pramejo, 11330 Termes');

INSERT INTO Organisation (numero,adresse) VALUES
(9950,'933 Montargue, 56240 Berné'),
(9951,'186 Le-fond-de-barbasse, 52230 Saudron');

INSERT INTO Organisation (numero,adresse) VALUES
(9952,'23 Les Serieysses, 27130 Piseux'),
(9953,'880 Les Petits Jaillots, 26190 La Motte-Fanjas');

INSERT INTO Organisation (numero,adresse) VALUES
(9954,'482 Res Du Port A3, 04230 Lardiers'),
(9955,'840bis Calade Bernard Boetti, 49320 Brissac Loire Aubance');

INSERT INTO Organisation (numero,adresse) VALUES
(9956,'723 Soula de Louyre, 44830 Brains'),
(9957,'401 Rue du Bel Homme, 33350 Sainte-Terre');

INSERT INTO Organisation (numero,adresse) VALUES
(9958,'641bis Verdillon, 14220 Saint-Omer'),
(9959,'134bis Grand Vallon, 71600 Saint-Yan');

INSERT INTO Organisation (numero,adresse) VALUES
(9960,'418 Tisonèche, 30700 La Capelle-et-Masmolène'),
(9961,'621 Ciernat, 21450 Saint-Marc-sur-Seine');

INSERT INTO Organisation (numero,adresse) VALUES
(9962,'414 Route de la Cave- Le Rougié, 38114 Allemond'),
(9963,'9 Les Saouses, 31540 Maurens');

INSERT INTO Organisation (numero,adresse) VALUES
(9964,'234 Roumanie, 02330 Montlevon'),
(9965,'49 Arpos, 26150 Barsac');

INSERT INTO Organisation (numero,adresse) VALUES
(9966,'207 Les Sauteaux, 14210 Avenay'),
(9967,'695 Bois à la Casaque, 78270 Rolleboise');

INSERT INTO Organisation (numero,adresse) VALUES
(9968,'248bis Baychère, 80130 Béthencourt-sur-Mer'),
(9969,'642 La Côte Pelouze, 67170 Geudertheim');

INSERT INTO Organisation (numero,adresse) VALUES
(9970,'0 Avenue des Prahines, 21360 Lusigny-sur-Ouche'),
(9971,'117 Les Triots de l''Etang, 80200 Flaucourt');

INSERT INTO Organisation (numero,adresse) VALUES
(9972,'41 Maison de santé, 03500 Montord'),
(9973,'374 Rayons D''Or, 80150 Agenvillers');

INSERT INTO Organisation (numero,adresse) VALUES
(9974,'598 Coumegnau de Haut, 55170 Lavincourt'),
(9975,'912bis Le Causse de Nissac, 20128 Grosseto-Prugna');

INSERT INTO Organisation (numero,adresse) VALUES
(9976,'874bis Cagnes Provencal C, 46160 Larnagol'),
(9977,'89 Pont de Mels, 76590 Torcy-le-Grand');

INSERT INTO Organisation (numero,adresse) VALUES
(9978,'415 Beauménil Bas, 31160 Razecueillé'),
(9979,'372bis La Redoute, 80370 Saint-Acheul');

INSERT INTO Organisation (numero,adresse) VALUES
(9980,'936bis Le Cialencier, 32140 Arrouède'),
(9981,'839bis Chaudebry, 02310 Pavant');

INSERT INTO Organisation (numero,adresse) VALUES
(9982,'343 Parking de Drouille, 47380 Pinel-Hauterive'),
(9983,'158 En Chamontan, 35150 Amanlis');

INSERT INTO Organisation (numero,adresse) VALUES
(9984,'752 Square Marius Otto, 23260 Saint-Oradoux-près-Crocq'),
(9985,'743bis Le Gard du Croly, 67700 Otterswiller');

INSERT INTO Organisation (numero,adresse) VALUES
(9986,'235 La Buscaliere, 57660 Lelling'),
(9987,'853 La Forge, 33210 Fargues');

INSERT INTO Organisation (numero,adresse) VALUES
(9988,'966 Raccourci Avenue Gravier, 60330 Silly-le-Long'),
(9989,'549 La Butte des Gaulmes, 33190 Saint-Exupéry');

INSERT INTO Organisation (numero,adresse) VALUES
(9990,'689 Le Chambon, 56320 Le Faouët'),
(9991,'756 Passage des Oudaias, 64160 Higuères-Souye');

INSERT INTO Organisation (numero,adresse) VALUES
(9992,'289 Les Couteliers, 27230 Folleville'),
(9993,'31 Les Pres du Mareau, 19330 Chanteix');

INSERT INTO Organisation (numero,adresse) VALUES
(9994,'453 Les Clos de Chavailles, 76710 Anceaumeville'),
(9995,'817 Le Mercadel, 50810 La Barre-de-Semilly');

INSERT INTO Organisation (numero,adresse) VALUES
(9996,'204 Au Dessus de la Vieille VI, 58420 Saint-Révérien'),
(9997,'16bis Cap De Sour, 39140 Larnaud');

INSERT INTO Organisation (numero,adresse) VALUES
(9998,'677bis Voie liaison Chemin de la Rosa Bianca - Avenue de Brancolar, 57980 Tenteling'),
(9999,'664 Foret du Mont Boron, 76290 Montivilliers');

