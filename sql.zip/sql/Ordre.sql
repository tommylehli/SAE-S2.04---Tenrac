INSERT INTO Ordre (numero,nomOrdre) VALUES
(0,'Les Gourmets Gratiné'),
(1,'Les Croqueurs du Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(2,'Les Amateurs du Doré'),
(3,'Les Tenders du Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(4,'Le Cercle des Poulet Gourmand'),
(5,'La Brigade du Dévoreurs Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(6,'Les Tenders du Ultime'),
(7,'Les Fromage Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(8,'Les Chevaliers Doré'),
(9,'Le Cercle des Croqueurs Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(10,'Les Poulet du Crémeux'),
(11,'La Confrérie du Croqueurs Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(12,'La Confrérie du Poulet Légendaire'),
(13,'Les Amateurs Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(14,'La Brigade du Dévoreurs Ultime'),
(15,'Le Cercle des Croqueurs Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(16,'Les Fans du Gourmand'),
(17,'La Brigade du Poulet Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(18,'La Brigade du Fromage Doré'),
(19,'La Brigade du Croqueurs Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(20,'La Brigade du Croqueurs Fondant'),
(21,'Les Tenders du Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(22,'Le Cercle des Fans Gratiné'),
(23,'Les Fans Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(24,'La Confrérie du Fans Savoureux'),
(25,'Les Dévoreurs du Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(26,'La Confrérie du Poulet Ultime'),
(27,'La Confrérie du Croqueurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(28,'Les Fromage du Suprême'),
(29,'Le Cercle des Chevaliers Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(30,'La Brigade du Fans Légendaire'),
(31,'La Confrérie du Chevaliers Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(32,'La Brigade du Fromage Doré'),
(33,'Le Cercle des Dévoreurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(34,'Le Cercle des Tenders Doré'),
(35,'Le Cercle des Fromage Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(36,'La Brigade du Gourmets Royal'),
(37,'Les Tenders Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(38,'Les Dévoreurs du Gourmand'),
(39,'Les Amateurs Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(40,'La Confrérie du Gourmets Fondant'),
(41,'Les Frères du Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(42,'Les Amateurs Ultime'),
(43,'Le Cercle des Dévoreurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(44,'La Brigade du Poulet Suprême'),
(45,'Le Cercle des Gourmets Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(46,'Les Fans Crémeux'),
(47,'Le Cercle des Chevaliers Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(48,'Les Chevaliers Savoureux'),
(49,'Le Cercle des Dévoreurs Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(50,'La Brigade du Poulet Suprême'),
(51,'Les Gourmets Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(52,'La Brigade du Tenders Royal'),
(53,'La Confrérie du Tenders Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(54,'Les Amateurs Légendaire'),
(55,'Les Croqueurs du Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(56,'La Brigade du Dévoreurs Légendaire'),
(57,'Les Chevaliers du Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(58,'La Brigade du Dévoreurs Ultime'),
(59,'La Confrérie du Fans Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(60,'La Confrérie du Croqueurs Gratiné'),
(61,'Les Amateurs du Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(62,'La Confrérie du Croqueurs Gratiné'),
(63,'La Brigade du Tenders Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(64,'La Brigade du Tenders Crémeux'),
(65,'La Brigade du Fromage Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(66,'Les Poulet du Royal'),
(67,'La Confrérie du Dévoreurs Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(68,'La Brigade du Dévoreurs Croustillant'),
(69,'La Confrérie du Fans Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(70,'Le Cercle des Croqueurs Royal'),
(71,'Les Fromage Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(72,'Le Cercle des Croqueurs Royal'),
(73,'Les Amateurs Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(74,'Les Frères Gourmand'),
(75,'La Confrérie du Tenders Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(76,'La Brigade du Croqueurs Fondant'),
(77,'La Brigade du Gourmets Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(78,'Les Fromage du Suprême'),
(79,'Le Cercle des Gourmets Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(80,'Les Tenders Gratiné'),
(81,'Les Poulet du Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(82,'Les Gourmets du Croustillant'),
(83,'La Brigade du Dévoreurs Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(84,'Les Fans du Gourmand'),
(85,'La Brigade du Croqueurs Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(86,'Les Croqueurs Légendaire'),
(87,'La Confrérie du Amateurs Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(88,'La Brigade du Dévoreurs Ultime'),
(89,'Le Cercle des Chevaliers Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(90,'La Brigade du Fans Légendaire'),
(91,'Les Frères Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(92,'La Brigade du Chevaliers Gratiné'),
(93,'La Brigade du Chevaliers Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(94,'La Confrérie du Croqueurs Suprême'),
(95,'Le Cercle des Fans Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(96,'Les Fans Royal'),
(97,'La Brigade du Frères Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(98,'La Confrérie du Fans Savoureux'),
(99,'Les Fans du Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(100,'Les Chevaliers Doré'),
(101,'Les Fans du Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(102,'Les Chevaliers du Crémeux'),
(103,'La Confrérie du Chevaliers Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(104,'Les Frères du Suprême'),
(105,'La Brigade du Chevaliers Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(106,'Les Amateurs du Doré'),
(107,'Les Poulet Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(108,'Les Amateurs Légendaire'),
(109,'Les Amateurs du Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(110,'La Brigade du Dévoreurs Ultime'),
(111,'La Confrérie du Amateurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(112,'Les Amateurs Ultime'),
(113,'Le Cercle des Amateurs Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(114,'Le Cercle des Poulet Gourmand'),
(115,'La Confrérie du Dévoreurs Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(116,'Les Poulet Savoureux'),
(117,'La Brigade du Fromage Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(118,'Les Amateurs Légendaire'),
(119,'Les Fans du Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(120,'La Confrérie du Fromage Royal'),
(121,'La Brigade du Frères Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(122,'La Brigade du Poulet Gratiné'),
(123,'Les Fans du Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(124,'La Brigade du Dévoreurs Légendaire'),
(125,'Les Chevaliers du Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(126,'La Confrérie du Chevaliers Croustillant'),
(127,'La Confrérie du Fans Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(128,'Les Fans du Gourmand'),
(129,'La Brigade du Chevaliers Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(130,'Les Fans Royal'),
(131,'Les Frères du Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(132,'La Brigade du Fans Ultime'),
(133,'La Confrérie du Croqueurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(134,'Les Tenders du Légendaire'),
(135,'La Confrérie du Poulet Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(136,'Les Fromage Fondant'),
(137,'Le Cercle des Poulet Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(138,'La Confrérie du Frères Crémeux'),
(139,'Les Fans Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(140,'Le Cercle des Amateurs Crémeux'),
(141,'La Brigade du Tenders Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(142,'Le Cercle des Croqueurs Crémeux'),
(143,'La Confrérie du Poulet Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(144,'La Brigade du Dévoreurs Croustillant'),
(145,'Les Amateurs du Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(146,'La Confrérie du Gourmets Fondant'),
(147,'La Brigade du Poulet Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(148,'Les Fans Royal'),
(149,'La Brigade du Croqueurs Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(150,'La Brigade du Fans Légendaire'),
(151,'Les Dévoreurs Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(152,'Les Chevaliers Doré'),
(153,'Les Gourmets du Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(154,'Les Croqueurs Croustillant'),
(155,'Le Cercle des Fans Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(156,'Le Cercle des Chevaliers Gourmand'),
(157,'Les Amateurs Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(158,'Les Croqueurs Ultime'),
(159,'La Brigade du Fans Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(160,'Le Cercle des Fromage Croustillant'),
(161,'Le Cercle des Croqueurs Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(162,'La Confrérie du Tenders Gourmand'),
(163,'Le Cercle des Frères Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(164,'Le Cercle des Dévoreurs Gratiné'),
(165,'Les Croqueurs du Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(166,'Les Amateurs du Savoureux'),
(167,'Les Fans du Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(168,'La Confrérie du Croqueurs Suprême'),
(169,'Les Fans du Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(170,'Le Cercle des Tenders Savoureux'),
(171,'Les Poulet Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(172,'La Confrérie du Chevaliers Croustillant'),
(173,'La Confrérie du Chevaliers Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(174,'La Brigade du Fans Croustillant'),
(175,'Le Cercle des Dévoreurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(176,'Le Cercle des Frères Ultime'),
(177,'Les Fans du Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(178,'Le Cercle des Frères Ultime'),
(179,'La Brigade du Chevaliers Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(180,'La Confrérie du Gourmets Gourmand'),
(181,'Les Gourmets du Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(182,'La Brigade du Croqueurs Fondant'),
(183,'La Confrérie du Dévoreurs Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(184,'Les Frères du Gratiné'),
(185,'Les Dévoreurs du Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(186,'Les Fromage Fondant'),
(187,'La Brigade du Fans Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(188,'Les Gourmets du Ultime'),
(189,'La Confrérie du Gourmets Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(190,'La Brigade du Croqueurs Fondant'),
(191,'La Brigade du Fans Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(192,'La Confrérie du Poulet Légendaire'),
(193,'La Confrérie du Gourmets Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(194,'Les Tenders du Ultime'),
(195,'La Brigade du Tenders Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(196,'Les Fromage du Gratiné'),
(197,'La Confrérie du Chevaliers Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(198,'Les Chevaliers Doré'),
(199,'La Confrérie du Tenders Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(200,'Le Cercle des Tenders Doré'),
(201,'Les Frères du Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(202,'La Brigade du Dévoreurs Ultime'),
(203,'Le Cercle des Frères Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(204,'La Brigade du Chevaliers Gratiné'),
(205,'Les Frères Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(206,'Le Cercle des Chevaliers Gourmand'),
(207,'La Brigade du Gourmets Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(208,'Les Dévoreurs Crémeux'),
(209,'Le Cercle des Frères Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(210,'La Brigade du Poulet Gratiné'),
(211,'Le Cercle des Fans Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(212,'Les Croqueurs Ultime'),
(213,'La Brigade du Chevaliers Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(214,'Les Croqueurs Croustillant'),
(215,'Le Cercle des Amateurs Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(216,'Le Cercle des Tenders Doré'),
(217,'La Confrérie du Chevaliers Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(218,'Le Cercle des Gourmets Savoureux'),
(219,'Les Fromage Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(220,'La Confrérie du Dévoreurs Savoureux'),
(221,'Le Cercle des Tenders Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(222,'La Brigade du Amateurs Gourmand'),
(223,'Le Cercle des Tenders Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(224,'Les Tenders Suprême'),
(225,'Les Fromage Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(226,'Le Cercle des Amateurs Royal'),
(227,'Les Fans Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(228,'Le Cercle des Tenders Doré'),
(229,'Les Dévoreurs Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(230,'La Confrérie du Poulet Ultime'),
(231,'La Confrérie du Croqueurs Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(232,'Les Chevaliers Doré'),
(233,'Les Fromage du Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(234,'La Confrérie du Croqueurs Suprême'),
(235,'Les Amateurs Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(236,'La Confrérie du Amateurs Gratiné'),
(237,'La Brigade du Croqueurs Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(238,'Les Chevaliers du Crémeux'),
(239,'La Brigade du Poulet Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(240,'La Brigade du Frères Savoureux'),
(241,'La Confrérie du Poulet Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(242,'La Brigade du Fromage Savoureux'),
(243,'La Brigade du Dévoreurs Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(244,'Les Croqueurs du Doré'),
(245,'La Brigade du Poulet Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(246,'Les Croqueurs Ultime'),
(247,'Le Cercle des Frères Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(248,'Les Frères Gourmand'),
(249,'Les Chevaliers du Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(250,'Les Dévoreurs Crémeux'),
(251,'Les Tenders du Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(252,'Les Amateurs du Doré'),
(253,'Les Tenders du Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(254,'La Confrérie du Croqueurs Suprême'),
(255,'Les Fromage Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(256,'Les Gourmets du Ultime'),
(257,'Le Cercle des Frères Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(258,'La Confrérie du Croqueurs Suprême'),
(259,'Le Cercle des Fans Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(260,'Les Chevaliers du Crémeux'),
(261,'La Confrérie du Frères Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(262,'La Brigade du Croqueurs Gourmand'),
(263,'La Confrérie du Gourmets Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(264,'Les Gourmets Suprême'),
(265,'Le Cercle des Frères Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(266,'Les Croqueurs du Doré'),
(267,'Les Amateurs Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(268,'La Confrérie du Croqueurs Suprême'),
(269,'La Brigade du Chevaliers Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(270,'Le Cercle des Chevaliers Gourmand'),
(271,'Les Tenders Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(272,'Le Cercle des Croqueurs Crémeux'),
(273,'Le Cercle des Fromage Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(274,'La Brigade du Gourmets Royal'),
(275,'Les Gourmets du Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(276,'Le Cercle des Gourmets Savoureux'),
(277,'La Brigade du Dévoreurs Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(278,'La Confrérie du Poulet Croustillant'),
(279,'Le Cercle des Frères Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(280,'Le Cercle des Chevaliers Gourmand'),
(281,'Le Cercle des Gourmets Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(282,'La Confrérie du Poulet Ultime'),
(283,'Les Croqueurs du Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(284,'Les Tenders Gratiné'),
(285,'La Confrérie du Fans Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(286,'La Brigade du Poulet Suprême'),
(287,'La Confrérie du Fans Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(288,'La Confrérie du Fromage Crémeux'),
(289,'Les Frères du Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(290,'Les Tenders du Ultime'),
(291,'La Confrérie du Fromage Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(292,'La Brigade du Fromage Savoureux'),
(293,'Les Croqueurs Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(294,'Les Tenders Gratiné'),
(295,'La Confrérie du Croqueurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(296,'La Confrérie du Fromage Royal'),
(297,'Les Chevaliers Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(298,'Les Tenders du Légendaire'),
(299,'Les Chevaliers du Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(300,'La Brigade du Amateurs Fondant'),
(301,'Le Cercle des Dévoreurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(302,'Les Chevaliers du Crémeux'),
(303,'Le Cercle des Chevaliers Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(304,'Les Gourmets du Ultime'),
(305,'La Confrérie du Croqueurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(306,'Les Fromage Fondant'),
(307,'La Brigade du Dévoreurs Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(308,'La Confrérie du Poulet Ultime'),
(309,'Les Gourmets Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(310,'La Brigade du Gourmets Royal'),
(311,'La Confrérie du Gourmets Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(312,'La Brigade du Fromage Doré'),
(313,'Les Croqueurs du Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(314,'La Confrérie du Dévoreurs Doré'),
(315,'Les Tenders du Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(316,'La Confrérie du Poulet Ultime'),
(317,'La Confrérie du Croqueurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(318,'La Confrérie du Tenders Gourmand'),
(319,'La Confrérie du Fromage Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(320,'La Confrérie du Dévoreurs Doré'),
(321,'Les Amateurs Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(322,'Les Dévoreurs Crémeux'),
(323,'Le Cercle des Gourmets Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(324,'La Confrérie du Chevaliers Ultime'),
(325,'Le Cercle des Tenders Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(326,'Le Cercle des Frères Croustillant'),
(327,'La Brigade du Chevaliers Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(328,'Les Frères du Gratiné'),
(329,'La Confrérie du Tenders Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(330,'Le Cercle des Gourmets Savoureux'),
(331,'Le Cercle des Frères Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(332,'Le Cercle des Chevaliers Fondant'),
(333,'Les Croqueurs Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(334,'Les Poulet Savoureux'),
(335,'La Confrérie du Amateurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(336,'La Confrérie du Fans Doré'),
(337,'Les Amateurs du Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(338,'La Confrérie du Poulet Croustillant'),
(339,'Le Cercle des Fromage Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(340,'Le Cercle des Gourmets Savoureux'),
(341,'La Brigade du Chevaliers Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(342,'La Brigade du Dévoreurs Légendaire'),
(343,'La Confrérie du Dévoreurs Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(344,'Les Poulet du Crémeux'),
(345,'La Brigade du Croqueurs Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(346,'Les Croqueurs du Doré'),
(347,'Le Cercle des Amateurs Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(348,'Le Cercle des Chevaliers Gourmand'),
(349,'Le Cercle des Gourmets Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(350,'Les Fromage Gourmand'),
(351,'La Confrérie du Tenders Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(352,'Les Poulet Doré'),
(353,'La Brigade du Tenders Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(354,'Le Cercle des Fans Suprême'),
(355,'La Confrérie du Poulet Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(356,'Les Amateurs Ultime'),
(357,'La Confrérie du Fromage Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(358,'La Brigade du Gourmets Royal'),
(359,'Les Croqueurs Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(360,'Le Cercle des Gourmets Doré'),
(361,'Les Poulet Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(362,'Les Chevaliers du Royal'),
(363,'Les Croqueurs Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(364,'Le Cercle des Tenders Doré'),
(365,'Les Tenders du Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(366,'Les Fromage du Suprême'),
(367,'Les Dévoreurs du Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(368,'La Confrérie du Dévoreurs Savoureux'),
(369,'Les Fromage Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(370,'La Brigade du Fans Croustillant'),
(371,'La Confrérie du Frères Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(372,'La Confrérie du Chevaliers Légendaire'),
(373,'Les Croqueurs Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(374,'Le Cercle des Gourmets Doré'),
(375,'La Brigade du Fans Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(376,'Les Croqueurs Légendaire'),
(377,'Le Cercle des Chevaliers Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(378,'La Confrérie du Chevaliers Ultime'),
(379,'La Confrérie du Gourmets Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(380,'Le Cercle des Fans Gratiné'),
(381,'La Brigade du Dévoreurs Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(382,'La Confrérie du Chevaliers Croustillant'),
(383,'La Confrérie du Tenders Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(384,'La Brigade du Fans Légendaire'),
(385,'Le Cercle des Frères Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(386,'Les Chevaliers du Royal'),
(387,'La Confrérie du Tenders Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(388,'La Brigade du Frères Savoureux'),
(389,'La Confrérie du Fromage Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(390,'Les Fromage du Gratiné'),
(391,'Les Dévoreurs Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(392,'La Confrérie du Poulet Croustillant'),
(393,'Les Fans du Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(394,'Les Amateurs Croustillant'),
(395,'La Confrérie du Chevaliers Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(396,'La Confrérie du Tenders Gourmand'),
(397,'La Confrérie du Amateurs Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(398,'La Confrérie du Tenders Gourmand'),
(399,'La Confrérie du Chevaliers Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(400,'La Brigade du Dévoreurs Ultime'),
(401,'Les Gourmets du Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(402,'Les Dévoreurs Crémeux'),
(403,'Le Cercle des Dévoreurs Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(404,'La Confrérie du Chevaliers Croustillant'),
(405,'Le Cercle des Frères Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(406,'Le Cercle des Frères Légendaire'),
(407,'Les Dévoreurs Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(408,'Les Amateurs Légendaire'),
(409,'Les Dévoreurs Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(410,'Le Cercle des Tenders Doré'),
(411,'Le Cercle des Croqueurs Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(412,'Le Cercle des Chevaliers Fondant'),
(413,'Les Fromage Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(414,'Les Amateurs Croustillant'),
(415,'La Brigade du Fans Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(416,'La Brigade du Fans Légendaire'),
(417,'Le Cercle des Croqueurs Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(418,'Les Frères Gourmand'),
(419,'Le Cercle des Frères Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(420,'Le Cercle des Croqueurs Royal'),
(421,'Le Cercle des Tenders Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(422,'Les Gourmets Suprême'),
(423,'La Brigade du Amateurs Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(424,'Les Croqueurs du Savoureux'),
(425,'Le Cercle des Croqueurs Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(426,'Les Tenders du Croustillant'),
(427,'La Confrérie du Poulet Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(428,'Les Gourmets du Légendaire'),
(429,'Les Dévoreurs du Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(430,'La Brigade du Tenders Crémeux'),
(431,'La Brigade du Frères Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(432,'La Brigade du Tenders Royal'),
(433,'Les Chevaliers du Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(434,'La Confrérie du Gourmets Gourmand'),
(435,'Les Amateurs Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(436,'Les Fromage Fondant'),
(437,'Les Fromage du Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(438,'Le Cercle des Fans Suprême'),
(439,'Les Dévoreurs du Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(440,'Les Amateurs Ultime'),
(441,'La Brigade du Poulet Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(442,'Les Fans Crémeux'),
(443,'La Brigade du Gourmets Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(444,'La Confrérie du Gourmets Gourmand'),
(445,'La Confrérie du Gourmets Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(446,'La Confrérie du Chevaliers Ultime'),
(447,'La Confrérie du Poulet Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(448,'La Confrérie du Frères Royal'),
(449,'Les Gourmets du Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(450,'La Confrérie du Dévoreurs Savoureux'),
(451,'Les Gourmets du Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(452,'La Brigade du Chevaliers Suprême'),
(453,'La Brigade du Fromage Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(454,'La Confrérie du Fans Doré'),
(455,'Les Chevaliers du Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(456,'La Brigade du Fans Légendaire'),
(457,'La Confrérie du Gourmets Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(458,'La Confrérie du Dévoreurs Savoureux'),
(459,'Le Cercle des Dévoreurs Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(460,'La Brigade du Poulet Suprême'),
(461,'Les Amateurs Légendaire');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(462,'La Confrérie du Poulet Croustillant'),
(463,'Les Frères Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(464,'La Confrérie du Chevaliers Ultime'),
(465,'La Confrérie du Amateurs Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(466,'Les Tenders Suprême'),
(467,'La Brigade du Fans Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(468,'La Confrérie du Fans Doré'),
(469,'La Confrérie du Chevaliers Croustillant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(470,'La Confrérie du Chevaliers Légendaire'),
(471,'Les Dévoreurs Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(472,'Le Cercle des Chevaliers Fondant'),
(473,'La Confrérie du Poulet Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(474,'La Confrérie du Gourmets Fondant'),
(475,'La Brigade du Tenders Crémeux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(476,'Les Fans du Gourmand'),
(477,'La Confrérie du Croqueurs Suprême');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(478,'Le Cercle des Poulet Gourmand'),
(479,'Le Cercle des Tenders Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(480,'Le Cercle des Chevaliers Fondant'),
(481,'La Brigade du Frères Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(482,'Les Amateurs du Doré'),
(483,'Les Dévoreurs Royal');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(484,'La Brigade du Chevaliers Suprême'),
(485,'La Brigade du Fromage Savoureux');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(486,'La Confrérie du Fans Doré'),
(487,'Le Cercle des Tenders Doré');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(488,'La Brigade du Fromage Savoureux'),
(489,'La Confrérie du Tenders Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(490,'La Brigade du Tenders Royal'),
(491,'La Brigade du Fans Ultime');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(492,'La Confrérie du Poulet Ultime'),
(493,'Les Dévoreurs du Fondant');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(494,'Les Dévoreurs Royal'),
(495,'Le Cercle des Chevaliers Gourmand');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(496,'La Brigade du Tenders Royal'),
(497,'La Brigade du Poulet Gratiné');

INSERT INTO Ordre (numero,nomOrdre) VALUES
(498,'Les Tenders du Légendaire'),
(499,'Le Cercle des Frères Ultime');

