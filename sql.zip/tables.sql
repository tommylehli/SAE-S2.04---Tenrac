-- Partie Jaune

PROMPT "Création des tables de la partie jaune du MCD"

DROP TABLE IF EXISTS Organisme CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Rang CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Titre CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Dignite CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Grade CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Organisation CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Ordre CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Club CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Tenrac CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS GradeSuperieur CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Groupe CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Partenaire CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Date_ CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Repas CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Plat CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Aliment CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Legume CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Sauce CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Ingredient CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Intolerance CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Allergie CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Croyance CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Conviction CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Modele CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Machine CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Type_ CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Entretient CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS DateDeb CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Certificat CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Rejoint CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Deguste CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Compose CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Accompagne CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Forme CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Elabore CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Constitue CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Provoque CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS UtilisationOfficielle CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Possede CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Correspond CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Definit CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Repare CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Enregistre1 CASCADE CONSTRAINTS PURGE;
DROP TABLE IF EXISTS Enregistre2 CASCADE CONSTRAINTS PURGE;
DROP TRIGGER IF EXISTS trg_insert_gradesup;
DROP TRIGGER IF EXISTS trg_insert_utilisationofficielle;
DROP TRIGGER IF EXISTS trg_insert_certif;

CREATE TABLE Organisme(
   refOrganisme NUMBER(10, 0),
   nomOrganisme VARCHAR2(50) NOT NULL,
   typeOrganisme VARCHAR2(50) NOT NULL,
   raisonSociale VARCHAR2(50) NOT NULL,
   numeroSIRET VARCHAR2(14),
    CONSTRAINT ck_numeroSiret
    CHECK (LENGTH(numeroSIRET) = 14),
   PRIMARY KEY(refOrganisme)
);

CREATE TABLE Rang(
   rang VARCHAR2(50) CHECK (rang IN ('Novice', 'Compagnon')),
   PRIMARY KEY(rang)
);

CREATE TABLE Titre(
   titre VARCHAR2(50) CHECK (titre IN ('Philanthrope', 'Protecteur', 'Honorable')),
   PRIMARY KEY(titre)
);

CREATE TABLE Dignite(
   dignite VARCHAR2(50) CHECK (dignite IN ('Maitre', 'Grand Chancelier', 'Grand Maitre')),
   PRIMARY KEY(dignite)
);

CREATE TABLE Grade(
   nomGrade VARCHAR2(50) CHECK (nomGrade IN ('Affilie', 'Sympathisant', 'Adherent','Chevalier', 'Dame', 'Grand Chevalier', 'Haute Dame', 'Commandeur', 'Grand''Croix')),
   PRIMARY KEY(nomGrade)
);

CREATE TABLE Organisation(
   numero NUMBER(10, 0),
   adresse VARCHAR2(200) NOT NULL,
   PRIMARY KEY(numero)
);

CREATE TABLE Ordre(
   numero NUMBER(10, 0),
   nomOrdre VARCHAR2(50) NOT NULL,
   PRIMARY KEY(numero),
   FOREIGN KEY(numero) REFERENCES Organisation(numero)
);

CREATE TABLE Club(
   numero NUMBER(10, 0),
   nomClub VARCHAR2(50) NOT NULL,
   numeroOrdre NUMBER(5, 0),
   PRIMARY KEY(numero),
   FOREIGN KEY(numero) REFERENCES Organisation(numero),
   FOREIGN KEY(numeroOrdre) REFERENCES Ordre(numero)
);

CREATE TABLE Tenrac(
   numero NUMBER(20, 0),
   refOrganisme NUMBER(10, 0),
   codeMembre NUMBER(10, 0),
   nom VARCHAR2(50) NOT NULL,
   prenom VARCHAR2(50) NOT NULL,
   courriel VARCHAR2(50) NOT NULL,
   numeroTel VARCHAR2(14) NOT NULL,
    CONSTRAINT ck_tenrac_tel
    CHECK (REGEXP_LIKE(numeroTel, '[0-9][0-9]-[0-9][0-9]-[0-9][0-9]-[0-9][0-9]-[0-9][0-9]')),
   adressePostale VARCHAR2(100) NOT NULL,
   nomGrade VARCHAR2(50) NOT NULL,
   dignite VARCHAR2(50),
   titre VARCHAR2(50),
   rang VARCHAR2(50),
   PRIMARY KEY(numero, refOrganisme, codeMembre),
   FOREIGN KEY(numero) REFERENCES Organisation(numero),
   FOREIGN KEY(refOrganisme) REFERENCES Organisme(refOrganisme),
   FOREIGN KEY(nomGrade) REFERENCES Grade(nomGrade),
   FOREIGN KEY(dignite) REFERENCES Dignite(dignite),
   FOREIGN KEY(titre) REFERENCES Titre(titre),
   FOREIGN KEY(rang) REFERENCES Rang(rang)
);

CREATE TABLE GradeSuperieur(
   numero NUMBER(20, 0),
   refOrganisme NUMBER(5, 0),
   codeMembre NUMBER(5, 0),
   PRIMARY KEY(numero, refOrganisme, codeMembre),
   FOREIGN KEY(numero, refOrganisme, codeMembre) REFERENCES Tenrac(numero, refOrganisme, codeMembre)
);

-- Partie Verte

PROMPT "Création des tables de la partie verte du MCD"

CREATE TABLE Groupe(
   idGroupe NUMBER(10, 0),
   numero NUMBER(10, 0) NOT NULL,
   refOrganisme NUMBER(10, 0) NOT NULL,
   codeMembre NUMBER(10, 0) NOT NULL,
   PRIMARY KEY(idGroupe),
   FOREIGN KEY(numero, refOrganisme, codeMembre) REFERENCES GradeSuperieur(numero, refOrganisme, codeMembre)
);

CREATE TABLE Partenaire(
   adresse VARCHAR2(150),
   numero NUMBER(10, 0) NOT NULL,
   PRIMARY KEY(adresse),
   FOREIGN KEY(numero) REFERENCES Ordre(numero)
);

CREATE TABLE Date_(
   date_ DATE, 
   PRIMARY KEY(date_)
);

 CREATE TABLE Repas(
   idRepas NUMBER(10, 0),
   nomRepas VARCHAR2(100) NOT NULL,
   PRIMARY KEY(idRepas)
);

-- Partie Orange

PROMPT "Création des tables de la partie orange du MCD"

CREATE TABLE Plat(
   idPlat NUMBER(10, 0),
   nomPlat VARCHAR2(100) NOT NULL,
   PRIMARY KEY(idPlat)
);

CREATE TABLE Aliment(
   nomAliment VARCHAR2(75),
   PRIMARY KEY(nomAliment)
);

CREATE TABLE Legume(
   nomAliment VARCHAR2(75),
   PRIMARY KEY(nomAliment),
   FOREIGN KEY(nomAliment) REFERENCES Aliment(nomAliment)
);

CREATE TABLE Sauce(
   idSauce NUMBER(10, 0),
   nomSauce VARCHAR2(50) NOT NULL,
   PRIMARY KEY(idSauce)
);

CREATE TABLE Ingredient(
   idIngredient NUMBER(10, 0),
   nomIngredient VARCHAR2(50) NOT NULL,
   PRIMARY KEY(idIngredient)
);

CREATE TABLE Intolerance(
   idIntolerance NUMBER(10, 0),
   PRIMARY KEY(idIntolerance)
);

CREATE TABLE Allergie(
   idIntolerance NUMBER(10, 0),
   nomAllergie VARCHAR2(50) NOT NULL,
   PRIMARY KEY(idIntolerance),
   FOREIGN KEY(idIntolerance) REFERENCES Intolerance(idIntolerance)
);

CREATE TABLE Croyance(
   idIntolerance NUMBER(10, 0),
   nomCroyance VARCHAR2(50) NOT NULL,
   PRIMARY KEY(idIntolerance),
   FOREIGN KEY(idIntolerance) REFERENCES Intolerance(idIntolerance)
);

CREATE TABLE Conviction(
   idIntolerance NUMBER(10, 0),
   nomConviction VARCHAR2(100) NOT NULL,
   PRIMARY KEY(idIntolerance),
   FOREIGN KEY(idIntolerance) REFERENCES Intolerance(idIntolerance)
);

-- Partie Violette

PROMPT "Création des tables de la partie violette du MCD"

CREATE TABLE Modele(
   idModele NUMBER(10, 0),
   nomModele VARCHAR2(100) NOT NULL,
   PRIMARY KEY(idModele)
);

CREATE TABLE Machine(
   idMachine NUMBER(10, 0),
   nomMachine VARCHAR2(100) NOT NULL,
   idModele NUMBER(10, 0) NOT NULL,
   PRIMARY KEY(idMachine),
   FOREIGN KEY(idModele) REFERENCES Modele(idModele)
);

CREATE TABLE Type_(
   nomType VARCHAR2(100),
   PRIMARY KEY(nomType)
);

CREATE TABLE Entretient(
   typeEntretient VARCHAR2(75),
   PRIMARY KEY(typeEntretient)
);

CREATE TABLE DateDeb(
   dateDeb DATE,
   PRIMARY KEY(dateDeb)
);

CREATE TABLE Certificat(
   idCertificat NUMBER(10, 0),
   numero NUMBER(10, 0) NOT NULL,
   refOrganisme NUMBER(10, 0) NOT NULL,
   codeMembre NUMBER(10, 0) NOT NULL,
   PRIMARY KEY(idCertificat),
   FOREIGN KEY(numero, refOrganisme, codeMembre) REFERENCES Tenrac(numero, refOrganisme, codeMembre)
);

-- Partie Association

PROMPT "Création des tables de la partie association du MCD"

CREATE TABLE Rejoint(
   numero NUMBER(10, 0),
   refOrganisme NUMBER(10, 0),
   codeMembre NUMBER(10, 0),
   idGroupe NUMBER(10, 0),
   PRIMARY KEY(numero, refOrganisme, codeMembre, idGroupe),
   FOREIGN KEY(numero, refOrganisme, codeMembre) REFERENCES Tenrac(numero, refOrganisme, codeMembre),
   FOREIGN KEY(idGroupe) REFERENCES Groupe(idGroupe)
);

CREATE TABLE Deguste(
   adresse VARCHAR2(150),
   date_ DATE,
   idGroupe NUMBER(10, 0),
   idRepas NUMBER(10, 0),
   PRIMARY KEY(adresse, date_, idGroupe, idRepas),
   FOREIGN KEY(adresse) REFERENCES Partenaire(adresse),
   FOREIGN KEY(date_) REFERENCES Date_(date_),
   FOREIGN KEY(idGroupe) REFERENCES Groupe(idGroupe),
   FOREIGN KEY(idRepas) REFERENCES Repas(idRepas)
);

CREATE TABLE Compose(
   idRepas NUMBER(10, 0),
   idPlat NUMBER(10, 0),
   PRIMARY KEY(idRepas, idPlat),
   FOREIGN KEY(idRepas) REFERENCES Repas(idRepas),
   FOREIGN KEY(idPlat) REFERENCES Plat(idPlat)
);

CREATE TABLE Accompagne(
   idPlat NUMBER(10, 0),
   idSauce NUMBER(10, 0),
   PRIMARY KEY(idPlat, idSauce),
   FOREIGN KEY(idPlat) REFERENCES Plat(idPlat),
   FOREIGN KEY(idSauce) REFERENCES Sauce(idSauce)
);

CREATE TABLE Forme(
   idSauce NUMBER(10, 0),
   idIngredient NUMBER(10, 0),
   PRIMARY KEY(idSauce, idIngredient),
   FOREIGN KEY(idSauce) REFERENCES Sauce(idSauce),
   FOREIGN KEY(idIngredient) REFERENCES Ingredient(idIngredient)
);

CREATE TABLE Elabore(
   nomAliment VARCHAR2(75),
   idIngredient NUMBER(10, 0),
   PRIMARY KEY(nomAliment, idIngredient),
   FOREIGN KEY(nomAliment) REFERENCES Aliment(nomAliment),
   FOREIGN KEY(idIngredient) REFERENCES Ingredient(idIngredient)
);

CREATE TABLE Constitue(
   idPlat NUMBER(10, 0),
   nomAliment VARCHAR2(75),
   PRIMARY KEY(idPlat, nomAliment),
   FOREIGN KEY(idPlat) REFERENCES Plat(idPlat),
   FOREIGN KEY(nomAliment) REFERENCES Aliment(nomAliment)
);

CREATE TABLE Provoque(
   numero NUMBER(10, 0),
   refOrganisme NUMBER(10, 0),
   codeMembre NUMBER(10, 0),
   nomAliment VARCHAR2(75),
   idIntolerance NUMBER(10, 0),
   PRIMARY KEY(numero, refOrganisme, codeMembre, nomAliment, idIntolerance),
   FOREIGN KEY(numero, refOrganisme, codeMembre) REFERENCES Tenrac(numero, refOrganisme, codeMembre),
   FOREIGN KEY(nomAliment) REFERENCES Legume(nomAliment),
   FOREIGN KEY(idIntolerance) REFERENCES Intolerance(idIntolerance)
);

CREATE TABLE UtilisationOfficielle(
   idRepas NUMBER(10, 0),
   idMachine NUMBER(10, 0),
   PRIMARY KEY(idRepas, idMachine),
   FOREIGN KEY(idRepas) REFERENCES Repas(idRepas),
   FOREIGN KEY(idMachine) REFERENCES Machine(idMachine)
);

CREATE TABLE Possede(
   idMachine NUMBER(10, 0),
   idCertificat NUMBER(10, 0),
   PRIMARY KEY(idMachine, idCertificat),
   FOREIGN KEY(idMachine) REFERENCES Machine(idMachine),
   FOREIGN KEY(idCertificat) REFERENCES Certificat(idCertificat)
);

CREATE TABLE Correspond(
   idModele NUMBER(10, 0),
   nomType VARCHAR2(100),
   PRIMARY KEY(idModele, nomType),
   FOREIGN KEY(idModele) REFERENCES Modele(idModele),
   FOREIGN KEY(nomType) REFERENCES Type_(nomType)
);

CREATE TABLE Definit(
   nomType VARCHAR2(100),
   typeEntretient VARCHAR2(75),
   PRIMARY KEY(nomType, typeEntretient),
   FOREIGN KEY(nomType) REFERENCES Type_(nomType),
   FOREIGN KEY(typeEntretient) REFERENCES Entretient(typeEntretient)
);

CREATE TABLE Repare(
   idMachine NUMBER(10, 0),
   typeEntretient VARCHAR2(75),
   dateDeb DATE,
   dateFin DATE,
   PRIMARY KEY(idMachine, typeEntretient, dateDeb),
   FOREIGN KEY(idMachine) REFERENCES Machine(idMachine),
   FOREIGN KEY(typeEntretient) REFERENCES Entretient(typeEntretient),
   FOREIGN KEY(dateDeb) REFERENCES dateDeb(dateDeb)
);

CREATE TABLE Enregistre1(
   numero NUMBER(10, 0),
   idCertificat NUMBER(10, 0),
   PRIMARY KEY(numero, idCertificat),
   FOREIGN KEY(numero) REFERENCES Club(numero),
   FOREIGN KEY(idCertificat) REFERENCES Certificat(idCertificat)
);

CREATE TABLE Enregistre2(
   numero NUMBER(10, 0),
   idCertificat NUMBER(10, 0),
   PRIMARY KEY(numero, idCertificat),
   FOREIGN KEY(numero) REFERENCES Ordre(numero),
   FOREIGN KEY(idCertificat) REFERENCES Certificat(idCertificat)
);

-- Partie Trigger

CREATE OR REPLACE TRIGGER trg_insert_gradesup
BEFORE INSERT OR UPDATE ON GradeSuperieur
FOR EACH ROW
DECLARE
  v_grade_tenrac Tenrac.nomGrade%TYPE;
BEGIN
  BEGIN
    SELECT nomGrade 
    INTO v_grade_tenrac
    FROM Tenrac
    WHERE numero = :NEW.numero 
      AND refOrganisme = :NEW.refOrganisme 
      AND codeMembre = :NEW.codeMembre;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20001, 'Erreur : Ce membre n''existe pas dans Tenrac.');
  END;

  IF TRIM(v_grade_tenrac) NOT IN ('Chevalier', 'Dame', 'Grand Chevalier', 'Haute Dame', 'Commandeur', 'Grand''Croix') THEN
    RAISE_APPLICATION_ERROR(-20002, 'Le grade actuel du membre (' || v_grade_tenrac || ') est insuffisant pour présider une réunion.');
  END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_insert_utilisationofficielle
BEFORE INSERT OR UPDATE ON UtilisationOfficielle
FOR EACH ROW
DECLARE
  v_estcertif Machine.idMachine%TYPE;
BEGIN
  BEGIN
    SELECT idMachine
    INTO v_estcertif
    FROM Machine
    WHERE idMachine = :NEW.idMachine;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20003, 'Erreur : La machine ' || :NEW.idMachine || ' n''existe pas dans Machine.');
  END;
  
  BEGIN
    SELECT idMachine
    INTO v_estcertif
    FROM Possede
    WHERE idMachine = :NEW.idMachine;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20004, 'Erreur : La machine ' || :NEW.idMachine || ' n''existe pas dans Possede.');
  END;
END;
/

CREATE OR REPLACE TRIGGER trg_insert_certif
BEFORE INSERT OR UPDATE ON Certificat
FOR EACH ROW
DECLARE 
  v_dignite_tenrac Tenrac.dignite%TYPE;
BEGIN
  BEGIN
    SELECT dignite 
    INTO v_dignite_tenrac
    FROM Tenrac
    WHERE numero = :NEW.numero 
      AND refOrganisme = :NEW.refOrganisme 
      AND codeMembre = :NEW.codeMembre;
  
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20005, 'Erreur : Ce membre n''existe pas dans Tenrac.');
  END;

  IF TRIM(v_dignite_tenrac) IS NULL THEN
    RAISE_APPLICATION_ERROR(-20006, 'Le membre ne possède pas de dignité.');
  END IF;
END;
/

PROMPT "Fin de la création de la base de données Tenrac";