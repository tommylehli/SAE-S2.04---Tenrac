#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Type.csv");
	const unsigned numberOfType = 15;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> type = dictionaryOpener("../dictionnaires/types.txt");

	std::string dataAttribute1;

	std::string tuple;

	for(unsigned i (0); i < numberOfType; ++i){
		dataAttribute1 = stringGenerator(type);

		tuple = dataAttribute1 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}