#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Provoque.csv");
	const unsigned numberOfProvoque = 100000;
	const unsigned numberOfIntolerance = 35;
	const unsigned numberOfLegume = 80;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> numero = dictionaryOpener("../fichiers-temporaires/numeroTenracTemp.txt");
	std::vector<std::string> refOrganisme = dictionaryOpener("../fichiers-temporaires/refOrganismeTenracTemp.txt");
	std::vector<std::string> codeMembre = dictionaryOpener("../fichiers-temporaires/codeMembreTenracTemp.txt");
	std::vector<std::string> nomLegume = dictionaryOpener("../fichiers-temporaires/nomAlimentLegumeTemp.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	std::string dataAttribute3;
	std::string dataAttribute4;
	std::string dataAttribute5;
	unsigned num;
	
	std::string tuple;

	const unsigned numberOfTenracs = codeMembre.size();

	for(unsigned i (0); i < numberOfProvoque; ++i){
		num = rand() % numberOfTenracs;
		dataAttribute1 = numero[num];
		dataAttribute2 = refOrganisme[num];
		dataAttribute3 = codeMembre[num];
		dataAttribute4 = nomLegume[rand() % numberOfLegume];
		dataAttribute5 = std::to_string(rand() % numberOfIntolerance);


		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + ";"
				+ dataAttribute3 + ";"
				+ dataAttribute4 + ";"
				+ dataAttribute5 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}