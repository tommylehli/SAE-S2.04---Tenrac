#ifndef UTILITAIRES_H
#define UTILITAIRES_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <ctime>

std::vector<std::string> dictionaryOpener(const std::string dictionaryName);
unsigned positiveIntegerGenerator(const unsigned min, const unsigned max);
std::string stringGenerator(const std::vector<std::string> & dictionary);
std::string dateGenerator();
std::string phoneNumberGenerator();
std::string mailGenerator(const std::string & firstname, const std::string & lastname, const std::vector<std::string> & dictionary);
std::string addressGenerator(const std::vector<std::string> & locality, const std::vector<std::string> & city);
std::string SIRETGenerator();

#endif