#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Partenaire.csv");
	const unsigned numberOfPartenaires = 100;
	const unsigned numberOfOrdres = 500;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> locality = dictionaryOpener("../dictionnaires/lieux-dits.txt");
	std::vector<std::string> city = dictionaryOpener("../dictionnaires/villes.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	
	std::string tuple;

	for(unsigned i (0); i < numberOfPartenaires; ++i){
		dataAttribute1 = addressGenerator(locality, city);
		dataAttribute2 = std::to_string(rand() % numberOfOrdres);

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}