#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Organisation.csv");
	const unsigned numberOfOrganisations = 10000;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> locality = dictionaryOpener("../dictionnaires/lieux-dits.txt");
	std::vector<std::string> city = dictionaryOpener("../dictionnaires/villes.txt");

	unsigned dataAttribute1;
	std::string dataAttribute2;
	
	std::string tuple;

	for(unsigned i (0); i < numberOfOrganisations; ++i){
		dataAttribute1 = i;
		dataAttribute2 = addressGenerator(locality, city);

		tuple = std::to_string(dataAttribute1) + ";"
				+ dataAttribute2 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}