#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Ordre.csv");
	const unsigned numberOfOrdres = 500;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> name = dictionaryOpener("../Dictionnaires/noms-club.txt");

	unsigned dataAttribute1;
	std::string dataAttribute2;
	
	std::string tuple;

	for(unsigned i (0); i < numberOfOrdres; ++i){
		dataAttribute1 = i;
		dataAttribute2 = stringGenerator(name);

		tuple = std::to_string(dataAttribute1) + ";"
				+ dataAttribute2 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}