#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Correspond.csv");
	const unsigned numberOfCorrespond = 60;
	const unsigned numberOfModele = 30;
	const unsigned numberOfType = 15;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::string dataAttribute1;
	std::string dataAttribute2;

	std::string tuple;

	for(unsigned i (0); i < numberOfCorrespond; ++i){
		dataAttribute1 = std::to_string(rand() % numberOfModele);
		dataAttribute2 = std::to_string(rand() % numberOfType);

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}