#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Croyance.csv");
	const unsigned numberOfCroyance = 5;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> croyance = dictionaryOpener("../Dictionnaires/croyance.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	
	std::string tuple;

	for(unsigned i (0); i < numberOfCroyance; ++i){
		dataAttribute1 = std::to_string(i+10);
		dataAttribute2 = croyance[i];

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}