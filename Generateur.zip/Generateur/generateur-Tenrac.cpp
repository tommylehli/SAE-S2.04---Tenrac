#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Tenrac.csv");
	const unsigned numberOfTenracs = 1000000;
	const unsigned numberOfOrganimes = 1000;
	const unsigned numberOfOrganisations = 10000;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> firstname = dictionaryOpener("../dictionnaires/prenoms.txt");
	std::vector<std::string> lastname = dictionaryOpener("../dictionnaires/noms.txt");
	std::vector<std::string> locality = dictionaryOpener("../dictionnaires/lieux-dits.txt");
	std::vector<std::string> city = dictionaryOpener("../dictionnaires/villes.txt");
	std::vector<std::string> domainName = dictionaryOpener("../dictionnaires/noms-de-domaine.txt");
	std::vector<std::string> grade = dictionaryOpener("../dictionnaires/grades.txt");
	std::vector<std::string> rang = dictionaryOpener("../dictionnaires/rangs.txt");
	std::vector<std::string> titre = dictionaryOpener("../dictionnaires/titres.txt");
	std::vector<std::string> dignite = dictionaryOpener("../dictionnaires/dignites.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	unsigned dataAttribute3;
	std::string dataAttribute4;
	std::string dataAttribute5;
	std::string dataAttribute6;
	std::string dataAttribute7;
	std::string dataAttribute8;
	std::string dataAttribute9;
	std::string dataAttribute10;
	std::string dataAttribute11;
	std::string dataAttribute12;
	
	std::string tuple;

	for(unsigned i (0); i < numberOfTenracs; ++i){
		dataAttribute1 = std::to_string(rand() % numberOfOrganisations);
		dataAttribute2 = std::to_string(rand() % numberOfOrganimes);
		dataAttribute3 = i;
		dataAttribute4 = stringGenerator(lastname);
		dataAttribute5 = stringGenerator(firstname);
		dataAttribute6 = mailGenerator(dataAttribute4, dataAttribute5, domainName);
		dataAttribute7 = phoneNumberGenerator();
		dataAttribute8 = addressGenerator(locality, city);
		dataAttribute9 = stringGenerator(grade);
		dataAttribute10 = stringGenerator(dignite);
		dataAttribute11 = stringGenerator(titre);
		dataAttribute12 = stringGenerator(rang);


		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + ";"
				+ std::to_string(dataAttribute3) + ";"
				+ dataAttribute4 + ";"
				+ dataAttribute5 + ";"
				+ dataAttribute6 + ";"
				+ dataAttribute7 + ";"
				+ dataAttribute8 + ";"
				+ dataAttribute9 + ";"
				+ dataAttribute10 + ";"
				+ dataAttribute11 + ";"
				+ dataAttribute12 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}