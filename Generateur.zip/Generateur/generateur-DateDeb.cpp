#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/DateDeb.csv");
	const unsigned numberOfDate = 100;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::string dataAttribute1;
	
	std::string tuple;

	for(unsigned i (0); i < numberOfDate; ++i){
		dataAttribute1 = dateGenerator();

		tuple = dataAttribute1 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}