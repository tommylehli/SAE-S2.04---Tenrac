#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Entretient.csv");
	const unsigned numberOftypeEntretient = 10;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> type = dictionaryOpener("../dictionnaires/typesEntretient.txt");

	std::string dataAttribute1;

	std::string tuple;

	for(unsigned i (0); i < numberOftypeEntretient; ++i){
		dataAttribute1 = stringGenerator(type);

		tuple = dataAttribute1 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}