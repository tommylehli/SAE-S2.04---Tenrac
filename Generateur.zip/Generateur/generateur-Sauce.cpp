#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Sauce.csv");
	const unsigned numberOfSauce = 20;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> sauces = dictionaryOpener("../Dictionnaires/sauce.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	
	std::string tuple;

	for(unsigned i (0); i < numberOfSauce; ++i){
		dataAttribute1 = std::to_string(i);
		dataAttribute2 = sauces[i];

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}