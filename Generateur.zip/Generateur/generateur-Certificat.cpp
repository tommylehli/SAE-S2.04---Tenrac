#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Certificat.csv");
	const unsigned numberOfCertificat = 250;
	const unsigned numberOfTenrac = 1000000;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> numero = dictionaryOpener("../fichiers-temporaires/numeroCertificatTemp.txt");
	std::vector<std::string> refOrganisme = dictionaryOpener("../fichiers-temporaires/refOrganismeCertificatTemp.txt");
	std::vector<std::string> codeMembre = dictionaryOpener("../fichiers-temporaires/codeMembreCertificatTemp.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	std::string dataAttribute3;
	std::string dataAttribute4;
	unsigned num;

	std::string tuple;

	for(unsigned i (0); i < numberOfCertificat; ++i){
		num = rand() % numberOfTenrac;
		dataAttribute1 = std::to_string(i);
		dataAttribute2 = numero[num];
		dataAttribute3 = refOrganisme[num];
		dataAttribute4 = codeMembre[num];

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + ";"
				+ dataAttribute3 + ";"
				+ dataAttribute4 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}