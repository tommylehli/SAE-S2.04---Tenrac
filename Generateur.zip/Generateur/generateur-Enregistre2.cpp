#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Enregistre2.csv");
	const unsigned numberOfEnregistre = 75;
	const unsigned numberOfOrdre = 500;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> numero = dictionaryOpener("../fichiers-temporaires/numeroOrdreTemp.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	
	std::string tuple;

	for(unsigned i (175); i < 175 + numberOfEnregistre; ++i){
		dataAttribute1 = numero[rand() % numberOfOrdre];
		dataAttribute2 = std::to_string(i);

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}