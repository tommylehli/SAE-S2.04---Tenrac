#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/GradeSuperieur.csv");

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> numero = dictionaryOpener("../fichiers-temporaires/numeroTenracSupTemp.txt");
	std::vector<std::string> refOrganisme = dictionaryOpener("../fichiers-temporaires/refOrganismeTenracSupTemp.txt");
	std::vector<std::string> codeMembre = dictionaryOpener("../fichiers-temporaires/codeMembreTenracSupTemp.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	std::string dataAttribute3;

	std::string tuple;

	const unsigned numberOfGradeSup = codeMembre.size();

	for(unsigned i (0); i < numberOfGradeSup; ++i){
		dataAttribute1 = numero[i];
		dataAttribute2 = refOrganisme[i];
		dataAttribute3 = codeMembre[i];

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + ";"
				+ dataAttribute3 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}