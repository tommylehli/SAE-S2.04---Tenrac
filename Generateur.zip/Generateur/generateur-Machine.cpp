#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Machine.csv");
	const unsigned numberOfMachine = 250;
	const unsigned numberOfModele = 30;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> machine = dictionaryOpener("../dictionnaires/machine.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	std::string dataAttribute3;

	std::string tuple;

	for(unsigned i (0); i < numberOfMachine; ++i){
		dataAttribute1 = std::to_string(i);
		dataAttribute2 = stringGenerator(machine);
		dataAttribute3 = std::to_string(rand() % numberOfModele);

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + ";"
				+ dataAttribute3 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}