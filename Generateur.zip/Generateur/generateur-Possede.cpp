#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Possede.csv");
	const unsigned numberOfPossede = 4500;
	const unsigned numberOfMachine = 250;
	const unsigned numberOfCertificat = 250;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::string dataAttribute1;
	std::string dataAttribute2;

	std::string tuple;

	for(unsigned i (0); i < numberOfPossede; ++i){
		dataAttribute1 = std::to_string(rand() % numberOfMachine);
		dataAttribute2 = std::to_string(rand() % numberOfCertificat);

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}