#include "utilitaires.h"

// Renvoie un tableau contenant chaque ligne d'un fichier
std::vector<std::string> dictionaryOpener(const std::string dictionaryName){
	std::ifstream dictionary;
	dictionary.open(dictionaryName);

	std::vector<std::string> words;
	std::string line;

	while(std::getline(dictionary, line)){
		words.push_back(line);
	}

	dictionary.close();
	return words;
}

// Genere un entier positif
unsigned positiveIntegerGenerator(const unsigned min, const unsigned max){
	return ((rand() % (max - min + 1)) + min);
}

// Genere une chaine de caractere en fonction d'un dictionnaire
std::string stringGenerator(const std::vector<std::string> & dictionary){
	return dictionary[rand() % dictionary.size()];
}

// Genere une date entre le 01.01.2000 et le 31.12.2026
std::string dateGenerator(){
	std::string date = "";
	
	const unsigned daysPerMonth[] = {31,28,31,30,31,30,31,31,30,31,30,31};

	std::string year = std::to_string(rand() % (2026 - 2000) + 2001);
	unsigned intMonth = rand() % 12 + 1;
	std::string month = (intMonth < 10 ? "0" + std::to_string(intMonth) : std::to_string(intMonth));
	unsigned intDay = rand() % daysPerMonth[intMonth - 1] + 1;
	std::string day = (intDay < 10 ? "0" + std::to_string(intDay) : std::to_string(intDay));

	date = year + "-" + month + "-" + day;

	return date;
}

// Genere un numero de telephone commencant par 06 ou 07
std::string phoneNumberGenerator(){
	unsigned tempNumber;
	std::string number = "";

	number += (rand() % 2 == 0 ? "06" : "07");
	for(unsigned i (0); i < 5; ++i){
		tempNumber = (rand() % 100);
		number += (tempNumber < 10 ? "-0" + std::to_string(tempNumber) : "-" + std::to_string(tempNumber));
	}

	return number;
}

// Genere un eMail en fonction du prenom et du nom du proprietaire
std::string mailGenerator(const std::string & firstname, const std::string & lastname, const std::vector<std::string> & dictionary){
	return (firstname + "." + lastname + "@" + dictionary[rand() % dictionary.size()]);
}

/*
	Genere une adresse contenant :
		- le numero
		- 1/4 que le numero soit accompagne de "bis"
		- le lieu-dit en fonction d'un dictionnaire
		- la ville (contenant le code postal et le nom) en fonction d'un dictionnaire
*/
std::string addressGenerator(const std::vector<std::string> & locality, const std::vector<std::string> & city){
	std::string bis = (rand() % 4 == 0 ? "bis" : "");
	unsigned number = rand() % 1000;
	return (std::to_string(number) + bis + " " + locality[rand() % locality.size()] + ", " + city[rand() % city.size()]);
}

std::string SIRETGenerator(){
	std::string SIRET = "";
	for (unsigned i (0); i < 14; ++i){
		SIRET += std::to_string(rand() % 10);
	}
	return SIRET;
}