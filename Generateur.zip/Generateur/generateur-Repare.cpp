#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Repare.csv");
	const unsigned numberOfReparation = 125;
	const unsigned numberOfMachine = 250;
	const unsigned numberOfDateDeb = 100;
	const unsigned numberOfTypeEntretient = 10;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> dateDeb = dictionaryOpener("../fichiers-temporaires/dateDebTemp.txt");
	std::vector<std::string> type = dictionaryOpener("../Dictionnaires/typesEntretient.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	std::string dataAttribute3;
	std::string dataAttribute4;

	std::string tuple;

	for(unsigned i (0); i < numberOfReparation; ++i){
		dataAttribute1 = std::to_string(rand() % numberOfMachine);
		dataAttribute2 = stringGenerator(type);
		dataAttribute3 = stringGenerator(dateDeb);
		dataAttribute4 = dateGenerator();

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + ";"
				+ dataAttribute3 + ";"
				+ dataAttribute4 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}