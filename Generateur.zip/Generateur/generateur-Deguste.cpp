#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Deguste.csv");
	const unsigned numberOfDeguste = 60000;
	const unsigned numberOfGroupes = 10000;
	const unsigned numberOfPartenaires = 100;
	const unsigned numberOfDates = 600;
	const unsigned numberOfRepas = 50;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> dates = dictionaryOpener("../fichiers-temporaires/dateTemp.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;
	std::string dataAttribute3;
	std::string dataAttribute4;
	
	std::string tuple;

	for(unsigned i (0); i < numberOfDeguste; ++i){
		dataAttribute1 = std::to_string(rand() % numberOfPartenaires);
		dataAttribute2 = dates[rand() % numberOfDates];
		dataAttribute3 = std::to_string(rand() % numberOfGroupes);
		dataAttribute4 = std::to_string(rand() % numberOfRepas);


		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + ";"
				+ dataAttribute3 + ";"
				+ dataAttribute4 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}