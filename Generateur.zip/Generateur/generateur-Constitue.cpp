#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Constitue.csv");
	const unsigned numberOfConstitue = 650;
	const unsigned numberOfAliment = 320;
	const unsigned numberOfPlat = 100;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> nomAliments = dictionaryOpener("../Dictionnaires/aliment.txt");

	std::string dataAttribute1;
	std::string dataAttribute2;

	std::string tuple;

	for(unsigned i (0); i < numberOfConstitue; ++i){
		dataAttribute1 = std::to_string(rand() % numberOfPlat);
		dataAttribute2 = nomAliments[rand() % numberOfAliment];

		tuple = dataAttribute1 + ";"
				+ dataAttribute2 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}