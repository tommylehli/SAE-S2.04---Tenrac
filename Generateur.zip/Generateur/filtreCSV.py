import pandas as pd

# Charger le fichier (adapter le chemin)
df = pd.read_csv("../csv/Legume.csv", sep=";", usecols=["nomAliment"])

# Supprimer les valeurs vides
df = df.dropna()

# Supprimer les doublons
df = df.drop_duplicates()

# Limiter à 1 000 000 lignes
#df = df.head(1000000)

# Sauvegarder
df.to_csv("../fichiers-temporaires/nomAlimentLegumeTemp.txt", index=False, header=False)