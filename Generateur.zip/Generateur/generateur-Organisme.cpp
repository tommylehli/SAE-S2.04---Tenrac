#include "utilitaires.h"

int main(const int argc, const char *argv[]){
	srand(time(nullptr));
	if (argc < 2) return 1;

	std::ofstream file("../csv/Organisme.csv");
	const unsigned numberOfrefOrganisme = 1000;

	std::string header = "";
	for(unsigned i (1); i < argc-1; ++i){
		header += argv[i];
		header += ";";
	}
	header += argv[argc-1];
	header += "\n";

	file << header;

	std::vector<std::string> organame = dictionaryOpener("../Dictionnaires/noms-organismes.txt");
	std::vector<std::string> orgatype = dictionaryOpener("../Dictionnaires/types-organisme.txt");
	std::vector<std::string> raisonsociale = dictionaryOpener("../Dictionnaires/raison-sociale.txt");

	unsigned dataAttribute1;
	std::string dataAttribute2;
	std::string dataAttribute3;
	std::string dataAttribute4;
	std::string dataAttribute5;
	
	std::string tuple;

	for(unsigned i (0); i < numberOfrefOrganisme; ++i){
		dataAttribute1 = i;
		dataAttribute2 = organame[i];
		dataAttribute3 = stringGenerator(orgatype);
		dataAttribute4 = stringGenerator(raisonsociale);
		dataAttribute5 = SIRETGenerator();

		tuple = std::to_string(dataAttribute1) + ";"
				+ dataAttribute2 + ";"
				+ dataAttribute3 + ";"
				+ dataAttribute4 + ";"
				+ dataAttribute5 + "\n";

		file << tuple;
	}

	file.close();
	return 0;
}